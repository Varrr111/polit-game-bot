"""
Баннеры гайда (!guide): шапка «Гайд игрока» с маршрутом из 4 глав + полоса на каждую главу.
Стиль родственный баннерам механик (тот же арт, шрифт, свечения), но зеркальный и «путевой»:
арт слева, текст справа, внизу — маршрут игрока; у главы — медальон с номером и мини-маршрут.

    ./.venv/bin/python scripts/gen_guide_banners.py
→ assets/brand/guide_hero.png, assets/brand/guide_ch_<n>.png
"""

import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageOps

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
import gen_mech_banners as M  # noqa: E402  — общие кисти: шрифт, свечения, тени, маски
from cogs.guide import CHAPTERS  # noqa: E402

BRAND, UI = M.BRAND, M.UI
INK, DIM, CYAN = M.INK, M.DIM, M.CYAN


def _art_mirror(h, crop):
    """Арт Nova Order без логотипа, отзеркаленный (планета смотрит вправо, к тексту)."""
    art = Image.open(BRAND / "nova_avatar.jpg").convert("RGB")
    aw, ah = art.size
    band = art.crop((int(aw * crop[0]), int(ah * crop[1]), int(aw * crop[2]), int(ah * crop[3])))
    band = ImageOps.mirror(band)
    return band.resize((int(band.width * h / band.height), h), Image.LANCZOS)


def _base_left(w, h, band, tone_k, tint=None, tint_k=0.0, fade=(0.80, 1.0)):
    """Арт прижат к ЛЕВОМУ краю и тает вправо."""
    tone = band.resize((1, 1)).getpixel((0, 0))
    img = Image.new("RGB", (w, h), tuple(int(c * tone_k) for c in tone))
    if tint:
        band = Image.blend(band, Image.new("RGB", band.size, tint), tint_k)
    keep = 1.0 - M._hfade(band.width, *fade)
    img.paste(band, (0, 0), M._mask(keep, h))
    return img


def _shade_right(img, start, alpha, rgb=(6, 10, 18)):
    """Тёмная вуаль справа — под текст."""
    w, h = img.size
    x = np.linspace(0, 1, w)
    a = np.clip((x - start) / (1 - start), 0, 1) ** 0.9 * alpha / 255
    over = Image.new("RGBA", (w, h), (*rgb, 0))
    over.putalpha(M._mask(a, h))
    out = img.convert("RGBA")
    out.alpha_composite(over)
    return out


def _accent_line_r(img, rgb, y, thick):
    """Линия-акцент, яркая справа и тающая влево."""
    w, _ = img.size
    line = Image.new("RGBA", (w, thick), (*rgb, 0))
    line.putalpha(M._mask(np.clip((np.linspace(0, 1, w) - 0.15) / 0.85, 0, 1) ** 1.2, thick))
    img.alpha_composite(line, (0, y))


def _glow_line(img, p0, p1, rgb, width=4, blur=8, alpha=200):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(lay).line([p0, p1], fill=(*rgb, alpha), width=width * 3)
    img.alpha_composite(lay.filter(ImageFilter.GaussianBlur(blur)))
    ImageDraw.Draw(img).line([p0, p1], fill=(*rgb, 255), width=width)


def _glyph(icon: str, size: int, rgb, alpha: float = 1.0) -> Image.Image:
    """Только светлый глиф иконки (без тёмного тайла и его рамки), перекрашенный в rgb."""
    ic = Image.open(UI / f"ui_{icon}.png").convert("RGBA")
    # глиф занимает центр тайла (80/128) — обрезаем рамку тайла целиком
    m = int(ic.width * 0.17)
    ic = ic.crop((m, m, ic.width - m, ic.height - m)).resize((size, size), Image.LANCZOS)
    lum = np.array(ic.convert("RGB")).astype(np.float32).mean(axis=2)
    a = np.array(ic.getchannel("A")).astype(np.float32) / 255
    mask = np.clip((lum - 60) / 70, 0, 1) * a * alpha
    out = Image.new("RGBA", (size, size), (*rgb, 0))
    out.putalpha(Image.fromarray((mask * 255).astype(np.uint8)))
    return out


def _node(img, center, r, rgb, active: bool, icon: str | None = None, label: str | None = None):
    """Узел маршрута: кольцо с иконкой (активный — со свечением и заливкой)."""
    cx, cy = center
    if active:
        g = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(g).ellipse([cx - r - 14, cy - r - 14, cx + r + 14, cy + r + 14], fill=(*rgb, 150))
        img.alpha_composite(g.filter(ImageFilter.GaussianBlur(18)))
    d = ImageDraw.Draw(img)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(10, 18, 32, 255), outline=(*rgb, 255), width=4 if active else 3)
    if icon:
        size = int(r * 1.2)
        img.alpha_composite(_glyph(icon, size, rgb, 1.0 if active else 0.55), (cx - size // 2, cy - size // 2))
    if label:
        f = M._av(22, 2)
        tw = d.textlength(label, font=f)
        d.text((cx - tw / 2, cy + r + 14), label, font=f, fill=INK if active else DIM)


def hero():
    w, h = 1600, 600
    # арт меньше высоты баннера: планета ровно по центру, низ арта (с логотипом) растворяется в космосе
    bh = 470
    band = _art_mirror(bh, (0.15, 0.20, 0.85, 0.63))
    tone = band.resize((1, 1)).getpixel((0, 0))
    base = Image.new("RGB", (w, h), tuple(int(c * 0.6) for c in tone))
    keep_x = 1.0 - M._hfade(band.width, 0.52, 0.86)
    yy = np.linspace(0, 1, bh)
    keep_y = np.clip((1.0 - yy) / 0.34, 0, 1) ** 1.4
    mask = Image.fromarray((np.outer(keep_y, keep_x) * 255).astype(np.uint8), "L")
    planet_cy = 0.67                                              # центр планеты в кадре арта (доля высоты)
    py = int(h / 2 - planet_cy * bh)                              # → центр планеты = центр баннера
    base.paste(band, (0, py), mask)
    img = _shade_right(base, 0.30, 230)
    x0 = 760
    d = ImageDraw.Draw(img)
    M._spaced(d, (x0 + 4, 92), "NOVA ORDER  ·  ОБУЧЕНИЕ", M._av(26, 2), CYAN, 6)
    d.rounded_rectangle([x0 + 4, 138, x0 + 100, 144], radius=3, fill=CYAN)
    M._text_shadow(img, (x0 - 4, 156), "Гайд игрока", M._av(108, 0), INK)
    ImageDraw.Draw(img).text((x0 + 4, 290), "Как начать и во что играть — по шагам", font=M._av(32, 5), fill=DIM)
    # маршрут игрока: 4 главы
    n = len(CHAPTERS)
    xs = [x0 + 60 + i * 230 for i in range(n)]
    cy, r = 440, 44
    for i in range(n - 1):
        c0, c1 = CHAPTERS[i]["color"], CHAPTERS[i + 1]["color"]
        mid = tuple((a + b) // 2 for a, b in zip(c0, c1))
        _glow_line(img, (xs[i] + r + 6, cy), (xs[i + 1] - r - 6, cy), mid, width=3, blur=7, alpha=170)
    for i, ch in enumerate(CHAPTERS):
        _node(img, (xs[i], cy), r, ch["color"], True, ch["icon"], f"{i + 1}. {ch['short']}")
    _accent_line_r(img, CYAN, h - 6, 6)
    img.convert("RGB").save(BRAND / "guide_hero.png", optimize=True)


def chapter(idx: int, ch: dict):
    w, h = 1600, 320
    accent = ch["color"]
    band = _art_mirror(h, (0.28, 0.33, 0.74, 0.64))
    img = _shade_right(_base_left(w, h, band, 0.55, tint=accent, tint_k=0.16, fade=(0.50, 0.92)), 0.17, 220)
    # медальон с номером главы
    cx, cy, r = 190, h // 2, 92
    g = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(g).ellipse([cx - r - 10, cy - r - 10, cx + r + 10, cy + r + 10], fill=(*accent, 120))
    img.alpha_composite(g.filter(ImageFilter.GaussianBlur(26)))
    d = ImageDraw.Draw(img)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(8, 14, 26, 235), outline=(*accent, 255), width=5)
    d.ellipse([cx - r + 14, cy - r + 14, cx + r - 14, cy + r - 14], outline=(*accent, 90), width=2)
    num = str(idx + 1)
    f = M._av(118, 0)
    bx = d.textbbox((0, 0), num, font=f)
    M._text_shadow(img, (cx - (bx[2] - bx[0]) / 2 - bx[0], cy - (bx[3] - bx[1]) / 2 - bx[1]), num, f, INK, blur=6)
    # текст
    x0 = 340
    d = ImageDraw.Draw(img)
    M._spaced(d, (x0, 62), f"ГЛАВА {idx + 1} ИЗ {len(CHAPTERS)}", M._av(24, 2), accent, 6)
    M._text_shadow(img, (x0 - 4, 92), ch["title"], M._av(78, 0), INK, blur=8)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([x0, 200, x0 + 86, 205], radius=3, fill=accent)
    d.text((x0, 220), ch["strip"], font=M._av(27, 5), fill=DIM)
    # мини-маршрут справа: пройдено / текущая / впереди
    n = len(CHAPTERS)
    rx0, ry, rr, step = w - 120 - (n - 1) * 70, 64, 13, 70
    for i in range(n - 1):
        col = accent if i < idx else (70, 88, 112)
        d.line([(rx0 + i * step + rr, ry), (rx0 + (i + 1) * step - rr, ry)], fill=col, width=3)
    for i in range(n):
        cxx = rx0 + i * step
        if i == idx:
            gl = Image.new("RGBA", img.size, (0, 0, 0, 0))
            ImageDraw.Draw(gl).ellipse([cxx - 24, ry - 24, cxx + 24, ry + 24], fill=(*accent, 160))
            img.alpha_composite(gl.filter(ImageFilter.GaussianBlur(10)))
            d = ImageDraw.Draw(img)
            d.ellipse([cxx - rr - 3, ry - rr - 3, cxx + rr + 3, ry + rr + 3], fill=accent)
        elif i < idx:
            d.ellipse([cxx - rr, ry - rr, cxx + rr, ry + rr], fill=(*accent, 255))
        else:
            d.ellipse([cxx - rr, ry - rr, cxx + rr, ry + rr], outline=(90, 110, 138), width=3)
    # иконка главы — крупно и полупрозрачно справа
    size = 170
    img.alpha_composite(_glyph(ch["icon"], size, accent, 0.30), (w - size - 135, h - size - 38))
    M._accent_line(img, accent, h - 5, 5)
    img.convert("RGB").save(BRAND / f"guide_ch_{idx + 1}.png", optimize=True)


if __name__ == "__main__":
    hero()
    for i, c in enumerate(CHAPTERS):
        chapter(i, c)
    print("Готово:", BRAND / "guide_hero.png", "+", len(CHAPTERS), "глав")
