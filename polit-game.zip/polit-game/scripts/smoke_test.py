"""
Офлайн смоук-тест: проверяет фундамент без подключения к Discord.

Запуск:  ./.venv/bin/python scripts/smoke_test.py

Проверяет: импорт всего, DB-слой (CRUD, money-delta, банк, кредиты, компании,
инфраструктуру, новости, кулдауны), чистые хелперы и загрузку когов.
Использует ВРЕМЕННУЮ БД, боевую data/game.db не трогает.
"""

import asyncio
import sys
import tempfile
from pathlib import Path

# корень проекта в sys.path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# временная БД ДО создания менеджеров
import utils.database as database
_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
database.DB_PATH = Path(_tmp.name)

from utils import (
    Countries, Settings, Credits, Companies, Infrastructure, BuildNews, Cooldown,
    int_format, string_to_number, calculate_income, get_object, get_object_by_user,
    update_money, CountryObject, InfrastructureType,
)

ok = 0
fail = 0


def check(label, cond):
    global ok, fail
    if cond:
        ok += 1
        print(f"  ✅ {label}")
    else:
        fail += 1
        print(f"  ❌ {label}")


def test_formatters():
    print("[форматтеры]")
    check("int_format(1234567) == '1.234.567'", int_format(1234567) == "1.234.567")
    check("string_to_number('100') == 100", string_to_number("100") == 100)
    check("string_to_number('5кк') == 5_000_000", string_to_number("5кк") == 5_000_000)
    check("string_to_number('1.000.000') == 1_000_000", string_to_number("1.000.000") == 1_000_000)
    check("string_to_number('все', all_amount=777) == 777", string_to_number("все", all_amount=777) == 777)
    check("string_to_number('50%', all_amount=1000) == 500", string_to_number("50%", all_amount=1000) == 500)
    check("string_to_number('мусор') == 0", string_to_number("мусор") == 0)


def test_participants():
    print("[участники / деньги]")
    c = Countries()
    c.create_object(name="Тестляндия", flag="🏳️", user=123, money=1_000_000,
                    territory=2000, population=50_000_000, continent="Азия",
                    trade_lvl=1, tourism_lvl=0, economy_lvl=2)
    obj = c.get_object("Тестляндия")
    check("create+get участника", isinstance(obj, CountryObject) and obj.money == 1_000_000)
    check("get_object_by_user", get_object_by_user(123) is not None)
    check("get_object по имени", get_object("Тестляндия") is not None)

    # money — это дельта
    update_money("Тестляндия", 500_000)
    check("update_money +500k", c.get_object("Тестляндия").money == 1_500_000)
    c.update_object("Тестляндия", money=-200_000, trade_lvl=3)
    obj = c.get_object("Тестляндия")
    check("update_object money-delta + поле", obj.money == 1_300_000 and obj.trade_lvl == 3)

    stats = c.get_stat_lvls("Тестляндия")
    check("get_stat_lvls", stats == {"trade": 3, "tourism": 0, "economy": 2})

    inc = calculate_income(obj)
    nxt = calculate_income(obj, next_level=True)
    check("calculate_income даёт все статы", set(inc) == {"trade", "tourism", "economy"})
    check("calculate_income next > current (economy)", nxt["economy"] > inc["economy"])


def test_bank():
    print("[банк]")
    s = Settings()
    s.dep_bank("Тестляндия", 1_000_000)
    check("dep_bank", s.get_bank("Тестляндия") == 1_000_000)
    s.with_bank("Тестляндия", 400_000)
    check("with_bank", s.get_bank("Тестляндия") == 600_000)
    s.add_resource("Тестляндия", "нефть", 50)
    s.add_resource("Тестляндия", "нефть", 25)
    check("add_resource накапливает", s.get_resources("Тестляндия").get("нефть") == 75)


def test_credits():
    print("[кредиты]")
    cr = Credits()
    cr.add_credit_offer("Тестляндия", 5_000_000, 24, 10, 1000)
    offers = cr.get_credit_offers()
    check("add/get credit offer", len(offers) == 1 and offers[0].amount == 5_000_000)
    oid = offers[0].id
    check("get_credit_offer по id", cr.get_credit_offer(oid) is not None)
    cr.add_credit_history("A", "B", 1_000_000, 10, 24, 1000, 2000)
    check("get_active_credits", len(cr.get_active_credits()) == 1)
    active = cr.get_active_credits()[0]
    cr.update_credit_status(active.id, "completed")
    check("update_credit_status", len(cr.get_active_credits()) == 0)
    cr.delete_credit_offer(oid)
    check("delete_credit_offer", len(cr.get_credit_offers()) == 0)


def test_companies():
    print("[компании]")
    co = Companies()
    co.create_company("Нефтегаз", "Тестляндия", "Нефтедобыча")
    check("create_company", co.get_company("Тестляндия", "Нефтегаз") is not None)
    check("get_companies", len(co.get_companies("Тестляндия")) == 1)
    check("count_by_specialization", co.get_company_count_by_specialization("Тестляндия", "Нефтедобыча") == 1)
    co.update_company("Тестляндия", "Нефтегаз", "Нефтегаз-2", 3)
    upd = co.get_company("Тестляндия", "Нефтегаз-2")
    check("update_company", upd is not None and upd.level == 3)
    co.delete_company("Тестляндия", "Нефтегаз-2")
    check("delete_company", len(co.get_companies("Тестляндия")) == 0)


def test_infra_news_cooldown():
    print("[инфраструктура / новости / кулдауны]")
    infra = Infrastructure()
    infra.create_infrastructure("Тестляндия", InfrastructureType.CHP.value)
    infra.create_infrastructure("Тестляндия", "chp")
    got = infra.get_infrastructure("Тестляндия")
    check("create_infrastructure x2 (chp=2)", got is not None and got.chp == 2)

    bn = BuildNews()
    bn.update_news("Тестляндия", "festival", 1)
    cnt, last = bn.get_build("Тестляндия", "festival")
    check("build_news update/get", cnt == 1 and last > 0)
    bn.reset_news("Тестляндия", "festival")
    check("build_news reset", bn.get_build("Тестляндия", "festival") == (0, 0))

    cd = Cooldown()
    cd.set_cooldown(InfrastructureType.HPS2.value, 123456.0, "Тестляндия")
    check("cooldown set/get", cd.get_cooldown(InfrastructureType.HPS2.value, "Тестляндия") == 123456.0)


async def test_cogs_load():
    print("[загрузка когов]")
    import disnake
    from disnake.ext import commands
    bot = commands.Bot(command_prefix="!", intents=disnake.Intents.all())
    # В disnake load_extension синхронный.
    bot.load_extension("cogs.items")
    bot.load_extension("cogs.registration")
    bot.load_extension("cogs.economy")
    names = sorted(c.name for c in bot.commands)
    check("economy+items+registration загрузились", "balance" in names and "bank" in names and "register" in names)
    print(f"     команды: {names}")
    await bot.close()


def main():
    print("=== SMOKE TEST ===")
    test_formatters()
    test_participants()
    test_bank()
    test_credits()
    test_companies()
    test_infra_news_cooldown()
    asyncio.run(test_cogs_load())
    print(f"\nИТОГО: ✅ {ok}  ❌ {fail}")
    Path(_tmp.name).unlink(missing_ok=True)
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
