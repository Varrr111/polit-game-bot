#!/usr/bin/env bash
# Чистый архив бота для заливки на хостинг (лимит 100 МБ).
# Внутри одна папка polit-game-bot/ со всеми файлами.
# Исключает то, что хостингу не нужно: локальное окружение, промо-видео,
# превью карты, кэши, локальную базу (у хоста своя — GAME_DB_PATH).
#   bash scripts/make_upload_zip.sh   →   ~/Desktop/polit-game-bot-upload.zip
set -e
cd "$(dirname "$0")/../.."
D="polit-game-bot"
OUT="$HOME/Desktop/polit-game-bot-upload.zip"
rm -f "$OUT"
zip -r -9 -q "$OUT" "$D" \
  -x "$D/.venv/*" "$D/venv/*" "$D/brag-output/*" "$D/videos/*" \
     "$D/assets/map/_preview*" "$D/assets/_svg/*" \
     "*__pycache__*" "*.pyc" "*.DS_Store" "$D/.git/*" \
     "$D/data/*.db" "$D/data/*.db-*"
echo "Готово: $OUT ($(du -h "$OUT" | cut -f1))"
