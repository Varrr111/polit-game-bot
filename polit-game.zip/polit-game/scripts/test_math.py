"""
Тесты «чистой» математики EconomyCog (без подключения к Discord).

Проверяет calculate_bank_income, population_growth, calculate_tax,
calculate_electricity на границах и инвариантах. Использует временную БД.

Запуск:  ./.venv/bin/python scripts/test_math.py
"""

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import utils.database as database
_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
database.DB_PATH = Path(_tmp.name)

from cogs.economy import EconomyCog
from utils import CompanyObject, InfrastructureObject

ok = 0
fail = 0


def check(label, cond):
    global ok, fail
    ok, fail = (ok + 1, fail) if cond else (ok, fail + 1)
    print(f"  {'✅' if cond else '❌'} {label}")


cog = EconomyCog(bot=None)  # init создаёт только менеджеры, бот не нужен


def test_bank_income():
    print("[банк: доход]")
    for bal in (0, 1_000_000, 1_000_000_000, 10_000_000_000_000):
        val = cog.calculate_bank_income(bal)
        check(f"bank_income({bal}) ∈ [0, 1e9], int", isinstance(val, int) and 0 <= val <= 1_000_000_000)
    check("bank_income(0) == 0", cog.calculate_bank_income(0) == 0)
    check("bank_income кап 1e9 на огромном балансе",
          cog.calculate_bank_income(10**18) == 1_000_000_000)


def test_population_growth():
    print("[рост населения]")
    for pop in (0, 1_000_000, 49_000_000, 50_000_000, 2_000_000_000):
        g = cog.population_growth(pop)
        check(f"growth({pop}) ∈ [0, 100000]", 0 <= g <= 100_000)
    gmin = cog.population_growth(1_000_000, get_min=True)
    gmax = cog.population_growth(1_000_000, get_max=True)
    check("growth: min <= max", gmin <= gmax)


def test_tax():
    print("[налоги]")
    check("tax(0) == 0", cog.calculate_tax(0) == 0)
    check("tax(-5) == 0", cog.calculate_tax(-5) == 0)
    check("tax('мусор') == 0", cog.calculate_tax("мусор") == 0)
    for pop in (5_000_000, 50_000_000, 150_000_000, 600_000_000):
        t = cog.calculate_tax(pop)
        check(f"tax({pop}) >= 0", t >= 0)
    check("налог растёт с населением (10M < 200M)",
          cog.calculate_tax(10_000_000) < cog.calculate_tax(200_000_000))


def test_electricity():
    print("[электричество]")
    infra = InfrastructureObject(name="X", chp=2, atomic=1, hps1=0, hps2=0, hps3=0, hps4=0)
    companies = [
        CompanyObject(name="A", country="X", specialization="Нефтедобыча", level=1),
        CompanyObject(name="B", country="X", specialization="Автозавод", level=1),
    ]
    pop_ratio, comp_ratio, balance = cog.calculate_electricity(True, 50_000_000, companies, infra)
    check("pop_ratio ∈ [0,1]", 0.0 <= pop_ratio <= 1.0)
    check("comp_ratio ∈ [0,1]", 0.0 <= comp_ratio <= 1.0)
    check("balance — число", isinstance(balance, (int, float)))

    # нет генерации — ratio должны быть 0 при наличии спроса
    empty = InfrastructureObject(name="Y")
    pr, cr, _ = cog.calculate_electricity(True, 10_000_000, [], empty)
    check("без генерации pop_ratio == 0", pr == 0.0)

    # min/max режимы не падают и дают граничные значения
    _, _, bmin = cog.calculate_electricity(True, 50_000_000, companies, infra, get_min=True)
    _, _, bmax = cog.calculate_electricity(True, 50_000_000, companies, infra, get_max=True)
    check("get_min/get_max работают", isinstance(bmin, (int, float)) and isinstance(bmax, (int, float)))


def test_upgrade_info():
    print("[get_upgrade_info]")
    from utils import CountryObject
    c = CountryObject(name="Z", flag="🏳️", user=1, trade_lvl=0, tourism_lvl=0, economy_lvl=5)
    cur, name, cost = cog.get_upgrade_info(c, "trade")
    check("trade lvl0 -> есть следующий уровень с ценой>0", name != "MAX" and cost > 0)
    cur, name, cost = cog.get_upgrade_info(c, "economy")
    check("economy lvl5 -> MAX", name == "MAX")


def main():
    print("=== MATH TEST ===")
    test_bank_income()
    test_population_growth()
    test_tax()
    test_electricity()
    test_upgrade_info()
    print(f"\nИТОГО: ✅ {ok}  ❌ {fail}")
    Path(_tmp.name).unlink(missing_ok=True)
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
