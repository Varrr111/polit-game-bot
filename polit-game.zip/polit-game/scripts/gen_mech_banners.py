"""
Баннеры меню механик (!mechanics): шапка «Механики мира» + полоса на каждый раздел.
Рисуется локально (Pillow + numpy), в фирменной палитре, с эмблемой проекта.

    ./.venv/bin/python scripts/gen_mech_banners.py
→ assets/brand/mech_hero.png, assets/brand/mech_cat_<ключ>.png
"""

import random
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from utils.mechanics_text import CATEGORIES  # noqa: E402

BRAND = ROOT / "assets" / "brand"
UI = ROOT / "assets" / "ui"
FONT_B = ROOT / "assets" / "map" / "fonts" / "DejaVuSans-Bold.ttf"
FONT_R = ROOT / "assets" / "map" / "fonts" / "DejaVuSans.ttf"
CYAN = (108, 196, 238)
INK = (226, 236, 248)
DIM = (150, 172, 200)


def _font(path, size):
    return ImageFont.truetype(str(path), size)


def _space(w: int, h: int, glow_xy, glow_rgb, seed: int) -> Image.Image:
    """Тёмно-синее «космическое» полотно: градиент + свечение + звёзды."""
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    base = np.zeros((h, w, 3), np.float32)
    base[..., 0], base[..., 1], base[..., 2] = 8, 12, 22
    base += (y / h)[..., None] * np.array([4, 8, 14], np.float32)
    gx, gy = glow_xy
    d = np.sqrt(((x - gx) / w) ** 2 * 2.2 + ((y - gy) / h) ** 2)
    glow = np.clip(1.0 - d * 1.35, 0, 1) ** 2.2
    base += glow[..., None] * np.array(glow_rgb, np.float32) * 0.55
    img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGB")
    rnd = random.Random(seed)
    dr = ImageDraw.Draw(img)
    for _ in range(int(w * h / 2600)):
        sx, sy = rnd.randrange(w), rnd.randrange(h)
        b = rnd.randint(70, 200)
        dr.point((sx, sy), fill=(b, b, min(255, b + 30)))
    return img


def _grid(img: Image.Image, color, alpha: int, step: int = 80):
    over = Image.new("RGBA", img.size, (0, 0, 0, 0))
    dr = ImageDraw.Draw(over)
    w, h = img.size
    for gx in range(0, w, step):
        dr.line([(gx, 0), (gx, h)], fill=(*color, alpha), width=1)
    for gy in range(0, h, step):
        dr.line([(0, gy), (w, gy)], fill=(*color, alpha), width=1)
    img.paste(over, (0, 0), over)


def _frame(img: Image.Image, color):
    dr = ImageDraw.Draw(img)
    w, h = img.size
    dr.rectangle([6, 6, w - 7, h - 7], outline=(*color, ), width=2)
    for cx, cy in ((6, 6), (w - 7, 6), (6, h - 7), (w - 7, h - 7)):   # уголки-«скобы»
        sx = 1 if cx < w / 2 else -1
        sy = 1 if cy < h / 2 else -1
        dr.line([(cx, cy), (cx + 46 * sx, cy)], fill=INK, width=4)
        dr.line([(cx, cy), (cx, cy + 46 * sy)], fill=INK, width=4)


def _spaced(dr, xy, text, font, fill, spacing):
    x, y = xy
    for ch in text:
        dr.text((x, y), ch, font=font, fill=fill)
        x += dr.textlength(ch, font=font) + spacing


def _paste_glow(img, emblem: Image.Image, xy, glow_rgb):
    pad = 70   # запас под размытие, чтобы у свечения не было квадратных краёв
    a = Image.new("L", (emblem.width + 2 * pad, emblem.height + 2 * pad), 0)
    a.paste(emblem.getchannel("A"), (pad, pad))
    glow = Image.new("RGBA", a.size, (*glow_rgb, 0))
    glow.putalpha(a.filter(ImageFilter.GaussianBlur(28)))
    img.paste(glow, (xy[0] - pad, xy[1] - pad), glow)
    img.paste(emblem, xy, emblem)


def _round_mask(size: int) -> Image.Image:
    m = Image.new("L", (size, size), 0)
    ImageDraw.Draw(m).ellipse([0, 0, size - 1, size - 1], fill=255)
    return m


AVENIR = "/System/Library/Fonts/Avenir Next.ttc"   # кириллица: Bold=0, Demi=2, Medium=5


def _av(size, face=0):
    try:
        return ImageFont.truetype(AVENIR, size, index=face)
    except OSError:                                   # не macOS — запасной DejaVu
        return _font(FONT_B if face in (0, 2) else FONT_R, size)


def _art_band(w, h, crop):
    """Арт-аватарка Nova Order, вырезанная полосой и вписанная по высоте."""
    art = Image.open(BRAND / "nova_avatar.jpg").convert("RGB")
    aw, ah = art.size
    band = art.crop((int(aw * crop[0]), int(ah * crop[1]), int(aw * crop[2]), int(ah * crop[3])))
    return band.resize((int(band.width * h / band.height), h), Image.LANCZOS)


def _hfade(width, start, end, power=1.4):
    """Горизонтальная маска 0→1 (start..end — доли ширины)."""
    x = np.linspace(0, 1, width)
    return np.clip((x - start) / max(1e-6, end - start), 0, 1) ** power


def _mask(arr, h):
    return Image.fromarray((np.tile(arr, (h, 1)) * 255).astype(np.uint8), "L")


def _base_with_art(w, h, band, tone_k, tint=None, tint_k=0.0, fade=(0.0, 0.10)):
    tone = band.resize((1, 1)).getpixel((0, 0))
    img = Image.new("RGB", (w, h), tuple(int(c * tone_k) for c in tone))
    if tint:
        band = Image.blend(band, Image.new("RGB", band.size, tint), tint_k)
    x0 = w - band.width
    img.paste(band, (x0, 0), _mask(_hfade(band.width, *fade), h))
    return img


def _shade_left(img, reach, alpha, rgb=(6, 10, 18)):
    w, h = img.size
    over = Image.new("RGBA", (w, h), (*rgb, 0))
    over.putalpha(_mask(np.clip(1.0 - np.linspace(0, 1, w) / reach, 0, 1) ** 1.25 * alpha / 255, h))
    out = img.convert("RGBA"); out.alpha_composite(over)
    return out


def _accent_line(img, rgb, y, thick):
    """Тонкая линия-акцент: яркая слева, тает к правому краю."""
    w, _ = img.size
    line = Image.new("RGBA", (w, thick), (*rgb, 0))
    line.putalpha(_mask(np.clip(1.0 - np.linspace(0, 1, w) / 0.85, 0, 1) ** 1.2, thick))
    img.alpha_composite(line, (0, y))


def _text_shadow(img, xy, text, font, fill, blur=10, alpha=170):
    sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).text((xy[0], xy[1] + 4), text, font=font, fill=(0, 0, 0, alpha))
    img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(blur)))
    ImageDraw.Draw(img).text(xy, text, font=font, fill=fill)


def _soft_glow(img, icon, xy, rgb, radius=34, strength=1.0):
    pad = radius * 3
    a = Image.new("L", (icon.width + 2 * pad, icon.height + 2 * pad), 0)
    a.paste(icon.getchannel("A"), (pad, pad))
    a = a.filter(ImageFilter.GaussianBlur(radius)).point(lambda v: min(255, int(v * strength)))
    g = Image.new("RGBA", a.size, (*rgb, 0)); g.putalpha(a)
    img.alpha_composite(g, (xy[0] - pad, xy[1] - pad))
    img.alpha_composite(icon, xy)


def hero():
    """Шапка: арт Nova Order справа, слева заголовок на тёмном космосе."""
    w, h = 1600, 600
    band = _art_band(w, h, (0.10, 0.30, 1.0, 0.82))
    img = _shade_left(_base_with_art(w, h, band, 0.75, fade=(0.0, 0.09)), 0.62, 185)
    d = ImageDraw.Draw(img)
    _spaced(d, (100, 140), "NOVA ORDER  ·  СПРАВОЧНИК", _av(26, 2), CYAN, 6)
    d.rounded_rectangle([100, 186, 196, 192], radius=3, fill=CYAN)
    _text_shadow(img, (94, 210), "Механики", _av(124, 0), INK)
    _text_shadow(img, (94, 340), "мира", _av(124, 0), INK)
    ImageDraw.Draw(img).text((100, 498), "Как устроена каждая система игры", font=_av(32, 5), fill=DIM)
    _accent_line(img, CYAN, h - 6, 6)
    img.convert("RGB").save(BRAND / "mech_hero.png", optimize=True)


def category(key: str, meta: dict):
    """Полоса раздела: тонированный арт, иконка с мягким свечением, большая римская цифра."""
    w, h = 1600, 320
    accent = meta["color"]
    band = _art_band(w, h, (0.22, 0.34, 0.92, 0.66))
    img = _shade_left(_base_with_art(w, h, band, 0.55, tint=accent, tint_k=0.18, fade=(0.0, 0.25)), 0.75, 215)
    # большая римская цифра справа (полупрозрачная)
    ghost = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gf = _av(210, 0)
    gd = ImageDraw.Draw(ghost)
    bx = gd.textbbox((0, 0), meta["num"], font=gf)          # реальные границы глифов
    gx = w - (bx[2] - bx[0]) - 110 - bx[0]
    gy = (h - (bx[3] - bx[1])) // 2 - bx[1]
    gd.text((gx, gy), meta["num"], font=gf, fill=(*accent, 70))
    img.alpha_composite(ghost)
    # иконка раздела
    tile = 168
    icon = Image.open(UI / f"ui_{meta['icon']}.png").convert("RGBA").resize((tile, tile), Image.LANCZOS)
    _soft_glow(img, icon, (90, (h - tile) // 2), accent, radius=30, strength=0.9)
    x0 = 90 + tile + 52
    d = ImageDraw.Draw(img)
    _spaced(d, (x0, 74), f"РАЗДЕЛ {meta['num']}", _av(24, 2), accent, 6)
    _text_shadow(img, (x0 - 4, 102), meta["title"], _av(80, 0), INK, blur=8)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([x0, 212, x0 + 86, 217], radius=3, fill=accent)
    d.text((x0, 230), meta["strip"], font=_av(28, 5), fill=DIM)
    _accent_line(img, accent, h - 5, 5)
    img.convert("RGB").save(BRAND / f"mech_cat_{key}.png", optimize=True)


if __name__ == "__main__":
    hero()
    for k, m in CATEGORIES.items():
        category(k, m)
    print("Готово:", BRAND / "mech_hero.png", "+", len(CATEGORIES), "полос разделов")
