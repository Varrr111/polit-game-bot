"""
Загрузка иконок ресурсов в бота как application emojis (эмодзи приложения).

Эмодзи принадлежат БОТУ (не серверу), доступны везде. Запускать один раз
(и повторно после изменения иконок — скрипт идемпотентен: существующие
пропускает). Нужен DISCORD_TOKEN в .env.

Запуск:  ./.venv/bin/python scripts/upload_emojis.py
"""

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import disnake
import config
from utils.resources import RESOURCE_SLUG, BUILDING_SLUG, ACTION_SLUG, UI_SLUG
from utils.upgrades import CATEGORY_SLUG
from utils.equipment import EQUIP_SLUG
from utils.politics import POL_SLUG, REL_SLUG

A = ROOT / "assets"
# (slug, путь к png) для всех групп
ALL_ICONS = (
    [(s, A / "resources" / f"{s}.png") for s in RESOURCE_SLUG.values()]
    + [(s, A / "buildings" / f"{s}.png") for s in BUILDING_SLUG.values()]
    + [(s, A / "actions" / f"{s}.png") for s in ACTION_SLUG.values()]
    + [(s, A / "ui" / f"{s}.png") for s in UI_SLUG.values()]
    + [(s, A / "dev" / f"{s}.png") for s in CATEGORY_SLUG.values()]
    + [(s, A / "equipment" / f"{s}.png") for s in EQUIP_SLUG.values()]
    + [(s, A / "politics" / f"{s}.png") for s in POL_SLUG.values()]
    + [(s, A / "politics" / f"{s}.png") for s in REL_SLUG.values()]
)


async def main():
    if not config.TOKEN:
        raise SystemExit("DISCORD_TOKEN не задан (.env).")

    client = disnake.Client(intents=disnake.Intents.none())

    @client.event
    async def on_ready():
        try:
            existing = {e.name: e for e in await client.fetch_application_emojis()}
            mapping = {}
            created = replaced = failed = 0
            fails = []
            for slug, png in ALL_ICONS:
                if not png.exists():
                    print(f"! пропуск {slug}: нет файла {png}")
                    continue
                old = existing.get(slug)
                data = png.read_bytes()
                # Discord не обновляет эмодзи: удаляем старое и создаём заново.
                # Каждый — в своём try + ретрай, чтобы rate-limit не рушил весь прогон.
                ok = False
                for attempt in (1, 2, 3):
                    try:
                        if old is not None:
                            await old.delete()
                            old = None  # удалили — на ретрае уже не трогаем
                        emoji = await client.create_application_emoji(name=slug, image=data)
                        mapping[slug] = f"<:{emoji.name}:{emoji.id}>"
                        ok = True
                        break
                    except Exception as e:
                        if attempt < 3:
                            await asyncio.sleep(3)  # переждать rate-limit
                        else:
                            print(f"✗ {slug}: {e}")
                if ok:
                    if slug in existing:
                        replaced += 1
                    else:
                        created += 1
                    print(f"{'↻' if slug in existing else '+'} {slug}")
                else:
                    failed += 1
                    fails.append(slug)
                await asyncio.sleep(0.4)  # щадящий темп против rate-limit

            print(f"\nГотово. Создано {created}, заменено {replaced}, провалено {failed}, всего активно {len(mapping)}.")
            if fails:
                print("НЕ залиты (перезапусти скрипт — он их доделает):", ", ".join(fails))
            print("Перезапусти бота — он подхватит иконки при старте (on_ready).")
        finally:
            await client.close()

    await client.start(config.TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
