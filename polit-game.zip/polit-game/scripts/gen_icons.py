"""
Генератор иконок ресурсов (PNG 128×128, прозрачный фон).

Создаёт минималистичные глифы в сине-стальной палитре проекта.
Рендерит с супердискретизацией (×4) для гладких краёв.
Файлы: assets/resources/<slug>.png  (slug — латинское имя из RESOURCE_SLUG).

Запуск:  ./.venv/bin/python scripts/gen_icons.py
Иконки — цельный стартовый сет; любую можно заменить позже (система это умеет).
"""

import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from utils.resources import RESOURCE_SLUG, BUILDINGS, BUILDING_SLUG, ACTION_SLUG

from PIL import Image, ImageDraw

OUT = ROOT / "assets" / "resources"
OUT.mkdir(parents=True, exist_ok=True)
OUT_B = ROOT / "assets" / "buildings"
OUT_B.mkdir(parents=True, exist_ok=True)
OUT_A = ROOT / "assets" / "actions"
OUT_A.mkdir(parents=True, exist_ok=True)

S = 4                       # супердискретизация
SZ = 128 * S
PAD = 14 * S

# Палитра
INK = (10, 24, 46)         # тёмно-синий фон тайла
INK2 = (16, 38, 66)
EDGE = (60, 110, 165)
WHITE = (233, 240, 250)

# Цвета ресурсов (акцент глифа)
COL = {
    "oil": (72, 82, 98), "gas": (90, 180, 230), "coal": (70, 78, 90),
    "iron": (150, 160, 172), "gold": (232, 190, 70), "wood": (90, 160, 90),
    "grain": (222, 186, 90), "uranium": (120, 210, 120), "copper": (200, 120, 70),
    "aluminium": (176, 196, 212), "building": (200, 120, 90), "steel": (120, 150, 180),
    "fuel": (90, 180, 230), "electronics": (90, 200, 170), "ammo": (210, 180, 90),
}


def _tile(d: ImageDraw.ImageDraw):
    r = 28 * S
    d.rounded_rectangle([6 * S, 6 * S, SZ - 6 * S, SZ - 6 * S], radius=r, fill=INK2, outline=EDGE, width=2 * S)


def _poly(d, pts, fill):
    d.polygon([(x * S, y * S) for (x, y) in pts], fill=fill)


def _ell(d, box, fill=None, outline=None, w=0):
    d.ellipse([v * S for v in box], fill=fill, outline=outline, width=w * S)


def _rect(d, box, fill=None, outline=None, w=0, r=0):
    coords = [v * S for v in box]
    if r:
        d.rounded_rectangle(coords, radius=r * S, fill=fill, outline=outline, width=w * S)
    else:
        d.rectangle(coords, fill=fill, outline=outline, width=w * S)


def _line(d, a, b, fill, w):
    d.line([(a[0] * S, a[1] * S), (b[0] * S, b[1] * S)], fill=fill, width=w * S)


# ── глифы (координаты в «логических» 0..128) ──
def g_oil(d, c):      # капля
    _poly(d, [(64, 34), (90, 86), (64, 100), (38, 86)], c); _ell(d, (52, 70, 68, 86), fill=WHITE)
def g_gas(d, c):      # пламя
    _poly(d, [(64, 32), (84, 70), (74, 96), (54, 96), (44, 70)], c); _poly(d, [(64, 56), (74, 82), (54, 82)], WHITE)
def g_coal(d, c):     # камень
    _poly(d, [(40, 60), (58, 40), (88, 48), (94, 78), (70, 96), (44, 86)], c)
def g_iron(d, c):     # слиток
    _poly(d, [(36, 70), (92, 70), (84, 92), (44, 92)], c); _poly(d, [(44, 56), (96, 56), (92, 70), (36, 70)], tuple(min(255, x+25) for x in c))
def g_gold(d, c):     # монета
    _ell(d, (38, 38, 90, 90), fill=c, outline=WHITE, w=2); _ell(d, (52, 52, 76, 76), outline=WHITE, w=2)
def g_wood(d, c):     # дерево
    _rect(d, (60, 78, 68, 100), fill=(110, 80, 50)); _poly(d, [(64, 30), (86, 66), (42, 66)], c); _poly(d, [(64, 48), (82, 82), (46, 82)], c)
def g_grain(d, c):    # колос
    _line(d, (64, 98), (64, 50), c, 4)
    for y in (54, 64, 74):
        _line(d, (64, y), (52, y - 8), c, 3); _line(d, (64, y), (76, y - 8), c, 3)
def g_uranium(d, c):  # атом
    _ell(d, (56, 56, 72, 72), fill=c)
    for a in (0, 60, 120):
        bb = (34, 54, 94, 74)
        import math
        img = Image.new("RGBA", (SZ, SZ), (0, 0, 0, 0)); dd = ImageDraw.Draw(img)
        dd.ellipse([v * S for v in bb], outline=c, width=2 * S)
        img = img.rotate(a, center=(SZ // 2, SZ // 2))
        d._image.alpha_composite(img)
def g_copper(d, c):   g_iron(d, c)
def g_aluminium(d, c): g_iron(d, c)
def g_building(d, c):  # кирпичи
    for (x, y) in [(40, 54), (66, 54), (40, 74), (66, 74)]:
        _rect(d, (x, y, x + 22, y + 16), fill=c, outline=INK2, w=1, r=2)
def g_steel(d, c):    # двутавр
    _rect(d, (40, 40, 88, 50), fill=c); _rect(d, (40, 78, 88, 88), fill=c); _rect(d, (58, 50, 70, 78), fill=c)
def g_fuel(d, c):     # канистра
    _rect(d, (44, 44, 84, 96), fill=c, r=6); _rect(d, (54, 36, 70, 46), fill=c, r=2); _rect(d, (52, 56, 76, 64), fill=WHITE)
def g_electronics(d, c):  # чип
    _rect(d, (46, 46, 82, 82), fill=c, r=4)
    for i in range(3):
        x = 54 + i * 10
        _line(d, (x, 40), (x, 46), c, 3); _line(d, (x, 82), (x, 88), c, 3)
        _line(d, (40, 54 + i * 10), (46, 54 + i * 10), c, 3); _line(d, (82, 54 + i * 10), (88, 54 + i * 10), c, 3)
    _rect(d, (58, 58, 70, 70), fill=INK2)
def g_ammo(d, c):     # патрон
    _poly(d, [(64, 30), (74, 48), (54, 48)], c); _rect(d, (54, 48, 74, 96), fill=c, r=3); _rect(d, (54, 88, 74, 98), fill=tuple(max(0, x-40) for x in c), r=2)


GLYPHS = {
    "oil": g_oil, "gas": g_gas, "coal": g_coal, "iron": g_iron, "gold": g_gold,
    "wood": g_wood, "grain": g_grain, "uranium": g_uranium, "copper": g_copper,
    "aluminium": g_aluminium, "building": g_building, "steel": g_steel,
    "fuel": g_fuel, "electronics": g_electronics, "ammo": g_ammo,
}


def make(slug: str):
    img = Image.new("RGBA", (SZ, SZ), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d._image = img  # для glyph'ов, которым нужен композит (атом)
    _tile(d)
    GLYPHS[slug](d, COL.get(slug, WHITE))
    img = img.resize((128, 128), Image.LANCZOS)
    img.save(OUT / f"{slug}.png")


# ═══════════════ ЗДАНИЯ (силуэты, в цвет ресурса) ═══════════════
STEEL = (120, 150, 180)


def ba_derrick(d, c):  # буровая вышка
    _poly(d, [(52, 96), (76, 96), (70, 40), (58, 40)], c)
    _line(d, (58, 40), (76, 96), INK2, 3); _line(d, (70, 40), (52, 96), INK2, 3)
    _rect(d, (59, 30, 69, 42), fill=c)


def ba_mine(d, c):  # гора + вход-штрек
    _poly(d, [(26, 94), (64, 40), (102, 94)], c)
    _poly(d, [(64, 40), (84, 70), (44, 70)], tuple(min(255, x + 24) for x in c))
    _rect(d, (55, 74, 73, 94), fill=INK2)          # тёмный вход
    _rect(d, (51, 68, 77, 75), fill=(60, 66, 78))  # балка над входом


def ba_factory(d, c):  # завод с трубами
    _rect(d, (38, 60, 90, 92), fill=c, r=3)
    _rect(d, (44, 42, 53, 60), fill=c); _rect(d, (58, 50, 67, 60), fill=c)
    for x in (46, 60, 74):
        _rect(d, (x, 70, x + 7, 82), fill=INK2)


def ba_sawmill(d, c):  # бревно + стальная пила
    _rect(d, (32, 74, 94, 88), fill=(120, 86, 54), r=5)
    _ell(d, (54, 40, 86, 72), fill=(150, 160, 172), outline=INK2, w=2)
    _ell(d, (66, 52, 74, 60), fill=INK2)


def ba_farm(d, c):  # амбар
    _poly(d, [(40, 66), (64, 46), (88, 66), (88, 92), (40, 92)], c)
    _poly(d, [(40, 66), (64, 46), (88, 66)], tuple(min(255, x + 22) for x in c))
    _rect(d, (57, 74, 71, 92), fill=INK2)


def ba_warehouse(d, c):  # склад-коробка
    _rect(d, (38, 54, 90, 92), fill=c, r=4)
    _rect(d, (38, 54, 90, 64), fill=tuple(min(255, x + 20) for x in c))
    _rect(d, (56, 64, 72, 92), fill=INK2)


_ARCH = {"derrick": ba_derrick, "mine": ba_mine, "factory": ba_factory,
         "sawmill": ba_sawmill, "farm": ba_farm, "warehouse": ba_warehouse}
_BUILDING_ARCH = {
    "oil_well": "derrick", "gas_well": "derrick",
    "coal_mine": "mine", "iron_mine": "mine", "gold_mine": "mine",
    "uranium_mine": "mine", "copper_mine": "mine",
    "alu_plant": "factory", "build_combine": "factory", "steel_mill": "factory",
    "refinery": "factory", "electro_fab": "factory", "arms_factory": "factory",
    "sawmill": "sawmill", "farm": "farm", "warehouse": "warehouse",
}


def make_building(key: str):
    img = Image.new("RGBA", (SZ, SZ), (0, 0, 0, 0))
    d = ImageDraw.Draw(img); d._image = img
    _tile(d)
    out = BUILDINGS[key][2]
    tint = COL.get(RESOURCE_SLUG.get(out, ""), STEEL) if out else STEEL
    _ARCH[_BUILDING_ARCH[key]](d, tint)
    img.resize((128, 128), Image.LANCZOS).save(OUT_B / f"{BUILDING_SLUG[key]}.png")


# ═══════════════ ДЕЙСТВИЯ (голубые, тема снежинки) ═══════════════
ACC = (104, 194, 236)
HANDLE = (150, 120, 80)


def aa_mine(d):  # кирка: рукоять + изогнутая голова
    _line(d, (44, 94), (70, 46), HANDLE, 7)
    _poly(d, [(34, 56), (64, 38), (94, 56), (90, 63), (64, 47), (38, 63)], ACC)


def aa_build(d):  # молоток
    _line(d, (58, 92), (68, 50), HANDLE, 8)
    _rect(d, (48, 38, 88, 54), fill=ACC, r=4)


def aa_craft(d):  # шестерня
    cx, cy, r = 64, 64, 26
    pts = []
    for i in range(16):
        ang = math.pi * 2 * i / 16
        rr = r if i % 2 == 0 else r - 9
        pts.append((cx + rr * math.cos(ang), cy + rr * math.sin(ang)))
    _poly(d, pts, ACC)
    _ell(d, (cx - 9, cy - 9, cx + 9, cy + 9), fill=INK2)


def aa_exchange(d):  # две стрелки
    _line(d, (38, 52), (86, 52), ACC, 7); _poly(d, [(86, 44), (100, 52), (86, 60)], ACC)
    _line(d, (42, 76), (90, 76), ACC, 7); _poly(d, [(42, 68), (28, 76), (42, 84)], ACC)


def aa_deposits(d):  # метка на карте
    _ell(d, (46, 34, 82, 70), fill=ACC)
    _poly(d, [(46, 58), (82, 58), (64, 96)], ACC)
    _ell(d, (57, 44, 71, 58), fill=INK2)


_ACTION = {"mine": aa_mine, "build": aa_build, "craft": aa_craft,
           "exchange": aa_exchange, "deposits": aa_deposits}


def make_action(name: str):
    img = Image.new("RGBA", (SZ, SZ), (0, 0, 0, 0))
    d = ImageDraw.Draw(img); d._image = img
    _tile(d)
    _ACTION[name](d)
    img.resize((128, 128), Image.LANCZOS).save(OUT_A / f"{ACTION_SLUG[name]}.png")


def main():
    for res, slug in RESOURCE_SLUG.items():
        make(slug)
    for key in BUILDINGS:
        make_building(key)
    for name in ACTION_SLUG:
        make_action(name)
    print(f"Сгенерировано: ресурсы {len(RESOURCE_SLUG)} → {OUT}")
    print(f"               здания {len(BUILDINGS)} → {OUT_B}")
    print(f"               действия {len(ACTION_SLUG)} → {OUT_A}")
    print("Залей в бота: scripts/upload_emojis.py")


if __name__ == "__main__":
    main()
