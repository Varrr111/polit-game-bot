"""
Баннеры правил сервера (!rules): шапка «Правила сервера» + полоса на каждый раздел (§1–§5).
Родня баннеров механик (тот же арт, шрифт, свечения), строгий официальный вид:
двойная рамка-печать вокруг иконки, крупный «§N» призраком справа.

    ./.venv/bin/python scripts/gen_rules_banners.py
→ assets/brand/rules_hero.png, assets/brand/rules_<n>.png
"""

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
import gen_mech_banners as M  # noqa: E402
import gen_guide_banners as G  # noqa: E402  — _glyph: глиф иконки без тайла
from utils.rules_text import SECTIONS  # noqa: E402

BRAND, UI = M.BRAND, M.UI
INK, DIM = M.INK, M.DIM
ACCENT = M.CYAN   # фирменный голубой — официальный тон


def _seal(img, icon: str, center, size, rgb):
    """Иконка в «печати»: свечение + двойное кольцо."""
    cx, cy = center
    r = size // 2 + 26
    g = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(g).ellipse([cx - r - 8, cy - r - 8, cx + r + 8, cy + r + 8], fill=(*rgb, 110))
    img.alpha_composite(g.filter(ImageFilter.GaussianBlur(24)))
    d = ImageDraw.Draw(img)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(8, 14, 26, 240), outline=(*rgb, 255), width=4)
    d.ellipse([cx - r + 11, cy - r + 11, cx + r - 11, cy + r - 11], outline=(*rgb, 90), width=2)
    glyph = G._glyph(icon, size, rgb)                          # только глиф, в цвете раздела
    img.alpha_composite(glyph, (cx - size // 2, cy - size // 2))


def _fit(text: str, max_w: int, size: int, face: int = 0, min_size: int = 48):
    """Шрифт заголовка, который влезает в max_w (длинные названия не наезжают на «§»)."""
    d = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    while size > min_size and d.textlength(text, font=M._av(size, face)) > max_w:
        size -= 2
    return M._av(size, face)


def hero():
    w, h = 1600, 600
    # планета без логотипа арта
    band = M._art_band(w, h, (0.18, 0.12, 0.98, 0.62))
    img = M._shade_left(M._base_with_art(w, h, band, 0.7, fade=(0.0, 0.12)), 0.62, 200)
    # большой «§» призраком за текстом
    ghost = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(ghost).text((560, -40), "§", font=M._av(640, 0), fill=(*ACCENT, 22))
    img.alpha_composite(ghost)
    d = ImageDraw.Draw(img)
    M._spaced(d, (100, 140), "NOVA ORDER  ·  ОФИЦИАЛЬНО", M._av(26, 2), ACCENT, 6)
    d.rounded_rectangle([100, 186, 196, 192], radius=3, fill=ACCENT)
    M._text_shadow(img, (94, 210), "Правила", M._av(124, 0), INK)
    M._text_shadow(img, (94, 340), "сервера", M._av(124, 0), INK)
    ImageDraw.Draw(img).text((100, 498), "Обязательны для всех участников", font=M._av(32, 5), fill=DIM)
    M._accent_line(img, ACCENT, h - 6, 6)
    img.convert("RGB").save(BRAND / "rules_hero.png", optimize=True)


def section(sec: dict):
    w, h = 1600, 320
    accent = sec["color"]
    band = M._art_band(w, h, (0.22, 0.34, 0.92, 0.66))
    img = M._shade_left(M._base_with_art(w, h, band, 0.55, tint=accent, tint_k=0.18, fade=(0.0, 0.25)), 0.75, 215)
    # «§N» призраком справа
    ghost = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(ghost)
    gf = M._av(180, 0)
    txt = f"§{sec['num']}"
    bx = gd.textbbox((0, 0), txt, font=gf)
    gx = w - (bx[2] - bx[0]) - 80 - bx[0]
    gy = (h - (bx[3] - bx[1])) // 2 - bx[1]
    gd.text((gx, gy), txt, font=gf, fill=(*accent, 70))
    img.alpha_composite(ghost)
    _seal(img, sec["icon"], (190, h // 2), 104, accent)
    x0 = 340
    d = ImageDraw.Draw(img)
    M._spaced(d, (x0, 74), f"РАЗДЕЛ {sec['num']}", M._av(24, 2), accent, 6)
    M._text_shadow(img, (x0 - 4, 102), sec["title"], _fit(sec["title"], 840, 78), INK, blur=8)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([x0, 212, x0 + 86, 217], radius=3, fill=accent)
    d.text((x0, 230), sec["strip"], font=M._av(27, 5), fill=DIM)
    M._accent_line(img, accent, h - 5, 5)
    img.convert("RGB").save(BRAND / f"rules_{sec['num']}.png", optimize=True)


if __name__ == "__main__":
    hero()
    for s in SECTIONS:
        section(s)
    print("Готово:", BRAND / "rules_hero.png", "+", len(SECTIONS), "разделов")
