"""
Баннеры «Наследия»: торжественная золотая полоса на каждую державу (пост провозглашения).
Родня баннеров механик/гайда/правил (тот же арт, шрифт, свечения), но в золоте:
медальон с короной, «ЛЕГЕНДАРНАЯ ДЕРЖАВА», титул, девиз, орнамент с лилией, призрачный венец.

    ./.venv/bin/python scripts/gen_legacy_banners.py
→ assets/brand/legacy/<ключ>.jpg
"""

import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
import gen_mech_banners as M  # noqa: E402
import gen_guide_banners as G  # noqa: E402
from utils.legacy import FORMABLES, GOLD, bonus_text  # noqa: E402

OUT = M.BRAND / "legacy"
INK = (246, 236, 214)          # тёплый белый — под золото
DIM = (196, 178, 140)
GOLD_HI = (250, 218, 132)


def _fit(text: str, max_w: int, size: int, face: int = 0, min_size: int = 44):
    d = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    while size > min_size and d.textlength(text, font=M._av(size, face)) > max_w:
        size -= 2
    return M._av(size, face)


def _ornament(img, x0: int, x1: int, y: int):
    """Золотой орнамент: две тающие линии и лилия в центре."""
    d = ImageDraw.Draw(img)
    mid = (x0 + x1) // 2
    for side in (-1, 1):
        for i in range(0, (x1 - x0) // 2 - 34, 2):
            a = max(0, 255 - int(i / ((x1 - x0) / 2) * 255))
            x = mid + side * (34 + i)
            d.point((x, y), fill=(*GOLD, a))
            d.point((x, y + 6), fill=(*GOLD, a // 2))
    lily = G._glyph("legacy", 40, GOLD_HI)
    img.alpha_composite(lily, (mid - 20, y - 17))


def banner(key: str, f: dict):
    w, h = 1600, 440
    band = M._art_band(w, h, (0.16, 0.18, 1.0, 0.62))   # без логотипа арта
    img = M._shade_left(M._base_with_art(w, h, band, 0.5, tint=GOLD, tint_k=0.28, fade=(0.0, 0.45)), 0.66, 205)
    # тёплая золотая подсветка слева
    glow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([-260, -200, 760, 640], fill=(*GOLD, 46))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(120)))
    # призрачный венец справа
    ghost = G._glyph("legacy_crown", 300, GOLD, 0.16)
    img.alpha_composite(ghost, (w - 300 - 90, (h - 300) // 2))
    # медальон с короной
    cx, cy, r = 200, h // 2, 112
    g2 = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(g2).ellipse([cx - r - 16, cy - r - 16, cx + r + 16, cy + r + 16], fill=(*GOLD, 140))
    img.alpha_composite(g2.filter(ImageFilter.GaussianBlur(30)))
    d = ImageDraw.Draw(img)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(18, 14, 8, 245), outline=(*GOLD, 255), width=5)
    d.ellipse([cx - r + 14, cy - r + 14, cx + r - 14, cy + r - 14], outline=(*GOLD, 110), width=2)
    crown = G._glyph("legacy_crown", 128, GOLD_HI)
    img.alpha_composite(crown, (cx - 64, cy - 64))
    # текст
    x0, tw = 380, 820
    d = ImageDraw.Draw(img)
    M._spaced(d, (x0, 78), "ЛЕГЕНДАРНАЯ ДЕРЖАВА", M._av(24, 2), GOLD, 7)
    M._text_shadow(img, (x0 - 4, 112), f["title"], _fit(f["title"], tw, 92), INK, blur=10, alpha=200)
    _ornament(img, x0, x0 + 520, 248)
    d = ImageDraw.Draw(img)
    d.text((x0, 276), f"«{f['motto']}»", font=M._av(32, 5), fill=INK)
    founders = " · ".join(f["founders"])
    d.text((x0, 326), f"Основатели: {founders}", font=_fit(f"Основатели: {founders}", tw, 24, 5, 18), fill=DIM)
    d.text((x0, 360), bonus_text(f["bonuses"]).capitalize(), font=M._av(24, 2), fill=GOLD)
    M._accent_line(img, GOLD, h - 6, 6)
    OUT.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(OUT / f"{key}.jpg", quality=90, optimize=True, progressive=True)


if __name__ == "__main__":
    for k, f in FORMABLES.items():
        banner(k, f)
    print("Готово:", OUT, "—", len(FORMABLES), "баннеров")
