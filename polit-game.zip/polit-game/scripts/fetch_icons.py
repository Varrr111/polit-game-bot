"""
Профессиональные иконки из набора game-icons.net (CC BY 3.0).

Скачивает выбранные SVG, убирает фон, перекрашивает глиф в тему проекта
(ресурсы — по цвету ресурса, здания — по продукту, действия — голубой под
снежинку) и кладёт на аккуратный тёмный тайл. Результат → assets/{resources,
buildings,actions}/<slug>.png — заменяет кустарные PIL-иконки.

Запуск:  ./.venv/bin/python scripts/fetch_icons.py
Требует: cairosvg, Pillow, сеть.
"""

import io
import re
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from utils.resources import RESOURCES, RESOURCE_SLUG, BUILDINGS, BUILDING_SLUG, ACTION_SLUG, UI_SLUG
from utils.upgrades import CATEGORY_SLUG
from utils.equipment import EQUIP_SLUG, EQUIP_CATEGORIES
from utils.politics import POL_SLUG, REL_SLUG

# Иконки категорий техники (game-icons slugs, все проверены). Цвет — по роду войск.
EQUIP_GI = {
    "mbt": "lorc/battle-tank", "light_tank": "lorc/tank", "ifv": "skoll/tank-tread",
    "apc": "skoll/apc", "mrap": "delapouite/truck", "spg": "delapouite/mortar",
    "mlrs": "lorc/missile-pod", "towed_arty": "quoting/field-gun", "atgm": "delapouite/missile-launcher",
    "aa_gun": "delapouite/walking-turret", "sam_short": "lorc/missile-swarm", "sam_long": "lorc/radar-dish",
    "recon_veh": "delapouite/jeep", "eng_veh": "delapouite/bulldozer",
    "fighter": "delapouite/jet-fighter", "multirole": "skoll/airplane", "interceptor": "delapouite/airplane-departure",
    "bomber": "delapouite/stealth-bomber", "strike": "delapouite/plane-wing", "attack_heli": "delapouite/helicopter",
    "transp_heli": "delapouite/helicopter", "transp_plane": "delapouite/paper-plane", "awacs": "lorc/radar-sweep",
    "uav_recon": "delapouite/delivery-drone", "uav_combat": "lorc/targeting",
    "missile_boat": "delapouite/ship-bow", "corvette": "delapouite/fishing-boat", "frigate": "delapouite/sailboat",
    "destroyer": "cathelineau/battleship", "cruiser": "cathelineau/cruiser", "carrier": "delapouite/cargo-ship",
    "lhd": "delapouite/ship-wheel", "sub_diesel": "delapouite/submarine", "sub_nuclear": "delapouite/submarine",
    "minesweeper": "lorc/mine-explosion",
    "tactical_msl": "lorc/rocket", "cruise_msl": "lorc/rocket-flight", "ballistic_msl": "skoll/nuclear-bomb",
    "aa_missile": "lorc/on-target", "anti_ship": "delapouite/torpedo",
}
EQUIP_DOMAIN_COLOR = {
    "land": (150, 168, 192), "air": (108, 196, 238), "naval": (120, 160, 205), "missile": (224, 150, 110),
}

import cairosvg
from PIL import Image, ImageDraw

BASE = "https://raw.githubusercontent.com/game-icons/icons/master"
CACHE = ROOT / "assets" / "_svg"
CACHE.mkdir(parents=True, exist_ok=True)

INK = (12, 24, 42)
INK2 = (16, 34, 58)
EDGE = (62, 112, 168)
CYAN = (108, 196, 238)

# Цвет ресурса (для глифа ресурса и здания-по-продукту)
RES_COLOR = {
    "железо": (158, 170, 184), "уголь": (120, 128, 142), "хром": (160, 182, 202),
    "никель": (200, 210, 220), "марганец": (150, 134, 150), "медь": (212, 132, 80),
    "нефть": (120, 150, 185), "бокситы": (206, 142, 100), "молибден": (132, 150, 176),
    "вольфрам": (96, 108, 128), "сталь": (148, 168, 196), "топливо": (120, 172, 212),
    "электроника": (116, 206, 186), "уран": (140, 210, 120), "ядерное топливо": (120, 214, 170),
}

RES_GI = {
    "железо": "lorc/gems", "уголь": "delapouite/coal-pile", "хром": "lorc/crystal-cluster",
    "никель": "lorc/crystal-shine", "марганец": "delapouite/falling-rocks", "медь": "delapouite/gold-nuggets",
    "нефть": "lorc/drop", "бокситы": "delapouite/stone-stack", "молибден": "lorc/crystal-bars",
    "вольфрам": "lorc/crystal-growth", "сталь": "delapouite/i-beam",
    "топливо": "delapouite/fuel-tank", "электроника": "delapouite/cpu",
    "уран": "lorc/radioactive", "ядерное топливо": "lorc/test-tubes",
}
BLD_GI = {
    "factory_small": "delapouite/factory", "factory_medium": "delapouite/factory",
    "factory_large": "delapouite/factory", "steel_mill": "delapouite/factory",
    "refinery": "delapouite/oil-rig", "electro_fab": "delapouite/factory",
    "warehouse": "delapouite/warehouse", "fuel_fab": "delapouite/nuclear-plant",
}
# цвет здания: заводы-производства — по размеру, остальные — по продукту
BLD_COLOR = {
    "factory_small": (150, 168, 192), "factory_medium": (108, 196, 238), "factory_large": (232, 194, 96),
}
ACT_GI = {
    "mine": "lorc/mining", "build": "delapouite/crane", "craft": "lorc/cog",
    "exchange": "lorc/trade", "deposits": "lorc/treasure-map",
}
UI_GI = {
    "check": "delapouite/check-mark", "lock": "delapouite/plain-padlock",
    "upgrade": "delapouite/upgrade", "up": "badges/arrow-up",
    "down": "badges/arrow-down", "flat": "badges/minus",
    "coins": "delapouite/coins", "storage": "delapouite/stack",
    "gov": "delapouite/greek-temple", "stability": "lorc/checked-shield",
    "barracks": "delapouite/barracks", "academy": "lorc/medal", "command": "delapouite/tower-flag",
    "recruit": "lorc/rally-the-troops", "form": "skoll/rank-3",
    "soldier": "delapouite/sergeant", "attack": "lorc/crossed-swords",
    "armor": "sbed/shield", "hp": "sbed/health-normal",
    "ev_social": "delapouite/three-friends", "ev_nature": "delapouite/oak-leaf",
    "ev_science": "lorc/round-bottom-flask", "ev_diplomacy": "delapouite/shaking-hands",
    # шпионаж (Этап 1)
    "spy": "delapouite/spy", "recon": "delapouite/binoculars",
    "counterintel": "lorc/eye-shield", "agent": "lorc/domino-mask",
    "sweep": "lorc/shield-echoes", "destab": "delapouite/uprising",
    "eco_sab": "delapouite/bank", "sabotage": "lorc/spanner",
    "theft": "delapouite/robber", "heat": "lorc/small-fire",
    "exposed": "lorc/burning-eye",
    # права / !perm
    "perm": "lorc/key", "perm_grant": "delapouite/padlock-open",
    "perm_revoke": "lorc/padlock", "perm_all": "delapouite/star-key",
    "perm_clear": "delapouite/broom",
    # админ-инструменты
    "reload": "lorc/cycle", "dbreset": "delapouite/trash-can", "tools": "delapouite/toolbox",
    # ультиматумы
    "ultimatum": "lorc/sands-of-time", "accept": "delapouite/shaking-hands",
    "reject": "sbed/cancel", "counter": "lorc/scales", "blockade": "delapouite/brick-wall",
    # гайд / новости
    "guide": "lorc/open-book", "news": "delapouite/newspaper",
    # политика: переходы строя
    "legitimacy": "delapouite/throne-king", "reform": "lorc/scroll-unfurled",
    "revolution": "lorc/molotov", "opposition": "lorc/fist",
    # регистрация
    "atomic": "delapouite/nuclear-plant", "population": "delapouite/family-house",
    # санкции
    "sanctions": "lorc/gavel", "embargo": "delapouite/cargo-crate",
    "financial": "lorc/frozen-orb", "techban": "delapouite/cpu", "resilience": "delapouite/castle",
    # защита сервера
    "guard": "lorc/surrounded-shield", "antispam": "delapouite/megaphone",
    "antinuke": "lorc/bright-explosion", "antiwebhook": "lorc/linked-rings",
    "antiban": "delapouite/thor-hammer", "antibot": "lorc/android-mask",
    "antirole": "lorc/energy-shield", "raidmode": "lorc/rally-the-troops",
    "raider": "lorc/cowled", "restore": "delapouite/save",
    # война (Этап 2)
    "war": "lorc/crossed-swords", "war_declare": "lorc/hunting-horn",
    "front": "delapouite/brick-wall", "offensive": "lorc/saber-slash",
    "defense_op": "sbed/shield", "siege": "delapouite/trebuchet",
    "victory": "lorc/laurel-crown", "defeat": "lorc/broken-shield",
    "peace": "lorc/dove", "losses": "lorc/skull-crossed-bones",
    "supply": "delapouite/cargo-crate", "warplan": "lorc/papers",
    "exhaustion": "lorc/despair",
    # соединения армии (13 типов)
    "fm_motor_rifle": "delapouite/sergeant", "fm_tank_div": "lorc/tank",
    "fm_arty_regt": "lorc/cannon-shot", "fm_aa_div": "lorc/missile-pod",
    "fm_recon_bn": "delapouite/binoculars", "fm_air_wing": "delapouite/jet-fighter",
    "fm_bomber_wing": "lorc/grenade", "fm_heli_regt": "delapouite/helicopter",
    "fm_uav_sqn": "delapouite/paper-plane", "fm_flotilla": "delapouite/sailboat",
    "fm_carrier_group": "delapouite/cargo-ship", "fm_sub_fleet": "delapouite/submarine",
    "fm_missile_bde": "delapouite/missile-launcher",
    # торговля
    "trade": "delapouite/two-coins", "market": "delapouite/shop",
    "buy": "delapouite/pay-money", "sell": "delapouite/receive-money",
    "deal": "delapouite/shaking-hands", "cancel_x": "sbed/cancel",
    # дипломатия
    "diplo": "lorc/conversation", "relations": "lorc/heart-tower",
    "rel_up": "delapouite/thumb-up", "rel_down": "delapouite/thumb-down",
    "influence": "lorc/crown-coin", "treaty": "delapouite/scroll-quill",
    "nonaggression": "delapouite/olive", "trade_pact": "delapouite/money-stack",
    "alliance": "delapouite/shield-bash", "transit": "delapouite/open-gate",
    "embassy": "lorc/flying-flag", "reputation": "delapouite/ribbon-medal",
    "incident": "lorc/hazard-sign", "deescalate": "lorc/meditation",
    "escalate": "lorc/fire-ring", "betrayal": "lorc/backstab",
    "call_arms": "lorc/crossed-axes", "envelope": "lorc/envelope",    # альянсы
    "bloc_mil": "lorc/surrounded-shield",
    "bloc_eco": "delapouite/bank",
    "charter": "lorc/scroll-unfurled",
    "cohesion": "lorc/linked-rings",
    "vote": "delapouite/vote",
    "treasury": "lorc/locked-chest",
    "leader": "lorc/laurel-crown",
    "invite": "delapouite/entry-door",
    "expel": "lorc/boot-kick",
    "leave_bloc": "delapouite/exit-door",
    "split": "lorc/cracked-shield",
    "ratify": "lorc/hourglass",
    "joint_command": "lorc/rally-the-troops",
    "intel_share": "lorc/eye-shield",
    "customs": "delapouite/barrier",
    "currency_union": "delapouite/coins-pile",
    # атомная программа
    "nuclear": "lorc/fission",
    "physics": "lorc/round-bottom-flask",
    "centrifuge": "lorc/cycle",
    "enrich": "lorc/chemical-tank",
    "heu": "delapouite/barrel",
    "warhead": "skoll/nuclear-bomb",
    "nuke_test": "lorc/mushroom-cloud",
    "npt": "lorc/shield-reflect",
    "violator": "lorc/biohazard",
    "fallout": "lorc/gas-mask",
    "launch": "delapouite/missile-launcher",
    "intercept": "lorc/radar-sweep",
    "accident": "delapouite/nuclear-waste",
    "umbrella": "lorc/atomic-slashes",
    "deterrence": "lorc/explosion-rays",
    "nuke_club": "delapouite/round-table",
    "inspect": "lorc/magnifying-glass",
    "nuke_sab": "delapouite/spy",
    "research": "lorc/stopwatch",    # ООН
    "un": "lorc/laurels",
    "un_condemn": "lorc/gavel",
    "un_aid": "delapouite/first-aid-kit",
    "un_embargo": "lorc/padlock",
    "un_sc": "delapouite/discussion",
    "veto": "lorc/hand",
    "resolution": "delapouite/stamper",
    "un_news": "delapouite/newspaper",
    "ga": "delapouite/earth-africa-europe",
    "abstain": "lorc/scales",
    "secgen": "delapouite/megaphone",
    "ai_state": "lorc/processor",
    "legacy": "delapouite/fleur-de-lys", "legacy_crown": "lorc/queen-crown", "legacy_decline": "lorc/crown-of-thorns",
    # Модерация
    "mod": "delapouite/whistle",
    "mod_warn": "lorc/hazard-sign",
    "mod_timeout": "lorc/hourglass",
    "mod_ban": "lorc/hammer-drop",
    "mod_unban": "delapouite/padlock-open",
    "purge": "delapouite/broom",
    # ЧВК
    "pmc": "lorc/mailed-fist",
    "contract": "lorc/tied-scroll",
    "riot": "lorc/riot-shield",
    "pmc_target": "lorc/targeting",
    "pmc_hire": "delapouite/barracks-tent",
    "pmc_base": "delapouite/military-fort",
    "black_market": "lorc/cowled",
    "pmc_rating": "lorc/trophy",
}
UI_COLOR = {
    "check": (96, 204, 148), "lock": (156, 176, 200), "upgrade": (108, 196, 238),
    "up": (96, 204, 148), "down": (224, 110, 118), "flat": (150, 162, 178),
    "coins": (232, 194, 96), "storage": (142, 180, 212),
    "gov": (142, 180, 212), "stability": (108, 196, 238),
    "barracks": (150, 178, 210), "academy": (232, 194, 96), "command": (142, 180, 212),
    "recruit": (150, 178, 210), "form": (150, 178, 210),
    "soldier": (150, 178, 210), "attack": (206, 118, 108), "armor": (142, 180, 212), "hp": (224, 110, 118),
    "ev_social": (150, 178, 210), "ev_nature": (96, 196, 130),
    "ev_science": (108, 196, 238), "ev_diplomacy": (232, 194, 120),
    # шпионаж: нейтральное своё — сталь/циан; враждебные операции — красный/янтарь;
    # кража — золото; защита — зелёный; накал/разоблачение — огонь.
    "spy": (142, 180, 212), "recon": (108, 196, 238), "counterintel": (120, 160, 205),
    "agent": (150, 178, 210), "sweep": (96, 204, 148), "destab": (224, 150, 110),
    "eco_sab": (206, 118, 108), "sabotage": (206, 118, 108), "theft": (232, 194, 96),
    "heat": (230, 150, 80), "exposed": (224, 110, 118),
    # права: ключ — тёплое золото; выдать — зелёный; забрать — красный; всё — золото; сброс — сталь
    "perm": (214, 188, 136), "perm_grant": (96, 204, 148), "perm_revoke": (206, 118, 108),
    "perm_all": (232, 194, 96), "perm_clear": (150, 178, 210),
    # админ: reload — циан; dbreset — красный (опасно); tools — сталь
    "reload": (108, 196, 238), "dbreset": (206, 118, 108), "tools": (142, 180, 212),
    # ультиматумы: срок — янтарь; принять — зелёный; отказ/блокада — красный; торг — циан
    "ultimatum": (224, 160, 90), "accept": (96, 204, 148), "reject": (206, 118, 108),
    "counter": (108, 196, 238), "blockade": (206, 118, 108),
    # гайд — тёплое золото (том); новости — циан
    "guide": (214, 188, 136), "news": (108, 196, 238),
    # политика: легитимность — золото; реформа — циан; революция — огонь; оппозиция — янтарь
    "legitimacy": (214, 188, 136), "reform": (108, 196, 238),
    "revolution": (224, 120, 90), "opposition": (210, 150, 96),
    # регистрация: АЭС — ядерно-зелёный; население — сталь
    "atomic": (150, 200, 130), "population": (150, 178, 210),
    # санкции: общий — янтарь; эмбарго/тех — красный; финансы — лёд; устойчивость — зелёная сталь
    "sanctions": (214, 150, 110), "embargo": (206, 118, 108), "financial": (140, 200, 235),
    "techban": (200, 130, 120), "resilience": (120, 190, 150),
    # защита: щит — циан-сталь; угрозы — красный; антиспам/рейд — янтарь; восстановление — зелёный
    "guard": (108, 196, 238), "antispam": (224, 180, 110), "antinuke": (224, 110, 118),
    "antiwebhook": (142, 180, 212), "antiban": (206, 118, 108), "antibot": (150, 178, 210),
    "antirole": (120, 170, 210), "raidmode": (224, 110, 118), "raider": (170, 110, 120),
    "restore": (96, 204, 148),
    # война
    "war": (206, 118, 108), "war_declare": (224, 160, 90), "front": (142, 180, 212),
    "offensive": (224, 110, 118), "defense_op": (108, 196, 238), "siege": (206, 118, 108),
    "victory": (232, 194, 96), "defeat": (150, 162, 178), "peace": (96, 204, 148),
    "losses": (150, 162, 178), "supply": (142, 180, 212), "warplan": (142, 180, 212),
    "exhaustion": (210, 150, 96),
    # соединения: суша — сталь, артиллерия/ракеты — красный, ПВО/авиация — циан, флот — синий, разведка — зелёный
    "fm_motor_rifle": (150, 178, 210), "fm_tank_div": (142, 180, 212),
    "fm_arty_regt": (206, 118, 108), "fm_aa_div": (108, 196, 238),
    "fm_recon_bn": (96, 204, 148), "fm_air_wing": (108, 196, 238),
    "fm_bomber_wing": (120, 170, 210), "fm_heli_regt": (108, 196, 238),
    "fm_uav_sqn": (142, 196, 230), "fm_flotilla": (120, 160, 205),
    "fm_carrier_group": (120, 160, 205), "fm_sub_fleet": (110, 150, 195),
    "fm_missile_bde": (206, 118, 108),
    # торговля
    "trade": (232, 194, 96), "market": (142, 180, 212), "buy": (96, 204, 148),
    "sell": (232, 194, 96), "deal": (108, 196, 238), "cancel_x": (206, 118, 108),
    # дипломатия: общее — циан; сближение/договоры — зелёный и золото; конфликт — красный/янтарь
    "diplo": (108, 196, 238), "relations": (214, 150, 170), "rel_up": (96, 204, 148),
    "rel_down": (224, 110, 118), "influence": (232, 194, 96), "treaty": (214, 188, 136),
    "nonaggression": (96, 204, 148), "trade_pact": (232, 194, 96), "alliance": (108, 196, 238),
    "transit": (142, 180, 212), "embassy": (142, 180, 212), "reputation": (232, 194, 96),
    "incident": (224, 160, 90), "deescalate": (96, 204, 148), "escalate": (224, 120, 90),
    "betrayal": (206, 118, 108), "call_arms": (206, 118, 108), "envelope": (214, 188, 136),    # альянсы: военное — циан/сталь, экономика — золото, раскол — красный
    "bloc_mil": (108, 196, 238),
    "bloc_eco": (232, 194, 96),
    "charter": (214, 188, 136),
    "cohesion": (108, 196, 238),
    "vote": (142, 180, 212),
    "treasury": (232, 194, 96),
    "leader": (232, 194, 96),
    "invite": (96, 204, 148),
    "expel": (206, 118, 108),
    "leave_bloc": (224, 160, 90),
    "split": (206, 118, 108),
    "ratify": (150, 162, 178),
    "joint_command": (108, 196, 238),
    "intel_share": (142, 196, 230),
    "customs": (232, 194, 96),
    "currency_union": (232, 194, 96),
    # атомная программа: мирное — зелёный/циан, оружие — красный, тревога — янтарь
    "nuclear": (156, 220, 120),
    "physics": (108, 196, 238),
    "centrifuge": (108, 196, 238),
    "enrich": (156, 220, 120),
    "heu": (232, 194, 96),
    "warhead": (206, 118, 108),
    "nuke_test": (224, 140, 90),
    "npt": (142, 180, 212),
    "violator": (206, 118, 108),
    "fallout": (224, 160, 90),
    "launch": (206, 118, 108),
    "intercept": (108, 196, 238),
    "accident": (224, 160, 90),
    "umbrella": (108, 196, 238),
    "deterrence": (232, 194, 96),
    "nuke_club": (232, 194, 96),
    "inspect": (142, 180, 212),
    "nuke_sab": (206, 118, 108),
    "research": (150, 162, 178),    # ООН
    "un": (108, 196, 238),
    "un_condemn": (206, 118, 108),
    "un_aid": (96, 204, 148),
    "un_embargo": (224, 160, 90),
    "un_sc": (142, 180, 212),
    "veto": (206, 118, 108),
    "resolution": (214, 188, 136),
    "un_news": (142, 180, 212),
    "ga": (108, 196, 238),
    "abstain": (150, 162, 178),
    "secgen": (232, 194, 96),
    "ai_state": (150, 172, 205),
    "legacy": (232, 194, 96), "legacy_crown": (240, 204, 110), "legacy_decline": (176, 120, 110),
    # Модерация
    "mod": (108, 196, 238),
    "mod_warn": (232, 194, 96),
    "mod_timeout": (224, 160, 90),
    "mod_ban": (206, 118, 108),
    "mod_unban": (96, 204, 148),
    "purge": (142, 180, 212),
    # ЧВК
    "pmc": (150, 172, 205),
    "contract": (214, 188, 136),
    "riot": (142, 180, 212),
    "pmc_target": (206, 118, 108),
    "pmc_hire": (96, 204, 148),
    "pmc_base": (150, 172, 205),
    "black_market": (130, 140, 160),
    "pmc_rating": (226, 190, 92),
}

# Идеологии и религии (game-icons, все проверены). Цвета — по теме.
POL_GI = {
    "none": "delapouite/round-star", "democracy": "delapouite/vote", "liberalism": "lorc/dove",
    "socialism": "skoll/fist", "communism": "delapouite/hammer-sickle", "monarchy": "lorc/crown",
    "technocracy": "skoll/atom", "theocracy": "delapouite/church", "authoritarian": "delapouite/all-seeing-eye",
    "fascism": "lorc/crossed-swords",
}
REL_GI = {
    "secular": "lorc/scales", "christianity": "delapouite/crucifix", "islam": "lorc/moon",
    "buddhism": "lorc/lotus", "judaism": "lorc/holy-symbol", "atheism": "lorc/interdiction",
}
POL_COLOR = (150, 172, 205)   # сталь-синий для строёв
REL_COLOR = (214, 188, 136)   # тёплое золото для религий
# Категории прокачки
DEV_GI = {
    "economy": "lorc/profit", "science": "lord-berandas/microscope",
    "infra": "delapouite/modern-city", "mining": "delapouite/mining-helmet",
    "military": "lorc/crossed-swords",
}
DEV_COLOR = {
    "economy": (232, 194, 96), "science": (108, 196, 238), "infra": (142, 180, 212),
    "mining": (212, 150, 80), "military": (206, 118, 108),
}


def fetch_svg(gi: str) -> str:
    cache = CACHE / (gi.replace("/", "_") + ".svg")
    if cache.exists():
        return cache.read_text(encoding="utf-8")
    url = f"{BASE}/{gi}.svg"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    data = urllib.request.urlopen(req, timeout=20).read().decode("utf-8")
    cache.write_text(data, encoding="utf-8")
    return data


def recolor(svg: str, color) -> str:
    hexc = "#%02x%02x%02x" % color
    svg = re.sub(r'<path d="M0 0h512v512H0z"[^>]*/>', "", svg)   # убрать фон
    if 'fill="#fff"' in svg:
        svg = svg.replace('fill="#fff"', f'fill="{hexc}"')
    else:
        svg = re.sub(r"<path ", f'<path fill="{hexc}" ', svg, count=1)
    return svg


def tile(sz=128) -> Image.Image:
    S = 4
    img = Image.new("RGBA", (sz * S, sz * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = int(30 * S)
    # лёгкий вертикальный градиент
    top, bot = INK2, INK
    grad = Image.new("RGBA", (1, sz * S))
    for y in range(sz * S):
        f = y / (sz * S)
        grad.putpixel((0, y), (int(top[0] + (bot[0] - top[0]) * f),
                               int(top[1] + (bot[1] - top[1]) * f),
                               int(top[2] + (bot[2] - top[2]) * f), 255))
    grad = grad.resize((sz * S, sz * S))
    mask = Image.new("L", (sz * S, sz * S), 0)
    ImageDraw.Draw(mask).rounded_rectangle([6 * S, 6 * S, sz * S - 6 * S, sz * S - 6 * S], radius=r, fill=255)
    img.paste(grad, (0, 0), mask)
    d.rounded_rectangle([6 * S, 6 * S, sz * S - 6 * S, sz * S - 6 * S], radius=r, outline=EDGE + (255,), width=2 * S)
    return img.resize((sz, sz), Image.LANCZOS)


def make(gi: str, color, out_path: Path):
    svg = recolor(fetch_svg(gi), color)
    png = cairosvg.svg2png(bytestring=svg.encode("utf-8"), output_width=256, output_height=256)
    glyph = Image.open(io.BytesIO(png)).convert("RGBA")
    g = 80  # размер глифа на тайле 128
    glyph = glyph.resize((g, g), Image.LANCZOS)
    t = tile(128)
    t.alpha_composite(glyph, ((128 - g) // 2, (128 - g) // 2))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.save(out_path)


def make_arrow(direction: str, color, out_path: Path):
    """Рисует стрелку-треугольник (пагинация) прямо на тайле — без сети."""
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    cx, cy = 64 * S, 64 * S
    w, h = 26 * S, 30 * S  # ширина/высота треугольника
    if direction == "next":
        pts = [(cx - w // 2, cy - h // 2), (cx - w // 2, cy + h // 2), (cx + w // 2, cy)]
    else:  # prev
        pts = [(cx + w // 2, cy - h // 2), (cx + w // 2, cy + h // 2), (cx - w // 2, cy)]
    d.polygon(pts, fill=color + (255,))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def make_currency(out_path: Path):
    """Рисует монету-валюту: золотой диск + знак валюты ¤ (без сети)."""
    import math
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    cx, cy = 64 * S, 64 * S
    R = 34 * S
    gold = (232, 194, 96, 255)
    gold_d = (190, 150, 64, 255)
    ink = (26, 38, 60, 255)
    d.ellipse([cx - R, cy - R, cx + R, cy + R], fill=gold, outline=gold_d, width=int(2.6 * S))
    r2 = int(R * 0.72)
    d.ellipse([cx - r2, cy - r2, cx + r2, cy + r2], outline=gold_d, width=max(2, int(1.4 * S)))
    # знак валюты ¤: центральный кружок + 4 диагональных луча
    rc = int(R * 0.30)
    lw = int(2.8 * S)
    d.ellipse([cx - rc, cy - rc, cx + rc, cy + rc], outline=ink, width=lw)
    for ang in (45, 135, 225, 315):
        a = math.radians(ang)
        x1 = cx + int(rc * math.cos(a)); y1 = cy - int(rc * math.sin(a))
        x2 = cx + int((rc + 9 * S) * math.cos(a)); y2 = cy - int((rc + 9 * S) * math.sin(a))
        d.line([x1, y1, x2, y2], fill=ink, width=lw)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def make_military(kind: str, color, out_path: Path):
    """Рисует силуэт рода войск (танк/авиа/флот/ракета/завод) на тайле — без сети."""
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    col = color + (255,)
    cx, cy = 64 * S, 64 * S

    def rect(x1, y1, x2, y2):
        d.rectangle([cx + x1 * S, cy + y1 * S, cx + x2 * S, cy + y2 * S], fill=col)

    def poly(pts):
        d.polygon([(cx + x * S, cy + y * S) for x, y in pts], fill=col)

    def circ(x, y, r):
        d.ellipse([cx + (x - r) * S, cy + (y - r) * S, cx + (x + r) * S, cy + (y + r) * S], fill=col)

    if kind == "land":            # танк
        rect(-24, 2, 24, 12)                         # корпус
        for wx in range(-22, 23, 9):                 # катки
            circ(wx, 13, 4)
        rect(-12, -6, 10, 2)                         # башня
        rect(10, -4, 28, -1)                         # ствол
    elif kind == "air":           # истребитель (вид сверху)
        poly([(0, -28), (5, -6), (5, 20), (-5, 20), (-5, -6)])   # фюзеляж
        poly([(-28, 6), (28, 6), (6, -4), (-6, -4)])             # крылья
        poly([(-12, 22), (12, 22), (4, 14), (-4, 14)])           # хвост
    elif kind == "naval":         # корабль
        poly([(-30, 6), (30, 6), (22, 20), (-22, 20)])           # корпус
        rect(-10, -8, 8, 6)                                      # надстройка
        rect(-2, -22, 1, -8)                                     # мачта
        rect(12, -2, 22, 6)                                      # нос.надстройка
    elif kind == "missile":       # ракета
        poly([(0, -30), (7, -16), (-7, -16)])                    # носовой конус
        rect(-7, -16, 7, 18)                                     # корпус
        poly([(-7, 10), (-18, 24), (-7, 20)])                    # левый стабилизатор
        poly([(7, 10), (18, 24), (7, 20)])                       # правый стабилизатор
    else:                          # plant — завод
        rect(-26, 0, 26, 22)                                     # корпус цеха
        poly([(-26, 0), (-26, -8), (-14, 0)])                    # зубцы крыши
        poly([(-14, 0), (-14, -8), (-2, 0)])
        poly([(-2, 0), (-2, -8), (10, 0)])
        rect(16, -20, 22, 0)                                     # труба
        circ(0, -16, 7)                                          # звезда-кружок
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def make_plus(color, out_path: Path):
    """Иконка «зарегистрировать/добавить» — жирный плюс на тайле."""
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    cx, cy = 64 * S, 64 * S
    col = color + (255,)
    a, b = 6 * S, 22 * S
    d.rectangle([cx - a, cy - b, cx + a, cy + b], fill=col)
    d.rectangle([cx - b, cy - a, cx + b, cy + a], fill=col)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def make_license(color, out_path: Path):
    """Иконка «лицензия» — документ с строками и печатью."""
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    cx, cy = 64 * S, 64 * S
    col = color + (255,)
    lw = max(2, int(2.4 * S))
    # лист документа
    d.rounded_rectangle([cx - 22 * S, cy - 26 * S, cx + 22 * S, cy + 26 * S],
                        radius=5 * S, outline=col, width=lw)
    # строки текста
    for i, y in enumerate((-16, -8, 0)):
        x2 = 14 if i < 2 else 6
        d.line([cx - 14 * S, cy + y * S, cx + x2 * S, cy + y * S], fill=col, width=lw)
    # печать (кружок с лентами)
    r = 7 * S
    pcx, pcy = cx + 9 * S, cy + 14 * S
    d.ellipse([pcx - r, pcy - r, pcx + r, pcy + r], outline=col, width=lw)
    d.line([pcx - 3 * S, pcy + r, pcx - 6 * S, pcy + r + 7 * S], fill=col, width=lw)
    d.line([pcx + 3 * S, pcy + r, pcx + 6 * S, pcy + r + 7 * S], fill=col, width=lw)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def make_smiley(color, out_path: Path):
    """Иконка «счастье» — улыбка на тайле."""
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    cx, cy = 64 * S, 64 * S
    col = color + (255,)
    r = 30 * S
    lw = max(2, int(2.6 * S))
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=col, width=lw)      # лицо
    ey = cy - 8 * S
    for ex in (cx - 11 * S, cx + 11 * S):                                  # глаза
        d.ellipse([ex - 3 * S, ey - 3 * S, ex + 3 * S, ey + 3 * S], fill=col)
    d.arc([cx - 15 * S, cy - 6 * S, cx + 15 * S, cy + 18 * S], 20, 160, fill=col, width=lw)  # улыбка
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def make_flag(color, out_path: Path):
    """Иконка «распустить» — белый флаг (капитуляция/роспуск) на тайле."""
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    cx, cy = 64 * S, 64 * S
    col = color + (255,)
    lw = max(2, int(3 * S))
    d.line([cx - 16 * S, cy - 30 * S, cx - 16 * S, cy + 32 * S], fill=col, width=lw)  # древко
    d.polygon([(cx - 16 * S, cy - 30 * S), (cx + 26 * S, cy - 20 * S), (cx - 16 * S, cy - 4 * S)], fill=col)  # полотнище
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def make_globe(color, out_path: Path):
    """Рисует стилизованный глобус (контур + меридиан + параллели) — без сети."""
    S = 4
    t = tile(128).resize((128 * S, 128 * S), Image.LANCZOS)
    d = ImageDraw.Draw(t)
    cx, cy = 64 * S, 64 * S
    r = 32 * S
    lw = max(2, int(2.3 * S))
    col = color + (255,)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=col, width=lw)            # контур
    d.ellipse([cx - r // 2, cy - r, cx + r // 2, cy + r], outline=col, width=lw)  # меридиан
    d.line([cx - r, cy, cx + r, cy], fill=col, width=lw)                          # экватор
    off = int(r * 0.55)
    half = int((r ** 2 - off ** 2) ** 0.5)
    d.line([cx - half, cy - off, cx + half, cy - off], fill=col, width=lw)        # параллель ↑
    d.line([cx - half, cy + off, cx + half, cy + off], fill=col, width=lw)        # параллель ↓
    out_path.parent.mkdir(parents=True, exist_ok=True)
    t.resize((128, 128), Image.LANCZOS).save(out_path)


def main():
    done = fail = 0
    jobs = []
    for name in RESOURCES:
        if name in RES_GI:
            jobs.append((RES_GI[name], RES_COLOR[name], ROOT / "assets" / "resources" / f"{RESOURCE_SLUG[name]}.png"))
    for key in BUILDINGS:
        out = BUILDINGS[key][2]
        color = BLD_COLOR.get(key) or RES_COLOR.get(out, (142, 180, 212))
        jobs.append((BLD_GI[key], color, ROOT / "assets" / "buildings" / f"{BUILDING_SLUG[key]}.png"))
    for name in ACT_GI:
        jobs.append((ACT_GI[name], CYAN, ROOT / "assets" / "actions" / f"{ACTION_SLUG[name]}.png"))
    for name in UI_GI:
        jobs.append((UI_GI[name], UI_COLOR[name], ROOT / "assets" / "ui" / f"{UI_SLUG[name]}.png"))
    for name in DEV_GI:
        jobs.append((DEV_GI[name], DEV_COLOR[name], ROOT / "assets" / "dev" / f"{CATEGORY_SLUG[name]}.png"))
    for key, gi in EQUIP_GI.items():
        domain = EQUIP_CATEGORIES[key][2]
        color = EQUIP_DOMAIN_COLOR.get(domain, CYAN)
        jobs.append((gi, color, ROOT / "assets" / "equipment" / f"{EQUIP_SLUG[key]}.png"))
    for key, gi in POL_GI.items():
        jobs.append((gi, POL_COLOR, ROOT / "assets" / "politics" / f"{POL_SLUG[key]}.png"))
    for key, gi in REL_GI.items():
        jobs.append((gi, REL_COLOR, ROOT / "assets" / "politics" / f"{REL_SLUG[key]}.png"))

    # Стрелки пагинации рисуем локально (без сети) — один стиль с тайлами.
    for direction in ("prev", "next"):
        out = ROOT / "assets" / "ui" / f"ui_{direction}.png"
        try:
            make_arrow(direction, CYAN, out)
            done += 1
            print(f"✓ arrow:{direction:24} → {out.name}")
        except Exception as e:
            fail += 1
            print(f"✗ arrow:{direction:24} ОШИБКА: {e}")

    # Глобус (шапка регистрации) — тоже локально.
    try:
        gout = ROOT / "assets" / "ui" / "ui_globe.png"
        make_globe(CYAN, gout)
        done += 1
        print(f"✓ globe{'':25} → {gout.name}")
    except Exception as e:
        fail += 1
        print(f"✗ globe ОШИБКА: {e}")

    # Валюта (монета ¤) — локально.
    try:
        cout = ROOT / "assets" / "ui" / "ui_money.png"
        make_currency(cout)
        done += 1
        print(f"✓ currency{'':22} → {cout.name}")
    except Exception as e:
        fail += 1
        print(f"✗ currency ОШИБКА: {e}")

    # Рода войск + военный завод — локально.
    for kind in ("land", "air", "naval", "missile", "plant"):
        out = ROOT / "assets" / "ui" / f"ui_{kind}.png"
        try:
            make_military(kind, CYAN, out)
            done += 1
            print(f"✓ military:{kind:20} → {out.name}")
        except Exception as e:
            fail += 1
            print(f"✗ military:{kind:20} ОШИБКА: {e}")

    # Кнопки + счастье + флаг: регистрация (+), лицензия, счастье, распустить — локально.
    for name, fn in (("ui_register", make_plus), ("ui_license", make_license),
                     ("ui_happy", make_smiley), ("ui_disband", make_flag)):
        out = ROOT / "assets" / "ui" / f"{name}.png"
        try:
            fn(CYAN, out)
            done += 1
            print(f"✓ {name:28} → {out.name}")
        except Exception as e:
            fail += 1
            print(f"✗ {name:28} ОШИБКА: {e}")

    for gi, color, out_path in jobs:
        try:
            make(gi, color, out_path)
            done += 1
            print(f"✓ {gi:30} → {out_path.name}")
        except Exception as e:
            fail += 1
            print(f"✗ {gi:30} ОШИБКА: {e}")
    print(f"\nГотово: {done} иконок, ошибок {fail}")
    print("Превью: собери контактный лист; залей в бота: scripts/upload_emojis.py")


if __name__ == "__main__":
    main()
