"""
Разовая загрузка геоданных и шрифта для карты мира.

Качает:
  * Natural Earth 110m Admin-0 (страны)  -> assets/map/world_admin0.geojson
  * (опц.) Natural Earth 50m Admin-0      -> assets/map/world_admin0_50m.geojson  (детальнее)
  * шрифт DejaVuSans (+Bold) с кириллицей -> assets/map/fonts/

Данные Natural Earth — public domain. Шрифт DejaVu — свободная лицензия.

Запуск:
    ./.venv/bin/python scripts/fetch_map.py          # базовый набор (110m + шрифты)
    ./.venv/bin/python scripts/fetch_map.py --50m    # ещё и детальная 50m
    ./.venv/bin/python scripts/fetch_map.py --inspect # показать свойства первой страны
"""

import json
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAP_DIR = ROOT / "assets" / "map"
FONT_DIR = MAP_DIR / "fonts"

NE_BASE = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson"

DOWNLOADS = {
    # Страны (для нац. границ, подписей, сопоставления имён) — лёгкий 110m.
    "world_admin0.geojson": f"{NE_BASE}/ne_110m_admin_0_countries.geojson",
    # РЕГИОНЫ (области/штаты) всех стран — 10m (~39 МБ), полное покрытие.
    "world_admin1.geojson": f"{NE_BASE}/ne_10m_admin_1_states_provinces.geojson",
}

FONTS = {
    # Надёжный источник статичных TTF с полной кириллицей (репозиторий matplotlib).
    "DejaVuSans.ttf": "https://raw.githubusercontent.com/matplotlib/matplotlib/main/lib/matplotlib/mpl-data/fonts/ttf/DejaVuSans.ttf",
    "DejaVuSans-Bold.ttf": "https://raw.githubusercontent.com/matplotlib/matplotlib/main/lib/matplotlib/mpl-data/fonts/ttf/DejaVuSans-Bold.ttf",
}


def _fetch(url: str, dest: Path):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        print(f"  уже есть: {dest.relative_to(ROOT)} ({dest.stat().st_size // 1024} KB)")
        return
    print(f"  качаю {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "nova-order-bot/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r:
        data = r.read()
    dest.write_bytes(data)
    print(f"  -> {dest.relative_to(ROOT)} ({len(data) // 1024} KB)")


def _inspect():
    path = MAP_DIR / "world_admin0.geojson"
    gj = json.loads(path.read_text(encoding="utf-8"))
    feats = gj["features"]
    print(f"Стран (features): {len(feats)}")
    props = feats[0]["properties"]
    ru_keys = [k for k in props if k.upper().startswith("NAME_RU") or k.upper() == "NAME_RU"]
    print(f"Ключи с русским названием: {ru_keys or 'НЕТ'}")
    # покажем, как называются несколько известных стран
    sample = {}
    for f in feats:
        p = f["properties"]
        a3 = p.get("ADM0_A3") or p.get("ISO_A3")
        if a3 in ("RUS", "USA", "UKR", "PRK", "ZAF", "GBR", "FRA", "NOR", "KOR"):
            sample[a3] = {
                "ADM0_A3": a3,
                "NAME": p.get("NAME"),
                "NAME_RU": p.get("NAME_RU"),
                "NAME_LONG": p.get("NAME_LONG"),
            }
    print("Примеры сопоставления:")
    for a3, v in sorted(sample.items()):
        print("  ", v)


def main():
    args = sys.argv[1:]
    if "--inspect" in args:
        _inspect()
        return
    print("Загрузка геоданных карты…")
    for name, url in DOWNLOADS.items():
        _fetch(url, MAP_DIR / name)
    print("Шрифты…")
    for name, url in FONTS.items():
        _fetch(url, FONT_DIR / name)
    print("Готово. Проверить сопоставление имён:  ./.venv/bin/python scripts/fetch_map.py --inspect")


if __name__ == "__main__":
    main()
