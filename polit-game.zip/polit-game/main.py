"""
Точка входа бота военно-политической игры (disnake).

Запуск:  python main.py
Токен берётся из .env (DISCORD_TOKEN). ID сервера/ролей/каналов — в config.py.
"""

import logging

import disnake
from disnake.ext import commands

import config
from utils.runtime import set_bot

logging.basicConfig(level=logging.INFO)

# Коги, которые загружаем при старте. Добавляем по мере разработки.
INITIAL_EXTENSIONS = [
    "cogs.items",
    "cogs.registration",
    "cogs.resources",
    "cogs.development",
    "cogs.equipment",
    "cogs.state",
    "cogs.army",
    "cogs.events",
    "cogs.economy",
    "cogs.worldmap",
    "cogs.spy",
    "cogs.ultimatum",
    "cogs.sanctions",
    "cogs.diplomacy",
    "cogs.alliance",
    "cogs.nuclear",
    "cogs.un",
    "cogs.war",
    "cogs.npc",
    "cogs.legacy",
    "cogs.pmc",
    "cogs.moderation",
    "cogs.trade",
    "cogs.console",
    "cogs.perms",
    "cogs.news",
    "cogs.serversetup",
    "cogs.serverstats",
    "cogs.serverlogs",
    "cogs.guard",
    "cogs.cleanup",
    "cogs.masstools",
    "cogs.idconfig",
    "cogs.admintools",
    "cogs.help",
    "cogs.guide",
    "cogs.mechanics",
    "cogs.rules",
]


class GameBot(commands.Bot):
    def __init__(self):
        intents = disnake.Intents.all()  # нужны members + message_content
        super().__init__(command_prefix=config.PREFIX, intents=intents, help_command=None)
        set_bot(self)
        # В disnake load_extension синхронный (не await).
        for ext in INITIAL_EXTENSIONS:
            try:
                self.load_extension(ext)
                logging.info("Загружен ког: %s", ext)
            except Exception:
                logging.exception("Не удалось загрузить ког: %s", ext)

    async def on_ready(self):
        # Подхватываем иконки ресурсов из application-эмодзи бота (загружены
        # через scripts/upload_emojis.py). Если их нет — остаются юникод-иконки.
        try:
            from utils.resources import apply_custom_emojis
            emojis = await self.fetch_application_emojis()
            n = apply_custom_emojis({e.name: f"<:{e.name}:{e.id}>" for e in emojis})
            logging.info("Иконок ресурсов подхвачено: %s", n)
        except Exception:
            logging.exception("Не удалось загрузить иконки ресурсов (останутся юникод)")
        logging.info("Бот запущен как %s (id=%s)", self.user, self.user.id)


def main():
    if not config.TOKEN:
        raise SystemExit("DISCORD_TOKEN не задан. Создайте .env (см. .env.example).")
    GameBot().run(config.TOKEN)


if __name__ == "__main__":
    main()
