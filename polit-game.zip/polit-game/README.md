# polit-game-bot

Discord-бот для военно-политических игр (экономика, страны/ЧВК/регионы,
банк и кредиты, компании, инфраструктура, войны).

Проект собирается с нуля. От клиента получен только один ког — `cogs/economy.py`
(исходно `economy-3.py`), который используется как эталон API: по нему
восстанавливается весь фундамент (`utils/`, `config.py`, DB-слой).

## Структура

```
polit-game-bot/
├── main.py              # точка входа, загрузка когов
├── config.py            # ID, цвета (светло-синий/тёмно-синий), параметры
├── requirements.txt
├── .env.example         # DISCORD_TOKEN
├── utils/               # фундамент (фасад через from utils import *)
│   ├── __init__.py      # реэкспорт всего API
│   ├── enums.py         # InfrastructureType
│   ├── objects.py       # датаклассы (CountryObject, CreditOfferObject, ...)
│   ├── constants.py     # большие справочники (LEVELS_CONFIG, специализации)
│   ├── database.py      # базовый SQLite-слой (BaseDB, UserDB)
│   ├── managers.py      # менеджеры данных (Countries, Credits, ...)
│   ├── helpers.py       # int_format, get_object, update_money, ...
│   └── decorators.py    # interaction_error_handler
├── cogs/
│   ├── economy.py       # экономика (файл клиента) — будет отрефакторен
│   └── items.py         # инвентарь (InventoryView)
├── data/                # SQLite база (game.db)
└── docs/                # заметки/дизайн
```

## Запуск (после реализации фундамента)

```bash
cd ~/Desktop/polit-game-bot
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # вписать токен
python main.py
```

## Статус

Фундамент **реализован и проверен** (смоук-тест 33/33):
- окружение (discord.py 2.7.1), DB-слой (SQLite), хелперы, справочники;
- коги грузятся, 12 команд регистрируются;
- баги исходного кога исправлены, компании edit/delete реализованы.

Игровой баланс (числа уровней/доходов/стоимостей) и ID сервера — пока
ЗАГЛУШКИ, их заменит клиент (`docs/questions.md`). Что дальше — в `ROADMAP.md`.

Проверка: `./.venv/bin/python scripts/smoke_test.py`
