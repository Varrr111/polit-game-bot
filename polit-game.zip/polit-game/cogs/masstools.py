"""
🧰 Массовые админ-инструменты для сервера.

  !massrole   — панель: выбери одну/несколько ролей (меню) и выдай их ВСЕМ
                участникам в один клик (или забери у всех). Можно выбрать кому:
                всем людям / вообще всем / только тем, у кого нет ролей.
  !resetnicks — сброс никнеймов всех участников (их имя снова = ник Discord).
                Зарегистрированным игрокам возвращается корректный игровой ник
                (флаг + страна + строй), чтобы не поломать отображение игры.
                Сначала предпросмотр; выполнение — !resetnicks confirm.

Доступ: владелец сервера или выдача через !perm (scope massrole / resetnicks).
Безопасно: не трогаем владельца, роли выше роли бота и управляемые (бот-роли).
"""

import asyncio
import logging
import random

import disnake
from disnake.ext import commands

from utils import SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, COMMAND_COLOR, Countries
from utils.perms import has_command_access
from utils.resources import ui_icon
from utils.ui import Panel, cid, parse_cid

log = logging.getLogger("masstools")

TARGET_LABELS = {
    "humans": "Всем людям (без ботов)",
    "all": "Вообще всем (и ботам)",
    "norole": "Только у кого нет ролей",
}

# ── генератор рандомных английских гейм-ников (типа stigg, wixta, digiii) ──
RABBIT_MATCH = "rabbitboost"
import datetime as _dt
MSK = _dt.timezone(_dt.timedelta(hours=3))
RABBIT_JOIN_DATE = _dt.date(2026, 10, 10)   # меняем ник всем, кто зашёл в этот день (МСК)
NICK_ONSETS = [
    "b", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "v", "w", "x", "z",
    "st", "tr", "br", "dr", "gr", "kr", "sk", "sn", "sp", "sh", "ch", "kl", "zy", "wi", "ni",
]
NICK_MID = ["b", "d", "g", "k", "l", "m", "n", "r", "t", "v", "x", "z", "st", "ck"]
NICK_VOWELS = ["a", "e", "i", "o", "u", "y"]
NICK_CODAS = ["", "", "", "n", "x", "g", "gg", "k", "z", "t", "s", "ck", "xx"]


def generate_nick(used: set[str]) -> str:
    """Короткий рандомный латиница-ник (stigg / wixta / digiii), уникальный в пачке."""
    for _ in range(60):
        s = random.choice(NICK_ONSETS) + random.choice(NICK_VOWELS)
        if random.random() < 0.7:                       # вторая «буква-гласная»
            s += random.choice(NICK_MID) + random.choice(NICK_VOWELS)
        if random.random() < 0.5:                       # концовка
            s += random.choice(NICK_CODAS)
        if s and random.random() < 0.28:                # хвост: digiii, stigg
            s += s[-1] * random.randint(1, 2)
        s = s.lower()
        if 4 <= len(s) <= 8 and s not in used and s.isalpha():
            used.add(s)
            return s
    s = (random.choice(NICK_ONSETS) + random.choice(NICK_VOWELS) + str(random.randint(1, 99))).lower()
    used.add(s)
    return s[:8]


def _pe(name: str):
    """emoji= для кнопок/опций: кастом-иконка или None (без юникод-мусора)."""
    ic = ui_icon(name)
    return ic if (ic and ic.startswith("<")) else None


class MassToolsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._sess: dict[int, dict] = {}

    def _can(self, member) -> bool:
        return has_command_access(member, "massrole") or (
            member.guild and member.id == member.guild.owner_id)

    def _session(self, uid: int) -> dict:
        return self._sess.setdefault(uid, {"roles": [], "target": "humans"})

    # ── выборка участников по фильтру ──
    @staticmethod
    def _members_for(guild, target: str) -> list[disnake.Member]:
        out = []
        for m in guild.members:
            if target == "all":
                out.append(m)
            elif target == "norole":
                if not m.bot and len(m.roles) <= 1:   # только @everyone
                    out.append(m)
            else:  # humans
                if not m.bot:
                    out.append(m)
        return out

    @staticmethod
    def _assignable(guild, role_ids):
        """Делит выбранные роли на (можно выдать, нельзя)."""
        me = guild.me
        good, bad = [], []
        for rid in role_ids:
            r = guild.get_role(int(rid))
            if not r:
                continue
            if r.is_default() or r.managed or (me and r >= me.top_role):
                bad.append(r)
            else:
                good.append(r)
        return good, bad

    # ═══════════════ ПАНЕЛЬ !massrole ═══════════════
    def _panel(self, guild, uid: int, note: str | None = None) -> Panel:
        s = self._session(uid)
        good, bad = self._assignable(guild, s["roles"])
        items = [disnake.ui.TextDisplay(f"## {ui_icon('perm')} Массовая выдача ролей · !massrole")]
        if note:
            items.append(disnake.ui.TextDisplay(note))

        sel_txt = ", ".join(f"**{r.name}**" for r in good) if good else "—"
        warn = (f"\n-# ⚠️ Нельзя выдать (выше роли бота/системные): "
                f"{', '.join(r.name for r in bad)}" if bad else "")
        n_targets = len(self._members_for(guild, s["target"]))
        items.append(disnake.ui.TextDisplay(
            f"**Выбранные роли:** {sel_txt}{warn}\n"
            f"**Кому:** {TARGET_LABELS[s['target']]} — сейчас это **{n_targets}** участников.\n"
            "-# Выбери роли и кому, затем «Выдать всем» или «Забрать у всех»."))

        items.append(disnake.ui.ActionRow(disnake.ui.RoleSelect(
            custom_id=cid("mass", "roles"), placeholder="Выбрать роли (можно несколько)…",
            min_values=0, max_values=10)))

        opts = [disnake.SelectOption(label=TARGET_LABELS[k], value=k, default=(k == s["target"]))
                for k in TARGET_LABELS]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("mass", "target"), placeholder="Кому выдавать…", options=opts)))

        B = disnake.ButtonStyle
        ready = bool(good)
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="Выдать всем", emoji=_pe("perm_grant"),
                              disabled=not ready, custom_id=cid("mass", "apply", "add")),
            disnake.ui.Button(style=B.danger, label="Забрать у всех", emoji=_pe("perm_revoke"),
                              disabled=not ready, custom_id=cid("mass", "apply", "remove")),
            disnake.ui.Button(style=B.secondary, label="Сброс", emoji=_pe("perm_clear"),
                              custom_id=cid("mass", "clear"))))

        p = Panel()
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    def _simple(self, text: str, color=COMMAND_COLOR):
        p = Panel()
        p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(text),
                                        accent_colour=disnake.Colour(color)))
        return p.components

    # ── обработчики панели ──
    @commands.Cog.listener("on_dropdown")
    async def _mass_drop(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("mass:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("🔒 Нет доступа.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        if action == "roles":
            s["roles"] = list(inter.values)
        elif action == "target":
            s["target"] = inter.values[0] if inter.values else "humans"
        await inter.response.edit_message(components=self._panel(inter.guild, inter.author.id).components)

    @commands.Cog.listener("on_button_click")
    async def _mass_btn(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("mass:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("🔒 Нет доступа.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        if action == "clear":
            s.update(roles=[], target="humans")
            await inter.response.edit_message(
                components=self._panel(inter.guild, inter.author.id,
                                       f"{ui_icon('perm_clear')} Выбор сброшен.").components)
            return
        if action == "apply":
            await self._run_massrole(inter, s, args[0] if args else "add")

    async def _run_massrole(self, inter, s, mode: str):
        guild = inter.guild
        good, _bad = self._assignable(guild, s["roles"])
        if not good:
            await inter.response.edit_message(
                components=self._panel(guild, inter.author.id, "⚠️ Не выбрано ни одной выдаваемой роли.").components)
            return
        await inter.response.edit_message(components=self._simple(
            f"{ui_icon('perm')} Загружаю участников…", WARNING_COLOR))
        try:
            await guild.chunk()
        except Exception:
            log.exception("chunk() не удался")

        targets = self._members_for(guild, s["target"])
        add = (mode == "add")
        verb = "Выдаю" if add else "Забираю"
        await inter.edit_original_message(components=self._simple(
            f"{ui_icon('perm')} {verb} роли ({', '.join(r.name for r in good)}) у **{len(targets)}** "
            f"участников…\n-# Это займёт ~{int(len(targets) * 0.4 / 60) + 1} мин.", WARNING_COLOR))

        done = skipped = failed = 0
        for i, m in enumerate(targets, 1):
            if m.id == guild.owner_id and not add:
                pass  # у владельца роли забрать можно, если ниже бота — ок
            try:
                if add:
                    missing = [r for r in good if r not in m.roles]
                    if not missing:
                        skipped += 1
                    else:
                        await m.add_roles(*missing, reason=f"massrole от {inter.author}")
                        done += 1
                else:
                    have = [r for r in good if r in m.roles]
                    if not have:
                        skipped += 1
                    else:
                        await m.remove_roles(*have, reason=f"massrole от {inter.author}")
                        done += 1
            except disnake.Forbidden:
                failed += 1
            except disnake.HTTPException:
                failed += 1
            if i % 25 == 0:
                try:
                    await inter.edit_original_message(components=self._simple(
                        f"{ui_icon('perm')} {verb}… обработано **{i}/{len(targets)}** · "
                        f"изменено {done} · пропущено {skipped} · ошибок {failed}", WARNING_COLOR))
                except Exception:
                    pass
            await asyncio.sleep(0.4)

        act = "выданы" if add else "забраны"
        await inter.edit_original_message(components=self._simple(
            f"{ui_icon('perm_grant') if add else ui_icon('perm_revoke')} **Готово.** Роли {act}.\n"
            f"**Изменено:** {done}\n**Пропущено (уже так):** {skipped}\n"
            f"**Ошибок (роль выше бота/нет прав):** {failed}", SUCCESS_COLOR))

    @commands.command(name="massrole", aliases=["массроль", "выдать-всем", "роль-всем"])
    async def massrole_cmd(self, ctx: commands.Context):
        if not ctx.guild:
            return
        if not self._can(ctx.author):
            await ctx.send(embed=disnake.Embed(
                description="🔒 Выдавать роли массово может владелец сервера или обладатель доступа (`!perm`).",
                color=ERROR_COLOR))
            return
        self._session(ctx.author.id).update(roles=[], target="humans")
        await ctx.send(components=self._panel(ctx.guild, ctx.author.id).components)

    # ═══════════════ !resetnicks ═══════════════
    @commands.command(name="resetnicks", aliases=["сбросить-ники", "сброс-ников", "resetnicknames"])
    async def resetnicks_cmd(self, ctx: commands.Context, confirm: str = ""):
        if not ctx.guild:
            return
        if not has_command_access(ctx.author, "resetnicks") and ctx.author.id != ctx.guild.owner_id:
            await ctx.send(embed=disnake.Embed(
                description="🔒 Сбрасывать ники может владелец сервера или обладатель доступа (`!perm`).",
                color=ERROR_COLOR))
            return

        loading = await ctx.send(embed=disnake.Embed(
            description="⏳ Загружаю участников…", color=COMMAND_COLOR))
        try:
            await ctx.guild.chunk()
        except Exception:
            log.exception("chunk() не удался")

        me = ctx.guild.me
        registered = self._registered_names()
        # кандидаты: есть кастомный ник, не владелец, роль ниже бота
        cand = [m for m in ctx.guild.members
                if m.nick and m.id != ctx.guild.owner_id and (not me or m.top_role < me.top_role)]

        if confirm.lower() not in ("confirm", "да", "yes", "подтвердить"):
            await loading.edit(embed=disnake.Embed(
                title=f"{ui_icon('perm_clear')} Сброс никнеймов — предпросмотр",
                description=(f"Сейчас свой ник имеют (и мы можем изменить): **{len(cand)}** участников.\n"
                            f"Из них зарегистрированных игроков: **{sum(1 for m in cand if m.id in registered)}** "
                            "— им вернём корректный игровой ник (флаг + страна + строй), не пустой.\n\n"
                            "Остальным ник будет сброшен (останется имя Discord).\n"
                            "Не трогаем: владельца и тех, чья роль выше роли бота.\n\n"
                            "Выполнить: **`!resetnicks confirm`**"),
                color=WARNING_COLOR))
            return

        if not cand:
            await loading.edit(embed=disnake.Embed(
                description="Некому сбрасывать — ни у кого нет кастомного ника (из доступных боту).",
                color=COMMAND_COLOR))
            return

        from cogs.registration import _apply_nick
        countries = Countries()
        done = failed = regame = 0
        total = len(cand)
        await loading.edit(embed=disnake.Embed(
            title=f"{ui_icon('perm_clear')} Сбрасываю ники…",
            description=f"Обрабатываю **{total}** участников. ~{int(total * 0.4 / 60) + 1} мин.",
            color=WARNING_COLOR))

        for i, m in enumerate(cand, 1):
            try:
                if m.id in registered:
                    # вернуть правильный игровой ник вместо пустого
                    obj = countries.get_object_by_user(m.id)
                    if obj:
                        await _apply_nick(m, obj.name)
                        regame += 1
                    else:
                        await m.edit(nick=None, reason="resetnicks")
                        done += 1
                else:
                    await m.edit(nick=None, reason="resetnicks")
                    done += 1
            except disnake.Forbidden:
                failed += 1
            except disnake.HTTPException:
                failed += 1
            if i % 25 == 0:
                try:
                    await loading.edit(embed=disnake.Embed(
                        title=f"{ui_icon('perm_clear')} Сбрасываю ники…",
                        description=f"Обработано **{i}/{total}** · сброшено {done} · "
                                    f"игровых восстановлено {regame} · ошибок {failed}",
                        color=WARNING_COLOR))
                except Exception:
                    pass
            await asyncio.sleep(0.4)

        await loading.edit(embed=disnake.Embed(
            title="✅ Ники сброшены",
            description=(f"**Сброшено в обычное имя:** {done}\n"
                         f"**Игрокам возвращён игровой ник:** {regame}\n"
                         f"**Ошибок (роль выше бота/нет прав):** {failed}"),
            color=SUCCESS_COLOR))

    # ═══════════════ !rabbitnicks ═══════════════
    @commands.command(name="rabbitnicks", aliases=["rabbit", "фикс-рэббит", "рэббит", "фиксники"])
    async def rabbitnicks_cmd(self, ctx: commands.Context, confirm: str = ""):
        """Всем, у кого ник «RabbitBoost» (накрутка), ставит красивый сгенерированный ник."""
        if not ctx.guild:
            return
        if not has_command_access(ctx.author, "rabbitnicks") and ctx.author.id != ctx.guild.owner_id:
            await ctx.send(embed=disnake.Embed(
                description="🔒 Доступно владельцу сервера или по `!perm rabbitnicks`.",
                color=ERROR_COLOR))
            return

        loading = await ctx.send(embed=disnake.Embed(
            description="⏳ Загружаю участников…", color=COMMAND_COLOR))
        try:
            await ctx.guild.chunk()
        except Exception:
            log.exception("chunk() не удался")

        me = ctx.guild.me
        # кандидаты: ЗАШЛИ 10.10.2026 (по МСК), не владелец, роль ниже бота, не бот
        cand = [m for m in ctx.guild.members
                if not m.bot and m.id != ctx.guild.owner_id
                and (not me or m.top_role < me.top_role)
                and m.joined_at and m.joined_at.astimezone(MSK).date() == RABBIT_JOIN_DATE]

        if confirm.lower() not in ("confirm", "да", "yes", "подтвердить"):
            sample = ", ".join(generate_nick(set()) for _ in range(3))
            await loading.edit(embed=disnake.Embed(
                title="✨ Смена ников зашедшим 10.10.2026 — предпросмотр",
                description=(f"Зашло на сервер **{RABBIT_JOIN_DATE.isoformat()}** (МСК): **{len(cand)}** участников.\n"
                            f"Каждому поставим уникальный рандомный ник.\n\n"
                            f"Примеры того, что будет: *{sample}*\n\n"
                            "Не трогаем: владельца, ботов и роли выше роли бота.\n\n"
                            "Выполнить: **`!rabbitnicks confirm`**"),
                color=WARNING_COLOR))
            return

        if not cand:
            await loading.edit(embed=disnake.Embed(
                description="Никого с ником **RabbitBoost** не нашёл (из доступных боту).",
                color=COMMAND_COLOR))
            return

        used = {(m.nick or m.name or "").lower() for m in ctx.guild.members}
        done = failed = 0
        total = len(cand)
        await loading.edit(embed=disnake.Embed(
            title="✨ Генерирую и ставлю ники…",
            description=f"Обрабатываю **{total}** участников. ~{int(total * 0.4 / 60) + 1} мин.",
            color=WARNING_COLOR))

        for i, m in enumerate(cand, 1):
            try:
                await m.edit(nick=generate_nick(used), reason=f"rabbitnicks от {ctx.author}")
                done += 1
            except disnake.Forbidden:
                failed += 1
            except disnake.HTTPException:
                failed += 1
            if i % 25 == 0:
                try:
                    await loading.edit(embed=disnake.Embed(
                        title="✨ Генерирую и ставлю ники…",
                        description=f"Обработано **{i}/{total}** · поставлено {done} · ошибок {failed}",
                        color=WARNING_COLOR))
                except Exception:
                    pass
            await asyncio.sleep(0.4)

        await loading.edit(embed=disnake.Embed(
            title="✅ Ники обновлены",
            description=(f"**Поставлено красивых ников:** {done}\n"
                         f"**Ошибок (роль выше бота/нет прав):** {failed}"),
            color=SUCCESS_COLOR))

    @staticmethod
    def _registered_names() -> set[int]:
        ids = set()
        try:
            for r in Countries()._query_all("SELECT user FROM countries"):
                try:
                    ids.add(int(r["user"]))
                except (TypeError, ValueError, KeyError):
                    pass
        except Exception:
            log.exception("Не удалось получить зарегистрированных")
        return ids


def setup(bot: commands.Bot):
    bot.add_cog(MassToolsCog(bot))
