"""
📜 ПРАВИЛА СЕРВЕРА — !rules / !правила

Публикует штаб (perm "rules") в указанный канал, иначе в канал правил (CH_RULES) или текущий:
шапка-баннер «Правила сервера» + по посту на каждый раздел (§1–§5) с баннером.
Официальные правила сообщества (не игровые). Пункты пронумерованы — на них
ссылается администрация при наказаниях.
Тексты — utils/rules_text.py, баннеры — scripts/gen_rules_banners.py.
Только кастом-иконки.
"""

import time
from pathlib import Path

import disnake
from disnake.ext import commands

from utils import COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR
from utils.ui import Panel
from utils.resources import ui_icon
from utils.serverconfig import rid
from utils.perms import has_command_access
import utils.rules_text as RT

BRAND = Path(__file__).resolve().parent.parent / "assets" / "brand"
HERO_FILE = "rules_hero.png"
HERO_COLOR = (108, 196, 238)


def I(slug: str) -> str:
    return ui_icon(slug)


def _gallery(filename: str):
    return disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=f"attachment://{filename}"))


def _file(filename: str):
    path = BRAND / filename
    return disnake.File(str(path), filename=filename) if path.exists() else None


def hero_post(with_image: bool) -> Panel:
    toc = "\n".join(f"{I(s['icon'])} **§{s['num']}. {s['title']}** — {s['strip']}" for s in RT.SECTIONS)
    items = [_gallery(HERO_FILE)] if with_image else []
    items += [
        disnake.ui.TextDisplay(f"## {I('resolution')} Правила сервера Nova Order\n{RT.INTRO}"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.large),
        disnake.ui.TextDisplay(f"-# СОДЕРЖАНИЕ\n{toc}"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(
            f"{I('un_condemn')} Меры воздействия применяются со ссылкой на пункт правил (например, «п. 3.2»)."),
    ]
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(RT.rgb_int(HERO_COLOR))))
    return p


def section_post(sec: dict, with_image: bool, last: bool = False) -> Panel:
    items = ([_gallery(f"rules_{sec['num']}.png")] if with_image else
             [disnake.ui.TextDisplay(f"## {I(sec['icon'])} §{sec['num']}. {sec['title']}")])
    points = "\n\n".join(f"**{num}**  {text}" for num, text in sec["points"])
    items.append(disnake.ui.TextDisplay(points))
    if last:
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(
            f"-# {I('resolution')} Администрация Nova Order · редакция от <t:{int(time.time())}:D>"))
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(RT.rgb_int(sec["color"]))))
    return p


class RulesCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _send(self, channel, panel: Panel, filename: str | None):
        f = _file(filename) if filename else None
        if f:
            await channel.send(components=panel.components, file=f)
        else:
            await channel.send(components=panel.components)

    @commands.command(name="rules", aliases=["правила", "кодекс"])
    async def rules_cmd(self, ctx: commands.Context, channel: disnake.TextChannel | None = None):
        """ШТАБ: опубликовать правила в указанный канал (иначе — канал правил или текущий)."""
        if not has_command_access(ctx.author, "rules"):
            await ctx.send(embed=disnake.Embed(
                description=f"{I('lock')} Правила публикует штаб. Читай их в канале правил.", color=ERROR_COLOR))
            return
        bound = ctx.guild.get_channel(rid("CH_RULES", 0)) if ctx.guild else None
        # в привязке может оказаться категория/голосовой — публикуем только в текстовый канал
        target = channel or (bound if isinstance(bound, disnake.TextChannel) else None) or ctx.channel
        hero = (BRAND / HERO_FILE).exists()
        await self._send(target, hero_post(hero), HERO_FILE if hero else None)
        for i, sec in enumerate(RT.SECTIONS):
            fname = f"rules_{sec['num']}.png"
            has = (BRAND / fname).exists()
            await self._send(target, section_post(sec, has, last=(i == len(RT.SECTIONS) - 1)),
                             fname if has else None)
        if target.id != ctx.channel.id:
            await ctx.send(embed=disnake.Embed(
                description=f"{I('check')} Правила опубликованы в {target.mention}.", color=SUCCESS_COLOR))
        else:
            try:
                await ctx.message.delete()
            except Exception:
                pass


def setup(bot: commands.Bot):
    bot.add_cog(RulesCog(bot))
