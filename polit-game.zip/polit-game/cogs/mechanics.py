"""
📚 МЕНЮ МЕХАНИК — !mechanics

Публичная витрина «как устроена игра» (не путать с !guide — лёгким обучением).
Публикует штаб: шапка-баннер + 4 раздела (Экономика · Государство · Армия и война ·
Дипломатия). В разделе каждая механика — строка «название + кнопка «Подробнее»»,
между механиками разделители. Кнопка открывает ПОДРОБНУЮ панель, видимую только
нажавшему (эфемерно), с переходами к связанным механикам.

Состояние не хранится — ключ механики в custom_id, поэтому кнопки работают и после
рестарта. Баннеры: scripts/gen_mech_banners.py. Тексты: utils/mechanics_text.py.
Только кастом-эмодзи (ui_icon в тексте, emoji= в кнопках).
"""

from pathlib import Path

import disnake
from disnake.ext import commands

from utils import COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, has_command_access
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
import utils.mechanics_text as MT

BRAND = Path(__file__).resolve().parent.parent / "assets" / "brand"
HERO_FILE = "mech_hero.png"


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def I(slug: str) -> str:
    return ui_icon(slug)


def _color(cat: str) -> disnake.Colour:
    return disnake.Colour(MT.rgb_int(MT.CATEGORIES[cat]["color"]))


def _gallery(filename: str):
    return disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=f"attachment://{filename}"))


def _file(filename: str) -> disnake.File | None:
    path = BRAND / filename
    return disnake.File(str(path), filename=filename) if path.exists() else None


# ═══════════════ ПУБЛИЧНЫЕ ПОСТЫ ═══════════════
def hero_post(with_image: bool) -> Panel:
    toc = "\n".join(
        f"{I(c['icon'])} **{c['num']}. {c['title']}** — {c['strip']}" for c in MT.CATEGORIES.values())
    items = []
    if with_image:
        items.append(_gallery(HERO_FILE))
    items += [
        disnake.ui.TextDisplay(
            f"## {I('guide')} Механики мира Nova Order\n"
            "Полный справочник: как устроена каждая система игры, из чего она складывается "
            "и как связана с остальными."),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.large),
        disnake.ui.TextDisplay(f"-# СОДЕРЖАНИЕ\n{toc}"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(
            f"{I('check')} Нажми **«Подробнее»** у любой механики — откроется подробная панель, "
            "которую видишь **только ты**.\n"
            f"-# Новичку — сначала `!guide` (короткое обучение), затем этот справочник."),
    ]
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


def category_post(cat: str, with_image: bool) -> Panel:
    meta = MT.CATEGORIES[cat]
    items = []
    if with_image:
        items.append(_gallery(f"mech_cat_{cat}.png"))
    else:
        items.append(disnake.ui.TextDisplay(f"## {I(meta['icon'])} {meta['num']}. {meta['title']}"))
    keys = MT.ORDER[cat]
    for i, key in enumerate(keys):
        m = MT.MECHANICS[key]
        items.append(disnake.ui.Section(
            disnake.ui.TextDisplay(f"### {I(m['icon'])} {m['title']}\n{m['tagline']}\n-# {m['cmd']}"),
            accessory=disnake.ui.Button(
                style=disnake.ButtonStyle.primary, label="Подробнее", emoji=_pe(m["icon"]),
                custom_id=cid("mech", "open", key))))
        if i < len(keys) - 1:
            items.append(disnake.ui.Separator())
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=_color(cat)))
    return p


# ═══════════════ ПОДРОБНАЯ ПАНЕЛЬ (эфемерно) ═══════════════
def detail_text(key: str) -> list[str]:
    """Блоки текста подробной панели (отдельно — чтобы тест проверял лимит 4000)."""
    m = MT.MECHANICS[key]
    cat = MT.CATEGORIES[m["cat"]]
    blocks = [
        f"## {I(m['icon'])} {m['title']}\n-# {cat['num']}. {cat['title']} · {m['cmd']}",
        m["what"],
        f"### {I('tools')} Как это работает\n" + "\n".join(f"{I(s)} {t}" for s, t in m["how"]),
        f"### {I('warplan')} Как играть\n" + "\n".join(f"**{n}.** {t}" for n, t in enumerate(m["play"], 1)),
    ]
    if m.get("links"):
        blocks.append(f"### {I('globe')} Связь с другими механиками\n"
                      + "\n".join(f"{I(s)} {t}" for s, t in m["links"]))
    blocks.append(f"### {I('guide')} Команды\n" + "\n".join(f"`{c}` — {d}" for c, d in m["cmds"]))
    return blocks


def detail_panel(key: str) -> Panel:
    m = MT.MECHANICS[key]
    blocks = detail_text(key)
    items = [disnake.ui.TextDisplay(blocks[0]), disnake.ui.Separator(),
             disnake.ui.TextDisplay(blocks[1]), disnake.ui.Separator()]
    for b in blocks[2:]:
        items.append(disnake.ui.TextDisplay(b))
    related = [k for k in m.get("related", []) if k in MT.MECHANICS][:5]
    if related:
        items.append(disnake.ui.Separator(spacing=disnake.SeparatorSpacing.large))
        items.append(disnake.ui.TextDisplay("-# СВЯЗАННЫЕ МЕХАНИКИ"))
        items.append(disnake.ui.ActionRow(*[
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label=MT.MECHANICS[k]["title"][:80],
                              emoji=_pe(MT.MECHANICS[k]["icon"]), custom_id=cid("mech", "go", k))
            for k in related]))
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=_color(m["cat"])))
    return p


class MechanicsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_button_click")
    async def _mech_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("mech:"):
            return
        _, action, args = parse_cid(c)
        key = args[0] if args else ""
        if key not in MT.MECHANICS:
            return
        if action == "open":     # из публичного меню → новая панель только для нажавшего
            await inter.response.send_message(components=detail_panel(key).components, ephemeral=True)
        elif action == "go":     # переход внутри своей панели
            await inter.response.edit_message(components=detail_panel(key).components)

    async def _send(self, channel, panel: Panel, filename: str | None):
        f = _file(filename) if filename else None
        if f:
            await channel.send(components=panel.components, file=f)
        else:
            await channel.send(components=panel.components)

    @commands.command(name="mechanics", aliases=["механики", "mech", "справочник"])
    async def mechanics_cmd(self, ctx: commands.Context, channel: disnake.TextChannel | None = None):
        """ШТАБ: опубликовать меню механик в текущем (или указанном) канале."""
        if not has_command_access(ctx.author, "mechanics"):
            await ctx.send(embed=disnake.Embed(
                description=f"{I('lock')} Меню механик публикует штаб (`!perm`). "
                            "Читай его в информационном канале.", color=ERROR_COLOR))
            return
        target = channel or ctx.channel
        hero_img = (BRAND / HERO_FILE).exists()
        await self._send(target, hero_post(hero_img), HERO_FILE if hero_img else None)
        for cat in MT.CATEGORIES:
            fname = f"mech_cat_{cat}.png"
            has = (BRAND / fname).exists()
            await self._send(target, category_post(cat, has), fname if has else None)
        if target.id != ctx.channel.id:
            await ctx.send(embed=disnake.Embed(
                description=f"{I('check')} Меню механик опубликовано в {target.mention}.", color=SUCCESS_COLOR))
        else:
            try:
                await ctx.message.delete()
            except Exception:
                pass


def setup(bot: commands.Bot):
    bot.add_cog(MechanicsCog(bot))
