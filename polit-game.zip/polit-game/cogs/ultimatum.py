"""
⏳ УЛЬТИМАТУМЫ — !ultimatum

Страна публично требует что-то у другой под угрозой последствий. Решает игрок-цель
(Принять / Отклонить / Контрпредложение) до дедлайна. РЕАЛИЗМ СИЛЫ: слабый не может
давить сильного — power ratio режет требования (потолки) и «зубастость» угрозы
(leverage) — см. utils/ultimatum. Территория при принятии передаётся на карте авто.
Отказ → casus belli (война — куратор) + опц. блокада (авто income_mult).

Билдер — приватно в ЛС; сам ультиматум публикуется в #ультиматумы с кнопками.
Стиль: Components V2, кастом-иконки, defer, анти-дыры, минимум обычных эмодзи.
"""

import json
import logging
import random
import time

import disnake
from disnake.ext import commands, tasks

from utils import (
    Countries, Settings, Effects, Army, Equipment, Cooldown, Ultimatums, MapState,
    update_money, int_format, string_to_number,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon, res_icon, res_label, RESOURCE_SLUG
from utils.serverconfig import rid
from utils.upgrades import country_income
import utils.ultimatum as UL
import utils.army as ARM
import utils.worldmap as WM

log = logging.getLogger("ultimatum")

RESOURCES = list(RESOURCE_SLUG.keys())
_PAGE = 25
_DAY = 86400
DEADLINE_CHOICES = [6, 12, 24, 48]


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _num(raw: str):
    raw = (raw or "").strip().replace(" ", "")
    try:
        return int(float(raw))
    except (ValueError, TypeError):
        pass
    try:
        v = string_to_number(raw)
        return int(v) if v is not None else None
    except Exception:
        return None


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


class UltimatumCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.settings = Settings()
        self.effects = Effects()
        self.army = Army()
        self.equip = Equipment()
        self.cooldown = Cooldown()
        self.ult = Ultimatums()
        self.mapstate = MapState()
        self._sessions: dict[int, dict] = {}
        self.deadline_tick.start()

    def cog_unload(self):
        self.deadline_tick.cancel()

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    # ───── сессия ─────
    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "target": None, "demands": [], "deadline": UL.DEADLINE_DEF_H,
                 "consequence": "war", "pend": None, "res": None}
            self._sessions[uid] = s
        return s

    def _actor(self, uid: int):
        return self.countries.get_object_by_user(uid)

    # ───── сила / рычаг / потолки ─────
    def _power(self, name: str) -> float:
        o = self.countries.get_object(name)
        if not o:
            return 1.0
        now = int(time.time())
        academy = self.army.building_count(name, "academy")
        hap = getattr(o, "happiness", 50.0) or 0.0
        stab = getattr(o, "stability", 50.0) or 0.0
        forms = self.army.formations_for(name)
        army_power = sum(ARM.formation_power(f["template"], academy, hap, stab)
                         for f in forms if now >= f["ready_at"])
        arsenal = sum(self.equip.category_counts(name).values())
        income = country_income(name)
        return UL.power_score(army_power, arsenal, income, o.population, o.territory)

    def _ratio(self, issuer: str, target: str) -> float:
        return UL.power_ratio(self._bloc_power(issuer), self._bloc_power(target))

    def _bloc_power(self, name: str) -> float:
        """Сила страны + военные союзники (с весом): давить на страну с сильным
        союзником сложнее, а за спиной у сильного союзника — проще."""
        al = self.bot.get_cog("AllianceCog")
        allies = al.ult_allies(name) if al else []   # члены военного блока × сплочённость
        nuc = self.bot.get_cog("NuclearCog")
        deter = nuc.deter_mult(name) if nuc else 1.0   # ядерное сдерживание (свой арсенал или зонтик блока)
        return (self._power(name) + sum(w * self._power(a) for a, w in allies)) * deter

    def _caps(self, issuer: str, target: str, ratio: float) -> dict:
        t = self.countries.get_object(target)
        res = self.settings.get_resources(target)
        forms = len(self.army.formations_for(target))
        return {
            "money": UL.money_cap(t.money if t else 0, ratio),
            "resource": {r: UL.resource_cap(res.get(r, 0), ratio) for r in RESOURCES},
            "territory": UL.territory_cap(ratio),
            "demilitarize": UL.demil_cap(forms, ratio),
        }

    # ═══════════════ ПАНЕЛЬ (билдер, ЛС) ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('ultimatum')} Ультиматумы")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _render(self, uid, note=None) -> Panel:
        s = self._session(uid)
        actor = self._actor(uid)
        if not actor:
            return self._container(self._head(note) + [disnake.ui.TextDisplay(
                "-# У вас нет страны. Откройте панель регистрации.")], WARNING_COLOR)
        if s["view"] == "build":
            return self._panel_build(uid, actor, note)
        return self._panel_hub(uid, actor, note)

    def _panel_hub(self, uid, actor, note=None):
        items = self._head(note)
        issued = self.ult.pending_by_issuer(actor.name)
        incoming = self.ult.pending_for_target(actor.name)
        lines = [f"### {actor.flag} {actor.name}"]
        if issued:
            lines.append("-# ВЫ ВЫДВИНУЛИ:")
            for u in issued[:5]:
                tgt = self.countries.get_object(u["target"])
                lines.append(f"→ {(tgt.flag + ' ') if tgt else ''}{u['target']} · "
                             f"{self._demands_short(u['demands'])}")
        if incoming:
            lines.append(f"-# ВАМ ВЫДВИНУЛИ: **{len(incoming)}** (ответьте в #ультиматумы)")
        if not issued and not incoming:
            lines.append("-# Активных ультиматумов нет.")
        items.append(disnake.ui.TextDisplay("\n".join(lines)))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(disnake.ui.Button(
            style=disnake.ButtonStyle.danger, label="Выдвинуть ультиматум",
            emoji=_pe("ultimatum"), custom_id=cid("ult", "goto", "build"))))
        return self._container(items)

    def _panel_build(self, uid, actor, note=None):
        s = self._session(uid)
        items = self._head(note)
        target = s["target"]
        if not target:
            names = sorted(n for n in self.countries.get_object_names() if n != actor.name)
            items.append(disnake.ui.TextDisplay("### Кому выдвигаем?"))
            if names:
                opts = [disnake.SelectOption(label=f"{(self.countries.get_object(n).flag)} {n}"[:100],
                                             value=n) for n in names[:25]]
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("ult", "target"), placeholder="Выберите цель…", options=opts)))
            else:
                items.append(disnake.ui.TextDisplay("-# Нет других стран."))
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.secondary, label="Назад", emoji=_pe("prev"),
                custom_id=cid("ult", "goto", "hub"))))
            return self._container(items)

        tobj = self.countries.get_object(target)
        ratio = self._ratio(actor.name, target)
        lev = UL.leverage(ratio)
        caps = self._caps(actor.name, target, ratio)
        serious = UL.is_serious(ratio)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('ultimatum')} Цель: {tobj.flag} {target}\n"
            f"{ui_icon('attack')} Рычаг: **{lev:.0f}/100** · соотношение сил **×{ratio:.2f}**\n"
            + ("" if serious else
               "-# ⚠ Цель несопоставимо сильнее — серьёзных требований выставить нельзя (блеф).\n")
            + f"-# Потолки: {ui_icon('money')} {int_format(caps['money'])} · "
              f"{ui_icon('globe')} области до **{caps['territory']}** · "
              f"{ui_icon('disband')} демил. до **{caps['demilitarize']}**"))
        # текущие требования
        if s["demands"]:
            dl = "\n".join(f"• {self._one_demand_text(d)}" for d in s["demands"])
            items.append(disnake.ui.TextDisplay(f"-# ТРЕБОВАНИЯ:\n{dl}"))
        # добавить требование
        dopts = []
        for k, meta in UL.DEMANDS.items():
            cap_ok = True
            if meta["material"]:
                if k == "money":
                    cap_ok = caps["money"] > 0
                elif k == "resource":
                    cap_ok = any(v > 0 for v in caps["resource"].values())
                elif k == "territory":
                    cap_ok = caps["territory"] > 0
                elif k == "demilitarize":
                    cap_ok = caps["demilitarize"] > 0
            if cap_ok:
                dopts.append(disnake.SelectOption(label=meta["label"], value=k, emoji=_pe(meta["icon"])))
        if dopts:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("ult", "adddemand"), placeholder="Добавить требование…", options=dopts)))
        # дедлайн + последствие
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("ult", "deadline"), placeholder=f"Срок: {s['deadline']} ч",
            options=[disnake.SelectOption(label=f"{h} часов", value=str(h),
                                          default=(h == s["deadline"])) for h in DEADLINE_CHOICES])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("ult", "conseq"),
            placeholder=f"Последствие отказа: {UL.CONSEQUENCES[s['consequence']]['label']}",
            options=[disnake.SelectOption(label=v["label"], value=k, emoji=_pe(v["icon"]),
                                          default=(k == s["consequence"])) for k, v in UL.CONSEQUENCES.items()])))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Выставить ультиматум",
                              emoji=_pe("ultimatum"), disabled=(not s["demands"]),
                              custom_id=cid("ult", "issue")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Очистить",
                              emoji=_pe("perm_clear"), custom_id=cid("ult", "clear")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Сменить цель",
                              custom_id=cid("ult", "retarget"))))
        return self._container(items)

    # ───── текст требований ─────
    def _one_demand_text(self, d: dict) -> str:
        t = d["type"]
        if t == "money":
            return f"{ui_icon('money')} Контрибуция {int_format(d['amount'])} {CURRENCY}"
        if t == "resource":
            return f"{res_icon(d['res'])} {res_label(d['res'])} — {int_format(d['amount'])}"
        if t == "territory":
            return f"{ui_icon('globe')} Территория — {d['amount']} обл."
        if t == "demilitarize":
            return f"{ui_icon('disband')} Демилитаризация — {d['amount']} соединений"
        if t == "apology":
            return f"{ui_icon('gov')} Публичные извинения"
        return UL.demand_label(t)

    def _demands_short(self, demands_json: str) -> str:
        try:
            ds = json.loads(demands_json)
        except Exception:
            return "—"
        return ", ".join(self._one_demand_text(d) for d in ds)

    # ═══════════════ ОБРАБОТЧИКИ БИЛДЕРА ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _ult_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("ult:"):
            return
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        v = inter.values[0]
        # действия, которые МОГУТ открыть модалку — БЕЗ defer (иначе send_modal не сработает)
        if action == "adddemand":
            await self._begin_demand(inter, s, v)
            return
        if action == "respick":
            s["res"] = v
            await self._open_amount_modal(inter, "resource")
            return
        await self._defer(inter)
        if action == "target":
            s.update(target=v, demands=[], pend=None, res=None)
        elif action == "deadline":
            s["deadline"] = int(v)
        elif action == "conseq":
            s["consequence"] = v
        await inter.edit_original_message(components=self._render(inter.author.id).components)

    async def _begin_demand(self, inter, s, dtype):
        meta = UL.DEMANDS.get(dtype)
        actor = self._actor(inter.author.id)
        if not meta or not actor or not s["target"]:
            await inter.response.edit_message(components=self._render(inter.author.id).components)
            return
        if dtype == "apology":
            s["demands"].append({"type": "apology"})
            await inter.response.edit_message(
                components=self._render(inter.author.id, "Добавлено: извинения.").components)
            return
        if dtype == "resource":
            ratio = self._ratio(actor.name, s["target"])
            caps = self._caps(actor.name, s["target"], ratio)
            opts = [disnake.SelectOption(label=f"{res_label(r)} (до {int_format(caps['resource'][r])})",
                                         value=r, emoji=_pe_res(r))
                    for r in RESOURCES if caps["resource"][r] > 0][:25]
            if not opts:
                await inter.response.edit_message(
                    components=self._render(inter.author.id, "Ресурсов для требования нет.").components)
                return
            items = self._head("Какой ресурс требовать?")
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("ult", "respick"), placeholder="Ресурс…", options=opts)))
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.secondary, label="Назад", emoji=_pe("prev"),
                custom_id=cid("ult", "goto", "build"))))
            await inter.response.edit_message(components=self._container(items).components)
            return
        # money / territory / demilitarize → модалка количества
        await self._open_amount_modal(inter, dtype)

    async def _open_amount_modal(self, inter, dtype):
        labels = {"money": "Сумма контрибуции", "territory": "Сколько областей",
                  "demilitarize": "Сколько соединений распустить", "resource": "Сколько ресурса"}
        modal = disnake.ui.Modal(
            title=UL.DEMANDS[dtype]["label"][:45], custom_id=cid("ult", "amodal", dtype),
            components=[disnake.ui.TextInput(
                label=labels.get(dtype, "Количество")[:45], custom_id="val",
                style=disnake.TextInputStyle.short, placeholder="число", required=True)])
        try:
            await inter.response.send_modal(modal)
        except Exception:
            pass

    @commands.Cog.listener("on_modal_submit")
    async def _ult_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("ult:amodal:"):
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        actor = self._actor(inter.author.id)
        _, _, args = parse_cid(c)
        dtype = args[0]
        amount = _num(inter.text_values.get("val", ""))
        if amount is None or amount <= 0 or not actor or not s["target"]:
            await inter.edit_original_message(
                components=self._render(inter.author.id, "Неверное число.").components)
            return
        ratio = self._ratio(actor.name, s["target"])
        caps = self._caps(actor.name, s["target"], ratio)
        cap = {"money": caps["money"], "territory": caps["territory"],
               "demilitarize": caps["demilitarize"],
               "resource": caps["resource"].get(s["res"], 0)}.get(dtype, 0)
        amount = _clamp(amount, 1, cap) if cap > 0 else 0
        if amount <= 0:
            await inter.edit_original_message(
                components=self._render(inter.author.id, "Потолок требования — 0 (цель слишком сильна).").components)
            return
        d = {"type": dtype, "amount": int(amount)}
        if dtype == "resource":
            d["res"] = s["res"]
        s["demands"].append(d)
        s["pend"] = None
        await inter.edit_original_message(
            components=self._render(inter.author.id, f"Добавлено: {self._one_demand_text(d)}").components)

    @commands.Cog.listener("on_button_click")
    async def _ult_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if c.startswith("ultr:"):
            await self._response_button(inter)
            return
        if not c.startswith("ult:"):
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        if action == "issue":
            await self._issue(inter)
            return
        await self._defer(inter)
        if action == "goto":
            s["view"] = args[0]
        elif action == "retarget":
            s.update(target=None, demands=[])
        elif action == "clear":
            s["demands"] = []
        await inter.edit_original_message(components=self._render(inter.author.id).components)

    # ═══════════════ ВЫСТАВЛЕНИЕ ═══════════════
    async def _issue(self, inter):
        await self._defer(inter)
        uid = inter.author.id
        s = self._session(uid)
        actor = self._actor(uid)
        target = s["target"]
        tobj = self.countries.get_object(target) if target else None
        now = int(time.time())
        if not actor or not tobj or target == actor.name or not s["demands"]:
            await inter.edit_original_message(components=self._render(uid, "Нельзя выставить.").components)
            return
        if not self._channel():
            await inter.edit_original_message(components=self._render(
                uid, "Канал #ультиматумы не настроен. Выполните `!autoconfig` или `!setupserver`.").components)
            return
        if self.ult.active_between(actor.name, target):
            await inter.edit_original_message(
                components=self._render(uid, "У вас уже есть активный ультиматум к этой стране.").components)
            return
        cdleft = int(self.cooldown.get_cooldown("ultimatum", actor.name) - now)
        if cdleft > 0:
            await inter.edit_original_message(
                components=self._render(uid, f"Перезарядка дипломатии: ещё {cdleft // 60}м.").components)
            return
        if actor.money < UL.ISSUE_COST:
            await inter.edit_original_message(
                components=self._render(uid, f"Нужно {int_format(UL.ISSUE_COST)} {CURRENCY} на выдвижение.").components)
            return
        # предоплата, кулдаун, расчёт рычага, запись
        update_money(actor.name, -UL.ISSUE_COST)
        self.cooldown.set_cooldown("ultimatum", now + UL.ULT_COOLDOWN, actor.name)
        lev = UL.leverage(self._ratio(actor.name, target))
        deadline = now + s["deadline"] * 3600
        demands_json = json.dumps(s["demands"], ensure_ascii=False)
        uid_ult = self.ult.create(actor.name, target, demands_json, s["consequence"], deadline, lev, now)
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("ultimatum", actor.name, target, f"{actor.name} предъявила ультиматум {target}")
        # публичный пост
        msg = await self._post_ultimatum(actor, tobj, uid_ult)
        if msg:
            self.ult.set_message(uid_ult, msg.id)
        s.update(view="hub", target=None, demands=[])
        await self._defer(inter)
        await inter.edit_original_message(
            components=self._render(uid, f"{ui_icon('ultimatum')} Ультиматум выставлен в #ультиматумы.").components)

    def _channel(self):
        ch_id = rid("CH_ULTIMATUM", 0)
        if not ch_id:
            return None
        g = self.bot.get_guild(GUILD_ID)
        return (g.get_channel(ch_id) if g else None) or self.bot.get_channel(ch_id)

    async def _post_ultimatum(self, actor, tobj, uid_ult):
        u = self.ult.get(uid_ult)
        channel = self._channel()
        if not channel:
            return None
        cons = UL.CONSEQUENCES[u["consequence"]]
        left = max(0, u["deadline"] - int(time.time()))
        body = (f"{ui_icon('ultimatum')} **УЛЬТИМАТУМ**\n"
                f"{actor.flag} **{actor.name}** → {tobj.flag} **{tobj.name}**\n\n"
                f"-# ТРЕБОВАНИЯ:\n{self._demands_short(u['demands'])}\n\n"
                f"-# Последствие отказа: {ui_icon(cons['icon'])} {cons['label']}\n"
                f"-# Срок: **{left // 3600} ч** · рычаг **{u['leverage']:.0f}/100**\n"
                f"-# Ответить может только {tobj.flag} {tobj.name}.")
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(body),
            disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Принять",
                                  emoji=_pe("accept"), custom_id=cid("ultr", "accept", str(uid_ult))),
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Отклонить",
                                  emoji=_pe("reject"), custom_id=cid("ultr", "reject", str(uid_ult))),
                disnake.ui.Button(style=disnake.ButtonStyle.primary, label="Контрпредложение",
                                  emoji=_pe("counter"), custom_id=cid("ultr", "counter", str(uid_ult))),
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Отозвать",
                                  custom_id=cid("ultr", "withdraw", str(uid_ult)))),
            accent_colour=disnake.Colour(WARNING_COLOR)))
        try:
            return await channel.send(components=p.components)
        except Exception:
            return None

    # ═══════════════ ОТВЕТ НА УЛЬТИМАТУМ (публичные кнопки) ═══════════════
    async def _response_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        _, action, args = parse_cid(c)
        uid_ult = int(args[0]) if args and args[0].isdigit() else 0
        u = self.ult.get(uid_ult)
        if not u:
            await inter.response.send_message("Ультиматум не найден.", ephemeral=True)
            return
        issuer = self.countries.get_object(u["issuer"])
        target = self.countries.get_object(u["target"])
        if not issuer or not target:
            await inter.response.send_message("Одна из стран больше не существует.", ephemeral=True)
            return
        # контрпредложение: решает ИНИЦИАТОР
        if action in ("caccept", "creject"):
            if u["status"] != "countered":
                await inter.response.send_message("Контрпредложение неактуально.", ephemeral=True)
                return
            if inter.author.id != issuer.user:
                await inter.response.send_message("Решать по контрпредложению может только инициатор.", ephemeral=True)
                return
            await self._defer(inter)
            if action == "caccept":
                await self._resolve_accept(inter, u, issuer, target)
            else:
                await self._resolve_reject(inter, u, issuer, target, expired=False)
            return
        # остальное — только по активному (pending)
        if u["status"] != "pending":
            await inter.response.send_message("Этот ультиматум уже неактуален.", ephemeral=True)
            return
        if action == "withdraw":
            if inter.author.id != issuer.user:
                await inter.response.send_message("Отозвать может только инициатор.", ephemeral=True)
                return
            await self._defer(inter)
            self.ult.set_status(uid_ult, "withdrawn")
            await self._finalize_post(inter, u, f"{ui_icon('reject')} {issuer.flag} {issuer.name} отозвал(а) ультиматум.")
            return
        # accept/reject/counter — только цель
        if inter.author.id != target.user:
            await inter.response.send_message("Отвечать может только страна-цель.", ephemeral=True)
            return
        await self._defer(inter)
        if action == "accept":
            await self._resolve_accept(inter, u, issuer, target)
        elif action == "reject":
            await self._resolve_reject(inter, u, issuer, target, expired=False)
        elif action == "counter":
            await self._resolve_counter(inter, u, issuer, target)

    async def _finalize_post(self, inter, u, note: str):
        """Заменяет кнопки под постом на итоговый текст."""
        try:
            p = Panel(timeout=None)
            p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(note),
                                            accent_colour=disnake.Colour(COMMAND_COLOR)))
            await inter.edit_original_message(components=p.components)
        except Exception:
            pass

    async def _resolve_accept(self, inter, u, issuer, target):
        demands = json.loads(u["demands"])
        lines = self._apply_demands(issuer, target, demands)
        # унижение цели + дип. победа инициатора
        weight = min(1.0, 0.2 + 0.2 * len(demands))
        hit = int(round(random.randint(*UL.ACCEPT_HUMILIATION) * weight))
        self._adj(target.name, happiness=-hit)
        self._adj(issuer.name, happiness=UL.ACCEPT_ISSUER_HAPPY)
        self.ult.set_status(u["id"], "accepted")
        note = (f"{ui_icon('accept')} **УЛЬТИМАТУМ ПРИНЯТ**\n"
                f"{target.flag} {target.name} уступил(а) требованиям {issuer.flag} {issuer.name}.\n\n"
                + "\n".join(lines) + f"\n-# {target.flag} {target.name}: −{hit} счастья (унижение).")
        await self._finalize_post(inter, u, note)

    async def _resolve_reject(self, inter, u, issuer, target, expired: bool):
        lev = u["leverage"]
        self.ult.set_status(u["id"], "expired" if expired else "rejected")
        extra = []
        if not expired:
            stab_hit = UL.reject_stability_hit(lev)
            if stab_hit > 0:
                self._adj(target.name, stability=-stab_hit)
                extra.append(f"{target.flag} {target.name}: −{stab_hit} стабильности (военная паника).")
            if UL.is_bluff(lev):
                self._adj(issuer.name, happiness=-UL.BLUFF_HAPPY_HIT)
                extra.append(f"{issuer.flag} {issuer.name}: −{UL.BLUFF_HAPPY_HIT} счастья (пустая угроза).")
        # последствие
        now = int(time.time())
        if u["consequence"] == "blockade":
            mult = round(random.uniform(*UL.BLOCKADE_MULT), 2)
            hours = random.randint(*UL.BLOCKADE_HOURS)
            self.effects.add(target.name, "income_mult", mult, now + hours * 3600)
            extra.append(f"{ui_icon('blockade')} Блокада: доход {target.flag} {target.name} ×{mult:.2f} на {hours}ч.")
        verb = "ПРОСРОЧЕН" if expired else "ОТКЛОНЁН"
        note = (f"{ui_icon('reject')} **УЛЬТИМАТУМ {verb}**\n"
                f"{target.flag} {target.name} не уступил(а) {issuer.flag} {issuer.name}.\n"
                + ("\n" + "\n".join(extra) if extra else "")
                + f"\n\n{ui_icon('attack')} **Casus belli** для {issuer.flag} {issuer.name} — "
                  f"повод к войне (куратор, `!warmap`).")
        await self._finalize_post(inter, u, note)

    async def _resolve_counter(self, inter, u, issuer, target):
        demands = json.loads(u["demands"])
        for d in demands:
            if d.get("amount"):
                d["amount"] = max(1, int(d["amount"] * UL.COUNTER_FACTOR))
        self.ult.set_demands(u["id"], json.dumps(demands, ensure_ascii=False))
        self.ult.set_status(u["id"], "countered")
        note = (f"{ui_icon('counter')} **КОНТРПРЕДЛОЖЕНИЕ**\n"
                f"{target.flag} {target.name} предлагает смягчённые условия "
                f"{issuer.flag} {issuer.name}:\n\n-# {self._demands_short(json.dumps(demands, ensure_ascii=False))}\n"
                f"-# Решение — за {issuer.flag} {issuer.name}.")
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(note),
            disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Принять условия",
                                  emoji=_pe("accept"), custom_id=cid("ultr", "caccept", str(u["id"]))),
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Отказаться",
                                  emoji=_pe("reject"), custom_id=cid("ultr", "creject", str(u["id"])))),
            accent_colour=disnake.Colour(COMMAND_COLOR)))
        try:
            await inter.edit_original_message(components=p.components)
        except Exception:
            pass

    # ───── применение требований ─────
    def _apply_demands(self, issuer, target, demands) -> list[str]:
        lines = []
        for d in demands:
            t = d["type"]
            if t == "money":
                amt = min(int(d["amount"]), max(0, self.countries.get_object(target.name).money))
                if amt > 0:
                    update_money(target.name, -amt)
                    update_money(issuer.name, amt)
                lines.append(f"{ui_icon('money')} Контрибуция: {int_format(amt)} {CURRENCY} → {issuer.flag} {issuer.name}")
            elif t == "resource":
                res = d["res"]
                have = self.settings.get_resources(target.name).get(res, 0)
                amt = min(int(d["amount"]), have)
                if amt > 0:
                    self.settings.add_resource(target.name, res, -amt)
                    self.settings.add_resource(issuer.name, res, amt)
                lines.append(f"{res_icon(res)} {res_label(res)}: {int_format(amt)} → {issuer.flag} {issuer.name}")
            elif t == "territory":
                moved = self._transfer_territory(issuer, target, int(d["amount"]))
                lines.append(f"{ui_icon('globe')} Территория: передано **{moved}** обл. → {issuer.flag} {issuer.name}")
            elif t == "demilitarize":
                n = self._demilitarize(target.name, int(d["amount"]))
                lines.append(f"{ui_icon('disband')} Демилитаризация: распущено **{n}** соединений")
            elif t == "apology":
                self._adj(target.name, happiness=-3)
                lines.append(f"{ui_icon('gov')} Публичные извинения принесены.")
        return lines

    def _transfer_territory(self, issuer, target, count) -> int:
        count = max(0, count)
        if count <= 0:
            return 0
        a3_t = WM.resolve_a3(target.name)
        a3_i = WM.resolve_a3(issuer.name)
        moved = 0
        if a3_t and a3_i:
            overrides = self.mapstate.overrides()
            # области цели, ещё не отданные кому-то
            regs = [r for r in WM.regions_of(a3_t) if overrides.get(r) in (None, a3_t)]
            for r in regs[:count]:
                self.mapstate.set_owner(r, a3_i)
                moved += 1
            if moved:
                self.bot.dispatch("map_dirty")
        # числовая территория (для статов/дохода) — пропорционально
        to = self.countries.get_object(target.name)
        total_reg = len(WM.regions_of(a3_t)) if a3_t else 0
        if to and total_reg and moved:
            km = int(to.territory * moved / total_reg)
            self.countries.update_object(target.name, territory=max(0, to.territory - km))
            io = self.countries.get_object(issuer.name)
            if io:
                self.countries.update_object(issuer.name, territory=io.territory + km)
        elif to and moved == 0:
            # карта недоступна — символическая передача по числу (count как % областей неизвестен)
            pass
        return moved

    def _demilitarize(self, country, count) -> int:
        forms = self.army.formations_for(country)
        n = 0
        for f in forms[:max(0, count)]:
            self.army.remove_formation(f["id"])
            n += 1
        return n

    def _adj(self, name, happiness=None, stability=None):
        o = self.countries.get_object(name)
        if not o:
            return
        if happiness is not None:
            self.countries.update_object(name, happiness=round(_clamp((o.happiness or 0) + happiness, 0, 100), 2))
        if stability is not None:
            o2 = self.countries.get_object(name)
            self.countries.update_object(name, stability=round(_clamp((o2.stability or 0) + stability, 0, 100), 2))

    # ═══════════════ ФОНОВЫЙ ЦИКЛ ДЕДЛАЙНОВ ═══════════════
    @tasks.loop(minutes=5)
    async def deadline_tick(self):
        try:
            now = int(time.time())
            channel = self._channel()
            for u in self.ult.pending_expired(now):
                issuer = self.countries.get_object(u["issuer"])
                target = self.countries.get_object(u["target"])
                if not issuer or not target:
                    self.ult.set_status(u["id"], "expired")
                    continue
                # эффекты просрочки (как мягкий отказ) + пост
                self.ult.set_status(u["id"], "expired")
                now2 = int(time.time())
                if u["consequence"] == "blockade":
                    mult = round(random.uniform(*UL.BLOCKADE_MULT), 2)
                    hrs = random.randint(*UL.BLOCKADE_HOURS)
                    self.effects.add(target.name, "income_mult", mult, now2 + hrs * 3600)
                if channel:
                    try:
                        await channel.send(embed=disnake.Embed(
                            title="Ультиматум просрочен",
                            description=(f"{target.flag} {target.name} не ответил(а) "
                                        f"{issuer.flag} {issuer.name} в срок.\n"
                                        f"{ui_icon('attack')} Casus belli для {issuer.flag} {issuer.name}."),
                            color=WARNING_COLOR))
                    except Exception:
                        pass
        except Exception:
            log.exception("сбой цикла дедлайнов ультиматумов")

    @deadline_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="ultimatum", aliases=["ультиматум", "ultimatums", "ультиматумы"])
    async def ultimatum_cmd(self, ctx: commands.Context):
        actor = self._actor(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(
                description="Ультиматумы доступны только зарегистрированным странам.", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(view="hub", target=None, demands=[], deadline=UL.DEADLINE_DEF_H, consequence="war")
        try:
            await ctx.author.send(components=self._render(ctx.author.id).components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(
                description="Не могу написать в ЛС — включите личные сообщения и повторите `!ultimatum`.",
                color=WARNING_COLOR))
            return
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('ultimatum')} Панель ультиматумов отправлена в личные сообщения.",
                color=COMMAND_COLOR), delete_after=12)


def _pe_res(name: str):
    try:
        return disnake.PartialEmoji.from_str(res_icon(name))
    except Exception:
        return None


def setup(bot: commands.Bot):
    bot.add_cog(UltimatumCog(bot))
