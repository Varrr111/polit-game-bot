import asyncio
import logging
import random
import time
from datetime import datetime

import disnake
from disnake.ext import commands, tasks

log = logging.getLogger("economy.autocollect")

from cogs.items import InventoryView
from utils import *
from utils.serverconfig import rid, sget
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon, action_icon, res_icon, res_label, PRODUCTION_BUILDINGS
import utils.politics as pol
import utils.army as army
import utils.nuclear as NU

# Как часто бот ПРОВЕРЯЕТ, кому пора выдать доход (минуты). Петля дешёвая —
# держим 1, чтобы после простоя бот быстро доплатил всем, у кого час прошёл.
CHECK_INTERVAL_MINUTES = 1
# Как часто КАЖДАЯ страна реально получает доход (секунды) — КД на выдачу.
INCOME_PERIOD_SECONDS = 3600  # раз в час
# Насыщенный акцент панели авто-дохода (ярче базового бренд-цвета).
INCOME_ACCENT = 0x1E90FF

# ── Критерии авто-дохода (значения-ЗАГЛУШКИ, тюнинг под клиента) ──
TAX_PER_CAPITA = 0.1            # налог с жителя в час
TAX_SOFT_CAP = 50_000_000      # мягкий потолок налогов/ч
LAND_RENT_PER_KM2 = 2          # рента с км² территории в час
INDUSTRY_PER_FACTORY = 400_000 # доход с одного завода/ч
HAPPINESS_PIVOT = 70           # счастье выше → бонус к доходу
HAPPINESS_BONUS_PER_POINT = 0.005  # +0.5% дохода за каждый пункт счастья сверх pivot

# Иконка строки дохода по названию источника (резолвится на момент показа).
def _source_icon(reason: str) -> str:
    return {
        "Налоги": ui_icon("coins"),
        "Земля": action_icon("deposits"),
        "Промышленность": action_icon("build"),
        "Развитие": ui_icon("upgrade"),
        "Тег сервера": ui_icon("check"),
        "Народная поддержка": ui_icon("up"),
        "Строй": ui_icon("gov"),
        "Стабильность": ui_icon("stability"),
        "Содержание армии": ui_icon("soldier"),
        "События": "✨",
    }.get(reason, "▸")


async def _swap_level_role(member, guild, new_role_id: int, old_role_id: int):
    """Безопасно выдаёт новую роль уровня и снимает старую.

    Пропускает незаданные роли (id=0) и отсутствующие на сервере, чтобы
    апгрейд/даунгрейд не падал при неполной конфигурации ролей.
    """
    new_role = guild.get_role(new_role_id) if new_role_id else None
    old_role = guild.get_role(old_role_id) if old_role_id else None
    if new_role:
        await member.add_roles(new_role)
    if old_role:
        await member.remove_roles(old_role)


def _pe(slug: str):
    """UI-слаг → PartialEmoji для emoji= кнопок (кастом-иконка бота)."""
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


class BalanceView(Panel):

    def _nuke_line(self, name: str) -> str:
        """Публичный ядерный статус (тайная программа не видна)."""
        nuc = self.cog.bot.get_cog("NuclearCog")
        st = nuc.nuc.get(name) if nuc else None
        if not st:
            return ""
        pub = NU.public_status(st["status"])
        if pub == "member" and not st["plants"] and not st["stage"]:
            return ""
        extra = f"  ·  {ui_icon('atomic')} АЭС **{st['fueled']}/{st['plants']}**" if st["plants"] else ""
        return f"\n{ui_icon(NU.npt_icon(pub))} {NU.npt_label(pub)}{extra}"
    def __init__(
        self, cog: "EconomyCog", ctx: commands.Context,
        obj: CountryObject | PMCObject | RegionObject | TerroristObject | RebelObject,
        stats: dict[str, int], licenses: list[str], inv_items: list[InventoryObject]
        ):
        super().__init__(timeout=300)
        self.cog = cog
        self.ctx = ctx
        self.obj = obj
        self.stats = stats
        self.licenses = licenses
        self.items = inv_items

        member = ctx.guild.get_member(obj.user)
        total_income = country_income(obj.name)

        gdp_line = ""

        if isinstance(obj, CountryObject):
            if obj.name in ("СССР", "Россия", "США"):
                whois = "Сверхдержава"
            elif obj.name in ("Ирак",
                "Иран",
                "Израиль",
                "Египет",
                "Саудовская Аравия",
                "Индия",
                "Китай",
                "Бразилия",
                "Аргентина",
                "ЮАР",
                "Вьетнам",
                "Великобритания",
                "Франция",
                "Испания",
                "ФРГ"):
                whois = "Держава"
            else:
                whois = "Страна"
            gdp_line = f"\n-# ВВП {int_format(country_gdp(obj.name))} {CURRENCY} (растёт с развитием)"
        if isinstance(obj, RegionObject):
            whois = "Регион"
        if isinstance(obj, PMCObject):
            whois = "ЧВК"
        if isinstance(obj, RebelObject):
            whois = "Повстанец"
        if isinstance(obj, TerroristObject):
            whois = "Террорист"

        avatar_url = None
        if member:
            avatar_url = member.display_avatar.url if member.display_avatar else member.default_avatar.url

        lgc = self.cog.bot.get_cog("LegacyCog") if isinstance(obj, CountryObject) else None
        title = lgc.title_of(obj.name) if lgc else None
        header_text = (
            f"-# {ctx.guild.name}\n"
            + (f"## {ui_icon('legacy_crown')} {title}\n-# {obj.flag} {obj.name} · легендарная держава\n" if title else
               f"## {obj.flag}  {obj.name}\n")
            + ""
            f"<@{obj.user}> · `{whois}`{gdp_line}"
        )

        balance_block = (
            f"-# {ui_icon('money')} БАЛАНС\n"
            f"# {int_format(obj.money)} {CURRENCY}\n"
            f"-# {ui_icon('up')} +{int_format(total_income)} {CURRENCY} / ч  ·  "
            f"+{int_format(total_income * 24)} {CURRENCY} / сутки"
        )

        items: list[disnake.ui.Item] = []
        if avatar_url:
            items.append(disnake.ui.Section(disnake.ui.TextDisplay(header_text),
                                            accessory=disnake.ui.Thumbnail(avatar_url)))
        else:
            items.append(disnake.ui.TextDisplay(header_text))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(balance_block))

        if isinstance(obj, CountryObject):
            pop_growth = int_format(self.cog.population_growth(obj.population, get_max=True))

            # ── Состояние государства (счастье / стабильность / строй / религия) ──
            ideo, rel = self.cog.politics.get(obj.name)
            hap = getattr(obj, "happiness", 50.0) or 0.0
            stab = getattr(obj, "stability", 50.0) or 0.0
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"-# СОСТОЯНИЕ\n"
                f"{ui_icon('happy')} Счастье **{hap:.0f}**  ·  {ui_icon('stability')} Стабильность **{stab:.0f}**\n"
                f"{pol.ideo_icon(ideo)} {pol.ideo_label(ideo)}  ·  {pol.rel_icon(rel)} {pol.rel_label(rel)}"
                + self._nuke_line(obj.name)
            ))

            # ── Армия (соединения / личный состав / техника) ──
            try:
                forms = len(self.cog.army.formations_for(obj.name))
                pool = self.cog.army.get_pool(obj.name)
                tech = Equipment().count_owned(obj.name)
                items.append(disnake.ui.Separator())
                items.append(disnake.ui.TextDisplay(
                    f"-# {ui_icon('soldier')} ВООРУЖЁННЫЕ СИЛЫ\n"
                    f"{ui_icon('form')} Соединений **{forms}**  ·  "
                    f"{ui_icon('recruit')} Резерв л/с **{int_format(pool)}**  ·  "
                    f"{ui_icon('plant')} Техники **{int_format(tech)}**"
                ))
            except Exception:
                pass

            # ── Территория / население / континент ──
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"-# {ui_icon('globe')} ТЕРРИТОРИЯ · НАСЕЛЕНИЕ · КОНТИНЕНТ\n"
                f"`{int_format(obj.territory)} км²`  ·  `{int_format(obj.population)} чел.`  ·  {obj.continent}\n"
                f"-# прирост населения  {ui_icon('up')} +{pop_growth} / ч"
            ))

            # ── Подсказки + игровой год ──
            year = sget("GAME_YEAR")
            half = sget("GAME_HALF")
            year_line = f"  ·  {ui_icon('globe')} Год **{year} ({half}/2)**" if year else ""
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"-# {ui_icon('upgrade')} `!develop` развитие  ·  {ui_icon('storage')} `!resources` ресурсы  ·  "
                f"{ui_icon('soldier')} `!army` армия{year_line}"
            ))
        else:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(f"-# СТРАНА РАСПОЛОЖЕНИЯ\n**{obj.country}**"))

        if ctx.guild.banner:
            items.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(
                ctx.guild.banner.url.replace("?size=1024", "?size=512")
            )))

        # Кнопки с custom_id (роутинг в EconomyCog.on_balance_button). В Components V2
        # колбэки .callback НЕ работают — только маршрутизация по custom_id.
        B = disnake.ButtonStyle
        nm = self.obj.name
        panel_buttons = []
        if isinstance(self.obj, CountryObject):
            panel_buttons.append(disnake.ui.Button(
                style=B.secondary, label="Ресурсы", emoji=_pe("storage"),
                custom_id=cid("bal", "res", nm)))
            panel_buttons.append(disnake.ui.Button(
                style=B.secondary, label="Армия", emoji=_pe("soldier"),
                custom_id=cid("bal", "army", nm)))
            panel_buttons.append(disnake.ui.Button(
                style=B.secondary, label="Техника", emoji=_pe("plant"),
                custom_id=cid("bal", "tech", nm)))
            if self.cog.infrastructure.get_infrastructure(nm):
                panel_buttons.append(disnake.ui.Button(
                    style=B.secondary, label="Инфраструктура", custom_id=cid("bal", "infra", nm)))
        if self.licenses:
            panel_buttons.append(disnake.ui.Button(
                style=B.secondary, label="Лицензии", emoji=_pe("license"),
                custom_id=cid("bal", "lic", nm)))
        if self.items:
            panel_buttons.append(disnake.ui.Button(
                style=B.secondary, label="Инвентарь", custom_id=cid("bal", "inv", nm)))
        if panel_buttons:
            items.append(disnake.ui.Separator())
            for i in range(0, len(panel_buttons), 5):
                items.append(disnake.ui.ActionRow(*panel_buttons[i:i + 5]))

        container = disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR))
        self.add_item(container)



class EconomyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.pmcs = PMCs()
        self.regions = Regions()
        self.terrorists = Terrorists()
        self.rebels = Rebels()
        self.items = Items()
        self.logs = Logging()
        self.settings = Settings()
        self.wars = Wars()
        self.infrastructure = Infrastructure()
        self.buildnews = BuildNews()
        self.cooldown = Cooldown()
        self.buildings = Buildings()
        self.politics = Politics()
        self.army = Army()
        self.effects = Effects()
        self.sanctions = Sanctions()

    async def cog_check(self, ctx: commands.Context) -> bool:
        """Команды кога работают у того, у кого есть роль PROFILE_ROLE.

        Админ и куратор экономики проходят всегда (чтобы могли управлять).
        """
        if not ctx.guild:
            return False
        if is_staff(ctx.author):
            return True
        if MAIN_ECO_CURATOR and ctx.guild.get_role(MAIN_ECO_CURATOR) in ctx.author.roles:
            return True
        if ctx.author.get_role(rid("PROFILE_ROLE", PROFILE_ROLE)):
            return True
        await ctx.send(embed=disnake.Embed(description="Вы не зарегистрированы.", color=ERROR_COLOR))
        return False

    async def cog_command_error(self, ctx: commands.Context, error: commands.CommandError):
        # Сообщение незарегистрированному уже отправлено в cog_check — глушим шум.
        if isinstance(error, commands.CheckFailure):
            return
        raise error

    # ───── кнопки баланса (Components V2 → роутинг по custom_id) ─────
    @commands.Cog.listener("on_button_click")
    async def on_balance_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("bal:"):
            return
        _, section, args = parse_cid(c)
        name = args[0] if args else ""
        obj = get_object(name)
        if not obj:
            await inter.response.send_message("Профиль не найден.", ephemeral=True)
            return
        # детали (ресурсы/армия/техника/…) — только владельцу профиля или штабу,
        # чтобы не обесценивать разведку (!spy). Чужим — отказ.
        if inter.author.id != getattr(obj, "user", None) and not is_staff(inter.author):
            await inter.response.send_message(
                "🔒 Это чужой профиль — детали видит только владелец. Разведка — через `!spy`.",
                ephemeral=True)
            return
        if section == "inv":
            inv = self.items.get_inventory(obj.name)
            if not inv:
                await inter.response.send_message("Инвентарь пуст.", ephemeral=True)
                return
            view = InventoryView(inv, obj, inter.author.id)
            await inter.response.send_message(components=view.components, ephemeral=True)
            return
        emb = self._balance_section_embed(obj, section)
        if emb is None:
            await inter.response.send_message("Нет данных.", ephemeral=True)
            return
        await inter.response.send_message(embed=emb, ephemeral=True)

    def _balance_section_embed(self, obj, section: str):
        name = obj.name
        flag = getattr(obj, "flag", "🏳️")
        if section == "res":
            resources = self.settings.get_resources(name)
            text = "\n".join(f"{res_icon(r)} **{res_label(r)}:** {int_format(a)}"
                             for r, a in resources.items() if a > 0) or "Склад пуст."
            return disnake.Embed(title=f"Ресурсы · {flag} {name}", description=text[:4000],
                                 color=COMMAND_COLOR)
        if section == "army":
            now = int(time.time())
            forms = self.army.formations_for(name)
            pool = self.army.get_pool(name)
            blds = self.army.get_buildings(name)
            flines = []
            for f in forms:
                status = "✅" if now >= f["ready_at"] else "⏳"
                flines.append(f"{status} {army.form_label(f['template'])} · "
                              f"{int_format(f['personnel'])} л/с")
            bl = " · ".join(f"{army.bld_label(k)}: {v}" for k, v in blds.items()) or "—"
            desc = (f"{ui_icon('recruit')} Резерв л/с: **{int_format(pool)}**\n"
                    f"{ui_icon('barracks')} Здания: {bl}\n\n"
                    f"-# СОЕДИНЕНИЯ ({len(forms)}):\n"
                    + ("\n".join(flines) if flines else "— нет соединений"))
            return disnake.Embed(title=f"Армия · {flag} {name}", description=desc[:4000],
                                 color=COMMAND_COLOR)
        if section == "tech":
            eq = Equipment()
            rows = eq.arsenal(name)
            if not rows:
                return disnake.Embed(title=f"Техника · {flag} {name}",
                                     description="Арсенал пуст.", color=COMMAND_COLOR)
            total = sum(r["count"] for r in rows)
            lines = [f"**{r['name']}** ({r['cls']}) ×{int_format(r['count'])}" for r in rows[:40]]
            extra = f"\n-# …ещё {len(rows) - 40} моделей" if len(rows) > 40 else ""
            return disnake.Embed(
                title=f"Техника · {flag} {name} · всего {int_format(total)}",
                description="\n".join(lines) + extra, color=COMMAND_COLOR)
        if section == "infra":
            inf = self.infrastructure.get_infrastructure(name)
            e = disnake.Embed(title=f"Инфраструктура · {flag} {name}", color=COMMAND_COLOR)
            labels = [("chp", "ТЭС (ТЭЦ)"), ("atomic", "АЭС"), ("hps1", "Микро ГЭС"),
                      ("hps2", "Малая ГЭС"), ("hps3", "Средняя ГЭС"), ("hps4", "Большая ГЭС")]
            any_ = False
            if inf:
                for attr, lab in labels:
                    v = getattr(inf, attr, 0)
                    if v:
                        e.add_field(name=lab, value=str(v), inline=True)
                        any_ = True
            if not any_:
                e.description = "Нет объектов инфраструктуры."
            return e
        if section == "lic":
            lic = self.items.get_licenses(name)
            return disnake.Embed(title=f"Лицензии · {flag} {name}",
                                 description="\n".join(lic) if lic else "Нет лицензий.",
                                 color=COMMAND_COLOR)
        return None

    def get_upgrade_info(self, obj: CountryObject | RegionObject | PMCObject | RebelObject | TerroristObject, level_type: str) -> tuple[int, str, int]:
        """Получить текущий уровень, название и стоимость улучшения"""
        if level_type == "trade":
            current_lvl = obj.trade_lvl if hasattr(obj, 'trade_lvl') else 0
        elif level_type == "tourism":
            current_lvl = obj.tourism_lvl if hasattr(obj, 'tourism_lvl') else 0
        elif level_type == "economy":
            current_lvl = obj.economy_lvl if hasattr(obj, 'economy_lvl') else 0
        else:
            return 0, "", 0

        if current_lvl + 1 >= len(LEVELS_CONFIG[level_type][0]):
            return current_lvl, "MAX", 0

        next_level_info = LEVELS_CONFIG[level_type][0][current_lvl + 1]  # current_lvl is next level
        return current_lvl, next_level_info[0], next_level_info[3]  # index 3 is cost

    def _compute_profile_extras(self, obj):
        stats = {}
        for m in get_all_managers():
            if m().get_object(obj.name):
                stats = m().get_stat_lvls(obj.name)
                break
        return stats, self.items.get_licenses(obj.name), self.items.get_inventory(obj.name)

    def _build_balance_view(self, inter, obj) -> "BalanceView":
        stats, licenses, inv = self._compute_profile_extras(obj)
        return BalanceView(self, inter, obj, stats, licenses, inv)

    def _is_manager(self, inter: disnake.MessageInteraction) -> bool:
        return (is_staff(inter.author)
                or (bool(MAIN_ECO_CURATOR) and inter.guild.get_role(MAIN_ECO_CURATOR) in inter.author.roles))

    async def _route_upgrade(self, inter: disnake.MessageInteraction, stat: str, objname: str):
        obj = get_object(objname)
        if not obj or inter.author.id != getattr(obj, "user", None) or not hasattr(obj, f"{stat}_lvl"):
            await inter.response.send_message("Это не ваш профиль.", ephemeral=True)
            return
        current, name, cost = self.get_upgrade_info(obj, stat)
        if name == "MAX":
            await inter.response.send_message("Уже максимальный уровень.", ephemeral=True)
            return
        if obj.money < cost:
            await inter.response.send_message(
                f"Недостаточно средств. Нужно {int_format(cost)} {CURRENCY}, у вас {int_format(obj.money)} {CURRENCY}.",
                ephemeral=True)
            return
        for m in get_all_managers():
            if m().get_object(objname):
                m().update_object(objname, money=-cost, **{f"{stat}_lvl": current + 1})
                obj = m().get_object(objname)
                break
        lvls = {"trade": TRADE_LVLS, "tourism": TOURISM_LVLS, "economy": ECONOMY_LVLS}[stat]
        new_lvl = getattr(obj, f"{stat}_lvl")
        if 0 < new_lvl < len(lvls):
            await _swap_level_role(inter.author, inter.guild, lvls[new_lvl][1], lvls[new_lvl - 1][1])
        view = self._build_balance_view(inter, obj)
        await inter.response.edit_message(components=view.components)

    def _income_panels(self, results: list, next_ts: int, banner_url: str | None = None) -> list[list]:
        """Строит насыщенные V2-панели авто-дохода (по 5 стран на сообщение).

        results: [(name, flag, breakdown, total, balance, avatar_url, pop_delta)]
        """
        cur = ui_icon("money")
        total_all = sum(r[3] for r in results)
        panels = []
        groups = [results[i:i + 5] for i in range(0, len(results), 5)]
        for gi, grp in enumerate(groups):
            items: list = []
            # Шапка с итогами — на первом сообщении плотнее.
            head = (f"## {ui_icon('coins')} Авто-доход за час\n"
                    f"-# следующая выплата <t:{next_ts}:R> · <t:{next_ts}:t>\n"
                    f"-# выдано **{len(results)}** стран(ам) · суммарно **+{int_format(total_all)} {cur}**")
            items.append(disnake.ui.TextDisplay(head))
            if banner_url and gi == 0:
                items.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(banner_url)))
            items.append(disnake.ui.Separator(divider=True))

            for name, flag, breakdown, total, balance, avatar, pop_delta in grp:
                lines = []
                for reason, inc in breakdown:
                    sign = "+" if inc >= 0 else "−"
                    lines.append(f"{_source_icon(reason)}  {reason}  **{sign}{int_format(abs(inc))} {cur}**")
                body = (f"### {flag}  {name}\n" + "\n".join(lines)
                        + f"\n**＋{int_format(total)} {cur}** на баланс"
                        + f"\n-# казна **{int_format(balance)} {cur}**"
                        + (f"  ·  👥 +{int_format(pop_delta)}/ч" if pop_delta else ""))
                if avatar:
                    items.append(disnake.ui.Section(disnake.ui.TextDisplay(body),
                                                    accessory=disnake.ui.Thumbnail(avatar)))
                else:
                    items.append(disnake.ui.TextDisplay(body))
                items.append(disnake.ui.Separator())

            items.append(disnake.ui.TextDisplay(
                f"-# {cur} национальная казна · начисление автоматически раз в час"))
            panel = Panel(timeout=None)
            panel.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(INCOME_ACCENT)))
            panels.append(panel.components)
        return panels

    # ── Критерии дохода (разнообразие источников) ──
    def _pop_tax(self, population: int) -> int:
        return min(int((population or 0) * TAX_PER_CAPITA), TAX_SOFT_CAP)

    def _industry_income(self, name: str) -> int:
        owned = self.buildings.get_buildings(name)
        factories = sum(c for k, c in owned.items() if k in PRODUCTION_BUILDINGS)
        return factories * INDUSTRY_PER_FACTORY

    def _support_bonus_frac(self, happiness: float) -> float:
        return max(0.0, (happiness or 0) - HAPPINESS_PIVOT) * HAPPINESS_BONUS_PER_POINT

    def _base_income(self, result, member, guild) -> tuple[list, int]:
        """Источники, идущие на БАЛАНС (без банка). → ([(reason, amount)], сумма)."""
        out, total = [], 0
        tax = self._pop_tax(getattr(result, "population", 0))
        if tax:
            out.append(("Налоги", tax)); total += tax
        land = int((getattr(result, "territory", 0) or 0) * LAND_RENT_PER_KM2)
        if land:
            out.append(("Земля", land)); total += land
        ind = self._industry_income(result.name)
        if ind:
            out.append(("Промышленность", ind)); total += ind
        dev = country_income(result.name)
        if dev:
            out.append(("Развитие", dev)); total += dev
        pg = getattr(member, "primary_guild", None) if member is not None else None
        if pg is not None and getattr(pg, "guild_id", None) == guild.id:
            out.append(("Тег сервера", TAG_INCOME)); total += TAG_INCOME
        return out, total

    async def _do_autocollect(self, force: bool = False) -> dict:
        """Один проход начисления дохода. Возвращает диагностику.

        Выдача гейтится персональным КД (INCOME_PERIOD_SECONDS): каждая страна
        получает деньги не чаще раза в час, а петля часто проверяет, кому пора.
        КД и прирост населения — ТОЛЬКО при реальной выплате (часовой таймер
        стартует с первой выплаты). force=True игнорирует КД (для теста).
        """
        diag = {"guild": False, "channel": None, "checked": 0,
                "paid": [], "skipped": [], "sent": False, "error": None}
        guild = self.bot.get_guild(GUILD_ID)
        if guild is None:
            diag["error"] = f"guild {GUILD_ID} не найден — бот на этом сервере?"
            return diag
        diag["guild"] = True
        inc_ch = rid("CH_INCOME", INCOME_CHANNEL)
        channel = guild.get_channel(inc_ch) or self.bot.get_channel(inc_ch)
        if channel is None:
            diag["error"] = f"канал {inc_ch} не найден — проверь INCOME_CHANNEL / CH_INCOME"
            return diag
        diag["channel"] = getattr(channel, "name", channel.id)

        now = int(time.time())
        results = []
        for result in self.countries.all_objects():
            try:
                diag["checked"] += 1
                until = self.cooldown.get_cooldown("autoincome", result.name)
                if not force and now < until:
                    diag["skipped"].append((result.name, f"КД ещё {int(until - now)}с"))
                    continue

                member = guild.get_member(result.user)
                all_income = []
                total_income = 0

                # Основные источники на баланс: налоги, земля, промышленность,
                # развитие, тег сервера.
                base_sources, base_sum = self._base_income(result, member, guild)
                all_income.extend(base_sources)
                total_income += base_sum

                # Народная поддержка — бонус-множитель от счастья.
                bonus = int(base_sum * self._support_bonus_frac(getattr(result, "happiness", 100)))
                if bonus:
                    all_income.append(("Народная поддержка", bonus))
                    total_income += bonus

                # Идеология и стабильность — множители дохода (показываем дельтой).
                subtotal = total_income
                if subtotal:
                    ideology, _rel = self.politics.get(result.name)
                    ideo_delta = round(subtotal * (pol.ideo(ideology)["income"] - 1))
                    if ideo_delta:
                        all_income.append(("Строй", ideo_delta))
                        total_income += ideo_delta
                    sfac = pol.stability_factor(getattr(result, "stability", 100.0) or 0.0)
                    stab_delta = round((subtotal + ideo_delta) * (sfac - 1))
                    if stab_delta:
                        all_income.append(("Стабильность", stab_delta))
                        total_income += stab_delta

                # События — временный множитель дохода (баффы/дебафы).
                ev_mult = self.effects.income_mult(result.name, now)
                if ev_mult != 1.0 and total_income:
                    ev_delta = round(total_income * (ev_mult - 1))
                    if ev_delta:
                        all_income.append(("События", ev_delta))
                        total_income += ev_delta

                # Санкции — удар по доходу цели + взаимная цена санкционеру.
                sanc_mult = self.sanctions.income_mult(result.name)
                alc = self.bot.get_cog("AllianceCog")
                if sanc_mult < 1.0 and alc:   # валютный союз смягчает удар чужих санкций
                    sanc_mult = 1.0 - (1.0 - sanc_mult) * (1.0 - alc.sanction_shield(result.name))
                if sanc_mult != 1.0 and total_income:
                    sanc_delta = round(total_income * (sanc_mult - 1))
                    if sanc_delta:
                        all_income.append(("Санкции", sanc_delta))
                        total_income += sanc_delta

                # Торговые соглашения (дипломатия) — бонус к доходу.
                dip = self.bot.get_cog("DiplomacyCog")
                tp_mult = dip.trade_pact_mult(result.name) if dip else 1.0
                if tp_mult != 1.0 and total_income:
                    tp_delta = round(total_income * (tp_mult - 1))
                    if tp_delta:
                        all_income.append(("Торговые соглашения", tp_delta))
                        total_income += tp_delta

                # Атом — АЭС (+), содержание станций и арсенала (−).
                nuc = self.bot.get_cog("NuclearCog")
                if nuc:
                    for label, delta in nuc.income_lines(result.name, total_income):
                        all_income.append((label, delta))
                        total_income += delta

                # Наследие — бонус легендарной державы к доходу.
                lgc = self.bot.get_cog("LegacyCog")
                if lgc:
                    for label, delta in lgc.income_lines(result.name, total_income):
                        all_income.append((label, delta))
                        total_income += delta

                # Альянсы — общий рынок/таможня (+), взносы в фонд блока (−).
                if alc:
                    for label, delta in alc.income_lines(result.name, total_income):
                        all_income.append((label, delta))
                        total_income += delta

                # Содержание армии — готовые соединения съедают деньги.
                upkeep = sum(army.formation_upkeep(f["template"])
                             for f in self.army.formations_for(result.name) if now >= f["ready_at"])
                if upkeep:
                    all_income.append(("Содержание армии", -upkeep))
                    total_income -= upkeep

                if not all_income:
                    diag["skipped"].append((result.name, "дохода нет"))
                    continue

                pop_delta = self.population_growth(result.population)
                self.countries.update_object(result.name, population=result.population + pop_delta)
                if total_income:
                    update_money(result.name, total_income)
                self.cooldown.set_cooldown("autoincome", now + INCOME_PERIOD_SECONDS, result.name)

                fresh = get_object(result.name)
                avatar = member.display_avatar.url if member is not None else None
                results.append((fresh.name, getattr(fresh, "flag", "🏳️"),
                                all_income, total_income, fresh.money, avatar, pop_delta))
                diag["paid"].append((result.name, total_income))
            except Exception as e:
                log.exception("ошибка начисления по стране %s", getattr(result, "name", "?"))
                diag["skipped"].append((getattr(result, "name", "?"), f"ошибка: {e}"))

        if results:
            try:
                banner_url = guild.banner.url if guild.banner else None
                for comp in self._income_panels(results, now + INCOME_PERIOD_SECONDS, banner_url):
                    await channel.send(components=comp)
                diag["sent"] = True
            except disnake.Forbidden:
                diag["error"] = f"НЕТ ПРАВ отправлять в #{diag['channel']} — выдай боту «Отправлять сообщения»"
                log.error(diag["error"])
            except Exception as e:
                diag["error"] = f"ошибка отправки: {e}"
                log.exception("не удалось отправить сводку дохода")
        return diag

    @tasks.loop(minutes=CHECK_INTERVAL_MINUTES)
    async def autocollect(self):
        try:
            d = await self._do_autocollect()
            if d["error"]:
                log.warning("авто-доход: %s", d["error"])
            elif d["paid"]:
                log.info("выдан доход: %s (проверено %d) → #%s", d["paid"], d["checked"], d["channel"])
            else:
                log.info("тик авто-дохода: проверено %d, к выдаче никого · %s", d["checked"], d["skipped"])
        except Exception:
            log.exception("сбой цикла авто-дохода")

    @autocollect.before_loop
    async def before_autocollect(self):
        await self.bot.wait_until_ready()
        self._migrate_bank_to_money()

    def _migrate_bank_to_money(self):
        """Банк расформирован — единый баланс. Разово переливает вклады в деньги."""
        try:
            rows = self.settings._query_all("SELECT name, amount FROM bank WHERE amount > 0")
            for r in rows:
                update_money(r["name"], r["amount"])
            if rows:
                self.settings._execute("UPDATE bank SET amount = 0")
                log.info("банк расформирован: вклады переведены в баланс у %d стран", len(rows))
        except Exception:
            log.exception("миграция банка в баланс не удалась")

    @commands.command(name="collectnow", aliases=["доход-сейчас", "force-income", "собрать-доход"])
    async def collectnow_cmd(self, ctx: commands.Context, mode: str | None = None):
        """АДМИН: прогнать начисление прямо сейчас и показать диагностику.

        `!collectnow force` — игнорировать часовой КД (для теста выплаты).
        """
        if not has_command_access(ctx.author, "collectnow"):
            await ctx.send(embed=disnake.Embed(description="Нет доступа к этой команде (`!perm`).", color=ERROR_COLOR))
            return
        force = (mode or "").lower() in ("force", "сила", "форс", "now")
        d = await self._do_autocollect(force=force)

        def fmt(pairs):
            return "\n".join(f"• {n} — {info}" for n, info in pairs) if pairs else "—"

        desc = (
            f"**guild:** {'найден' if d['guild'] else '❌ НЕ НАЙДЕН'}\n"
            f"**канал дохода:** {('#'+str(d['channel'])) if d['channel'] else '❌ НЕ НАЙДЕН'}\n"
            f"**проверено стран:** {d['checked']}\n"
            f"**режим:** {'FORCE (без КД)' if force else 'обычный (с КД)'}\n\n"
            f"**ВЫПЛАЧЕНО:**\n{fmt([(n, '+'+int_format(v)+' '+CURRENCY) for n, v in d['paid']])}\n\n"
            f"**ПРОПУЩЕНО:**\n{fmt(d['skipped'])}\n\n"
            f"**сводка отправлена в канал:** {'да' if d['sent'] else 'нет'}\n"
            f"**ошибка:** {d['error'] or '—'}"
        )
        color = SUCCESS_COLOR if d["paid"] and not d["error"] else (ERROR_COLOR if d["error"] else WARNING_COLOR)
        await ctx.send(embed=disnake.Embed(title="🔧 Диагностика авто-дохода", description=desc, color=color))

    def calculate_bank_income(self, balance: int, get_min: bool = False, get_max: bool = False):
        if get_min and get_max:
            raise ValueError("Can't pass get_min=True and get_max=True")
        min_percent = 19
        max_percent = 22
        if get_min:
            percent = min_percent
        elif get_max:
            percent = max_percent
        else:
            percent = random.randint(min_percent, max_percent)
        return min(round(balance / 10_000 * ((100 - percent) / 10)), 1_000_000_000)

    def population_growth(self, population: int, get_min: bool = False, get_max: bool = False) -> int:
        if get_min and get_max:
            raise ValueError("Can't pass get_min=True and get_max=True")
        if population < 50_000_000:
            annual_min, annual_max = 10, 100
        else:
            annual_min, annual_max = 1, 10

        if get_min:
            annual_max = annual_min
        elif get_max:
            annual_min = annual_max

        rate = random.randint(annual_min, annual_max) / 100_000
        return min(round(population * rate), 100_000)

    def calculate_tax(self, population: int):
        try:
            population = float(population)
        except (TypeError, ValueError):
            return 0
        if population <= 0:
            return 0
        p = population / 1_000_000.0

        if p <= 100:
            base_total_m = p
        elif p <= 500:
            base_total_m = 100.0 + (p - 100.0) * 0.6
        else:
            base_total_m = 100.0 + (500.0 - 100.0) * 0.6 + (p - 500.0) * 0.4

        if p <= 10:
            eff = 1.0
        elif p <= 50:
            eff = 0.85
        elif p <= 150:
            eff = 0.65
        elif p <= 500:
            eff = 0.48
        else:
            eff = random.uniform(30.0, 37.0) / 100.0

        result = base_total_m * eff * 1_000_000
        return round(result)

    def calculate_electricity(self, is_people_important: bool, population: int, companies: list, infrastructure: InfrastructureObject, get_min: bool = False, get_max: bool = False) -> tuple[float, float, int]:
        if get_min and get_max:
            raise ValueError("Can't pass get_min=True and get_max=True")
        total_production = 0
        for infra_type, data in INFRASTRUCTURE_ELECTRICITY.items():
            count = getattr(infrastructure, infra_type, 0)
            if count > 0:
                mn, mx = data[1], data[2]
                if data[1] != data[2]:
                    val = mn if get_min else mx if get_max else random.randrange(mn, mx)
                    total_production += val * count
                elif data[1] == data[2] and data[2] != 0:
                    total_production += mx * count
                else: # if zero
                    pass

        pop_demand = population * 81
        comp_demand = 0
        ranges = {
            True: (1_000_000_000, 2_300_000_000),
            False: (600_000_000, 1_500_000_000),
        }
        for company in companies:
            mn, mx = ranges[company.specialization in MINING_SPECIALIZATIONS]
            val = mn if get_min else mx if get_max else random.randrange(mn, mx)
            comp_demand += val

        total_balance = total_production - (pop_demand + comp_demand)
        if is_people_important:
            pop_ratio = min(1.0, total_production / pop_demand) if pop_demand > 0 else 1.0
            remaining_power = max(0, total_production - (pop_demand * pop_ratio))
            comp_ratio = min(1.0, remaining_power / comp_demand) if comp_demand > 0 else 1.0
        else:
            total_demand = pop_demand + comp_demand
            if total_demand == 0:
                pop_ratio, comp_ratio = 1.0, 1.0
            else:
                ratio = min(1.0, total_production / total_demand)
                pop_ratio, comp_ratio = ratio, ratio
        return pop_ratio, comp_ratio, total_balance

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.autocollect.is_running():
            self.autocollect.start()

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.guild is None:   # ЛС (DMChannel не имеет .guild) — игнорируем
            return
        # Канал новостей вынесен в config (был захардкожен). Пока не задан — выключено.
        if not config.NEWS_CHANNEL or message.channel.id != config.NEWS_CHANNEL:
            return
        obj = get_object_by_user(message.author.id)
        if not obj or not isinstance(obj, CountryObject):
            return
        content = message.content.lower().replace(' ', '')
        if "#фестиваль" in content:
            content_len = len(content.replace("#фестиваль", ''))
            if content_len < 400:
                await message.reply(f"Чтобы провести фестиваль в новости должно быть не менее 400 символов. В вашей новости {content_len} символов.", delete_after=20)
                return
            news_count, last_news = self.buildnews.get_build(obj.name, "festival")
            retry_after = last_news + 60 * 60
            if last_news and datetime.now(TZ).timestamp() - retry_after < 0:
                await message.reply(f"Отправьте следующую новость <t:{retry_after}:R> для проведения фестиваля", delete_after=20)
                return
            if news_count < 1:
                self.buildnews.update_news(obj.name, "festival", 1)
                await message.reply(f"Прогресс проведения фестиваля {news_count+1}/2", delete_after=20)
            else:
                if obj.money < 4_000_000_000:
                    await message.reply(f"Для проведения фестиваля необходимо 4.000.000.000 {CURRENCY}. У вас есть только {int_format(obj.money)} {CURRENCY}\nНапишите новость еще раз когда у вас появятся деньги.", delete_after=20)
                    return
                self.buildnews.reset_news(obj.name, "festival")
                update_money(obj.name, -4_000_000_000)
                self.countries.update_object(obj.name, happiness=obj.happiness + 10)
                await message.reply(f"Вы провели фестиваль\n-4.000.000.000 {CURRENCY}", delete_after=20)
        elif "#тэц" in content or "#тэс" in content:
            if obj.territory < 1200:
                await message.reply("Вы не можете зарегистрировать ТЭС (ТЭЦ) т.к. ваша территория меньше 1200 км².", delete_after=20)
                return
            content_len = len(content.replace("#тэц", '').replace("#тэс", ''))
            if content_len < 400:
                await message.reply(f"Для регистрации ТЭС (ТЭЦ) в новости должно быть не менее 400 символов. В вашей новости {content_len} символов.", delete_after=20)
                return
            news_count, _ = self.buildnews.get_build(obj.name, InfrastructureType.CHP.value)
            if news_count < 2:
                self.buildnews.update_news(obj.name, InfrastructureType.CHP.value, 1)
                await message.reply(f"Прогресс регистрации ТЭС (ТЭЦ) {news_count+1}/3", delete_after=20)
            else:
                if obj.money < 300_000_000:
                    await message.reply(f"Для регистрации ТЭС (ТЭЦ) необходимо 300.000.000 {CURRENCY}. У вас есть только {int_format(obj.money)} {CURRENCY}\nНапишите новость еще раз когда у вас появятся деньги.", delete_after=20)
                    return
                self.buildnews.reset_news(obj.name, InfrastructureType.CHP.value)
                self.infrastructure.create_infrastructure(obj.name, InfrastructureType.CHP.value)
                update_money(obj.name, -300_000_000)
                await message.reply(f"Вы зарегистрировали ТЭС (ТЭЦ)\n-300.000.000 {CURRENCY}", delete_after=20)
        elif "#аэс" in content:
            if obj.name not in CAN_REG_ATOMIC:
                await message.reply("Вы не можете зарегистрировать АЭС т.к. ваша страна недостаточно развита.", delete_after=20)
                return
            content_len = len(content.replace("#аэс", ''))
            if content_len < 400:
                await message.reply(f"Для регистрации АЭС в новости должно быть не менее 400 символов. В вашей новости {content_len} символов.", delete_after=20)
                return
            news_count, _ = self.buildnews.get_build(obj.name, InfrastructureType.ATOMIC.value)
            if news_count < 2:
                self.buildnews.update_news(obj.name, InfrastructureType.ATOMIC.value, 1)
                await message.reply(f"Прогресс регистрации АЭС {news_count+1}/3", delete_after=20)
            else:
                if obj.money < 400_000_000:
                    await message.reply(f"Для регистрации АЭС необходимо 400.000.000 {CURRENCY}. У вас есть только {int_format(obj.money)} {CURRENCY}\nНапишите новость еще раз когда у вас появятся деньги.", delete_after=20)
                    return
                self.buildnews.reset_news(obj.name, InfrastructureType.ATOMIC.value)
                self.infrastructure.create_infrastructure(obj.name, InfrastructureType.ATOMIC.value)
                update_money(obj.name, -400_000_000)
                await message.reply(f"Вы зарегистрировали АЭС\n-400.000.000 {CURRENCY}", delete_after=20)
        elif "мигэс" in content:
            content_len = len(content.replace("#мигэс", ''))
            if content_len < 400:
                await message.reply(f"Для регистрации Микро ГЭС в новости должно быть не менее 400 символов. В вашей новости {content_len} символов.", delete_after=20)
                return
            if obj.money < 10_000_000:
                await message.reply(f"Для регистрации Микро ГЭС необходимо 10.000.000 {CURRENCY}. У вас есть только {int_format(obj.money)} {CURRENCY}\nНапишите новость еще раз когда у вас появятся деньги.", delete_after=20)
                return
            await self.reg_infrastructure(obj.name, InfrastructureType.HPS1.value, datetime.now(TZ).timestamp()+60*60)
            update_money(obj.name, -10_000_000)
            await message.reply(f"Вы зарегистрировали Микро ГЭС\n-10.000.000 {CURRENCY}", delete_after=20)
        elif "мгэс" in content:
            cooldown = self.cooldown.get_cooldown(InfrastructureType.HPS2.value, obj.name)
            if cooldown < datetime.now(TZ).timestamp():
                await message.reply(f"Для регистрации Малой ГЭС следующую новость можно отправить <t:{cooldown}:R>", delete_after=20)
                return
            content_len = len(content.replace("#мгэс", ''))
            if content_len < 400:
                await message.reply(f"Для регистрации Малой ГЭС в новости должно быть не менее 400 символов. В вашей новости {content_len} символов.", delete_after=20)
                return
            news_count, last_news = self.buildnews.get_build(obj.name, InfrastructureType.HPS2.value)
            retry_after = last_news + 60 * 60
            if last_news and datetime.now(TZ).timestamp() - retry_after < 0:
                await message.reply(f"Отправьте следующую новость <t:{retry_after}:R> для регистрации Малой ГЭС", delete_after=20)
                return
            if news_count < 1:
                self.cooldown.set_cooldown(InfrastructureType.HPS2.value, datetime.now(TZ).timestamp()+60*60, obj.name)
                self.buildnews.update_news(obj.name, InfrastructureType.HPS2.value, 1)
                await message.reply(f"Прогресс регистрации Малой ГЭС {news_count+1}/2", delete_after=20)
            else:
                if obj.money < 50_000_000:
                    await message.reply(f"Для регистрации Малой ГЭС необходимо 50.000.000 {CURRENCY}. У вас есть только {int_format(obj.money)} {CURRENCY}\nНапишите новость еще раз когда у вас появятся деньги.", delete_after=20)
                    return
                self.buildnews.reset_news(obj.name, InfrastructureType.HPS2.value)
                await self.reg_infrastructure(obj.name, InfrastructureType.HPS2.value, datetime.now(TZ).timestamp()+60*60+60*20)
                update_money(obj.name, -50_000_000)
                await message.reply(f"Вы зарегистрировали Малую ГЭС\n-50.000.000 {CURRENCY}", delete_after=20)
        elif "сгэс" in content:
            cooldown = self.cooldown.get_cooldown(InfrastructureType.HPS3.value, obj.name)
            if cooldown < datetime.now(TZ).timestamp():
                await message.reply(f"Для регистрации Средней ГЭС следующую новость можно отправить <t:{cooldown}:R>", delete_after=20)
                return
            content_len = len(content.replace("#сгэс", ''))
            if content_len < 400:
                await message.reply(f"Для регистрации Средней ГЭС в новости должно быть не менее 400 символов. В вашей новости {content_len} символов.", delete_after=20)
                return
            news_count, last_news = self.buildnews.get_build(obj.name, InfrastructureType.HPS3.value)
            retry_after = last_news + 60 * 60
            if last_news and datetime.now(TZ).timestamp() - retry_after < 0:
                await message.reply(f"Отправьте следующую новость <t:{retry_after}:R> для регистрации Средней ГЭС", delete_after=20)
                return
            if news_count < 2:
                self.buildnews.update_news(obj.name, InfrastructureType.HPS3.value, 1)
                await message.reply(f"Прогресс регистрации Средней ГЭС {news_count+1}/3", delete_after=20)
            else:
                if obj.money < 100_000_000:
                    await message.reply(f"Для регистрации Средней ГЭС необходимо 100.000.000 {CURRENCY}. У вас есть только {int_format(obj.money)} {CURRENCY}\nНапишите новость еще раз когда у вас появятся деньги.", delete_after=20)
                    return
                self.buildnews.reset_news(obj.name, InfrastructureType.HPS3.value)
                await self.reg_infrastructure(obj.name, InfrastructureType.HPS3.value, datetime.now(TZ).timestamp()+60*60+60*40)
                update_money(obj.name, -100_000_000)
                await message.reply(f"Вы зарегистрировали Среднюю ГЭС\n-100.000.000 {CURRENCY}", delete_after=20)
        elif "бгэс" in content:
            cooldown = self.cooldown.get_cooldown(InfrastructureType.HPS4.value, obj.name)
            if cooldown < datetime.now(TZ).timestamp():
                await message.reply(f"Для регистрации Большой ГЭС следующую новость можно отправить <t:{cooldown}:R>", delete_after=20)
                return
            content_len = len(content.replace("#бгэс", ''))
            if content_len < 400:
                await message.reply(f"Для регистрации Большой ГЭС в новости должно быть не менее 400 символов. В вашей новости {content_len} символов.", delete_after=20)
                return
            news_count, last_news = self.buildnews.get_build(obj.name, InfrastructureType.HPS4.value)
            retry_after = last_news + 60 * 60
            if last_news and datetime.now(TZ).timestamp() - retry_after < 0:
                await message.reply(f"Отправьте следующую новость <t:{retry_after}:R> для регистрации Большой ГЭС", delete_after=20)
                return
            if news_count < 2:
                self.buildnews.update_news(obj.name, InfrastructureType.HPS4.value, 1)
                await message.reply(f"Прогресс регистрации Большой ГЭС {news_count+1}/3", delete_after=20)
            else:
                if obj.money < 240_000_000:
                    await message.reply(f"Для регистрации Большой ГЭС необходимо 240.000.000 {CURRENCY}. У вас есть только {int_format(obj.money)} {CURRENCY}\nНапишите новость еще раз когда у вас появятся деньги.", delete_after=20)
                    return
                self.buildnews.reset_news(obj.name, InfrastructureType.HPS4.value)
                await self.reg_infrastructure(obj.name, InfrastructureType.HPS4.value, datetime.now(TZ).timestamp()+60*60*2)
                update_money(obj.name, -240_000_000)
                await message.reply(f"Вы зарегистрировали Большую ГЭС\n-240.000.000 {CURRENCY}", delete_after=20)

    async def reg_infrastructure(self, name: str, infra: InfrastructureType, after: float):
        async def task():
            now = datetime.now(TZ).timestamp()
            if after > now:
                await asyncio.sleep(after - now)
            self.infrastructure.create_infrastructure(name, infra)
        asyncio.create_task(task())


    @commands.command(name="balance", aliases=["баланс", "bal", "бал", "b", "б", ",", "и", ",fk", "ифд"])
    async def balance_cmd(self, ctx: commands.Context, user: disnake.Member | disnake.User | str | None = None):
        pmc_cog = self.bot.get_cog("PmcCog")
        if pmc_cog:   # ЧВК — свой профиль (казна, бойцы, арсенал моделей, связи)
            if user is None:
                pm = Pmc().by_user(ctx.author.id)
            elif isinstance(user, (disnake.Member, disnake.User)):
                pm = Pmc().by_user(user.id)
            else:
                pm = Pmc().find(str(user))
            if pm:
                await ctx.send(components=pmc_cog.profile_panel(pm["name"]).components)
                return
        if user:
            try:
                result: CountryObject | PMCObject | RegionObject | TerroristObject | RebelObject = await find_user(ctx, user, isfetch=True)
            except TimeoutError:
                return
        else:
            result = get_object_by_user(ctx.author.id)
            if not result:
                await ctx.send(embed=disnake.Embed(description="Укажите участника.", color=ERROR_COLOR))
                return
        if not result:
            await ctx.send(embed=disnake.Embed(description="Участник не зарегистрирован.", color=ERROR_COLOR))
            return

        stats = {}
        for i in get_all_managers():
            if i().get_object(result.name):
                stats = i().get_stat_lvls(result.name)

        licenses = self.items.get_licenses(result.name)
        items = self.items.get_inventory(result.name)

        # if ctx.author.id == ADMINISTRATOR:
        #     result.user = ADMINISTRATOR
        view = BalanceView(self, ctx, result, stats, licenses, items)
        await ctx.send(components=view.components)

    @commands.command(name="add-money", aliases=["выдать-деньги", "give-money"])
    async def add_money_cmd(self, ctx: commands.Context, user: disnake.Member | int | str | None = None, amount: int | str = 0):
        if not await command_permissions_check(ctx, "manage-money"):
            return
        if not user:
            await ctx.send(embed=disnake.Embed(title="Ошибка", description="Укажите участника.\n`!add-money @User 100`", color=ERROR_COLOR))
            return
        if not amount:
            await ctx.send(embed=disnake.Embed(title="Ошибка", description=f"Укажите количество.\n`!add-money @{user.display_name} 100`", color=ERROR_COLOR))
            return
        try:
            result = await find_user(ctx, user, isfetch=True) # type: ignore[arg-type]
        except TimeoutError:
            return
        amount = string_to_number(amount)
        if not isinstance(amount, int) or amount < 1:
            await ctx.send(embed=disnake.Embed(title="Ошибка", description="Количество не является числом.", color=ERROR_COLOR))
            return
        result = update_money(result.name, amount)
        embed = disnake.Embed(
            title="Успешно",
            description=f"""Баланс <@{result.user}> изменён
{int_format(result.money)} {CURRENCY} (+{int_format(amount)} {CURRENCY})
""",
            color=SUCCESS_COLOR
            )
        await ctx.send(embed=embed)
        await self.logs.success("Изменение баланса", f"<@{ctx.author.id}> `({ctx.author.id})` изменил баланс {result.name}\n{int_format(result.money)} {CURRENCY} (+{int_format(amount)} {CURRENCY})")

    @commands.command(name="remove-money", aliases=["забрать деньги", "take-money"])
    async def remove_money_cmd(self, ctx: commands.Context, user: disnake.Member | int | str | None = None, amount: int | str = 0):
        if not await command_permissions_check(ctx, "manage-money"):
            return
        if not user:
            await ctx.send(embed=disnake.Embed(title="Ошибка", description="Укажите участника.\n`!remove-money @User 100`", color=ERROR_COLOR))
            return
        if not amount:
            await ctx.send(embed=disnake.Embed(title="Ошибка", description=f"Укажите количество.\n`!remove-money @{user.display_name} 100`", color=ERROR_COLOR))
            return
        try:
            result = await find_user(ctx, user, isfetch=True) # type: ignore[arg-type]
        except TimeoutError:
            return
        amount = string_to_number(amount)
        if not isinstance(amount, int) or amount < 1:
            await ctx.send(embed=disnake.Embed(title="Ошибка", description="Количество не является числом.", color=ERROR_COLOR))
            return
        update_money(result.name, -amount)
        embed = disnake.Embed(
            title="Успешно",
            description=f"""Баланс <@{result.user}> изменён
{int_format(result.money)} {CURRENCY} (-{int_format(amount)} {CURRENCY})
""",
            color=SUCCESS_COLOR
            )
        await ctx.send(embed=embed)
        await self.logs.success("Изменение баланса", f"<@{ctx.author.id}> `({ctx.author.id})` изменил баланс {result.name}\n{int_format(result.money)} {CURRENCY} (-{int_format(amount)} {CURRENCY})")

    @commands.command(name="pay", aliases=["передать"])
    async def pay_cmd(self, ctx: commands.Context, user: disnake.Member | int | str | None = None, amount: int | str = 0):
        if not await command_permissions_check(ctx, "pay"):
            return
        author_obj = get_object_by_user(ctx.author.id)
        if not author_obj:
            return
        if not user:
            await ctx.send(embed=disnake.Embed(description="Укажите участника и сумму.\n`!pay <игрок> <количество>`", color=ERROR_COLOR))
            return
        if not amount:
            await ctx.send(embed=disnake.Embed(description=f"Укажите сумму.\n`!pay {user.display_name.split()[0]} <количество>`", color=ERROR_COLOR))
            return
        amount = string_to_number(amount, all_amount=author_obj.money)
        if not isinstance(amount, int) or amount < 1:
            await ctx.send(embed=disnake.Embed(description="Количество не является числом.", color=ERROR_COLOR))
            return
        if author_obj.money < amount:
            await ctx.send(embed=disnake.Embed(description="Недостаточно средств.", color=ERROR_COLOR))
            return
        if isinstance(user, disnake.Member) and user.id == ctx.guild.me.id:
            author_obj = update_money(author_obj.name, -amount)
            embed = disnake.Embed(
                title="Успешно",
                description=f"""Вы забрали у себя {int_format(amount)} {CURRENCY}
На вашем балансе {int_format(author_obj.money)} {CURRENCY}""",
                color=SUCCESS_COLOR
            )
            await ctx.send(embed=embed)
            await self.logs.message("Передача средств(боту)", f"""<@{ctx.author.id}> `({ctx.author.id})` передал боту {int_format(amount)} {CURRENCY}
На балансе {author_obj.name} {int_format(author_obj.money)} {CURRENCY}""")
            return
        try:
            user_obj = await find_user(ctx, user, isfetch=True)
        except TimeoutError:
            return
        if not user_obj:
            return
        if user_obj.user == ctx.author.id:
            await ctx.send(embed=disnake.Embed(description="Вы не можете передать деньги самому себе.", color=ERROR_COLOR))
            return
        author_obj = update_money(author_obj.name, -amount)
        user_obj = update_money(user_obj.name, amount)
        embed = disnake.Embed(
            title="Успешно",
            description=f"""Вы передали <@{user_obj.user}> {int_format(amount)} {CURRENCY}
На балансе <@{user_obj.user}> {int_format(user_obj.money)} {CURRENCY}
На вашем балансе {int_format(author_obj.money)} {CURRENCY}""",
            color=SUCCESS_COLOR
        )
        await ctx.send(embed=embed)
        await self.logs.message("Передача средств", f"""<@{ctx.author.id}> `({ctx.author.id})` передал {user_obj.name} {int_format(amount)} {CURRENCY}
На балансе {user_obj.name} {int_format(user_obj.money)} {CURRENCY}
На балансе {author_obj.name} {int_format(author_obj.money)} {CURRENCY}""")

    @commands.command(name="work", aliases=["работа", "ворк"], description="Работать")
    async def work_cmd(self, ctx: commands.Context):
        result = get_object_by_user(ctx.author.id)
        if not result:
            return
        cooldown = self.settings.get_work_cooldown(result.name)
        timestamp = int(time.time())
        if cooldown and cooldown - timestamp > 0:
            await ctx.send(embed=disnake.Embed(title="Ошибка", description=f"Следующая работа <t:{cooldown}:R> в <t:{cooldown}:t>", color=ERROR_COLOR))
            return

        self.settings.update_work_cooldown(result.name, timestamp+WORK_CD)
        income = random.randint(WORK_MIN_INCOME, WORK_MAX_INCOME)
        result = update_money(result.name, income)
        embed = disnake.Embed(
            description=f"""Заработано +{int_format(income)} {CURRENCY}
На балансе {int_format(result.money)} {CURRENCY}
""",
            color=SUCCESS_COLOR
            )
        await ctx.send(embed=embed)


def setup(bot: commands.Bot):
    bot.add_cog(EconomyCog(bot))