"""
ЧВК — !чвк / !pmc · рейтинг — !чвк-рейтинг

Отдельный тип игрока: частная военная компания (свои таблицы — механики государств её не видят).
Игрок может быть ЛИБО страной, ЛИБО ЧВК.

ДЛЯ ЧВК (панель в ЛС): казна, бойцы, репутация, лицензия, содержание и частные заказы,
арсенал ИМЕННЫХ моделей стран, рынок стран (просьбы о продаже), сделки, чёрный рынок
(контрабанда и трофеи), биржа контрактов, отношения, смена базы, роспуск.
ДЛЯ СТРАНЫ (та же команда): заказы ЧВК, продажа техники ЧВК, лицензии ЧВК на своей
территории (налог/высылка), санкции против ЧВК, разведка против ЧВК.

Профиль ЧВК — в !balance (и !balance @ЧВК), арсенал — в !арсенал, база — метка на карте,
новости ЧВК — в канале мировых новостей (правило простоя — как у стран).
Часовой цикл: содержание, частные заказы, военные контракты, истечение заказов/сделок/лотов/
санкций, контрабанда раз в сутки. Только кастом-иконки.
"""

import logging
import random
import re
import time

import disnake
from disnake.ext import commands, tasks

import config
from utils import (
    Countries, Politics, Diplomacy, Effects, War, Pmc, Spy, Equipment, Army, Cooldown, Npc, News,
    update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
import utils.pmc as P
import utils.army as ARM
import utils.equipment as E
import utils.war as WE
import utils.spy as SPY
import utils.worldmap as WM

log = logging.getLogger("pmc")
_PAGE = 25
PMC_COLOR = 0x8E9AAF


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s and s.startswith("<") else None
    except Exception:
        return None


def _pe_cat(cat: str):
    s = E.cat_icon(cat)
    try:
        return disnake.PartialEmoji.from_str(s) if s and s.startswith("<") else None
    except Exception:
        return None


def _bar(frac: float, width: int = 10) -> str:
    filled = round(max(0.0, min(1.0, frac)) * width)
    return "▰" * filled + "▱" * (width - filled)


def _num(text: str) -> int | None:
    t = (text or "").strip().lower().replace(" ", "").replace("_", "").replace(",", "").replace(".", "")
    mult = 1
    while t.endswith(("k", "к")):
        mult *= 1000
        t = t[:-1]
    try:
        v = int(float(t) * mult)
    except ValueError:
        return None
    return v if v > 0 else None


def _rel_word(v: float) -> str:
    if v <= P.HOSTILE:
        return "враждебные"
    if v < -10:
        return "напряжённые"
    if v < 10:
        return "нейтральные"
    if v < 40:
        return "хорошие"
    return "партнёрские"


class PmcCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.pmc = Pmc()
        self.countries = Countries()
        self.war = War()
        self.effects = Effects()
        self.dip = Diplomacy()
        self.politics = Politics()
        self.equip = Equipment()
        self.cooldown = Cooldown()
        self._sessions: dict[int, dict] = {}
        self._nicks_synced = False
        self._migrate()
        self.pmc_tick.start()

    def cog_unload(self):
        self.pmc_tick.cancel()

    def _migrate(self):
        """Разовый переход на ЧВК v2: старая «абстрактная» техника и баланс в миллиарды — в стартовые рамки."""
        if self.pmc.meta("v2"):
            return
        for p in self.pmc.all():
            self.pmc.set(p["name"], money=min(int(p["money"] or 0), P.START_MONEY),
                         personnel=min(int(p["personnel"] or 0), P.START_PERSONNEL))
        self.pmc.drop_legacy_equipment()
        self.pmc.set_meta("v2", "1")

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    def _session(self, uid: int) -> dict:
        return self._sessions.setdefault(uid, {
            "view": "hub", "contract": None, "kind": None, "war": None, "target": None, "confirm": False,
            "page": 0, "sell_eid": None, "sell_pmc": None, "spy_pmc": None, "spy_op": None})

    # ═══════════════ СОСТОЯНИЕ ═══════════════
    def is_pmc(self, name: str) -> bool:
        return bool(name) and self.pmc.get(name) is not None

    def licensed(self, pm) -> bool:
        return not self.pmc.has_sanction(pm["name"], pm["base"], "expel", int(time.time()))

    def un_left(self, name: str) -> int:
        return max(0, self.pmc.un_until(name) - int(time.time()))

    def sanctioned(self, name: str, country: str) -> bool:
        return self.pmc.has_sanction(name, country, "sanction", int(time.time()))

    def hostile(self, name: str, country: str) -> bool:
        return self.pmc.rel(name, country) <= P.HOSTILE

    def _player_country(self, name: str):
        """Страна под управлением игрока (не ИИ) или None."""
        return self.countries.get_object(name) if name else None

    def _embargoed(self, country: str) -> bool:
        un = self.bot.get_cog("UNCog")
        try:
            return bool(un and un.embargoed(country))
        except Exception:
            return False

    def tax_rate(self, pm) -> int:
        return self.pmc.tax(pm["base"]) if self._player_country(pm["base"]) else 0

    # ═══════════════ API ДЛЯ ВОЙНЫ ═══════════════
    def power(self, name: str) -> dict:
        """Боевая мощь ЧВК: модели × состояние + профессиональная пехота × качество уровня репутации."""
        p = self.pmc.get(name)
        if not p:
            return {"atk": 0, "arm": 0, "hp": 0, "dom": {}, "upkeep": 0, "forms": [], "stab": 70}
        _k, _l, q = P.tier(p["reputation"] or 0)
        m = 0.9
        atk = arm = hp = 0.0
        dom = {"land": 0.0, "air": 0.0, "naval": 0.0, "missile": 0.0}
        for r in self.pmc.stock(name):
            ca, cd, ch = ARM.cat_combat(r["category"])
            n, g = r["count"], P.grade_mult(r["grade"])
            a, d, h = ca * n * q * m * g, cd * n * q * g, ch * n * q * m * g
            atk += a; arm += d; hp += h
            dk = E.cat_domain(r["category"])
            dom[dk] = dom.get(dk, 0.0) + WE.combat_power(a, d, h)
        inf = (p["personnel"] or 0) / 1000 * P.INF_K
        ia, iarm, ih = inf * ARM.INF_ATTACK * q * m, inf * ARM.INF_ARMOR * q, inf * ARM.INF_HP * q * m
        atk += ia; arm += iarm; hp += ih
        dom["land"] += WE.combat_power(ia, iarm, ih)
        return {"atk": int(atk), "arm": int(arm), "hp": int(hp), "dom": dom, "upkeep": 0, "forms": [], "stab": 70}

    def combat_score(self, name: str) -> int:
        pw = self.power(name)
        return int(WE.combat_power(pw["atk"], pw["arm"], pw["hp"]))

    @staticmethod
    def _loss(n: int, frac: float) -> int:
        """Потери с вероятностным округлением: 3 танка × 10% — иногда 1, а не всегда 0."""
        x = n * frac
        k = int(x)
        return min(n, k + (1 if random.random() < x - k else 0))

    def damage(self, name: str, frac: float):
        """Потери ЧВК в бою: бойцы и техника — пропорционально; часть техники — трофеи чёрного рынка."""
        p = self.pmc.get(name)
        if not p:
            return
        frac = max(0.0, min(1.0, frac))
        self.pmc.set(name, personnel=int((p["personnel"] or 0) * (1 - frac)))
        now = int(time.time())
        for r in self.pmc.stock(name):
            lost = self._loss(r["count"], frac)
            if lost:
                self.pmc.add_stock(name, r["model"], r["category"], r["cls"], r["origin"], r["grade"], -lost)
                self._trophy_lot(r["model"], r["category"], r["cls"], r["origin"], lost, now)

    def add_trophies(self, lost: dict):
        """Из WarCog: {equipment_id: потеряно шт} → часть уходит лотами на чёрный рынок."""
        now = int(time.time())
        for eid, n in lost.items():
            eq = self.equip.get(eid)
            if eq and eq["category"] in P.ALLOWED:
                self._trophy_lot(eq["name"], eq["category"], eq["cls"], eq["owner"], n, now)

    def _trophy_lot(self, model, cat, cls, origin, lost: int, now: int):
        k = self._loss(lost, P.TROPHY_SHARE)
        if k <= 0 or cat not in P.ALLOWED:
            return
        price = max(1, int(P.ref_price(cat, cls) * P.TROPHY_PRICE_K))
        self.pmc.add_lot(model, cat, cls, origin, k, price, "trophy", now, now + P.LOT_TTL)
        self.pmc.prune_lots(now, P.POOL_MAX)

    def personnel_upkeep(self, pm) -> int:
        return int((pm["personnel"] or 0) / 1000 * P.PERSONNEL_UPKEEP_K)

    def upkeep(self, name: str) -> int:
        p = self.pmc.get(name)
        if not p:
            return 0
        eq = sum(int(P.unit_upkeep(r["category"], r["cls"]) * P.grade_mult(r["grade"])) * r["count"]
                 for r in self.pmc.stock(name))
        return self.personnel_upkeep(p) + eq

    def passive(self, pm) -> int:
        if not self.licensed(pm):
            return 0
        v = P.PASSIVE[P.tier(pm["reputation"] or 0)[0]]
        return int(v * P.UN_INCOME_MULT) if self.un_left(pm["name"]) else v

    def _payout(self, name: str, amount: int) -> str:
        """Оплата ЧВК: налог стране базирования, санкции ООН замораживают половину. → строка итога."""
        pm = self.pmc.get(name)
        if not pm or amount <= 0:
            return ""
        rate = self.tax_rate(pm)
        tax = amount * rate // 100
        if tax:
            update_money(pm["base"], tax)
        net = amount - tax
        frozen = net - int(net * P.UN_INCOME_MULT) if self.un_left(name) else 0
        net -= frozen
        self.pmc.add_money(name, net)
        tail = (f" (налог {pm['base']} {rate}%: {int_format(tax)})" if tax else "") + \
               (f" · заморожено санкциями ООН: {int_format(frozen)}" if frozen else "")
        return f"{ui_icon('money')} ЧВК получила **{int_format(net)} {CURRENCY}**{tail}"

    # ═══════════════ КАНАЛ / ЛС ═══════════════
    def _channel(self):
        ch_id = rid("CH_PMC", 0) or rid("CH_WAR", 0)
        if not ch_id:
            return None
        g = self.bot.get_guild(GUILD_ID)
        return (g.get_channel(ch_id) if g else None) or self.bot.get_channel(ch_id)

    async def _post(self, text: str, color=PMC_COLOR):
        ch = self._channel()
        if not ch:
            return
        try:
            p = Panel(timeout=None)
            p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(text[:3900]), accent_colour=disnake.Colour(color)))
            await ch.send(components=p.components)
        except Exception:
            log.exception("пост ЧВК")

    async def _dm_user(self, user_id: int, text: str):
        if not user_id:
            return
        user = self.bot.get_user(user_id)
        if user is None:
            try:
                user = await self.bot.fetch_user(user_id)
            except Exception:
                return
        try:
            p = Panel(timeout=None)
            p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(text[:3900]),
                                            accent_colour=disnake.Colour(PMC_COLOR)))
            await user.send(components=p.components)
        except Exception:
            pass

    async def _dm_country(self, country: str, text: str):
        o = self.countries.get_object(country)
        if o:
            await self._dm_user(o.user, text)

    async def _dm_pmc(self, name: str, text: str):
        p = self.pmc.get(name)
        if p:
            await self._dm_user(p["user"], text)

    def _journal(self, actor: str, target: str, text: str):
        """Мировой журнал (его читает ООН: факты для резолюций против ЧВК)."""
        try:
            from utils import Un
            Un().log("pmc", actor, target, text, int(time.time()))
        except Exception:
            pass

    # ═══════════════ ОПИСАНИЯ (профиль, арсенал, досье) ═══════════════
    def _flag(self, country: str) -> str:
        o = self.countries.get_object(country)
        return o.flag if o else ""

    def stock_lines(self, name: str, limit: int = 30) -> list[str]:
        rows = self.pmc.stock(name)
        out = [f"{E.cat_icon(r['category'])} **{r['model']}** · {E.cat_label(r['category'])}, "
               f"{E.class_label(r['cls']).lower()} · {self._flag(r['origin'])} {r['origin']} · "
               f"{P.grade_label(r['grade'])} — `×{int_format(r['count'])}`" for r in rows[:limit]]
        if len(rows) > limit:
            out.append(f"-# …и ещё {len(rows) - limit} позиций")
        return out

    def status_line(self, pm) -> str:
        bits = []
        if not self.licensed(pm):
            bits.append(f"{ui_icon('expel')} **без лицензии** — выслана из {pm['base']}")
        un = self.un_left(pm["name"])
        if un:
            bits.append(f"{ui_icon('sanctions')} санкции ООН ещё {un // 3600}ч")
        by = [r["by"] for r in self.pmc.sanctions_of(pm["name"], int(time.time())) if r["kind"] == "sanction"]
        if by:
            bits.append(f"{ui_icon('sanctions')} санкции: {', '.join(by[:6])}")
        return " · ".join(bits)

    def profile_text(self, name: str) -> str:
        pm = self.pmc.get(name)
        if not pm:
            return ""
        _key, tlabel, q = P.tier(pm["reputation"] or 0)
        rate = self.tax_rate(pm)
        st = self.status_line(pm)
        return (f"### {ui_icon('pmc')} [{pm['tag']}] {name}\n"
                f"{ui_icon('pmc_base')} База: **{self._flag(pm['base'])} {pm['base']}**"
                + (f" · налог **{rate}%**" if rate else "") + "\n"
                f"{ui_icon('reputation')} Репутация {_bar((pm['reputation'] or 0) / 100)} **{pm['reputation']:.0f}** · "
                f"**{tlabel}** (качество ×{q})\n"
                f"{ui_icon('money')} Казна: **{int_format(pm['money'])} {CURRENCY}** · {ui_icon('up')} частные заказы "
                f"**+{int_format(self.passive(pm))}/ч** · {ui_icon('down')} содержание **{int_format(self.upkeep(name))}/ч**\n"
                f"{ui_icon('soldier')} Бойцов: **{int_format(pm['personnel'])}** · {ui_icon('attack')} Боевая мощь: "
                f"**{int_format(self.combat_score(name))}** · {ui_icon('contract')} выполнено контрактов: "
                f"**{pm['done_count'] or 0}**" + (f"\n{st}" if st else ""))

    def rel_lines(self, name: str, limit: int = 6) -> list[str]:
        return [f"{ui_icon('rel_up' if r['value'] >= 0 else 'rel_down')} {self._flag(r['country'])} {r['country']} "
                f"**{r['value']:+.0f}** · {_rel_word(r['value'])}" for r in self.pmc.rels(name)[:limit]]

    def profile_panel(self, name: str) -> Panel:
        """Профиль ЧВК для !balance (публично)."""
        items = [disnake.ui.TextDisplay(self.profile_text(name))]
        lines = self.stock_lines(name, 15)
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"{ui_icon('storage')} **Арсенал**\n"
                                            + ("\n".join(lines) if lines else "-# Техники нет.")))
        rl = self.rel_lines(name)
        if rl:
            items.append(disnake.ui.TextDisplay(f"{ui_icon('relations')} **Отношения**\n" + "\n".join(rl)))
        items.append(disnake.ui.TextDisplay("-# Частная военная компания · управление — `!чвк`"))
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(PMC_COLOR)))
        return p

    def arsenal_panel(self, name: str) -> Panel:
        pm = self.pmc.get(name)
        lines = self.stock_lines(name, 40)
        eq_up = self.upkeep(name) - self.personnel_upkeep(pm)
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('storage')} Арсенал ЧВК [{pm['tag']}] {name}\n"
            + ("\n".join(lines) if lines else "-# Техники нет. Купите модели у стран или на чёрном рынке (`!чвк`).")),
            disnake.ui.TextDisplay(f"-# Б/у техника воюет на {int(P.GRADES['worn'][1] * 100)}% мощности. "
                                   f"Содержание техники: **{int_format(eq_up)}/ч**")]
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(PMC_COLOR)))
        return p

    def dossier(self, name: str) -> str:
        """Компактное досье ЧВК для ИИ новостей и для разведки стран."""
        pm = self.pmc.get(name)
        if not pm:
            return ""
        _k, tlabel, _q = P.tier(pm["reputation"] or 0)
        stock = ", ".join(f"{r['model']} ({E.cat_label(r['category'])}, {P.grade_label(r['grade'])}) ×{r['count']}"
                          for r in self.pmc.stock(name)[:15]) or "нет"
        active = ", ".join(f"{P.contract_label(c['kind'])} для {c['client']}" for c in self.pmc.contracts_of_pmc(name))
        rels = ", ".join(f"{r['country']} {r['value']:+.0f}" for r in self.pmc.rels(name)[:6])
        st = self.status_line(pm).replace("**", "")
        return (f"Это ЧВК (частная военная компания), НЕ государство: территории, населения, ресурсов и заводов нет.\n"
                f"ЧВК «{name}» [{pm['tag']}], база {pm['base']}, лицензия {'есть' if self.licensed(pm) else 'отозвана'}. "
                f"Казна {int_format(pm['money'])} {CURRENCY}, бойцов {int_format(pm['personnel'])}, репутация "
                f"{pm['reputation']:.0f} ({tlabel}), боевая мощь {int_format(self.combat_score(name))}, "
                f"выполнено контрактов {pm['done_count'] or 0}.\n"
                f"Техника: {stock}.\nАктивные контракты: {active or 'нет'}.\nОтношения: {rels or 'нейтральные'}."
                + (f"\n{st}" if st else ""))

    def base_markers(self) -> dict[str, list[str]]:
        """{adm0_a3 страны базирования: [теги ЧВК]} — для карты мира."""
        out: dict[str, list[str]] = {}
        for p in self.pmc.all():
            a3 = WM.resolve_a3(p["base"])
            if a3:
                out.setdefault(a3, []).append(p["tag"])
        return out

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=PMC_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('pmc')} Частные военные компании")]
        if note:
            items.append(disnake.ui.TextDisplay(note[:3000]))
        return items

    def _back(self, label="⟵ Назад", to="hub"):
        return disnake.ui.Button(style=disnake.ButtonStyle.secondary, label=label, custom_id=cid("pmc", "goto", to))

    def _pager(self, s: dict, total: int) -> int:
        pages = max(1, (total + _PAGE - 1) // _PAGE)
        s["page"] = max(0, min(s["page"], pages - 1))
        return pages

    def _page_row(self, s, pages):
        return disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.primary, emoji=_pe("prev"), disabled=s["page"] == 0,
                              custom_id=cid("pmc", "page", "prev")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label=f"{s['page'] + 1}/{pages}", disabled=True,
                              custom_id=cid("pmc", "page", "noop")),
            disnake.ui.Button(style=disnake.ButtonStyle.primary, emoji=_pe("next"), disabled=s["page"] >= pages - 1,
                              custom_id=cid("pmc", "page", "next")))

    def _render(self, uid: int, note=None) -> Panel:
        s = self._session(uid)
        pm = self.pmc.by_user(uid)
        country = self.countries.get_object_by_user(uid)
        v = s["view"]
        if pm:
            view = {"board": self._panel_board, "market": self._panel_market, "black": self._panel_black,
                    "deals": self._panel_deals_pmc, "arsenal": self._panel_arsenal}.get(v, self._panel_pmc)
            return view(uid, pm, note)
        if country:
            view = {"order": self._panel_new_order, "trade": self._panel_trade, "license": self._panel_license,
                    "sanction": self._panel_sanction, "spy": self._panel_spy}.get(v, self._panel_client)
            return view(uid, country, note)
        return self._panel_found(note)

    # — ни страны, ни ЧВК: основание —
    def _panel_found(self, note=None):
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('pmc_base')} Основать свою ЧВК\n"
            f"Вместо государства можно играть за **частную военную компанию**: без территории — "
            f"деньги из контрактов с государствами и частных заказов.\n"
            f"{ui_icon('money')} Старт: **{int_format(P.START_MONEY)} {CURRENCY}** · {ui_icon('soldier')} "
            f"**{int_format(P.START_PERSONNEL)}** бойцов\n"
            f"{ui_icon('deal')} Технику покупаете у стран (их настоящие модели) или на чёрном рынке.\n"
            f"{ui_icon('license')} Страна базирования берёт налог и может выслать — с государствами нужно ладить.\n"
            f"-# Игрок может быть либо страной, либо ЧВК."))
        items.append(disnake.ui.ActionRow(disnake.ui.Button(
            style=disnake.ButtonStyle.success, label="Основать ЧВК", emoji=_pe("pmc"), custom_id=cid("pmc", "found"))))
        return self._container(items)

    # — ЧВК: главная —
    def _panel_pmc(self, uid, pm, note=None):
        s = self._session(uid)
        name = pm["name"]
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(self.profile_text(name)))
        eq = self.pmc.stock(name)
        incoming = len([d for d in self.pmc.deals_open(pmc=name) if d["direction"] == "sell"])
        items.append(disnake.ui.TextDisplay(
            f"{ui_icon('storage')} **Арсенал:** {sum(r['count'] for r in eq)} ед. · {len(eq)} моделей"
            + (f" · {ui_icon('deal')} предложений от стран: **{incoming}**" if incoming else "")))
        active = self.pmc.contracts_of_pmc(name)
        if active:
            lines = []
            for c in active:
                tail = (f" · война #{c['war_id']}" if c["kind"] == "war" else "") + \
                       (f" · до <t:{c['ends_at']}:R>" if c["ends_at"] else "")
                lines.append(f"{ui_icon(P.CONTRACTS[c['kind']]['icon'])} №{c['id']} {P.contract_label(c['kind'])} · "
                             f"заказчик **{c['client']}** · {int_format(c['price'])} {CURRENCY}{tail}")
            items.append(disnake.ui.TextDisplay(f"{ui_icon('contract')} **Активные контракты**\n" + "\n".join(lines)))
            war_c = [c for c in active if c["kind"] == "war"]
            if war_c:
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("pmc", "withdraw"), placeholder="Уйти с войны (штраф к репутации)…",
                    options=[disnake.SelectOption(label=f"№{c['id']} война #{c['war_id']} — {c['client']}"[:100],
                                                  value=str(c["id"]), emoji=_pe("leave_bloc"),
                                                  description=f"репутация {P.REP_WITHDRAW}, заказчику вернётся "
                                                              f"{int(P.WITHDRAW_REFUND * 100)}%"[:100])
                             for c in war_c[:25]])))
        B = disnake.ButtonStyle
        n_open = len(self.pmc.contracts("open"))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label=f"Биржа контрактов · {n_open}", emoji=_pe("contract"),
                              custom_id=cid("pmc", "goto", "board")),
            disnake.ui.Button(style=B.primary, label="Нанять бойцов", emoji=_pe("pmc_hire"), custom_id=cid("pmc", "hire")),
            disnake.ui.Button(style=B.primary, label="Арсенал и связи", emoji=_pe("storage"),
                              custom_id=cid("pmc", "goto", "arsenal"))))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.primary, label="Рынок стран", emoji=_pe("market"),
                              custom_id=cid("pmc", "goto", "market")),
            disnake.ui.Button(style=B.primary, label="Чёрный рынок", emoji=_pe("black_market"),
                              custom_id=cid("pmc", "goto", "black")),
            disnake.ui.Button(style=B.primary, label="Сделки", emoji=_pe("deal"), custom_id=cid("pmc", "goto", "deals"))))
        row = [disnake.ui.Button(style=B.secondary, label="Сменить базу", emoji=_pe("pmc_base"),
                                 custom_id=cid("pmc", "relocate")),
               disnake.ui.Button(style=B.secondary, label="Обновить", emoji=_pe("reload"), custom_id=cid("pmc", "goto", "hub"))]
        if s["confirm"]:
            row.append(disnake.ui.Button(style=B.danger, label="Да, распустить ЧВК", emoji=_pe("split"),
                                         custom_id=cid("pmc", "disband", "yes")))
        else:
            row.append(disnake.ui.Button(style=B.danger, label="Распустить", emoji=_pe("split"),
                                         custom_id=cid("pmc", "disband", "ask")))
        items.append(disnake.ui.ActionRow(*row))
        if s["confirm"]:
            items.append(disnake.ui.TextDisplay(f"{ui_icon('exposed')} Роспуск необратим: компания, деньги и техника "
                                                f"исчезнут, активные контракты будут сорваны."))
        return self._container(items)

    def _panel_arsenal(self, uid, pm, note=None):
        items = self._head(note)
        lines = self.stock_lines(pm["name"], 30)
        items.append(disnake.ui.TextDisplay(f"### {ui_icon('storage')} Арсенал\n" + ("\n".join(lines) if lines else
                                            "-# Техники нет. Покупайте модели у стран или на чёрном рынке.")))
        rl = self.rel_lines(pm["name"], 10)
        items.append(disnake.ui.TextDisplay(
            f"{ui_icon('relations')} **Отношения со странами**\n" + ("\n".join(rl) if rl else "-# Со всеми нейтральные.")
            + f"\n-# Ниже {P.HOSTILE} — страна не нанимает вас, не продаёт оружие и не пускает на базу."))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — ЧВК: рынок стран (просьба продать) —
    def _market_rows(self, pm) -> list:
        out = []
        for r in self.equip.market_rows(P.ALLOWED):
            c = r["country"]
            if not self._player_country(c) or self.sanctioned(pm["name"], c) or self.hostile(pm["name"], c) \
                    or self._embargoed(c):
                continue
            out.append(r)
        return out

    def _panel_market(self, uid, pm, note=None):
        s = self._session(uid)
        items = self._head(note)
        un = self.un_left(pm["name"])
        rows = self._market_rows(pm) if not un else []
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('market')} Рынок стран\nСвободные модели на складах государств. Выберите модель — "
            f"предложите количество и цену; страна примет или откажет. Деньги уходят стране, техника — новая.\n"
            f"-# Цена за единицу — не ниже {int(P.DEAL_MIN_K * 100)}% ориентира. Казна: "
            f"**{int_format(pm['money'])} {CURRENCY}**"
            + (f"\n{ui_icon('sanctions')} **Санкции ООН:** покупки запрещены ещё {un // 3600}ч." if un else "")))
        if rows:
            pages = self._pager(s, len(rows))
            page = rows[s["page"] * _PAGE:(s["page"] + 1) * _PAGE]
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "askpick"), placeholder="Выбрать модель — откроется окно сделки…",
                options=[disnake.SelectOption(
                    label=f"{r['name']} · {r['country']}"[:100], value=f"{r['id']}|{r['country']}"[:100],
                    emoji=_pe_cat(r["category"]),
                    description=f"{E.cat_label(r['category'])}, {E.class_label(r['cls']).lower()} · на складе "
                                f"{r['count']} · ориентир {int_format(P.ref_price(r['category'], r['cls']))}"[:100])
                    for r in page])))
            if pages > 1:
                items.append(self._page_row(s, pages))
        elif not un:
            items.append(disnake.ui.TextDisplay("-# Сейчас никто не готов продать вам подходящую технику."))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — ЧВК: чёрный рынок —
    def _panel_black(self, uid, pm, note=None):
        items = self._head(note)
        now = int(time.time())
        un = self.un_left(pm["name"])
        lots = self.pmc.lots(now)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('black_market')} Чёрный рынок\nКонтрабанда (новые партии раз в сутки) и трофеи с полей "
            f"сражений. Дёшево, но техника **б/у** — воюет на {int(P.GRADES['worn'][1] * 100)}%.\n"
            f"-# Казна: **{int_format(pm['money'])} {CURRENCY}**"
            + (f"\n{ui_icon('sanctions')} **Санкции ООН:** чёрный рынок закрыт ещё {un // 3600}ч." if un else "")))
        if lots and not un:
            items.append(disnake.ui.TextDisplay("\n".join(
                f"{E.cat_icon(lt['category'])} **{lt['model']}** ({self._flag(lt['origin'])} {lt['origin']}) · "
                f"{'трофей' if lt['source'] == 'trophy' else 'контрабанда'} · ×{lt['count']} по "
                f"**{int_format(lt['price'])}** · до <t:{lt['expires_at']}:R>" for lt in lots[:12])))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "lotpick"), placeholder="Купить лот — откроется окно количества…",
                options=[disnake.SelectOption(
                    label=f"{lt['model']} ×{lt['count']}"[:100], value=str(lt["id"]), emoji=_pe_cat(lt["category"]),
                    description=f"{int_format(lt['price'])} за ед. · {E.cat_label(lt['category'])}"[:100])
                    for lt in lots[:_PAGE]])))
        elif not un:
            items.append(disnake.ui.TextDisplay("-# Прилавки пусты — ждите новой партии."))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — сделки —
    def _deal_line(self, d, for_pmc: bool) -> str:
        if for_pmc:
            text = (f"{self._flag(d['country'])} {d['country']} предлагает" if d["direction"] == "sell"
                    else f"вы просите у {self._flag(d['country'])} {d['country']}")
        else:
            text = (f"вы предлагаете ЧВК **{d['pmc']}**" if d["direction"] == "sell"
                    else f"ЧВК **{d['pmc']}** просит")
        return (f"{E.cat_icon(d['category'])} №{d['id']} · {text}: **{d['model']}** ×{d['count']} по "
                f"{int_format(d['price'])} = **{int_format(d['price'] * d['count'])} {CURRENCY}**")

    def _panel_deals_pmc(self, uid, pm, note=None):
        items = self._head(note)
        deals = self.pmc.deals_open(pmc=pm["name"])
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('deal')} Сделки со странами\n" +
            ("\n".join(self._deal_line(d, True) for d in deals[:15]) if deals else "-# Открытых сделок нет.")
            + f"\n-# Сделка живёт {P.DEAL_TTL // 3600}ч. Техника из сделок — новая."))
        incoming = [d for d in deals if d["direction"] == "sell"]
        if incoming:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "dealacc"), placeholder="Принять предложение страны…",
                options=[disnake.SelectOption(label=f"№{d['id']} {d['model']} ×{d['count']} — {d['country']}"[:100],
                                              value=str(d["id"]), emoji=_pe("accept"),
                                              description=f"итого {int_format(d['price'] * d['count'])}"[:100])
                         for d in incoming[:25]])))
        if deals:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "dealno"), placeholder="Отклонить / отозвать сделку…",
                options=[disnake.SelectOption(label=f"№{d['id']} {d['model']} ×{d['count']} — {d['country']}"[:100],
                                              value=str(d["id"]), emoji=_pe("reject")) for d in deals[:25]])))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — ЧВК: биржа контрактов —
    def _contract_line(self, c) -> str:
        meta = P.CONTRACTS[c["kind"]]
        extra = (f" · война #{c['war_id']}" if c["war_id"] else "") + (f" · цель **{c['target']}**" if c["target"] else "")
        return (f"{ui_icon(meta['icon'])} **№{c['id']} {meta['label']}** · {self._flag(c['client'])} {c['client']} · "
                f"**{int_format(c['price'])} {CURRENCY}**{extra}")

    def _take_block(self, pm, c) -> str:
        meta = P.CONTRACTS[c["kind"]]
        if c["status"] != "open":
            return "контракт уже не открыт"
        if not self.licensed(pm):
            return f"нет лицензии — вас выслали из {pm['base']}, смените базу"
        if self.sanctioned(pm["name"], c["client"]):
            return f"{c['client']} ввела против вас санкции"
        if self.hostile(pm["name"], c["client"]):
            return f"отношения с {c['client']} враждебные"
        if (pm["personnel"] or 0) < meta["min_pers"]:
            return f"нужно бойцов от {int_format(meta['min_pers'])}"
        if (pm["reputation"] or 0) < meta["min_rep"]:
            return f"нужна репутация от {meta['min_rep']}"
        if c["kind"] == "war":
            w = self.war.get_war(c["war_id"])
            if not w or w["status"] != "active":
                return "война уже окончена"
            if self.war.is_participant(c["war_id"], pm["name"]):
                return "вы уже в этой войне"
        return ""

    def _panel_board(self, uid, pm, note=None):
        s = self._session(uid)
        items = self._head(note)
        open_c = self.pmc.contracts("open")
        if not open_c:
            items.append(disnake.ui.TextDisplay(f"### {ui_icon('contract')} Биржа контрактов\n-# Открытых заказов нет."))
            items.append(disnake.ui.ActionRow(self._back()))
            return self._container(items)
        items.append(disnake.ui.TextDisplay(f"### {ui_icon('contract')} Биржа контрактов\n"
                                            + "\n".join(self._contract_line(c) for c in open_c[:12])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("pmc", "pick"), placeholder="Открыть заказ…",
            options=[disnake.SelectOption(label=f"№{c['id']} {P.contract_label(c['kind'])} — {c['client']}"[:100],
                                          value=str(c["id"]), emoji=_pe(P.CONTRACTS[c["kind"]]["icon"]),
                                          description=f"{int_format(c['price'])} {CURRENCY}"[:100],
                                          default=(str(c["id"]) == str(s["contract"])))
                     for c in open_c[:_PAGE]])))
        c = self.pmc.contract(int(s["contract"])) if s["contract"] and str(s["contract"]).isdigit() else None
        if c and c["status"] == "open":
            meta = P.CONTRACTS[c["kind"]]
            block = self._take_block(pm, c)
            rate = self.tax_rate(pm)
            items.append(disnake.ui.TextDisplay(
                f"{self._contract_line(c)}\n-# {meta['desc']}\n"
                f"-# Требования: бойцов от {int_format(meta['min_pers'])}, репутация от {meta['min_rep']}"
                + (f" · налог базы {rate}%" if rate else "")
                + (f"\n{ui_icon('reject')} {block}" if block else "")))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Взять контракт", emoji=_pe("contract"),
                                  disabled=bool(block), custom_id=cid("pmc", "take", c["id"])),
                self._back()))
        else:
            items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — страна: главная (заказы + ЧВК мира) —
    def _panel_client(self, uid, country, note=None):
        items = self._head(note)
        mine = self.pmc.contracts_of_client(country.name)
        lines = [self._contract_line(c) + (" · ждёт исполнителя" if c["status"] == "open" else f" · исполняет **{c['pmc']}**")
                 for c in mine]
        items.append(disnake.ui.TextDisplay(
            f"### {country.flag} {country.name} · заказы ЧВК\n" + ("\n".join(lines[:10]) if lines else "-# Заказов нет.")))
        pmcs = self.pmc.all()[:8]
        if pmcs:
            items.append(disnake.ui.TextDisplay(f"{ui_icon('pmc')} **ЧВК мира**\n" + "\n".join(
                f"{ui_icon('reputation')} **[{p['tag']}] {p['name']}** · {P.tier(p['reputation'] or 0)[1]} · "
                f"бойцов {int_format(p['personnel'])} · база {p['base']} · к вам **{self.pmc.rel(p['name'], country.name):+.0f}**"
                + (f" {ui_icon('sanctions')}" if self.sanctioned(p["name"], country.name) else "")
                for p in pmcs)))
        open_mine = [c for c in mine if c["status"] == "open"]
        if open_mine:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "cancel"), placeholder="Отменить заказ (деньги вернутся)…",
                options=[disnake.SelectOption(label=f"№{c['id']} {P.contract_label(c['kind'])}"[:100], value=str(c["id"]),
                                              emoji=_pe("reject"), description=f"{int_format(c['price'])} {CURRENCY}"[:100])
                         for c in open_mine[:25]])))
        B = disnake.ButtonStyle
        n_req = len([d for d in self.pmc.deals_open(country=country.name) if d["direction"] == "ask"])
        based = len(self.pmc.based_in(country.name))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="Разместить заказ", emoji=_pe("contract"),
                              custom_id=cid("pmc", "goto", "order")),
            disnake.ui.Button(style=B.primary, label=f"Продажа техники · {n_req}" if n_req else "Продажа техники",
                              emoji=_pe("sell"), custom_id=cid("pmc", "goto", "trade")),
            disnake.ui.Button(style=B.primary, label=f"Лицензии · {based}", emoji=_pe("license"),
                              custom_id=cid("pmc", "goto", "license"))))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.danger, label="Санкции против ЧВК", emoji=_pe("sanctions"),
                              custom_id=cid("pmc", "goto", "sanction")),
            disnake.ui.Button(style=B.danger, label="Разведка против ЧВК", emoji=_pe("spy"),
                              custom_id=cid("pmc", "goto", "spy")),
            disnake.ui.Button(style=B.secondary, label="Обновить", emoji=_pe("reload"),
                              custom_id=cid("pmc", "goto", "hub"))))
        return self._container(items)

    def _panel_new_order(self, uid, country, note=None):
        s = self._session(uid)
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('contract')} Новый заказ\n-# Сумма замораживается сразу и уходит ЧВК при выполнении. "
            f"Открытый заказ живёт {P.CONTRACT_TTL // 3600}ч, отмена — полный возврат."))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("pmc", "kind"), placeholder="Тип контракта…",
            options=[disnake.SelectOption(label=f"{m['label']} · от {int_format(m['min_price'])}"[:100], value=k,
                                          emoji=_pe(m["icon"]), description=m["desc"][:100], default=(k == s["kind"]))
                     for k, m in P.CONTRACTS.items()])))
        ready = bool(s["kind"])
        if s["kind"] == "war":
            wars = list(self.war.active_for(country.name))
            if wars:
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("pmc", "war"), placeholder="Ваша война…",
                    options=[disnake.SelectOption(
                        label=f"Война #{w['id']}: {w['attacker']} — {w['defender']}"[:100], value=str(w["id"]),
                        emoji=_pe("war"), default=(str(w["id"]) == str(s["war"]))) for w in wars[:25]])))
            else:
                items.append(disnake.ui.TextDisplay("-# У вас нет активных войн."))
            ready = bool(s["war"])
        elif s["kind"] == "special":
            names = sorted(n for n in self.countries.get_object_names() if n != country.name)
            if names:
                pages = self._pager(s, len(names))
                page = names[s["page"] * _PAGE:(s["page"] + 1) * _PAGE]
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("pmc", "target"), placeholder="Цель спецоперации…",
                    options=[disnake.SelectOption(label=n[:100], value=n[:100], default=(n == s["target"]))
                             for n in page])))
                if pages > 1:
                    items.append(self._page_row(s, pages))
            else:
                items.append(disnake.ui.TextDisplay("-# Других стран-игроков нет."))
            ready = bool(s["target"])
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, label="Указать сумму и разместить",
                              emoji=_pe("money"), disabled=not ready, custom_id=cid("pmc", "price")),
            self._back()))
        return self._container(items)

    # — страна: продажа техники ЧВК —
    def _sellable(self, country: str) -> list:
        return [r for r in self.equip.arsenal(country) if r["category"] in P.ALLOWED]

    def _panel_trade(self, uid, country, note=None):
        s = self._session(uid)
        items = self._head(note)
        deals = self.pmc.deals_open(country=country.name)
        emb = self._embargoed(country.name)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('sell')} Продажа техники ЧВК\nПродавайте ЧВК модели со своего склада (свободный резерв, не "
            f"в соединениях) — деньги в казну. Флот, стратегическая авиация и ракеты ЧВК не продаются.\n"
            + ("\n".join(self._deal_line(d, False) for d in deals[:10]) if deals else "-# Открытых сделок нет.")
            + (f"\n{ui_icon('un_embargo')} **Оружейное эмбарго ООН** — продавать нельзя." if emb else "")))
        req = [d for d in deals if d["direction"] == "ask"]
        if req:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "dealacc"), placeholder="Принять просьбу ЧВК…",
                options=[disnake.SelectOption(label=f"№{d['id']} {d['model']} ×{d['count']} — {d['pmc']}"[:100],
                                              value=str(d["id"]), emoji=_pe("accept"),
                                              description=f"итого {int_format(d['price'] * d['count'])}"[:100])
                         for d in req[:25]])))
        if deals:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "dealno"), placeholder="Отклонить / отозвать сделку…",
                options=[disnake.SelectOption(label=f"№{d['id']} {d['model']} ×{d['count']} — {d['pmc']}"[:100],
                                              value=str(d["id"]), emoji=_pe("reject")) for d in deals[:25]])))
        stock = self._sellable(country.name)
        pmcs = [p for p in self.pmc.all() if not self.sanctioned(p["name"], country.name)]
        if stock and pmcs and not emb:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "sellmodel"), placeholder="Модель со склада…",
                options=[disnake.SelectOption(
                    label=f"{r['name']} ×{r['count']}"[:100], value=str(r["id"]), emoji=_pe_cat(r["category"]),
                    description=f"{E.cat_label(r['category'])} · ориентир {int_format(P.ref_price(r['category'], r['cls']))}"[:100],
                    default=(str(r["id"]) == str(s["sell_eid"]))) for r in stock[:25]])))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "sellpmc"), placeholder="Кому продать…",
                options=[disnake.SelectOption(
                    label=f"[{p['tag']}] {p['name']}"[:100], value=p["name"][:100], emoji=_pe("pmc"),
                    description=f"{P.tier(p['reputation'] or 0)[1]} · отношения {self.pmc.rel(p['name'], country.name):+.0f}"[:100],
                    default=(p["name"] == s["sell_pmc"])) for p in pmcs[:25]])))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Количество и цена", emoji=_pe("sell"),
                                  disabled=not (s["sell_eid"] and s["sell_pmc"]), custom_id=cid("pmc", "sellgo")),
                self._back()))
        else:
            if not emb:
                items.append(disnake.ui.TextDisplay("-# Нет подходящей техники на складе или нет ЧВК-покупателей."))
            items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — страна: лицензии ЧВК на своей территории —
    def _panel_license(self, uid, country, note=None):
        items = self._head(note)
        based = self.pmc.based_in(country.name)
        rate = self.pmc.tax(country.name)
        lines = [f"{ui_icon('pmc')} **[{p['tag']}] {p['name']}** · {P.tier(p['reputation'] or 0)[1]} · бойцов "
                 f"{int_format(p['personnel'])} · " + ("лицензия есть" if self.licensed(p) else f"{ui_icon('expel')} выслана")
                 for p in based]
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('license')} ЧВК на территории {country.flag} {country.name}\n"
            f"Налог с контрактов всех ЧВК с базой у вас: **{rate}%**. Высланная ЧВК не берёт контракты и не "
            f"получает частные заказы, пока не сменит базу.\n" + ("\n".join(lines[:15]) if lines else "-# Здесь нет ЧВК.")))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("pmc", "tax"), placeholder="Ставка налога…",
            options=[disnake.SelectOption(label=f"Налог {t}%", value=str(t), emoji=_pe("treasury"), default=(t == rate))
                     for t in P.TAX_STEPS])))
        if based:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "expel"), placeholder="Выслать ЧВК / вернуть лицензию…",
                options=[disnake.SelectOption(
                    label=(f"Выслать: {p['name']}" if self.licensed(p) else f"Вернуть лицензию: {p['name']}")[:100],
                    value=p["name"][:100], emoji=_pe("expel" if self.licensed(p) else "license"))
                    for p in based[:25]])))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — страна: санкции против ЧВК —
    def _panel_sanction(self, uid, country, note=None):
        items = self._head(note)
        pmcs = self.pmc.all()
        mine = set(self.pmc.sanctioned_by(country.name))
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('sanctions')} Санкции против ЧВК\nСанкции страны: ЧВК не может брать ваши контракты и "
            f"покупать у вас технику; отношения {P.REL_SANCTION}. Глобальные санкции вводит Совбез ООН (`!оон`).\n"
            + ("\n".join(f"{ui_icon('sanctions')} {n}" for n in sorted(mine)) if mine else "-# Ваших санкций нет.")))
        if pmcs:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "sanct"), placeholder="Ввести / снять санкции…",
                options=[disnake.SelectOption(
                    label=(f"Снять: {p['name']}" if p["name"] in mine else f"Ввести: {p['name']}")[:100],
                    value=p["name"][:100], emoji=_pe("check" if p["name"] in mine else "sanctions"))
                    for p in pmcs[:25]])))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — страна: разведка против ЧВК —
    def _panel_spy(self, uid, country, note=None):
        s = self._session(uid)
        items = self._head(note)
        now = int(time.time())
        recon, _c = Spy().get_agency(country.name)
        cd = max(0, int(self.cooldown.get_cooldown("pmc_spy", country.name) - now))
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('spy')} Разведка против ЧВК\nВаша разведка: **ур. {recon}**. Защита ЧВК зависит от её "
            f"уровня (новички / профессионалы / элита). Провал может вскрыть операцию публично.\n"
            + "\n".join(f"{ui_icon(m['icon'])} **{m['label']}** · {int_format(m['cost'])} — {m['desc']}"
                        for m in P.SPY_OPS.values())
            + (f"\n-# Следующая операция против ЧВК через {cd // 3600}ч {cd % 3600 // 60}м." if cd else "")))
        pmcs = self.pmc.all()
        if pmcs:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "spypmc"), placeholder="Цель — ЧВК…",
                options=[disnake.SelectOption(label=f"[{p['tag']}] {p['name']}"[:100], value=p["name"][:100],
                                              emoji=_pe("pmc"), description=f"{P.tier(p['reputation'] or 0)[1]}"[:100],
                                              default=(p["name"] == s["spy_pmc"])) for p in pmcs[:25]])))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("pmc", "spyop"), placeholder="Операция…",
                options=[disnake.SelectOption(label=f"{m['label']} · {int_format(m['cost'])}"[:100], value=k,
                                              emoji=_pe(m["icon"]), default=(k == s["spy_op"]))
                         for k, m in P.SPY_OPS.items()])))
        else:
            items.append(disnake.ui.TextDisplay("-# В мире нет ЧВК."))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Провести операцию", emoji=_pe("spy"),
                              disabled=not (s["spy_pmc"] and s["spy_op"]) or cd > 0, custom_id=cid("pmc", "spygo")),
            self._back()))
        return self._container(items)

    def _card(self, c, closed: str | None = None) -> Panel:
        meta = P.CONTRACTS[c["kind"]]
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon(meta['icon'])} Заказ №{c['id']} · {meta['label']}\n{self._contract_line(c)}\n-# {meta['desc']}\n"
            f"-# Требования: бойцов от {int_format(meta['min_pers'])}, репутация от {meta['min_rep']}")]
        if closed:
            items.append(disnake.ui.TextDisplay(closed))
        elif c["status"] == "open":
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.success, label="Взять контракт", emoji=_pe("contract"),
                custom_id=cid("pmc", "take", c["id"]))))
            items.append(disnake.ui.TextDisplay(f"-# Открыт до <t:{c['deadline']}:R>. Взять может любая ЧВК, "
                                                f"подходящая по требованиям."))
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(PMC_COLOR)))
        return p

    async def _refresh_card(self, c, closed: str):
        if not c or not c["channel_id"] or not c["msg_id"]:
            return
        ch = self.bot.get_channel(c["channel_id"])
        if not ch:
            return
        try:
            msg = await ch.fetch_message(c["msg_id"])
            await msg.edit(components=self._card(c, closed).components)
        except Exception:
            pass

    # ═══════════════ МОДАЛКИ ═══════════════
    def found_modal(self, from_reg: bool = False):
        """Окно основания ЧВК. from_reg — вызвано из публичной панели регистрации (ответ — приватный)."""
        return disnake.ui.Modal(title="Основать ЧВК", custom_id=cid("pmc", "mfoundreg" if from_reg else "mfound"),
                                components=[
            disnake.ui.TextInput(label="Название", custom_id="name", style=disnake.TextInputStyle.short,
                                 min_length=P.NAME_MIN, max_length=P.NAME_MAX, placeholder="Северный легион"),
            disnake.ui.TextInput(label=f"Тег ({P.TAG_MIN}–{P.TAG_MAX} букв)", custom_id="tag",
                                 style=disnake.TextInputStyle.short, min_length=P.TAG_MIN, max_length=P.TAG_MAX,
                                 placeholder="СЛ"),
            disnake.ui.TextInput(label="Страна базирования (любая страна мира)", custom_id="base",
                                 style=disnake.TextInputStyle.short, max_length=60, placeholder="Армения")])

    def _amount_modal(self, action: str, title: str, label: str, *args):
        return disnake.ui.Modal(title=title[:45], custom_id=cid("pmc", action, *args), components=[
            disnake.ui.TextInput(label=label[:45], custom_id="n", style=disnake.TextInputStyle.short,
                                 max_length=20, placeholder="например 100 или 5kk")])

    def _deal_modal(self, action: str, title: str, ref: int, *args):
        return disnake.ui.Modal(title=title[:45], custom_id=cid("pmc", action, *args), components=[
            disnake.ui.TextInput(label=f"Количество (до {P.DEAL_MAX_UNITS})", custom_id="n",
                                 style=disnake.TextInputStyle.short, max_length=6, placeholder="10"),
            disnake.ui.TextInput(label=f"Цена за ед. (от {int_format(int(ref * P.DEAL_MIN_K))})"[:45], custom_id="p",
                                 style=disnake.TextInputStyle.short, max_length=20, placeholder=str(ref))])

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _pmc_drop(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("pmc:"):
            return
        _, action, _ = parse_cid(c)
        v = inter.values[0] if inter.values else None
        s = self._session(inter.author.id)
        uid = inter.author.id
        if action == "askpick" and v and "|" in v:
            eid, country = v.split("|", 1)
            eq = self.equip.get(int(eid)) if eid.isdigit() else None
            if eq:
                await inter.response.send_modal(self._deal_modal(
                    "mask", f"Купить у {country}: {eq['name']}", P.ref_price(eq["category"], eq["cls"]), eid, country))
                return
        if action == "lotpick" and v and v.isdigit():
            lot = self.pmc.lot(int(v))
            if lot and lot["count"] > 0:
                await inter.response.send_modal(self._amount_modal(
                    "mlot", f"Купить: {lot['model']}", f"Сколько (есть {lot['count']}, по {int_format(lot['price'])})", v))
                return
        await self._defer(inter)
        note = None
        if action == "pick":
            s["contract"] = v
        elif action == "kind":
            s.update(kind=v, war=None, target=None, page=0)
        elif action == "war":
            s["war"] = v
        elif action == "target":
            s["target"] = v
        elif action == "cancel" and v and v.isdigit():
            note = await self._cancel(uid, int(v))
        elif action == "withdraw" and v and v.isdigit():
            note = await self._withdraw(uid, int(v))
        elif action == "dealacc" and v and v.isdigit():
            note = await self._deal_accept(uid, int(v))
        elif action == "dealno" and v and v.isdigit():
            note = await self._deal_close(uid, int(v))
        elif action == "sellmodel":
            s["sell_eid"] = v
        elif action == "sellpmc":
            s["sell_pmc"] = v
        elif action == "tax" and v and v.isdigit():
            note = self._set_tax(uid, int(v))
        elif action == "expel" and v:
            note = await self._expel_toggle(uid, v)
        elif action == "sanct" and v:
            note = await self._sanction_toggle(uid, v)
        elif action == "spypmc":
            s["spy_pmc"] = v
        elif action == "spyop":
            s["spy_op"] = v
        elif action in ("askpick", "lotpick"):
            note = f"{ui_icon('reject')} Позиция уже недоступна."
        await inter.edit_original_message(components=self._render(uid, note).components)

    @commands.Cog.listener("on_button_click")
    async def _pmc_btn(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("pmc:"):
            return
        _, action, args = parse_cid(c)
        s = self._session(inter.author.id)
        uid = inter.author.id
        if action == "found":
            await inter.response.send_modal(self.found_modal())
            return
        if action == "hire":
            await inter.response.send_modal(self._amount_modal(
                "mhire", "Нанять бойцов", f"Сколько бойцов ({int_format(P.HIRE_COST)} за бойца)"))
            return
        if action == "relocate":
            await inter.response.send_modal(disnake.ui.Modal(
                title="Сменить страну базирования", custom_id=cid("pmc", "mmove"), components=[
                    disnake.ui.TextInput(label=f"Новая страна (переезд {int_format(P.RELOCATE_COST)})"[:45],
                                         custom_id="base", style=disnake.TextInputStyle.short, max_length=60)]))
            return
        if action == "price":
            k = s["kind"]
            await inter.response.send_modal(self._amount_modal(
                "morder", "Сумма контракта",
                f"Сумма (от {int_format(P.CONTRACTS[k]['min_price'])})" if k in P.CONTRACTS else "Сумма"))
            return
        if action == "sellgo" and s["sell_eid"] and str(s["sell_eid"]).isdigit() and s["sell_pmc"]:
            eq = self.equip.get(int(s["sell_eid"]))
            if eq:
                await inter.response.send_modal(self._deal_modal(
                    "msell", f"Продать {s['sell_pmc']}", P.ref_price(eq["category"], eq["cls"])))
                return
        if action == "take" and args and args[0].isdigit():
            await self._defer(inter)
            note = await self._take(uid, int(args[0]))
            if inter.guild is None:      # кнопка в ЛС-панели — перерисовываем панель
                s["view"] = "board"
                await inter.edit_original_message(components=self._render(uid, note).components)
            else:                        # кнопка на карточке в канале — карточку не трогаем, ответ приватный
                await inter.followup.send(note[:1900], ephemeral=True)
            return
        await self._defer(inter)
        note = None
        if action == "goto":
            s.update(view=args[0] if args else "hub", confirm=False, page=0)
            if s["view"] in ("hub", "order"):
                s.update(contract=None)
            if s["view"] == "order":
                s.update(kind=None, war=None, target=None)
            if s["view"] == "trade":
                s.update(sell_eid=None, sell_pmc=None)
            if s["view"] == "spy":
                s.update(spy_pmc=None, spy_op=None)
        elif action == "page" and args:
            if args[0] == "prev":
                s["page"] = max(0, s["page"] - 1)
            elif args[0] == "next":
                s["page"] += 1
        elif action == "disband" and args:
            if args[0] == "ask":
                s["confirm"] = True
            else:
                note = await self._disband(uid, inter.guild)
                s.update(view="hub", confirm=False)
        elif action == "spygo":
            note = await self._spy_run(uid)
        await inter.edit_original_message(components=self._render(uid, note).components)

    @commands.Cog.listener("on_modal_submit")
    async def _pmc_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("pmc:"):
            return
        _, action, args = parse_cid(c)
        s = self._session(inter.author.id)
        uid = inter.author.id
        tv = inter.text_values
        if action == "mfoundreg":   # из панели регистрации: публичное сообщение не трогаем — отвечаем приватно
            await inter.response.defer(ephemeral=True)
            note = await self._found(inter.author, tv)
            ok = note.startswith(ui_icon("check"))
            p = self._container([disnake.ui.TextDisplay(
                note + ("\n-# Управление компанией — команда **`!чвк`** (панель придёт в личные сообщения)." if ok else ""))],
                SUCCESS_COLOR if ok else WARNING_COLOR)
            await inter.followup.send(components=p.components, ephemeral=True)
            return
        await inter.response.defer()
        if action == "mfound":
            note = await self._found(inter.author, tv)
        elif action == "mhire":
            note = self._hire(uid, _num(tv.get("n", "")))
        elif action == "mmove":
            note = await self._relocate(uid, tv.get("base", ""))
        elif action == "mlot" and args and args[0].isdigit():
            note = self._buy_lot(uid, int(args[0]), _num(tv.get("n", "")))
            s["view"] = "black"
        elif action == "mask" and len(args) >= 2 and args[0].isdigit():
            note = await self._ask(uid, int(args[0]), args[1], _num(tv.get("n", "")), _num(tv.get("p", "")))
            s["view"] = "market"
        elif action == "msell":
            note = await self._sell(uid, _num(tv.get("n", "")), _num(tv.get("p", "")))
            s["view"] = "trade"
        elif action == "morder":
            note = await self._order(uid, _num(tv.get("n", "")))
        else:
            return
        await inter.edit_original_message(components=self._render(uid, note).components)

    # ═══════════════ ОСНОВАНИЕ / БАЗА ═══════════════
    def _roster_name(self, raw: str) -> str | None:
        r = (raw or "").strip().lower()
        return next((n for n in config.COUNTRIES_ROSTER if n.lower() == r), None)

    def _base_block(self, name: str | None, base: str) -> str:
        """Можно ли базироваться в стране base. name — ЧВК (None при основании)."""
        if not WM.resolve_a3(base):
            return f"страна «{base}» не найдена на карте"
        if Npc().state(base)["dissolved"]:
            return f"{base} больше не существует"
        if name:
            now = int(time.time())
            if self.pmc.has_sanction(name, base, "expel", now):
                return f"{base} выслала вас — туда нельзя"
            if self.pmc.has_sanction(name, base, "sanction", now):
                return f"{base} ввела против вас санкции"
            if self.hostile(name, base):
                return f"отношения с {base} враждебные"
        return ""

    async def _found(self, author, tv: dict) -> str:
        uid = author.id
        if self.countries.get_object_by_user(uid):
            return f"{ui_icon('reject')} У вас есть страна — игрок может быть либо страной, либо ЧВК."
        if self.pmc.by_user(uid):
            return f"{ui_icon('reject')} У вас уже есть ЧВК."
        name = re.sub(r"\s+", " ", tv.get("name", "")).strip()[:P.NAME_MAX]
        tag = re.sub(r"[^\wА-Яа-яЁё]", "", tv.get("tag", "")).upper()[:P.TAG_MAX]
        base = self._roster_name(tv.get("base", ""))
        if len(name) < P.NAME_MIN or len(tag) < P.TAG_MIN:
            return f"{ui_icon('reject')} Нужны название и тег."
        if not re.search(r"[\wА-Яа-яЁё]", name) or any(ch in name for ch in ":|[]@#`*_~"):
            return f"{ui_icon('reject')} Недопустимые символы в названии."
        if not base:
            return f"{ui_icon('reject')} Страна базирования «{tv.get('base', '')}» не найдена — напишите как в списке стран."
        block = self._base_block(None, base)
        if block:
            return f"{ui_icon('reject')} {block}."
        if self.pmc.name_taken(name, tag) or self.countries.get_object(name) or self._roster_name(name):
            return f"{ui_icon('reject')} Название или тег заняты."   # не путать с государствами
        now = int(time.time())
        self.pmc.create(name, tag, uid, base, P.START_MONEY, P.START_PERSONNEL, P.REP_START, now)
        self.pmc.set(name, last_move=now)
        News().clear_country(name)
        News().touch(name, now, log=False)          # отсчёт правила простоя — с момента основания
        await self._grant_roles(author, name, tag)
        self.bot.dispatch("map_dirty")
        await self._post(f"{ui_icon('pmc')} Новая ЧВК **[{tag}] {name}** открывает набор контрактов. "
                         f"База — {self._flag(base)} {base}.")
        await self._dm_country(base, f"{ui_icon('license')} На вашей территории зарегистрирована ЧВК **[{tag}] {name}**. "
                                     f"Налог с её контрактов и высылка — `!чвк` → «Лицензии».")
        return (f"{ui_icon('check')} ЧВК **[{tag}] {name}** основана! {int_format(P.START_PERSONNEL)} бойцов и "
                f"{int_format(P.START_MONEY)} {CURRENCY}. Технику покупайте у стран и на чёрном рынке, "
                f"берите контракты на бирже. Публикуйте мировые новости — правило простоя действует и для ЧВК.")

    @staticmethod
    def nick(name: str, tag: str) -> str:
        return f"[{tag}] {name}"[:32]

    async def _grant_roles(self, author, name: str, tag: str):
        g = self.bot.get_guild(GUILD_ID)
        member = g.get_member(author.id) if g else None
        if not member:
            return
        try:
            from cogs.registration import _apply_registered_roles, _role
            await _apply_registered_roles(g, member)          # «Зарегистрирован» — доступ к игровым каналам
            pmc_role = _role(g, "ROLE_PMC", getattr(config, "PMC_ROLE", 0))
            if pmc_role:
                await member.add_roles(pmc_role, reason="основана ЧВК")
        except Exception:
            log.exception("роли ЧВК")
        try:
            await member.edit(nick=self.nick(name, tag), reason="ЧВК")
        except Exception:
            pass

    async def _sync_nicks(self):
        """После перезапуска: ники всех ЧВК — в формате «[ТЕГ] Название»."""
        g = self.bot.get_guild(GUILD_ID)
        if not g:
            return
        for p in self.pmc.all():
            m = g.get_member(p["user"])
            want = self.nick(p["name"], p["tag"])
            if m and m.nick != want:
                try:
                    await m.edit(nick=want, reason="ЧВК: формат ника")
                except Exception:
                    pass

    async def _relocate(self, uid: int, raw: str) -> str:
        pm = self.pmc.by_user(uid)
        if not pm:
            return f"{ui_icon('reject')} ЧВК не найдена."
        base = self._roster_name(raw)
        if not base:
            return f"{ui_icon('reject')} Страна «{raw}» не найдена — напишите как в списке стран."
        if base == pm["base"]:
            return f"{ui_icon('reject')} Вы уже базируетесь в {base}."
        block = self._base_block(pm["name"], base)
        if block:
            return f"{ui_icon('reject')} {block}."
        now = int(time.time())
        expelled = not self.licensed(pm)
        left = (pm["last_move"] or 0) + P.RELOCATE_CD - now
        if left > 0 and not expelled:
            return (f"{ui_icon('reject')} Переезд не чаще раза в {P.RELOCATE_CD // 3600}ч — ещё "
                    f"{left // 3600}ч {left % 3600 // 60}м.")
        if (pm["money"] or 0) < P.RELOCATE_COST:
            return f"{ui_icon('reject')} Переезд стоит {int_format(P.RELOCATE_COST)} {CURRENCY}."
        old = pm["base"]
        self.pmc.add_money(pm["name"], -P.RELOCATE_COST)
        self.pmc.set(pm["name"], base=base, last_move=now)
        self.bot.dispatch("map_dirty")
        await self._post(f"{ui_icon('pmc_base')} ЧВК **[{pm['tag']}] {pm['name']}** переносит базу: {old} → "
                         f"{self._flag(base)} **{base}**.")
        await self._dm_country(base, f"{ui_icon('license')} ЧВК **[{pm['tag']}] {pm['name']}** перенесла базу на вашу "
                                     f"территорию. Налог и высылка — `!чвк` → «Лицензии».")
        return f"{ui_icon('pmc_base')} База перенесена в **{base}** (−{int_format(P.RELOCATE_COST)} {CURRENCY})."

    # ═══════════════ НАЁМ / ПОКУПКИ ═══════════════
    def _hire(self, uid: int, n: int | None) -> str:
        pm = self.pmc.by_user(uid)
        if not pm or not n:
            return f"{ui_icon('reject')} Неверное количество."
        n = min(n, P.HIRE_MAX)
        cost = n * P.HIRE_COST
        if (pm["money"] or 0) < cost:
            return f"{ui_icon('reject')} Нужно {int_format(cost)} {CURRENCY}."
        self.pmc.add_money(pm["name"], -cost)
        self.pmc.set(pm["name"], personnel=(pm["personnel"] or 0) + n)
        return f"{ui_icon('pmc_hire')} Нанято **{int_format(n)}** бойцов за {int_format(cost)} {CURRENCY}."

    def _buy_lot(self, uid: int, lid: int, n: int | None) -> str:
        pm = self.pmc.by_user(uid)
        now = int(time.time())
        lot = self.pmc.lot(lid)
        if not pm or not n:
            return f"{ui_icon('reject')} Неверное количество."
        if self.un_left(pm["name"]):
            return f"{ui_icon('sanctions')} Санкции ООН: чёрный рынок для вас закрыт."
        if not lot or lot["count"] <= 0 or lot["expires_at"] <= now:
            return f"{ui_icon('reject')} Лот уже ушёл."
        if n > lot["count"]:
            return f"{ui_icon('reject')} В лоте только {lot['count']} ед."
        cost = n * lot["price"]
        if (pm["money"] or 0) < cost:
            return f"{ui_icon('reject')} Нужно {int_format(cost)} {CURRENCY}."
        if not self.pmc.take_lot(lid, n, now):
            return f"{ui_icon('reject')} Лот уже ушёл."
        self.pmc.add_money(pm["name"], -cost)
        self.pmc.add_stock(pm["name"], lot["model"], lot["category"], lot["cls"], lot["origin"], "worn", n)
        self.pmc.prune_lots(now, P.POOL_MAX)
        return f"{ui_icon('black_market')} Куплено **{n} × {lot['model']}** (б/у) за {int_format(cost)} {CURRENCY}."

    # ═══════════════ СДЕЛКИ СО СТРАНАМИ ═══════════════
    def _deal_terms_block(self, eq, count, price) -> str:
        if not eq or eq["category"] not in P.ALLOWED:
            return "эту технику ЧВК не продают"
        if not count or count > P.DEAL_MAX_UNITS:
            return f"количество от 1 до {P.DEAL_MAX_UNITS}"
        ref = P.ref_price(eq["category"], eq["cls"])
        if not price or price < int(ref * P.DEAL_MIN_K):
            return f"цена за единицу не ниже {int_format(int(ref * P.DEAL_MIN_K))}"
        return ""

    def _deal_block(self, d, check_money: bool = True) -> str:
        """Полная проверка сделки (при создании и в момент исполнения)."""
        pm = self.pmc.get(d["pmc"])
        if not pm:
            return "ЧВК больше не существует"
        if not self.countries.get_object(d["country"]):
            return "страна больше не в игре"
        if self.un_left(pm["name"]):
            return "ЧВК под санкциями ООН — покупки запрещены"
        if self.sanctioned(pm["name"], d["country"]):
            return f"{d['country']} ввела санкции против ЧВК"
        if self.hostile(pm["name"], d["country"]):
            return "отношения враждебные"
        if self._embargoed(d["country"]):
            return f"{d['country']} под оружейным эмбарго ООН"
        if self.equip.stock_of(d["country"], d["equipment_id"]) < d["count"]:
            return f"на складе {d['country']} уже нет {d['count']} × {d['model']}"
        if check_money and (pm["money"] or 0) < d["price"] * d["count"]:
            return f"у ЧВК нет {int_format(d['price'] * d['count'])} {CURRENCY}"
        return ""

    async def _sell(self, uid: int, n: int | None, price: int | None) -> str:
        """Страна предлагает ЧВК модель со своего склада."""
        s = self._session(uid)
        o = self.countries.get_object_by_user(uid)
        if not o or not s["sell_eid"] or not str(s["sell_eid"]).isdigit() or not s["sell_pmc"]:
            return f"{ui_icon('reject')} Выберите модель и ЧВК."
        eq = self.equip.get(int(s["sell_eid"]))
        pm = self.pmc.get(s["sell_pmc"])
        if not pm:
            return f"{ui_icon('reject')} ЧВК не найдена."
        block = self._deal_terms_block(eq, n, price)
        if block:
            return f"{ui_icon('reject')} {block}."
        if len(self.pmc.deals_open(country=o.name)) >= P.DEALS_OPEN_MAX:
            return f"{ui_icon('reject')} Слишком много открытых сделок (до {P.DEALS_OPEN_MAX})."
        block = self._deal_block({"pmc": pm["name"], "country": o.name, "equipment_id": eq["id"], "count": n,
                                  "price": price, "model": eq["name"]}, check_money=False)
        if block:
            return f"{ui_icon('reject')} {block}."
        did = self.pmc.create_deal("sell", o.name, pm["name"], eq, n, price, int(time.time()))
        s.update(sell_eid=None, sell_pmc=None)
        await self._dm_pmc(pm["name"], f"{ui_icon('deal')} {o.flag} **{o.name}** предлагает вам **{eq['name']}** ×{n} "
                                       f"по {int_format(price)} (итого **{int_format(n * price)} {CURRENCY}**). "
                                       f"Сделка №{did}: `!чвк` → «Сделки».")
        return f"{ui_icon('deal')} Предложение №{did} отправлено ЧВК **{pm['name']}**."

    async def _ask(self, uid: int, eid: int, country: str, n: int | None, price: int | None) -> str:
        """ЧВК просит страну продать модель."""
        pm = self.pmc.by_user(uid)
        eq = self.equip.get(eid)
        if not pm:
            return f"{ui_icon('reject')} ЧВК не найдена."
        block = self._deal_terms_block(eq, n, price)
        if block:
            return f"{ui_icon('reject')} {block}."
        if len([d for d in self.pmc.deals_open(pmc=pm["name"]) if d["direction"] == "ask"]) >= P.DEALS_OPEN_MAX:
            return f"{ui_icon('reject')} Слишком много открытых просьб (до {P.DEALS_OPEN_MAX})."
        block = self._deal_block({"pmc": pm["name"], "country": country, "equipment_id": eid, "count": n,
                                  "price": price, "model": eq["name"]})
        if block:
            return f"{ui_icon('reject')} {block}."
        did = self.pmc.create_deal("ask", country, pm["name"], eq, n, price, int(time.time()))
        await self._dm_country(country, f"{ui_icon('deal')} ЧВК **[{pm['tag']}] {pm['name']}** просит продать "
                                        f"**{eq['name']}** ×{n} по {int_format(price)} (итого **{int_format(n * price)} "
                                        f"{CURRENCY}** в вашу казну). Сделка №{did}: `!чвк` → «Продажа техники».")
        return f"{ui_icon('deal')} Просьба №{did} отправлена {self._flag(country)} **{country}**."

    async def _deal_accept(self, uid: int, did: int) -> str:
        d = self.pmc.deal(did)
        if not d or d["status"] != "open":
            return f"{ui_icon('reject')} Сделка уже закрыта."
        pm = self.pmc.by_user(uid)
        o = self.countries.get_object_by_user(uid)
        # принимает тот, КОМУ адресовано: предложение страны — ЧВК, просьбу ЧВК — страна
        if d["direction"] == "sell" and not (pm and pm["name"] == d["pmc"]):
            return f"{ui_icon('reject')} Это не ваша сделка."
        if d["direction"] == "ask" and not (o and o.name == d["country"]):
            return f"{ui_icon('reject')} Это не ваша сделка."
        block = self._deal_block(d)
        if block:
            return f"{ui_icon('reject')} Сделка невозможна: {block}."
        if not self.pmc.close_deal(did, "done"):      # атомарно — второй клик не исполнит дважды
            return f"{ui_icon('reject')} Сделка уже закрыта."
        total = d["price"] * d["count"]
        self.equip.add_stock(d["country"], d["equipment_id"], -d["count"])
        update_money(d["country"], total)
        self.pmc.add_money(d["pmc"], -total)
        self.pmc.add_stock(d["pmc"], d["model"], d["category"], d["cls"], d["country"], "new", d["count"])
        self.pmc.add_rel(d["pmc"], d["country"], P.REL_SALE)
        text = (f"{ui_icon('deal')} Сделка №{did} исполнена: **{d['model']}** ×{d['count']} → ЧВК **{d['pmc']}**, "
                f"{int_format(total)} {CURRENCY} → {d['country']}.")
        if d["direction"] == "sell":
            await self._dm_country(d["country"], text)
        else:
            await self._dm_pmc(d["pmc"], text)
        return text

    async def _deal_close(self, uid: int, did: int) -> str:
        d = self.pmc.deal(did)
        if not d or d["status"] != "open":
            return f"{ui_icon('reject')} Сделка уже закрыта."
        pm = self.pmc.by_user(uid)
        o = self.countries.get_object_by_user(uid)
        if not ((pm and pm["name"] == d["pmc"]) or (o and o.name == d["country"])):
            return f"{ui_icon('reject')} Это не ваша сделка."
        if not self.pmc.close_deal(did, "declined"):
            return f"{ui_icon('reject')} Сделка уже закрыта."
        text = f"{ui_icon('reject')} Сделка №{did} ({d['model']} ×{d['count']}) закрыта без исполнения."
        if pm:
            await self._dm_country(d["country"], text)
        else:
            await self._dm_pmc(d["pmc"], text)
        return text

    # ═══════════════ ЛИЦЕНЗИИ / САНКЦИИ ═══════════════
    def _set_tax(self, uid: int, rate: int) -> str:
        o = self.countries.get_object_by_user(uid)
        if not o or rate not in P.TAX_STEPS:
            return f"{ui_icon('reject')} Неверная ставка."
        self.pmc.set_tax(o.name, rate)
        return f"{ui_icon('treasury')} Налог с контрактов ЧВК на вашей территории — **{rate}%**."

    async def _expel_toggle(self, uid: int, name: str) -> str:
        o = self.countries.get_object_by_user(uid)
        pm = self.pmc.get(name)
        if not o or not pm or pm["base"] != o.name:
            return f"{ui_icon('reject')} Эта ЧВК не базируется у вас."
        if self.licensed(pm):
            self.pmc.sanction(name, o.name, "expel", 0)
            await self._dm_pmc(name, f"{ui_icon('expel')} {o.flag} **{o.name}** отозвала вашу лицензию. Контракты и "
                                     f"частные заказы недоступны, пока вы не смените базу (`!чвк` → «Сменить базу»).")
            await self._post(f"{ui_icon('expel')} {o.flag} **{o.name}** высылает ЧВК **[{pm['tag']}] {name}** со своей "
                             f"территории.", WARNING_COLOR)
            self._journal(o.name, name, f"{o.name} выслала ЧВК {name}")
            return f"{ui_icon('expel')} ЧВК **{name}** выслана."
        self.pmc.unsanction(name, o.name, "expel")
        await self._dm_pmc(name, f"{ui_icon('license')} {o.flag} **{o.name}** вернула вам лицензию.")
        return f"{ui_icon('license')} Лицензия ЧВК **{name}** восстановлена."

    async def _sanction_toggle(self, uid: int, name: str) -> str:
        o = self.countries.get_object_by_user(uid)
        pm = self.pmc.get(name)
        if not o or not pm:
            return f"{ui_icon('reject')} ЧВК не найдена."
        if self.sanctioned(name, o.name):
            self.pmc.unsanction(name, o.name, "sanction")
            await self._dm_pmc(name, f"{ui_icon('check')} {o.flag} **{o.name}** сняла санкции с вашей ЧВК.")
            return f"{ui_icon('check')} Санкции против **{name}** сняты."
        self.pmc.sanction(name, o.name, "sanction", 0)
        self.pmc.add_rel(name, o.name, P.REL_SANCTION)
        for d in self.pmc.deals_open(pmc=name, country=o.name):
            self.pmc.close_deal(d["id"], "cancelled")
        await self._dm_pmc(name, f"{ui_icon('sanctions')} {o.flag} **{o.name}** ввела санкции против вашей ЧВК: её "
                                 f"контракты и оружие для вас закрыты, отношения {P.REL_SANCTION}.")
        await self._post(f"{ui_icon('sanctions')} {o.flag} **{o.name}** вводит санкции против ЧВК **[{pm['tag']}] {name}**.",
                         WARNING_COLOR)
        self._journal(o.name, name, f"{o.name} ввела санкции против ЧВК {name}")
        return f"{ui_icon('sanctions')} Санкции против **{name}** введены."

    async def un_sanction(self, name: str, hours: int) -> str:
        """Из UnCog: санкции ООН против ЧВК на срок."""
        pm = self.pmc.get(name)
        if not pm:
            return ""
        until = int(time.time()) + hours * 3600
        self.pmc.sanction(name, "ООН", "un", until)
        for d in self.pmc.deals_open(pmc=name):
            self.pmc.close_deal(d["id"], "cancelled")
        await self._dm_pmc(name, f"{ui_icon('sanctions')} **Санкции ООН** против вашей ЧВК на {hours}ч: никаких покупок "
                                 f"(страны и чёрный рынок), доход ×{P.UN_INCOME_MULT}.")
        return (f"{ui_icon('sanctions')} ЧВК [{pm['tag']}] {name}: санкции ООН на {hours}ч — покупки техники запрещены, "
                f"доход ×{P.UN_INCOME_MULT}.")

    # ═══════════════ РАЗВЕДКА СТРАН ПРОТИВ ЧВК ═══════════════
    async def _spy_run(self, uid: int) -> str:
        s = self._session(uid)
        o = self.countries.get_object_by_user(uid)
        op, name = s["spy_op"], s["spy_pmc"]
        pm = self.pmc.get(name) if name else None
        if not o or not pm or op not in P.SPY_OPS:
            return f"{ui_icon('reject')} Выберите ЧВК и операцию."
        now = int(time.time())
        meta = P.SPY_OPS[op]
        spy = Spy()
        if self.cooldown.get_cooldown("pmc_spy", o.name) > now:
            return f"{ui_icon('reject')} Разведка ещё не готова к новой операции против ЧВК."
        if spy.ops_today(o.name, now - 86400) >= SPY.SPY_MAX_PER_DAY:
            return f"{ui_icon('reject')} Лимит операций разведки за сутки исчерпан."
        if (o.money or 0) < meta["cost"]:
            return f"{ui_icon('reject')} Нужно {int_format(meta['cost'])} {CURRENCY}."
        # предоплата и перезарядка — до броска (повторный клик не даст второй операции)
        update_money(o.name, -meta["cost"])
        self.cooldown.set_cooldown("pmc_spy", now + P.PMC_SPY_CD, o.name)
        recon, _c = spy.get_agency(o.name)
        raw, upd = spy.get_heat_raw(o.name)
        heat = SPY.effective_heat(raw, upd, now)
        security = P.SECURITY[P.tier(pm["reputation"] or 0)[0]]
        chance = SPY.success_chance(recon, security, 50.0, heat)
        spy.set_heat(o.name, heat + SPY.HEAT_PER_OP, now)
        ok = random.uniform(0, 100) <= chance
        spy.log_incident(o.name, name, f"pmc_{op}", now, ok, False)
        head = f"{ui_icon(meta['icon'])} «{meta['label']}» против **{name}**: "
        if not ok:
            if random.uniform(0, 100) <= SPY.expose_chance(security, heat):
                spy.set_heat(o.name, heat + SPY.HEAT_PER_OP + SPY.HEAT_ON_EXPOSE, now)
                self.pmc.add_rel(name, o.name, P.REL_SPY_EXPOSED)
                await self._post(f"{ui_icon('exposed')} Охрана ЧВК **[{pm['tag']}] {name}** поймала агентов "
                                 f"{o.flag} **{o.name}** («{meta['label']}»).", ERROR_COLOR)
                await self._dm_pmc(name, f"{ui_icon('exposed')} Ваша охрана сорвала операцию разведки "
                                         f"{o.flag} **{o.name}** («{meta['label']}»). Отношения {P.REL_SPY_EXPOSED}.")
                return head + f"провал с **разоблачением** (шанс был ~{chance:.0f}%). Отношения с ЧВК {P.REL_SPY_EXPOSED}."
            return head + f"сорвалась (шанс был ~{chance:.0f}%). Предоплата потеряна."
        if op == "dossier":
            return head + "успех.\n" + self.dossier(name)[:2500]
        if op == "sabotage":
            frac = random.uniform(*P.SABOTAGE_FRAC)
            lost_lines = []
            rows = self.pmc.stock(name)
            for r in rows:
                k = self._loss(r["count"], frac)
                if k:
                    self.pmc.add_stock(name, r["model"], r["category"], r["cls"], r["origin"], r["grade"], -k)
                    lost_lines.append(f"{r['model']} ×{k}")
            if not lost_lines and rows:      # хоть одна единица — иначе операция «впустую» при малом арсенале
                r = random.choice(rows)
                self.pmc.add_stock(name, r["model"], r["category"], r["cls"], r["origin"], r["grade"], -1)
                lost_lines.append(f"{r['model']} ×1")
            what = ", ".join(lost_lines) or "техники на базе не оказалось"
            if lost_lines:
                await self._dm_pmc(name, f"{ui_icon('sabotage')} **Диверсия на базе!** Неизвестные уничтожили: {what}.")
            return head + f"успех. Уничтожено: {what}."
        if op == "poach":
            k = int((pm["personnel"] or 0) * random.uniform(*P.POACH_FRAC))
            if k <= 0:
                return head + "успех, но переманивать некого."
            self.pmc.set(name, personnel=max(0, (pm["personnel"] or 0) - k))
            Army().add_pool(o.name, k)
            await self._dm_pmc(name, f"{ui_icon('pmc_hire')} **{int_format(k)}** бойцов разорвали контракты и ушли "
                                     f"на государственную службу.")
            return head + f"успех. **{int_format(k)}** бойцов перешли в резерв вашей армии."
        # kompromat
        ops = self.pmc.secret_ops(name, now - P.KOMPROMAT_DAYS * 86400)
        if not ops:
            return head + f"успех, но грязи не найдено: тайных операций за {P.KOMPROMAT_DAYS} дней нет."
        self.pmc.add_rep(name, P.REP_KOMPROMAT)
        lines = []
        for c in ops:
            self.pmc.update_contract(c["id"], status="exposed")
            if self.countries.get_object(c["client"]):
                self.dip.add_reputation(c["client"], P.KOMPROMAT_CLIENT_REP)
                if c["target"] and self.countries.get_object(c["target"]):
                    self.dip.add_relation(c["client"], c["target"], -20)
            if c["target"]:
                self.pmc.add_rel(name, c["target"], P.REL_KOMPROMAT)
            lines.append(f"спецоперация для **{c['client']}** против **{c['target']}**")
            self._journal(name, c["target"] or c["client"],
                          f"Компромат: ЧВК {name} провела спецоперацию для {c['client']} против {c['target']}")
        await self._post(f"{ui_icon('exposed')} **Компромат на ЧВК [{pm['tag']}] {name}.** Вскрыто:\n"
                         + "\n".join(f"• {x}" for x in lines[:10])
                         + f"\n-# Репутация ЧВК {P.REP_KOMPROMAT}, заказчиков {P.KOMPROMAT_CLIENT_REP}.", ERROR_COLOR)
        return head + f"успех. Вскрыто тайных операций: **{len(ops)}** — опубликовано."

    # ═══════════════ КОНТРАКТЫ ═══════════════
    async def _take(self, uid: int, cid_: int) -> str:
        pm = self.pmc.by_user(uid)
        c = self.pmc.contract(cid_)
        if not pm:
            return f"{ui_icon('reject')} Контракты берут только ЧВК (`!чвк`)."
        if not c:
            return f"{ui_icon('reject')} Заказ не найден."
        block = self._take_block(pm, c)
        if block:
            return f"{ui_icon('reject')} Нельзя: {block}."
        name, client, kind = pm["name"], c["client"], c["kind"]
        if not self.countries.get_object(client):
            return f"{ui_icon('reject')} Заказчик больше не в игре."
        if not self.pmc.claim_contract(cid_, name):      # атомарно: второй клик / вторая ЧВК — мимо
            return f"{ui_icon('reject')} Контракт уже взят."
        now = int(time.time())
        meta = P.CONTRACTS[kind]
        if kind == "war":
            w = self.war.get_war(c["war_id"])
            side = "att" if client == w["attacker"] else "def"
            enemy = w["defender"] if side == "att" else w["attacker"]
            wc = self.bot.get_cog("WarCog")
            ok, msg = wc.join_as_ally(c["war_id"], name, side) if wc else (False, "модуль войны недоступен")
            if not ok:
                self.pmc.update_contract(cid_, status="open", pmc="")
                return f"{ui_icon('reject')} {msg}"
            self.pmc.update_contract(cid_, ends_at=now + meta["hours"] * 3600)
            self.pmc.add_rel(name, enemy, P.REL_WAR_ENEMY)
            self._journal(name, enemy, f"ЧВК {name} вступила в войну #{c['war_id']} на стороне {client} против {enemy}")
            res = (f"{ui_icon('war')} ЧВК **[{pm['tag']}] {name}** вступает в войну #{c['war_id']} на стороне "
                   f"**{client}**. Оплата — по окончании войны или через {meta['hours'] // 24} дн.")
            await self._post(res)
        else:
            res = await self._execute_instant(pm, c)
        await self._refresh_card(self.pmc.contract(cid_), f"{ui_icon('check')} Контракт взяла ЧВК **[{pm['tag']}] {name}**.")
        await self._dm_country(client, f"{ui_icon('contract')} Ваш заказ №{cid_} ({meta['label']}) взяла "
                                       f"ЧВК **[{pm['tag']}] {name}**.\n{res}")
        return res

    async def _execute_instant(self, pm, c) -> str:
        """Мгновенные контракты: охрана, беспорядки, обучение, спецоперация (контракт уже «active»)."""
        now = int(time.time())
        name, client, kind = pm["name"], c["client"], c["kind"]
        o = self.countries.get_object(client)
        meta = P.CONTRACTS[kind]
        if kind == "guard":
            self.effects.add(client, "spy_counter", P.GUARD_COUNTER, now + meta["hours"] * 3600)
            res = f"{ui_icon('guard')} Охрана ЧВК «{name}»: контрразведка {client} +{P.GUARD_COUNTER} на {meta['hours']}ч."
        elif kind == "riot":
            stab = round(min(P.RIOT_STAB_MAX, (pm["personnel"] or 0) / 100 * P.RIOT_STAB_PER_100), 1)
            ps = self.politics.get_state(client)
            self.countries.update_object(client, stability=round(min(100.0, (o.stability or 0) + stab), 2),
                                         happiness=round(max(0.0, (o.happiness or 0) + P.RIOT_HAPPY), 2))
            self.politics.set_opposition(client, max(0.0, ps["opposition"] + P.RIOT_OPPOSITION))
            res = (f"{ui_icon('riot')} ЧВК «{name}» подавила беспорядки в {client}: стабильность +{stab}, "
                   f"оппозиция {P.RIOT_OPPOSITION}, счастье {P.RIOT_HAPPY}.")
        elif kind == "training":
            self.effects.add(client, "army_train", P.TRAIN_MULT, now + meta["hours"] * 3600)
            res = (f"{ui_icon('academy')} Инструкторы ЧВК «{name}»: армия {client} сильнее на "
                   f"{int(round((P.TRAIN_MULT - 1) * 100))}% на {meta['hours']}ч.")
        else:   # special
            target = c["target"]
            t = self.countries.get_object(target)
            tkey, _lbl, _q = P.tier(pm["reputation"] or 0)
            counter = Spy().get_agency(target)[1] if t else 0
            chance = max(10, min(90, P.SPECIAL_BASE + P.SPECIAL_PER_TIER[tkey] - counter * 5))
            if t and random.uniform(0, 100) <= chance:
                if random.random() < 0.5:
                    hit = random.randint(*P.SPECIAL_STAB)
                    self.countries.update_object(target, stability=round(max(0.0, (t.stability or 0) - hit), 2))
                    eff = f"стабильность −{hit}"
                else:
                    mult, hours = P.SPECIAL_ECO
                    self.effects.add(target, "income_mult", mult, now + hours * 3600)
                    eff = f"доход ×{mult} на {hours}ч"
                await self._dm_country(target, f"{ui_icon('pmc_target')} Неизвестные провели операцию на вашей "
                                               f"территории: {eff}.")
                res = f"{ui_icon('pmc_target')} Спецоперация ЧВК «{name}» против {target} удалась: {eff}."
            else:
                traced = random.random() < P.SPECIAL_CLIENT_TRACE
                self.pmc.add_rep(name, P.REP_EXPOSED)
                if target:
                    self.pmc.add_rel(name, target, P.REL_SPECIAL_EXPOSED)
                refund = c["price"] // 2
                update_money(client, refund)
                if traced and t:
                    self.dip.add_relation(client, target, -20)
                self.pmc.update_contract(c["id"], status="failed")
                who = f" Следы ведут к заказчику — **{client}**." if traced else ""
                self._journal(name, target, f"ЧВК {name} поймана при спецоперации против {target}."
                              + (f" Заказчик — {client}." if traced else ""))
                await self._post(f"{ui_icon('exposed')} **Провал спецоперации.** ЧВК **[{pm['tag']}] {name}** поймана "
                                 f"при операции против **{target}**.{who}", ERROR_COLOR)
                return (f"{ui_icon('exposed')} Спецоперация провалена: ЧВК раскрыта (репутация {P.REP_EXPOSED}, "
                        f"отношения с {target} {P.REL_SPECIAL_EXPOSED})." + (" Заказчик раскрыт." if traced else "")
                        + f" Заказчику возвращено {int_format(refund)}.")
        pay = self._finish_contract(c["id"], name, client, c["price"], P.REP_DONE)
        return res + f"\n{pay}, репутация +{P.REP_DONE}."

    def _finish_contract(self, cid_: int, name: str, client: str, price: int, rep: float) -> str:
        self.pmc.update_contract(cid_, status="done")
        pm = self.pmc.get(name)
        if pm:
            self.pmc.set(name, done_count=(pm["done_count"] or 0) + 1)
        self.pmc.add_rep(name, rep)
        self.pmc.add_rel(name, client, P.REL_CLIENT_DONE)
        return self._payout(name, price)

    async def _withdraw(self, uid: int, cid_: int) -> str:
        pm = self.pmc.by_user(uid)
        c = self.pmc.contract(cid_)
        if not pm or not c or c["pmc"] != pm["name"] or c["status"] != "active" or c["kind"] != "war":
            return f"{ui_icon('reject')} Контракт не найден."
        self.pmc.update_contract(cid_, status="failed")
        self.war.remove_ally(c["war_id"], pm["name"])
        refund = int(c["price"] * P.WITHDRAW_REFUND)
        update_money(c["client"], refund)
        self.pmc.add_rep(pm["name"], P.REP_WITHDRAW)
        self.pmc.add_rel(pm["name"], c["client"], -2 * P.REL_CLIENT_DONE)
        await self._dm_country(c["client"], f"{ui_icon('leave_bloc')} ЧВК **[{pm['tag']}] {pm['name']}** ушла с вашей "
                                            f"войны #{c['war_id']}. Возвращено {int_format(refund)} {CURRENCY}.")
        await self._post(f"{ui_icon('leave_bloc')} ЧВК **[{pm['tag']}] {pm['name']}** покинула войну #{c['war_id']}, "
                         f"сорвав контракт с **{c['client']}**.", WARNING_COLOR)
        return f"{ui_icon('leave_bloc')} Вы ушли с войны. Репутация {P.REP_WITHDRAW}."

    async def _disband(self, uid: int, guild, reason: str = "ЧВК распущена") -> str:
        pm = self.pmc.by_user(uid)
        if not pm:
            return f"{ui_icon('reject')} ЧВК не найдена."
        name = pm["name"]
        for c in self.pmc.contracts_of_pmc(name):
            self.pmc.update_contract(c["id"], status="failed")
            if c["kind"] == "war":
                self.war.remove_ally(c["war_id"], name)
                update_money(c["client"], c["price"])
        self.pmc.delete(name)
        News().clear_country(name)
        self.bot.dispatch("map_dirty")
        g = guild or self.bot.get_guild(GUILD_ID)
        member = g.get_member(uid) if g else None
        if member:
            try:
                from cogs.registration import _role
                reg = _role(g, "PROFILE_ROLE", config.PROFILE_ROLE)
                back = _role(g, "ROLE_REGISTERING")
                pmc_role = _role(g, "ROLE_PMC", getattr(config, "PMC_ROLE", 0))
                gone = [r for r in (reg, pmc_role) if r and r in member.roles]
                if gone:
                    await member.remove_roles(*gone, reason=reason)
                if back:
                    await member.add_roles(back, reason=reason)
                await member.edit(nick=None)
            except Exception:
                pass
        await self._post(f"{ui_icon('split')} ЧВК **[{pm['tag']}] {name}** распущена.", WARNING_COLOR)
        return f"{ui_icon('split')} ЧВК распущена. Можно зарегистрировать страну или основать новую ЧВК."

    # ═══════════════ ДЕЙСТВИЯ ЗАКАЗЧИКА ═══════════════
    async def _order(self, uid: int, price: int | None) -> str:
        s = self._session(uid)
        o = self.countries.get_object_by_user(uid)
        kind = s["kind"]
        if not o or kind not in P.CONTRACTS or not price:
            return f"{ui_icon('reject')} Выберите тип и сумму."
        meta = P.CONTRACTS[kind]
        if price < meta["min_price"]:
            return f"{ui_icon('reject')} Минимальная сумма — {int_format(meta['min_price'])} {CURRENCY}."
        if (o.money or 0) < price:
            return f"{ui_icon('reject')} Недостаточно средств."
        war_id, target = 0, ""
        if kind == "war":
            w = self.war.get_war(int(s["war"])) if s["war"] and str(s["war"]).isdigit() else None
            if not w or w["status"] != "active" or o.name not in (w["attacker"], w["defender"]):
                return f"{ui_icon('reject')} Выберите свою активную войну."
            war_id = w["id"]
        if kind == "special":
            target = s["target"] or ""
            if not self.countries.get_object(target) or target == o.name:
                return f"{ui_icon('reject')} Выберите цель."
        now = int(time.time())
        update_money(o.name, -price)
        cid_ = self.pmc.create_contract(o.name, kind, price, war_id, target, now, now + P.CONTRACT_TTL)
        ch = self._channel()
        if ch:
            try:
                msg = await ch.send(components=self._card(self.pmc.contract(cid_)).components)
                self.pmc.update_contract(cid_, channel_id=ch.id, msg_id=msg.id)
            except Exception:
                log.exception("карточка заказа ЧВК")
        s.update(view="hub", kind=None, war=None, target=None)
        return f"{ui_icon('contract')} Заказ №{cid_} размещён на бирже ЧВК. {int_format(price)} {CURRENCY} заморожено."

    async def _cancel(self, uid: int, cid_: int) -> str:
        o = self.countries.get_object_by_user(uid)
        c = self.pmc.contract(cid_)
        if not o or not c or c["client"] != o.name or c["status"] != "open":
            return f"{ui_icon('reject')} Отменить можно только свой открытый заказ."
        if not self.pmc.claim_contract(cid_, ""):         # атомарно (заказ могли взять в эту же секунду)
            return f"{ui_icon('reject')} Заказ уже взят."
        self.pmc.update_contract(cid_, status="cancelled")
        update_money(o.name, c["price"])
        await self._refresh_card(self.pmc.contract(cid_), f"{ui_icon('reject')} Заказ отменён заказчиком.")
        return f"{ui_icon('check')} Заказ №{cid_} отменён, {int_format(c['price'])} {CURRENCY} возвращено."

    # ═══════════════ ЧАСОВОЙ ЦИКЛ ═══════════════
    def _contraband(self, now: int) -> int:
        """Раз в сутки — партии случайных моделей стран на чёрный рынок. → число лотов."""
        last = int(self.pmc.meta("contraband_at") or 0)
        if now - last < P.CONTRABAND_EVERY:
            return 0
        self.pmc.set_meta("contraband_at", str(now))
        models = [m for m in self.equip.all_models(P.ALLOWED) if self.countries.get_object(m["owner"])]
        if not models:
            return 0
        k = min(len(models), random.randint(*P.CONTRABAND_LOTS))
        for m in random.sample(models, k):
            n = P.contraband_count(m["category"], m["cls"], random)
            price = max(1, int(P.ref_price(m["category"], m["cls"]) * P.CONTRABAND_PRICE_K))
            self.pmc.add_lot(m["name"], m["category"], m["cls"], m["owner"], n, price, "contraband", now,
                             now + P.LOT_TTL)
        self.pmc.prune_lots(now, P.POOL_MAX)
        return k

    async def _tick(self, now: int):
        # частные заказы и содержание
        for p in self.pmc.all():
            inc = self.passive(p)
            cost = self.upkeep(p["name"])
            money = (p["money"] or 0) + inc
            if money >= cost:
                self.pmc.add_money(p["name"], inc - cost)
            else:
                self.pmc.set(p["name"], money=0, personnel=int((p["personnel"] or 0) * 0.95))
                await self._dm_user(p["user"], f"{ui_icon('exposed')} Нечем платить бойцам — 5% дезертировали. "
                                               f"Берите контракты (`!чвк`).")
        # военные контракты: война кончилась или вышел срок
        for c in self.pmc.contracts("active"):
            if c["kind"] != "war":
                continue
            w = self.war.get_war(c["war_id"])
            over = not w or w["status"] != "active"
            if not over and now < (c["ends_at"] or 0):
                continue
            if not over:
                self.war.remove_ally(c["war_id"], c["pmc"])
            if not self.pmc.get(c["pmc"]):
                self.pmc.update_contract(c["id"], status="failed")
                continue
            win = bool(w) and (w["winner"] if "winner" in w.keys() else None) == c["client"]
            pay = self._finish_contract(c["id"], c["pmc"], c["client"], c["price"],
                                        P.REP_DONE + (P.REP_WAR_WIN if win else 0))
            await self._dm_pmc(c["pmc"], f"{ui_icon('contract')} Контракт №{c['id']} (война #{c['war_id']}) закрыт"
                                         + (", заказчик победил!" if win else ".") + f"\n{pay}")
        # открытые заказы истекли — возврат
        for c in self.pmc.contracts("open"):
            if now >= (c["deadline"] or 0) and self.pmc.claim_contract(c["id"], ""):
                self.pmc.update_contract(c["id"], status="expired")
                update_money(c["client"], c["price"])
                await self._refresh_card(self.pmc.contract(c["id"]), f"{ui_icon('reject')} Заказ истёк — деньги возвращены.")
        # сделки, лоты, санкции — по сроку
        for d in self.pmc.deals_open():
            if now - (d["created_at"] or 0) >= P.DEAL_TTL:
                self.pmc.close_deal(d["id"], "expired")
        self.pmc.prune_lots(now, P.POOL_MAX)
        self.pmc.prune_sanctions(now)
        if self._contraband(now) and self.pmc.all():
            await self._post(f"{ui_icon('black_market')} На чёрный рынок пришла новая партия контрабанды "
                             f"(`!чвк` → «Чёрный рынок»).")

    @tasks.loop(hours=1)
    async def pmc_tick(self):
        try:
            if not self._nicks_synced:
                self._nicks_synced = True
                await self._sync_nicks()
            await self._tick(int(time.time()))
        except Exception:
            log.exception("сбой цикла ЧВК")

    @pmc_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДЫ ═══════════════
    @commands.command(name="pmc", aliases=["чвк", "наёмники", "наемники", "контракты"])
    async def pmc_cmd(self, ctx: commands.Context):
        self._session(ctx.author.id).update(view="hub", contract=None, kind=None, war=None, target=None, confirm=False,
                                            page=0)
        try:
            await ctx.author.send(components=self._render(ctx.author.id).components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(description="Включите ЛС и повторите `!чвк`.", color=WARNING_COLOR))
            return
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('pmc')} Панель ЧВК отправлена вам в **личные сообщения**.",
                color=COMMAND_COLOR), delete_after=12)

    def rating(self) -> list[tuple[int, object]]:
        rows = []
        for p in self.pmc.all():
            score = int((p["reputation"] or 0) * 100 + self.combat_score(p["name"]) + (p["done_count"] or 0) * 300)
            rows.append((score, p))
        rows.sort(key=lambda x: -x[0])
        return rows

    @commands.command(name="pmc-top", aliases=["чвк-рейтинг", "рейтинг-чвк", "чвктоп", "pmctop"])
    async def pmc_top_cmd(self, ctx: commands.Context):
        rows = self.rating()
        if not rows:
            text = "-# В мире пока нет ЧВК."
        else:
            text = "\n".join(
                f"**{i}.** {ui_icon('pmc')} **[{p['tag']}] {p['name']}** · {P.tier(p['reputation'] or 0)[1]} · "
                f"{ui_icon('reputation')} {p['reputation']:.0f} · {ui_icon('soldier')} {int_format(p['personnel'])} · "
                f"{ui_icon('attack')} {int_format(self.combat_score(p['name']))} · {ui_icon('contract')} "
                f"{p['done_count'] or 0} · база {p['base']}" for i, (_s, p) in enumerate(rows[:15], 1))
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(f"## {ui_icon('pmc_rating')} Рейтинг ЧВК\n{text}"),
            disnake.ui.TextDisplay("-# Очки: репутация × 100 + боевая мощь + 300 за каждый выполненный контракт."),
            accent_colour=disnake.Colour(PMC_COLOR)))
        await ctx.send(components=p.components)


def setup(bot: commands.Bot):
    bot.add_cog(PmcCog(bot))
