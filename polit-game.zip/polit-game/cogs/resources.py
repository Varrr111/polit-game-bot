"""
Ког ресурсов: месторождения, здания, добыча, переработка — через UI-панели.

  !resources / !ресурсы   — панель ресурсов и построек
  !deposits  / !залежи    — геология страны (что можно добывать)
  !build     / !построить — ПАНЕЛЬ строительства (выбор здания из меню)
  !buildings / !постройки — ваши постройки
  !mine      / !добыть    — собрать сырьё со всех добывающих построек
  !craft     / !крафт     — ПАНЕЛЬ переработки (выбор материала из меню)

Выбор в меню → действие сразу (строит/крафтит), с мгновенным ответом.
Клики маршрутизируются по custom_id через on_dropdown.
"""

import random
import time

import disnake
from disnake.ext import commands, tasks

from utils import (
    Settings, Cooldown, Buildings, Market, Countries, Allocation, country_mining_multiplier,
    get_object, get_object_by_user, update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY,
    ADMINISTRATOR, MAIN_ECO_CURATOR, PROFILE_ROLE,
)
from utils.ui import Panel, cid, parse_cid
from utils.serverconfig import rid
from utils.perms import is_staff
from utils.resources import (
    RESOURCES, RAW_RESOURCES, MATERIAL_RESOURCES, RECIPES,
    res_icon, res_label, res_value,
    RICHNESS_MULT, country_deposits, has_deposit,
    ore_scale,
    BUILDINGS, FACTORY_BUILDINGS, PRODUCTION_BUILDINGS, OUT_TO_BUILDING, FACTORY_POWER,
    building_label, find_building, bld_icon, action_icon, ui_icon,
    LEVEL_MULT, MAX_BUILDING_LEVEL, upgrade_cost,
    STORAGE_BASE, STORAGE_PER_WAREHOUSE,
)


def _emoji(s: str):
    """Строка-иконка (юникод или '<:n:id>') → объект для emoji= у кнопок/опций."""
    try:
        return disnake.PartialEmoji.from_str(s)
    except Exception:
        return None

GRAIN_PER_CAPITA = 200_000  # 1 ед. зерна/ч на столько населения

LIQUIDITY = 50_000   # объём, заметно двигающий цену
SPREAD = 0.05        # спред биржи (продаёшь дешевле, покупаешь дороже)


def _richness_word(r: int) -> str:
    return {1: "бедное", 2: "среднее", 3: "богатое"}.get(r, "среднее")


# ─────────────────────────── ПАНЕЛИ ───────────────────────────
def _bar(value: float, maxv: float, n: int = 12) -> str:
    if maxv <= 0:
        return "▱" * n
    filled = max(0, min(n, round(n * value / maxv)))
    return "▰" * filled + "▱" * (n - filled)


class ResourcesPanel(Panel):
    def __init__(self, obj, resources: dict[str, int], buildings: dict[str, int],
                 rates: dict[str, int] | None = None, cap: int | None = None,
                 avatar_url: str | None = None):
        super().__init__(timeout=300)
        rates = rates or {}
        total_value = sum(amt * res_value(n) for n, amt in resources.items())
        prod_value = sum(rate * res_value(n) for n, rate in rates.items())

        header = (f"-# {getattr(obj, 'flag', '')} {obj.name}\n"
                  f"## {ui_icon('storage')} Ресурсы\n"
                  f"-# производство **~{int_format(prod_value)} {CURRENCY}/ч** · склад **~{int_format(total_value)} {CURRENCY}**")
        if avatar_url:
            items: list = [disnake.ui.Section(disnake.ui.TextDisplay(header),
                                              accessory=disnake.ui.Thumbnail(avatar_url))]
        else:
            items = [disnake.ui.TextDisplay(header)]

        # заполнение склада (суммарно)
        if cap:
            used = sum(resources.values())
            total_cap = cap * len(RESOURCES)
            pct = int(100 * used / total_cap) if total_cap else 0
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"-# ЗАПОЛНЕНИЕ СКЛАДА · лимит {int_format(cap)}/ресурс\n{_bar(used, total_cap)}  `{pct}%`"))

        def block(title: str, names: list[str], emoji: str):
            lines = []
            for n in names:
                amt = resources.get(n, 0)
                rate = rates.get(n, 0)
                if amt <= 0 and rate <= 0:
                    continue
                s = f"{res_icon(n)} **{res_label(n)}** · `{int_format(amt)}`"
                if rate > 0:
                    s += f"  `▲ +{int_format(rate)}/ч`"
                lines.append(s)
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(f"-# {emoji} {title}\n" + ("\n".join(lines) if lines else "-# —")))

        block("СЫРЬЁ", RAW_RESOURCES, action_icon("mine"))
        block("МАТЕРИАЛЫ", MATERIAL_RESOURCES, action_icon("craft"))
        known = [(k, c) for k, c in buildings.items() if k in BUILDINGS]
        if known:
            b_lines = "   ".join(f"{bld_icon(k)} **{building_label(k)}** `×{c}`" for k, c in known)
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(f"-# {action_icon('build')} ПОСТРОЙКИ\n{b_lines}"))

        # кнопки-хаб: всё кликами
        oid = obj.user
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(label="Заводы", emoji=_emoji(action_icon("build")), style=disnake.ButtonStyle.success,
                              custom_id=cid("res", "buildmenu", oid)),
            disnake.ui.Button(label="Распределение", emoji=_emoji(action_icon("craft")), style=disnake.ButtonStyle.primary,
                              custom_id=cid("res", "alloc", oid)),
            disnake.ui.Button(label="Переработка", emoji=_emoji(action_icon("craft")), style=disnake.ButtonStyle.primary,
                              custom_id=cid("res", "craftmenu", oid)),
            disnake.ui.Button(label="Биржа", emoji=_emoji(action_icon("exchange")), style=disnake.ButtonStyle.secondary,
                              custom_id=cid("res", "exchange", oid)),
            disnake.ui.Button(label="Залежи", emoji=_emoji(action_icon("deposits")), style=disnake.ButtonStyle.secondary,
                              custom_id=cid("res", "deposits", oid)),
        ))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


class BuildPanel(Panel):
    """Меню строительства + улучшения зданий."""

    def __init__(self, obj, owned: dict[str, int] | None = None, levels: dict[str, int] | None = None):
        super().__init__(timeout=300)
        owned = owned or {}
        levels = levels or {}
        deps = country_deposits(obj.name)

        kind_note = {"extract": " · добыча", "factory": " · завод", "storage": " · +склад"}
        options = []
        for key, (label, kind, out, cost) in BUILDINGS.items():
            locked = kind == "extract" and out not in deps
            options.append(disnake.SelectOption(
                label=(f"🔒 {label}" if locked else label)[:100], value=key,
                emoji=_emoji(bld_icon(key)),
                description=(f"{int_format(cost)} {CURRENCY}" + (" · нет залежи" if locked else kind_note.get(kind, "")))[:100]))
        build_select = disnake.ui.StringSelect(
            custom_id=cid("res", "build", obj.user), placeholder="Построить", options=options[:25])

        items = [disnake.ui.TextDisplay(f"-# {getattr(obj, 'flag', '')} {obj.name}\n## {action_icon('build')} Строительство\n"
                                        f"-# {ui_icon('lock')} — нет залежи (`!deposits`)"),
                 disnake.ui.Separator(),
                 disnake.ui.ActionRow(build_select)]

        # улучшение построенных зданий
        up_opts = []
        for key, count in owned.items():
            lvl = levels.get(key, 1)
            if lvl >= MAX_BUILDING_LEVEL:
                continue
            up_opts.append(disnake.SelectOption(
                label=f"{building_label(key)} ур.{lvl}→{lvl + 1}"[:100], value=key,
                description=f"{int_format(upgrade_cost(key, lvl))} {CURRENCY}"[:100]))
        if up_opts:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("res", "upgr", obj.user), placeholder="⬆️ Улучшить здание", options=up_opts[:25])))

        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


class CraftPanel(Panel):
    """Выбор материала для переработки из меню."""

    def __init__(self, obj):
        super().__init__(timeout=300)
        options = []
        for mat, inp in RECIPES.items():
            recipe = " + ".join(f"{q}×{res_label(r)}" for r, q in inp.items())
            options.append(disnake.SelectOption(
                label=f"{res_label(mat)}"[:100], value=mat, description=recipe[:100]))
        select = disnake.ui.StringSelect(
            custom_id=cid("res", "craft", obj.user),
            placeholder="Выберите материал (×1)", options=options)
        container = disnake.ui.Container(
            disnake.ui.TextDisplay(f"-# {getattr(obj, 'flag', '')} {obj.name}\n## {action_icon('craft')} Переработка\n"
                                   "-# выбор = +1 материал · нужен завод · для партии: `!craft <мат> <n>`"),
            disnake.ui.Separator(),
            disnake.ui.ActionRow(select),
            accent_colour=disnake.Colour(COMMAND_COLOR))
        self.add_item(container)


def _find_resource(query: str) -> str | None:
    if not query:
        return None
    q = query.strip().lower()
    if q in RESOURCES:
        return q
    for n in RESOURCES:
        if q in n.lower() or q in res_label(n).lower():
            return n
    return None


def _trend(f: float) -> str:
    return ui_icon("up") if f > 1.03 else ui_icon("down") if f < 0.97 else ui_icon("flat")


class ExchangePanel(Panel):
    """Доска биржи: цены + тренды, селект для продажи своих ресурсов."""

    def __init__(self, obj, factors: dict, holdings: dict):
        super().__init__(timeout=300)

        def line(n):
            f = factors.get(n, 1.0)
            price = max(1, int(res_value(n) * f))
            return f"{res_icon(n)} {res_label(n)} `{int_format(price)}` {_trend(f)}"

        items = [disnake.ui.TextDisplay(f"## {action_icon('exchange')} Мировая биржа\n"
                                        f"-# цена за ед. · {ui_icon('up')} растёт {ui_icon('down')} падает · продажи роняют курс")]
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"-# {action_icon('mine')} СЫРЬЁ\n" + "\n".join(line(n) for n in RAW_RESOURCES)))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"-# {action_icon('craft')} МАТЕРИАЛЫ\n" + "\n".join(line(n) for n in MATERIAL_RESOURCES)))

        sellable = [n for n in RESOURCES if holdings.get(n, 0) > 0]
        if sellable:
            opts = [disnake.SelectOption(label=f"{res_label(n)} (есть {int_format(holdings[n])})"[:100], value=n)
                    for n in sellable[:25]]
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("res", "exsel", obj.user), placeholder="Продать свой ресурс", options=opts)))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


class SellPanel(Panel):
    """Быстрая продажа: 25% / 50% / Всё."""

    def __init__(self, obj, res: str, have: int, price: int):
        super().__init__(timeout=120)
        oid = obj.user
        items = [disnake.ui.TextDisplay(
            f"## {action_icon('exchange')} Продажа {res_icon(res)} {res_label(res)}\n"
            f"-# цена {int_format(price)} {CURRENCY}/ед · у вас {int_format(have)}")]
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(label="25%", style=disnake.ButtonStyle.secondary, custom_id=cid("res", "exq", oid, res, 25)),
            disnake.ui.Button(label="50%", style=disnake.ButtonStyle.secondary, custom_id=cid("res", "exq", oid, res, 50)),
            disnake.ui.Button(label="Всё", style=disnake.ButtonStyle.success, custom_id=cid("res", "exq", oid, res, 100)),
        ))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


class AllocationPanel(Panel):
    """Распределение мощности заводов по рудам (веса → %)."""

    def __init__(self, obj, pool: int, weights: dict, rates: dict):
        super().__init__(timeout=300)
        deps = country_deposits(obj.name)
        total_w = sum(weights.values()) or 1
        lines = []
        for ore in RAW_RESOURCES:
            if ore not in deps:
                continue
            w = weights.get(ore, 0)
            pct = round(100 * w / total_w) if total_w else 0
            lines.append(f"{res_icon(ore)} **{res_label(ore)}** `{pct}%`  `+{int_format(rates.get(ore, 0))}/ч`")
        header = (f"-# {getattr(obj, 'flag', '')} {obj.name}\n"
                  f"## {action_icon('craft')} Распределение добычи\n"
                  f"-# пул заводов **{int_format(pool)}/ч** · усиль нужную руду в меню")
        items = [disnake.ui.TextDisplay(header), disnake.ui.Separator(),
                 disnake.ui.TextDisplay("\n".join(lines) if lines else "-# нет залежей или заводов")]
        opts = [disnake.SelectOption(label=f"{res_label(o)} +приоритет", value=o, emoji=_emoji(res_icon(o)))
                for o in RAW_RESOURCES if o in deps][:25]
        if opts:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("res", "aw", obj.user), placeholder="Усилить руду (+приоритет)", options=opts)))
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                label="Сбросить", style=disnake.ButtonStyle.secondary, custom_id=cid("res", "areset", obj.user))))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


# ─────────────────────────── КОГ ───────────────────────────
class ResourcesCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.settings = Settings()
        self.cooldown = Cooldown()
        self.buildings = Buildings()
        self.market = Market()
        self.alloc = Allocation()
        self.resource_tick.start()

    def cog_unload(self):
        self.resource_tick.cancel()

    async def cog_check(self, ctx: commands.Context) -> bool:
        if not ctx.guild:
            return False
        if is_staff(ctx.author):
            return True
        if MAIN_ECO_CURATOR and ctx.guild.get_role(MAIN_ECO_CURATOR) in ctx.author.roles:
            return True
        if ctx.author.get_role(rid("PROFILE_ROLE", PROFILE_ROLE)):
            return True
        if get_object_by_user(ctx.author.id):
            return True
        await ctx.send(embed=disnake.Embed(description="Вы не зарегистрированы.", color=ERROR_COLOR))
        return False

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CheckFailure):
            return
        raise error

    async def _require_obj(self, ctx):
        obj = get_object_by_user(ctx.author.id)
        if not obj:
            await ctx.send(embed=disnake.Embed(
                description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR))
        return obj

    # ───── логика (переиспользуется командой и панелью) ─────
    def _do_build(self, obj, key: str) -> disnake.Embed:
        label, kind, out, cost = BUILDINGS[key]
        if kind == "extract" and not has_deposit(obj.name, out):
            return disnake.Embed(
                description=f"В вашей стране нет залежи {res_icon(out)} {res_label(out)} — **{label}** построить нельзя.",
                color=ERROR_COLOR)
        if obj.money < cost:
            return disnake.Embed(
                description=f"Недостаточно средств. Нужно {int_format(cost)} {CURRENCY}, у вас {int_format(obj.money)} {CURRENCY}.",
                color=ERROR_COLOR)
        update_money(obj.name, -cost)
        self.buildings.add_building(obj.name, key, 1)
        total = self.buildings.get_count(obj.name, key)
        tip = {"production": f"+{int_format(FACTORY_POWER.get(key, 0))}/ч к пулу · распредели в «Распределение»",
               "factory": "переработка: `!craft`",
               "storage": f"+{int_format(STORAGE_PER_WAREHOUSE)} к вместимости"}.get(kind, "")
        return disnake.Embed(title="🏗️ Построено",
                             description=f"**{label}** (всего ×{total})\n-# −{int_format(cost)} {CURRENCY} · {tip}",
                             color=SUCCESS_COLOR)

    def _do_craft(self, obj, mat: str, amount: int) -> disnake.Embed:
        amount = max(1, amount)
        factory_key = OUT_TO_BUILDING[mat]
        if self.buildings.get_count(obj.name, factory_key) < 1:
            return disnake.Embed(
                description=f"Нужен завод **{building_label(factory_key)}**. Постройте через `!build`.",
                color=ERROR_COLOR)
        have = self.settings.get_resources(obj.name)
        recipe = RECIPES[mat]
        missing = [f"{res_icon(ing)} {res_label(ing)} — нужно {int_format(q * amount)}, есть {int_format(have.get(ing, 0))}"
                   for ing, q in recipe.items() if have.get(ing, 0) < q * amount]
        if missing:
            return disnake.Embed(title="Недостаточно сырья", description="\n".join(missing), color=ERROR_COLOR)
        for ing, q in recipe.items():
            self.settings.add_resource(obj.name, ing, -q * amount)
        self._add_capped(obj.name, mat, amount)
        spent = " + ".join(f"{int_format(q * amount)} {res_icon(r)}" for r, q in recipe.items())
        return disnake.Embed(
            description=f"{res_icon(mat)} Произведено **{int_format(amount)}** {res_label(mat).lower()}\n-# потрачено: {spent}",
            color=SUCCESS_COLOR)

    # ── пул заводов + распределение добычи ──
    def _factory_pool(self, name: str) -> int:
        """Суммарная мощность (пул руды/ч) всех универсальных заводов."""
        owned = self.buildings.get_buildings(name)
        levels = self.buildings.get_all_levels(name)
        total = 0
        for key, count in owned.items():
            if key in PRODUCTION_BUILDINGS:
                total += int(FACTORY_POWER[key] * count * LEVEL_MULT.get(levels.get(key, 1), 1.0))
        return total

    def _alloc_weights(self, name: str) -> dict[str, int]:
        """Веса распределения по рудам. По умолчанию — поровну по рудам с залежами."""
        w = self.alloc.get_weights(name)
        deps = country_deposits(name)
        w = {r: v for r, v in w.items() if r in deps}  # только то, что есть в земле
        if not w:
            return {r: 1 for r in deps}  # равномерно
        return w

    def _production_rates(self, obj) -> dict[str, int]:
        pool = self._factory_pool(obj.name)
        if pool <= 0:
            return {}
        weights = self._alloc_weights(obj.name)
        total_w = sum(weights.values())
        if total_w <= 0:
            return {}
        deps = country_deposits(obj.name)
        rates: dict[str, int] = {}
        for ore, w in weights.items():
            rich = RICHNESS_MULT.get(deps.get(ore, 0), 0)
            if rich <= 0:
                continue
            share = pool * w / total_w
            rates[ore] = int(share * rich * country_mining_multiplier(obj.name, ore) * ore_scale(ore))
        return rates

    def _deposits_embed(self, obj) -> disnake.Embed:
        deps = country_deposits(obj.name)
        if not deps:
            return disnake.Embed(title=f"Залежи {obj.name}", description="Нет известных месторождений.", color=WARNING_COLOR)
        lines = [f"{res_icon(r)} **{res_label(r)}** — {_richness_word(rich)}" for r, rich in deps.items()]
        return disnake.Embed(title=f"🗺️ Залежи {obj.name}",
                             description="\n".join(lines) + f"\n\n-# Стройте добычу кнопкой **{action_icon('build')} Строить**", color=COMMAND_COLOR)

    def _hub(self, obj, avatar_url: str | None = None) -> ResourcesPanel:
        return ResourcesPanel(obj, self.settings.get_resources(obj.name), self.buildings.get_buildings(obj.name),
                              rates=self._production_rates(obj), cap=self._storage_cap(obj.name),
                              avatar_url=avatar_url)

    def _build_panel(self, obj) -> BuildPanel:
        return BuildPanel(obj, self.buildings.get_buildings(obj.name), self.buildings.get_all_levels(obj.name))

    # ───── биржа ─────
    def _price(self, res: str) -> int:
        return max(1, int(res_value(res) * self.market.get_factor(res)))

    def _exchange_panel(self, obj) -> ExchangePanel:
        return ExchangePanel(obj, self.market.all_factors(), self.settings.get_resources(obj.name))

    def _do_sell(self, obj, res: str, amount: int) -> disnake.Embed:
        have = self.settings.get_resources(obj.name).get(res, 0)
        amount = min(amount, have)
        if amount <= 0:
            return disnake.Embed(description=f"Нечего продавать: {res_icon(res)} {res_label(res)}", color=ERROR_COLOR)
        price = self._price(res)
        gross = int(amount * price * (1 - SPREAD))
        self.settings.add_resource(obj.name, res, -amount)
        update_money(obj.name, gross)
        self.market.set_factor(res, self.market.get_factor(res) * (1 - min(0.5, amount / LIQUIDITY)))
        return disnake.Embed(title="💱 Продано",
                             description=f"{res_icon(res)} −{int_format(amount)} {res_label(res).lower()} → **+{int_format(gross)} {CURRENCY}**\n"
                                         f"-# по {int_format(price)} {CURRENCY}/ед · курс пошёл вниз",
                             color=SUCCESS_COLOR)

    def _do_buy(self, obj, res: str, amount: int) -> disnake.Embed:
        if amount <= 0:
            return disnake.Embed(description="Количество должно быть больше нуля.", color=ERROR_COLOR)
        room = max(0, self._storage_cap(obj.name) - self.settings.get_resources(obj.name).get(res, 0))
        amount = min(amount, room)
        if amount <= 0:
            return disnake.Embed(description="Склад полон — не влезет. Постройте **Склад** или расходуйте ресурсы.", color=WARNING_COLOR)
        price = self._price(res)
        cost = int(amount * price * (1 + SPREAD))
        fresh = get_object_by_user(obj.user) or get_object(obj.name)
        if not fresh or fresh.money < cost:
            return disnake.Embed(description=f"Недостаточно средств. Нужно {int_format(cost)} {CURRENCY}.", color=ERROR_COLOR)
        update_money(obj.name, -cost)
        self.settings.add_resource(obj.name, res, amount)
        self.market.set_factor(res, self.market.get_factor(res) * (1 + min(0.5, amount / LIQUIDITY)))
        return disnake.Embed(title="💱 Куплено",
                             description=f"{res_icon(res)} +{int_format(amount)} {res_label(res).lower()} → **−{int_format(cost)} {CURRENCY}**\n"
                                         f"-# по {int_format(price)} {CURRENCY}/ед · курс пошёл вверх",
                             color=SUCCESS_COLOR)

    # ───── склад / производство / улучшение / потребление ─────
    def _storage_cap(self, name: str) -> int:
        return STORAGE_BASE + self.buildings.get_count(name, "warehouse") * STORAGE_PER_WAREHOUSE

    def _add_capped(self, name: str, res: str, amount: int) -> int:
        """Добавляет ресурс с учётом лимита склада. Возвращает сколько реально добавлено."""
        if amount <= 0:
            self.settings.add_resource(name, res, amount)
            return amount
        room = max(0, self._storage_cap(name) - self.settings.get_resources(name).get(res, 0))
        added = min(amount, room)
        if added > 0:
            self.settings.add_resource(name, res, added)
        return added

    def _do_upgrade(self, obj, key: str) -> disnake.Embed:
        if self.buildings.get_count(obj.name, key) < 1:
            return disnake.Embed(description="Сначала постройте это здание.", color=ERROR_COLOR)
        lvl = self.buildings.get_level(obj.name, key)
        if lvl >= MAX_BUILDING_LEVEL:
            return disnake.Embed(description=f"**{building_label(key)}** уже максимального уровня.", color=WARNING_COLOR)
        cost = upgrade_cost(key, lvl)
        if obj.money < cost:
            return disnake.Embed(description=f"Недостаточно средств. Нужно {int_format(cost)} {CURRENCY}.", color=ERROR_COLOR)
        update_money(obj.name, -cost)
        self.buildings.set_level(obj.name, key, lvl + 1)
        return disnake.Embed(title="⬆️ Улучшено",
                             description=f"**{building_label(key)}** → ур.{lvl + 1} (выход ×{LEVEL_MULT[lvl + 1]})\n-# −{int_format(cost)} {CURRENCY}",
                             color=SUCCESS_COLOR)

    def _consume(self, obj):
        """Население ест зерно. Хватает → счастье чуть растёт, нет → падает."""
        pop = getattr(obj, "population", 0) or 0
        if pop <= 0:
            return
        need = max(1, pop // GRAIN_PER_CAPITA)
        have = self.settings.get_resources(obj.name).get("зерно", 0)
        cur_h = getattr(obj, "happiness", 100.0) or 100.0
        if have >= need:
            self.settings.add_resource(obj.name, "зерно", -need)
            new_h = min(100.0, cur_h + 0.2)
        else:
            new_h = max(0.0, cur_h - 1.0)
        Countries().update_object(obj.name, happiness=round(new_h, 2))

    @tasks.loop(hours=1)
    async def resource_tick(self):
        try:
            for obj in Countries().all_objects():
                for res, amt in self._production_rates(obj).items():
                    self._add_capped(obj.name, res, amt)
                self._consume(obj)
        except Exception:
            import traceback
            traceback.print_exc()

    @resource_tick.before_loop
    async def _before_tick(self):
        await self.bot.wait_until_ready()
        self._migrate_buildings()

    def _migrate_buildings(self):
        """Чистит устаревшие постройки (старая модель добычи) и выдаёт
        существующим странам стартовый завод, если завода нет."""
        try:
            self.buildings.cleanup_orphans(list(BUILDINGS))
            for obj in Countries().all_objects():
                owned = self.buildings.get_buildings(obj.name)
                if not any(k in PRODUCTION_BUILDINGS for k in owned):
                    self.buildings.add_building(obj.name, "factory_small", 1)
        except Exception:
            import traceback
            traceback.print_exc()

    # ───── просмотр ─────
    @commands.command(name="resources", aliases=["ресурсы", "res", "рес"])
    async def resources_cmd(self, ctx):
        obj = await self._require_obj(ctx)
        if not obj:
            return
        await ctx.send(components=self._hub(obj, ctx.author.display_avatar.url).components)

    @commands.command(name="deposits", aliases=["залежи", "геология"])
    async def deposits_cmd(self, ctx):
        obj = await self._require_obj(ctx)
        if not obj:
            return
        await ctx.send(embed=self._deposits_embed(obj))

    @commands.command(name="buildings", aliases=["постройки", "здания"])
    async def buildings_cmd(self, ctx):
        obj = await self._require_obj(ctx)
        if not obj:
            return
        owned = self.buildings.get_buildings(obj.name)
        if not owned:
            await ctx.send(embed=disnake.Embed(title="Постройки",
                                               description="Построек нет. Откройте `!build`.", color=WARNING_COLOR))
            return
        ext = [f"{bld_icon(k)} {building_label(k)} `×{c}` · {int_format(FACTORY_POWER[k])}/ч" for k, c in owned.items() if k in PRODUCTION_BUILDINGS]
        fac = [f"{bld_icon(k)} {building_label(k)} `×{c}` → {res_icon(BUILDINGS[k][2])}" for k, c in owned.items() if k in FACTORY_BUILDINGS]
        desc = ((f"**{action_icon('build')} Заводы**\n" + "\n".join(ext) + "\n\n") if ext else "") + ((f"**{action_icon('craft')} Переработка**\n" + "\n".join(fac)) if fac else "")
        await ctx.send(embed=disnake.Embed(title=f"Постройки {obj.name}", description=desc, color=COMMAND_COLOR))

    # ───── строительство ─────
    @commands.command(name="build", aliases=["построить", "стройка", "строить"])
    async def build_cmd(self, ctx, *, building: str | None = None):
        obj = await self._require_obj(ctx)
        if not obj:
            return
        if not building:
            await ctx.send(components=self._build_panel(obj).components)
            return
        key = find_building(building)
        if not key:
            await ctx.send(embed=disnake.Embed(description="Такого здания нет. Откройте `!build`.", color=ERROR_COLOR))
            return
        await ctx.send(embed=self._do_build(obj, key))

    # ───── переработка ─────
    @commands.command(name="craft", aliases=["крафт", "переработать", "process"])
    async def craft_cmd(self, ctx, material: str | None = None, amount: int = 1):
        obj = await self._require_obj(ctx)
        if not obj:
            return
        if not material:
            await ctx.send(components=CraftPanel(obj).components)
            return
        mat = None
        q = material.strip().lower()
        for m in RECIPES:
            if q in m.lower() or q in res_label(m).lower():
                mat = m
                break
        if not mat:
            await ctx.send(embed=disnake.Embed(description="Такой материал не производится. Откройте `!craft`.", color=ERROR_COLOR))
            return
        await ctx.send(embed=self._do_craft(obj, mat, amount))

    @commands.command(name="exchange", aliases=["биржа", "exch"])
    async def exchange_cmd(self, ctx, action: str | None = None, resource: str | None = None, amount: str | None = None):
        obj = await self._require_obj(ctx)
        if not obj:
            return
        if not action:
            await ctx.send(components=self._exchange_panel(obj).components)
            return
        res = _find_resource(resource or "")
        if not res:
            await ctx.send(embed=disnake.Embed(description="Укажите ресурс. Доска: `!exchange`", color=ERROR_COLOR))
            return
        act = action.lower()
        if act in ("sell", "продать"):
            if amount and amount.lower() in ("all", "всё", "все"):
                amt = self.settings.get_resources(obj.name).get(res, 0)
            else:
                amt = int(amount) if amount and amount.lstrip("-").isdigit() else 0
            await ctx.send(embed=self._do_sell(obj, res, amt))
        elif act in ("buy", "купить"):
            amt = int(amount) if amount and amount.lstrip("-").isdigit() else 0
            await ctx.send(embed=self._do_buy(obj, res, amt))
        else:
            await ctx.send(embed=disnake.Embed(description="`!exchange sell|buy <ресурс> <кол-во>`", color=ERROR_COLOR))

    # ───── роутер хаба (кнопки) ─────
    @commands.Cog.listener()
    async def on_button_click(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("res:"):
            return
        _, action, args = parse_cid(c)
        owner_id = int(args[0]) if args and args[0].isdigit() else None
        if owner_id and inter.author.id != owner_id:
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message(
                embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR), ephemeral=True)
            return
        if action == "alloc":
            await inter.response.send_message(components=self._alloc_panel(obj).components, ephemeral=True)
        elif action == "areset":
            self.alloc.reset(obj.name)
            await inter.response.edit_message(components=self._alloc_panel(obj).components)
        elif action == "buildmenu":
            await inter.response.send_message(components=self._build_panel(obj).components, ephemeral=True)
        elif action == "craftmenu":
            await inter.response.send_message(components=CraftPanel(obj).components, ephemeral=True)
        elif action == "exchange":
            await inter.response.send_message(components=self._exchange_panel(obj).components, ephemeral=True)
        elif action == "exq" and len(args) >= 3:
            res, pct = args[1], int(args[2]) if args[2].isdigit() else 0
            have = self.settings.get_resources(obj.name).get(res, 0)
            amount = have if pct >= 100 else have * pct // 100
            await inter.response.send_message(embed=self._do_sell(obj, res, amount), ephemeral=True)
        elif action == "deposits":
            await inter.response.send_message(embed=self._deposits_embed(obj), ephemeral=True)

    # ───── роутер меню (селекты) ─────
    @commands.Cog.listener()
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("res:"):
            return
        _, action, args = parse_cid(c)
        owner_id = int(args[0]) if args and args[0].isdigit() else None
        if owner_id and inter.author.id != owner_id:
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message(
                embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR), ephemeral=True)
            return
        value = inter.values[0]
        if action == "build":
            await inter.response.send_message(embed=self._do_build(obj, value), ephemeral=True)
        elif action == "upgr":
            await inter.response.send_message(embed=self._do_upgrade(obj, value), ephemeral=True)
        elif action == "craft":
            await inter.response.send_message(embed=self._do_craft(obj, value, 1), ephemeral=True)
        elif action == "exsel":
            have = self.settings.get_resources(obj.name).get(value, 0)
            await inter.response.send_message(
                components=SellPanel(obj, value, have, self._price(value)).components, ephemeral=True)
        elif action == "aw":
            # усилить выбранную руду: +2 к весу
            self.alloc.add_weight(obj.name, value, 2)
            await inter.response.edit_message(components=self._alloc_panel(obj).components)

    # ───── панель распределения ─────
    def _alloc_panel(self, obj) -> "AllocationPanel":
        pool = self._factory_pool(obj.name)
        weights = self._alloc_weights(obj.name)
        return AllocationPanel(obj, pool, weights, self._production_rates(obj))


def setup(bot: commands.Bot):
    bot.add_cog(ResourcesCog(bot))
