"""
Ког инвентаря и предметов.

economy.py импортирует отсюда InventoryView. Пока это скелет интерфейса —
полную реализацию (предметы, лицензии, использование) делаем на этапе 6.
"""

import disnake
from disnake.ext import commands

from utils import InventoryObject, COMMAND_COLOR
from utils.ui import Panel


class InventoryView(Panel):
    """Просмотр инвентаря участника (панель disnake V2). Статичная."""

    def __init__(self, items: list[InventoryObject], obj, user_id: int):
        super().__init__(timeout=300)
        self.items = items
        self.obj = obj
        self.user_id = user_id

        name = getattr(obj, "name", "—")
        parts: list[disnake.ui.Item] = [
            disnake.ui.TextDisplay(f"-# {name}\n## Инвентарь"),
            disnake.ui.Separator(),
        ]
        if items:
            lines = [f"**{it.name}**  `×{it.amount}`" for it in items]
            parts.append(disnake.ui.TextDisplay("\n".join(lines)))
        else:
            parts.append(disnake.ui.TextDisplay("-# Инвентарь пуст"))

        self.add_item(disnake.ui.Container(*parts, accent_colour=disnake.Colour(COMMAND_COLOR)))


class ItemsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # TODO: команды предметов/лицензий (этап 6).


def setup(bot: commands.Bot):
    bot.add_cog(ItemsCog(bot))
