"""
Система событий: раз в 6 часов каждой стране выпадает событие, зависящее от её
состояния (счастье, стабильность, казна, развитие, армия, население). Событие
даёт бафы/дебафы — мгновенные и временные (множитель дохода). Красиво постится
в канал событий (config.EVENTS_CHANNEL).

  !eventnow [force] — АДМИН: прогнать события сейчас (диагностика/тест)
"""

import asyncio
import logging
import random
import time

import disnake
from disnake.ext import commands, tasks

from utils import (
    Countries, Settings, Politics, Army, Effects, Cooldown,
    get_object, get_object_by_user, update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, CURRENCY,
    ADMINISTRATOR, GUILD_ID, INCOME_CHANNEL, EVENTS_CHANNEL,
)
from utils.upgrades import country_income
from utils.serverconfig import rid
from utils.perms import has_command_access
from utils.ui import Panel
from utils.resources import res_icon, res_label, ui_icon
import utils.army as ARM
import utils.events as EV

log = logging.getLogger("events")

EVENT_PERIOD = 6 * 3600       # период события на страну (сек)
CHECK_MINUTES = 5            # как часто проверяем, кому пора


def _clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, x))


class EventsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.politics = Politics()
        self.army = Army()
        self.effects = Effects()
        self.cooldown = Cooldown()
        self.event_tick.start()

    def cog_unload(self):
        self.event_tick.cancel()

    # ───── состояние страны ─────
    def _state(self, obj) -> EV.State:
        name = obj.name
        hap = getattr(obj, "happiness", 50.0) or 0.0
        stab = getattr(obj, "stability", 50.0) or 0.0
        academy = self.army.building_count(name, "academy")
        now = int(time.time())
        forms = self.army.formations_for(name)
        power = sum(ARM.formation_power(f["template"], academy, hap, stab)
                    for f in forms if now >= f["ready_at"])
        ready = sum(1 for f in forms if now >= f["ready_at"])
        grain = Settings().get_resources(name).get("зерно", 0)
        ideology, _rel = self.politics.get(name)
        return EV.State(
            happiness=hap, stability=stab, money=obj.money,
            population=getattr(obj, "population", 0), territory=getattr(obj, "territory", 0),
            dev_income=country_income(name), army_power=power, formations=ready,
            grain=grain, ideology=ideology)

    # ───── применение эффектов ─────
    def _apply(self, name: str, effects: list, now: int) -> list[str]:
        fresh = get_object(name)
        if not fresh:
            return []
        money = fresh.money
        pop = getattr(fresh, "population", 0) or 0
        hap = getattr(fresh, "happiness", 50.0) or 0.0
        stab = getattr(fresh, "stability", 50.0) or 0.0
        lines = []
        for op in effects:
            k = op[0]
            if k == "money_pct":
                d = int(money * op[1])
                if d:
                    update_money(name, d)
                    lines.append(self._money(d))
            elif k == "money":
                update_money(name, op[1])
                lines.append(self._money(op[1]))
            elif k == "happy":
                hap = _clamp(hap + op[1])
                self.countries.update_object(name, happiness=round(hap, 2))
                lines.append(f"{ui_icon('happy')} {self._sign(op[1])} счастья")
            elif k == "stab":
                stab = _clamp(stab + op[1])
                self.countries.update_object(name, stability=round(stab, 2))
                lines.append(f"{ui_icon('stability')} {self._sign(op[1])} стабильности")
            elif k == "pop_pct":
                d = int(pop * op[1])
                if d:
                    self.countries.update_object(name, population=max(0, pop + d))
                    lines.append(f"{ui_icon('ev_social')} {self._sign(d, fmt=True)} населения")
            elif k == "res":
                Settings().add_resource(name, op[1], op[2])
                lines.append(f"{res_icon(op[1])} {self._sign(op[2], fmt=True)} {res_label(op[1])}")
            elif k == "income_mult":
                self.effects.add(name, "income_mult", op[1], now + int(op[2] * 3600))
                arrow = ui_icon("up") if op[1] >= 1 else ui_icon("down")
                lines.append(f"{arrow} доход ×{op[1]:.2f} на {op[2]}ч")
            # неизвестные операции тихо пропускаем
        return lines

    def _money(self, d: int) -> str:
        return f"{ui_icon('coins')} {'+' if d >= 0 else '−'}{int_format(abs(d))} {CURRENCY}"

    def _sign(self, v, fmt=False) -> str:
        s = "+" if v >= 0 else "−"
        return f"{s}{int_format(abs(v)) if fmt else abs(v)}"

    # ───── панели ─────
    def _panels(self, results: list) -> list[list]:
        panels = []
        for grp in (results[i:i + 4] for i in range(0, len(results), 4)):
            p = Panel(timeout=None)
            for flag, name, ev, lines in grp:
                tone_word, color = EV.TONE.get(ev["tone"], ("Событие", COMMAND_COLOR))
                items = [
                    disnake.ui.TextDisplay(
                        f"-# {flag} {name}\n## {EV.cat_icon(ev['cat'])} {ev['title']}\n"
                        f"-# {ev['icon']} {EV.CATS.get(ev['cat'], ev['cat'])} · {tone_word}"),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay(ev["desc"].format(name=name)),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay("-# ПОСЛЕДСТВИЯ\n" + ("\n".join(lines) if lines else "— без ощутимых последствий")),
                ]
                p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
            panels.append(p.components)
        return panels

    def _channel(self, guild):
        cid_ = rid("CH_EVENTS", EVENTS_CHANNEL) or rid("CH_INCOME", INCOME_CHANNEL)
        return (guild.get_channel(cid_) if guild else None) or self.bot.get_channel(cid_)

    # ───── основной прогон ─────
    async def _run(self, force: bool = False) -> dict:
        diag = {"checked": 0, "fired": [], "channel": None, "error": None}
        guild = self.bot.get_guild(GUILD_ID)
        channel = self._channel(guild)
        if channel is None:
            diag["error"] = f"канал событий {EVENTS_CHANNEL or INCOME_CHANNEL} не найден"
            return diag
        diag["channel"] = getattr(channel, "name", channel.id)
        now = int(time.time())
        self.effects.cleanup(now)
        results = []
        for obj in self.countries.all_objects():
            try:
                diag["checked"] += 1
                if not force and now < self.cooldown.get_cooldown("event", obj.name):
                    continue
                self.cooldown.set_cooldown("event", now + EVENT_PERIOD, obj.name)
                state = self._state(obj)
                pool = EV.eligible(state)
                ev = random.choices(pool, weights=[e["weight"] for e in pool])[0]
                lines = self._apply(obj.name, ev["effects"], now)
                results.append((getattr(obj, "flag", "🏳️"), obj.name, ev, lines))
                diag["fired"].append((obj.name, ev["title"]))
            except Exception as e:
                log.exception("событие для %s", getattr(obj, "name", "?"))
                diag["error"] = str(e)
        if results:
            try:
                for comp in self._panels(results):
                    await channel.send(components=comp)
            except disnake.Forbidden:
                diag["error"] = f"НЕТ ПРАВ слать в #{diag['channel']}"
            except Exception as e:
                diag["error"] = f"ошибка отправки: {e}"
        return diag

    @tasks.loop(minutes=CHECK_MINUTES)
    async def event_tick(self):
        try:
            d = await self._run()
            if d["fired"]:
                log.info("события: %s", d["fired"])
            elif d["error"]:
                log.warning("события: %s", d["error"])
        except Exception:
            log.exception("сбой цикла событий")

    @event_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ───── админ-тест ─────
    @commands.command(name="eventnow", aliases=["событие-сейчас", "события-тест"])
    async def eventnow_cmd(self, ctx, mode: str | None = None):
        if not has_command_access(ctx.author, "eventnow"):
            await ctx.send(embed=disnake.Embed(description="Нет доступа к этой команде (`!perm`).", color=ERROR_COLOR))
            return
        force = (mode or "").lower() in ("force", "форс", "сила", "now")
        d = await self._run(force=force)
        fired = "\n".join(f"• {n} — {t}" for n, t in d["fired"]) or "—"
        await ctx.send(embed=disnake.Embed(
            title="🎲 Прогон событий",
            description=(f"**режим:** {'FORCE (без КД)' if force else 'обычный'}\n"
                        f"**канал:** {('#' + str(d['channel'])) if d['channel'] else '❌'}\n"
                        f"**проверено стран:** {d['checked']}\n\n"
                        f"**выпало ({len(d['fired'])}):**\n{fired}\n\n"
                        f"**ошибка:** {d['error'] or '—'}"),
            color=SUCCESS_COLOR if d["fired"] and not d["error"] else COMMAND_COLOR))


def setup(bot: commands.Bot):
    bot.add_cog(EventsCog(bot))
