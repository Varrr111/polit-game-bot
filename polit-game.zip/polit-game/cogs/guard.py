"""
🛡️ ЗАЩИТА СЕРВЕРА (Sentinel) — !guard

ЖЁСТКО к атакам, КОМФОРТНО к людям.
  • Анти-нюк: откат удаления каналов/ролей + БАН крушителя (иммунен только
    владелец — даже админ под угрозой, если аккаунт угнан). Анти-вебхук/бан/бот.
  • Анти-спам: СТУПЕНЧАТО (удаление → предупреждение → растущий тайм-аут), штаб и
    доверенные иммунны, безопасные ссылки (гифки/ютуб) разрешены, фильтр-слов пуст
    по умолчанию. Жёсткость — только в рейд-режиме.
  • Паник-автомат: шквал разрушений → авто рейд-режим + локдаун + тревога.

Панель !guard (модули/рейд/локдаун/вайтлист/рейдеры/статистика). Кастом-иконки.
"""

import asyncio
import logging
import time
from datetime import datetime, timedelta, timezone

import disnake
from disnake.ext import commands, tasks

from utils import Guard, COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, GUILD_ID
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
from utils.perms import is_staff, has_command_access
import utils.guard as G

log = logging.getLogger("guard")


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _is_owner(member, guild=None) -> bool:
    g = guild or getattr(member, "guild", None)
    return bool(g and member and member.id == g.owner_id)


class GuardCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.guard = Guard()
        self._sessions: dict[int, dict] = {}
        self.snapshot_loop.start()

    def cog_unload(self):
        self.snapshot_loop.cancel()

    # ───── доступ ─────
    def _can(self, member) -> bool:
        return _is_owner(member) or has_command_access(member, "guard")

    # ───── иммунитет ─────
    def _immune_nuke(self, member, guild, module="all") -> bool:
        if not member:
            return True
        return member.id in (guild.owner_id, guild.me.id) or self.guard.wl_has(member.id, module)

    def _trusted(self, member) -> bool:
        """Доверенный для анти-спама: прижившийся живой участник."""
        try:
            age_d = (datetime.now(timezone.utc) - member.created_at).days
        except Exception:
            age_d = 99
        return (age_d >= G.TRUSTED_ACCOUNT_AGE_D and
                G.msg_count.get(member.id, 0) >= G.TRUSTED_MEMBER_MIN)

    def _immune_spam(self, member) -> bool:
        if not member or member.bot:
            return True
        if member.id in (getattr(member.guild, "owner_id", 0), member.guild.me.id):
            return True
        if is_staff(member) or self.guard.wl_has(member.id, "antispam"):
            return True
        return self._trusted(member)

    # ───── лог ─────
    async def _glog(self, guild, title, desc, color=G.C_WARNING):
        ch_id = self.guard.log_channel() or rid("CH_LOG_MOD", 0) or rid("CH_LOG", 0)
        ch = guild.get_channel(ch_id) if (guild and ch_id) else None
        if not isinstance(ch, disnake.TextChannel):
            return
        e = disnake.Embed(title=title, description=desc, color=color,
                          timestamp=datetime.now(timezone.utc))
        try:
            await ch.send(embed=e)
        except Exception:
            pass

    # ═══════════════ СНАПШОТЫ ═══════════════
    def _snap(self, guild):
        if len(guild.channels) >= 4:
            G.CHANNEL_SNAPSHOT[guild.id] = [{
                "id": ch.id, "cat": isinstance(ch, disnake.CategoryChannel), "type": ch.type,
                "name": ch.name, "position": ch.position, "category_id": ch.category_id,
                "overwrites": ch.overwrites, "topic": getattr(ch, "topic", None),
                "nsfw": getattr(ch, "nsfw", False), "slowmode": getattr(ch, "slowmode_delay", 0),
            } for ch in guild.channels]
        G.ROLE_SNAPSHOT[guild.id] = [{
            "id": r.id, "name": r.name, "permissions": r.permissions, "color": r.color,
            "hoist": r.hoist, "mentionable": r.mentionable, "position": r.position,
        } for r in guild.roles if not r.is_default()]

    @commands.Cog.listener()
    async def on_ready(self):
        for g in self.bot.guilds:
            self._snap(g)

    @tasks.loop(minutes=10)
    async def snapshot_loop(self):
        for g in self.bot.guilds:
            if g.id not in G.LOCKED_GUILDS:
                self._snap(g)

    @snapshot_loop.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    async def _restore_channels(self, guild) -> int:
        snap = G.CHANNEL_SNAPSHOT.get(guild.id)
        if not snap:
            return 0
        existing = {ch.id for ch in guild.channels}
        cats = sorted([c for c in snap if c["cat"]], key=lambda x: x["position"])
        chans = sorted([c for c in snap if not c["cat"]], key=lambda x: x["position"])
        id_map, restored = {}, 0
        for cat in cats:
            if cat["id"] in existing:
                continue
            try:
                new = await guild.create_category(cat["name"], overwrites=cat["overwrites"])
                id_map[cat["id"]] = new.id
                restored += 1
                await asyncio.sleep(0.3)
            except Exception:
                pass
        for ch in chans:
            if ch["id"] in existing:
                continue
            category = guild.get_channel(id_map.get(ch["category_id"], ch["category_id"])) if ch["category_id"] else None
            try:
                if ch["type"] == disnake.ChannelType.text:
                    await guild.create_text_channel(ch["name"], category=category,
                                                    overwrites=ch["overwrites"], topic=ch["topic"],
                                                    slowmode_delay=ch["slowmode"], nsfw=ch["nsfw"])
                elif ch["type"] == disnake.ChannelType.voice:
                    await guild.create_voice_channel(ch["name"], category=category, overwrites=ch["overwrites"])
                else:
                    continue
                restored += 1
                await asyncio.sleep(0.2)
            except Exception:
                pass
        return restored

    # ═══════════════ АНТИ-НЮК ═══════════════
    async def _executor(self, guild, action, delay=0.8):
        await asyncio.sleep(delay)
        if not guild.me.guild_permissions.view_audit_log:
            return None
        try:
            async for entry in guild.audit_logs(limit=1, action=action):
                return entry.user
        except Exception:
            return None

    async def _punish(self, guild, member, reason) -> bool:
        """Снимает права ролей нарушителя и банит (не трогает владельца/бота)."""
        if not member or member.id in (guild.owner_id, guild.me.id):
            return False
        for role in getattr(member, "roles", []):
            if role.is_default() or role >= guild.me.top_role:
                continue
            try:
                await role.edit(permissions=disnake.Permissions.none())
            except Exception:
                pass
        try:
            await guild.ban(member, reason=reason)
            self.guard.stat_inc("bans")
            return True
        except Exception:
            return False

    def _panic_check(self) -> bool:
        now = time.time()
        G.panic_actions[:] = [t for t in G.panic_actions if now - t <= G.PANIC_WINDOW]
        G.panic_actions.append(now)
        return len(G.panic_actions) >= G.PANIC_ACTIONS

    async def _maybe_panic(self, guild):
        if self._panic_check() and guild.id not in G.LOCKED_GUILDS:
            self.guard.set_raid_mode(True)
            await self._lockdown(guild, on=True)
            await self._glog(guild, "🚨 ПАНИК-РЕЖИМ",
                             f"{ui_icon('raidmode')} Шквал разрушительных действий — авто рейд-режим + "
                             "локдаун всех каналов. Проверьте журнал и снимите вручную: `!unlock`, `!raid off`.",
                             G.C_DANGER)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        guild = channel.guild
        if not self.guard.module_on("antichannel") or guild.id in G.LOCKED_GUILDS:
            return
        if guild.id in G.SUPPRESS:        # бот сам перестраивает сервер — не мешаем
            return
        attacker = await self._executor(guild, disnake.AuditLogAction.channel_delete)
        if attacker and attacker.id == guild.me.id:   # это действие самого бота
            return
        # Иммунный (белый список / владелец) — это РАЗРЕШЁННОЕ действие: не
        # восстанавливаем и не наказываем, просто фиксируем новое состояние.
        if attacker and self._immune_nuke(attacker, guild, "antichannel"):
            self._snap(guild)
            return
        G.LOCKED_GUILDS.add(guild.id)
        try:
            if attacker:          # известный и НЕ иммунный — это атака
                banned = await self._punish(guild, attacker, "Sentinel: удаление канала")
                restored = await self._restore_channels(guild)
                self.guard.stat_inc("restored", restored)
                await self._glog(guild, "🛑 Анти-нюк — атака отражена",
                                 f"{ui_icon('antinuke')} **Нарушитель:** {attacker.mention}\n"
                                 f"Канал `{channel.name}` · бан {'✅' if banned else '❌'} · "
                                 f"{ui_icon('restore')} восстановлено объектов: **{restored}**", G.C_DANGER)
                await self._maybe_panic(guild)
            else:                 # исполнитель неизвестен — осторожно восстановим
                restored = await self._restore_channels(guild)
                if restored:
                    await self._glog(guild, "🏗️ Анти-нюк — восстановление",
                                     f"{ui_icon('restore')} Канал удалён (исполнитель неизвестен) · "
                                     f"восстановлено: **{restored}**", G.C_WARNING)
        finally:
            G.LOCKED_GUILDS.discard(guild.id)
            self._snap(guild)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        guild = role.guild
        if not self.guard.module_on("antirole"):
            return
        if guild.id in G.SUPPRESS:        # бот сам перестраивает сервер — не мешаем
            return
        attacker = await self._executor(guild, disnake.AuditLogAction.role_delete)
        if not attacker or attacker.id == guild.me.id or self._immune_nuke(attacker, guild, "antirole"):
            return
        data = next((r for r in G.ROLE_SNAPSHOT.get(guild.id, []) if r["id"] == role.id), None)
        name = data["name"] if data else role.name
        if data:
            try:
                nr = await guild.create_role(name=data["name"], permissions=data["permissions"],
                                             colour=data["color"], hoist=data["hoist"],
                                             mentionable=data["mentionable"], reason="Sentinel: откат роли")
                await nr.edit(position=min(data["position"], guild.me.top_role.position - 1))
            except Exception:
                pass
        await self._punish(guild, attacker, "Sentinel: удаление роли")
        self._snap(guild)
        await self._glog(guild, "🛑 Анти-роль — роль восстановлена",
                         f"{ui_icon('antirole')} Роль `{name}` восстановлена · нарушитель "
                         f"{attacker.mention} забанен.", G.C_DANGER)
        await self._maybe_panic(guild)

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        guild = after.guild
        if not self.guard.module_on("antirole"):
            return
        if guild.id in G.SUPPRESS:        # бот сам перестраивает сервер — не мешаем
            return
        # опасные права внезапно появились?
        gained = [p for p in G.DANGEROUS_PERMS
                  if getattr(after.permissions, p) and not getattr(before.permissions, p)]
        if not gained:
            return
        attacker = await self._executor(guild, disnake.AuditLogAction.role_update)
        if not attacker or attacker.id == guild.me.id or self._immune_nuke(attacker, guild, "antirole"):
            return
        try:
            await after.edit(permissions=before.permissions, reason="Sentinel: откат опасных прав")
        except Exception:
            pass
        await self._punish(guild, attacker, "Sentinel: выдача опасных прав роли")
        await self._glog(guild, "🛑 Анти-роль — опасные права откатаны",
                         f"{ui_icon('antirole')} Роль `{after.name}`: откатаны права "
                         f"({', '.join(gained)}) · {attacker.mention} забанен.", G.C_DANGER)

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        guild = channel.guild
        if not self.guard.module_on("antiwebhook"):
            return
        user = await self._executor(guild, disnake.AuditLogAction.webhook_create, delay=0.3)
        if not user or user.id == guild.me.id or self._immune_nuke(user, guild, "antiwebhook"):
            return
        deleted = 0
        try:
            for hook in await channel.webhooks():
                try:
                    await hook.delete()
                    deleted += 1
                except Exception:
                    pass
        except Exception:
            pass
        banned = await self._punish(guild, user, "Sentinel: несанкционированный вебхук")
        await self._glog(guild, "🛑 Анти-вебхук",
                         f"{ui_icon('antiwebhook')} {user.mention} · удалено вебхуков **{deleted}** · "
                         f"бан {'✅' if banned else '❌'}", G.C_DANGER)

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        if not self.guard.module_on("antiban"):
            return
        executor = await self._executor(guild, disnake.AuditLogAction.ban)
        if not executor or executor.id == guild.me.id or self._immune_nuke(executor, guild, "antiban"):
            return
        try:
            await guild.unban(user, reason="Sentinel: откат бана")
        except Exception:
            pass
        banned = await self._punish(guild, executor, "Sentinel: несанкционированный бан")
        await self._glog(guild, "🛑 Анти-бан — бан отменён",
                         f"{ui_icon('antiban')} Жертва {user.mention} разбанена · нарушитель "
                         f"{executor.mention} {'забанен ✅' if banned else '❌'}", G.C_DANGER)
        await self._maybe_panic(guild)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        guild = member.guild
        # глобальный рейдер-лист → автобан
        if self.guard.raider_is(member.id):
            try:
                await guild.ban(member, reason="Sentinel: в списке рейдеров")
                self.guard.stat_inc("raiders_banned")
                await self._glog(guild, "🚫 Автобан — рейдер",
                                 f"{ui_icon('raider')} {member} (`{member.id}`) — в глобальном списке рейдеров.",
                                 G.C_DANGER)
            except Exception:
                pass
            return
        # анти-бот: чужой бот без разрешения
        if member.bot and self.guard.module_on("antibot"):
            ex = await self._executor(guild, disnake.AuditLogAction.bot_add, delay=0.5)
            if ex and (ex.id == guild.owner_id or self.guard.wl_has(ex.id, "antibot")):
                return
            try:
                await guild.ban(member, reason="Sentinel: несанкционированный бот")
                await self._glog(guild, "🤖 Анти-бот",
                                 f"{ui_icon('antibot')} Бот {member.mention} заблокирован "
                                 f"(добавил {ex.mention if ex else 'неизвестно'}).", G.C_DANGER)
            except Exception:
                pass
            return
        # рейд-режим: новые аккаунты ограничиваем (не баним — комфорт)
        if self.guard.raid_mode():
            try:
                age_d = (datetime.now(timezone.utc) - member.created_at).days
            except Exception:
                age_d = 99
            if age_d < G.RAID_NEW_ACCOUNT_D:
                try:
                    await member.timeout(duration=timedelta(hours=1), reason="Sentinel: рейд-режим, новый аккаунт")
                    await self._glog(guild, "🚨 Рейд-режим — новый аккаунт в карантине",
                                     f"{ui_icon('raidmode')} {member.mention} · возраст **{age_d} дн.** — "
                                     "тайм-аут 1ч (снимите вручную, если свой).", G.C_WARNING)
                except Exception:
                    pass

    # ═══════════════ АНТИ-СПАМ (мягко, ступенчато) ═══════════════
    @commands.Cog.listener("on_message")
    async def _antispam(self, msg: disnake.Message):
        if not msg.guild or msg.author.bot or msg.webhook_id:
            return
        if not self.guard.module_on("antispam"):
            return
        member = msg.guild.get_member(msg.author.id)
        # счётчик сообщений (для «прижился»)
        G.msg_count[msg.author.id] = G.msg_count.get(msg.author.id, 0) + 1
        if self._immune_spam(member):
            return
        now = time.time()
        uid = msg.author.id
        txt = msg.content or ""
        lo = txt.lower()

        # масс-пинг / @everyone (явный абуз) → удалить + тайм-аут
        if msg.mention_everyone or (len(msg.mentions) + len(msg.role_mentions)) >= G.MASS_MENTION_LIMIT:
            await self._soft_punish(msg, member, "Массовые упоминания", delete=True, timeout=True)
            return

        # ссылки: безопасные (гифки/ютуб) — ок; прочие от недоверенных — мягко
        if G.URL_REGEX.search(txt) and not G.is_safe_link(txt):
            bucket = G.link_cache[uid]
            bucket[:] = [t for t in bucket if now - t <= G.LINK_WINDOW]
            bucket.append(now)
            if len(bucket) >= G.LINK_SOFT_LIMIT:
                bucket.clear()
                await self._soft_punish(msg, member, "Спам ссылками", delete=True, timeout=True)
            else:
                await self._delete(msg)
                await self._glog(msg.guild, "🔗 Ссылка удалена",
                                 f"{ui_icon('antiwebhook')} {msg.author.mention} — "
                                 f"страйк **{len(bucket)}/{G.LINK_SOFT_LIMIT}** (повтор → тайм-аут).", G.C_INFO)
            return

        # повтор одинаковых
        clean = lo.strip()
        if clean:
            hist = G.repeat_cache[uid]
            hist.append(clean)
            if len(hist) > G.REPEAT_LIMIT:
                hist.pop(0)
            if len(hist) == G.REPEAT_LIMIT and len(set(hist)) == 1:
                hist.clear()
                await self._soft_punish(msg, member, "Повтор одинаковых сообщений", delete=True, timeout=True, purge=True)
                return

        # флуд
        bucket = G.spam_cache[uid]
        bucket[:] = [t for t in bucket if now - t <= G.SPAM_INTERVAL]
        bucket.append(now)
        if len(bucket) >= G.SPAM_LIMIT:
            bucket.clear()
            await self._soft_punish(msg, member, "Флуд", delete=False, timeout=True, purge=True)
            return

        # рейд-скорость (только в рейд-режиме)
        if self.guard.raid_mode():
            raid = G.raid_cache[uid]
            raid[:] = [t for t in raid if now - t <= G.RAID_SPEED_WINDOW]
            raid.append(now)
            if len(raid) >= G.RAID_SPEED_LIMIT:
                raid.clear()
                await self._soft_punish(msg, member, "Рейд — высокая скорость", delete=False, timeout=True, purge=True)

    async def _delete(self, msg):
        try:
            await msg.delete()
            self.guard.stat_inc("blocked")
        except Exception:
            pass

    async def _soft_punish(self, msg, member, reason, *, delete=False, timeout=False, purge=False):
        if delete:
            await self._delete(msg)
        if purge:
            try:
                async for m in msg.channel.history(limit=25):
                    if m.author.id == msg.author.id:
                        await m.delete()
            except Exception:
                pass
        if timeout and member:
            secs = G.next_timeout(member.id, time.time())
            try:
                await member.timeout(duration=timedelta(seconds=secs), reason=f"Sentinel: {reason}")
                self.guard.stat_inc("timeouts")
                mins = secs // 60
                await self._glog(msg.guild, "📣 Анти-спам",
                                 f"{ui_icon('antispam')} {msg.author.mention} — **{reason}** · "
                                 f"тайм-аут **{mins}м** (ступенчато).", G.C_WARNING)
            except Exception:
                pass

    # ═══════════════ ЛОКДАУН ═══════════════
    async def _lockdown(self, guild, on: bool) -> int:
        n = 0
        everyone = guild.default_role
        for ch in guild.text_channels:
            try:
                ow = ch.overwrites_for(everyone)
                ow.send_messages = False if on else None
                await ch.set_permissions(everyone, overwrite=ow, reason="Sentinel lockdown")
                n += 1
            except Exception:
                pass
        if on:
            G.LOCKED_GUILDS.add(guild.id)
        else:
            G.LOCKED_GUILDS.discard(guild.id)
        return n

    # ═══════════════ ПАНЕЛЬ (всё в одном меню) ═══════════════
    def _session(self, uid):
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "wl_user": None, "wl_mods": set(), "raider_user": None}
            self._sessions[uid] = s
        return s

    # модули для вайтлиста: полный иммунитет + по-модульно
    def _wl_module_opts(self, selected):
        opts = [disnake.SelectOption(label="Полный иммунитет (всё)", value="all",
                                     emoji=_pe("guard"), default=("all" in selected))]
        for k, (slug, label, _d) in G.MODULE_META.items():
            opts.append(disnake.SelectOption(label=label, value=k, emoji=_pe(slug),
                                             default=(k in selected)))
        return opts

    def _cont(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _panel(self, uid) -> Panel:
        view = self._session(uid)["view"]
        if view == "wl":
            return self._panel_wl(uid)
        if view == "raiders":
            return self._panel_raiders(uid)
        if view == "log":
            return self._panel_log(uid)
        return self._panel_hub(uid)

    def _panel_hub(self, uid) -> Panel:
        gs = self.guard
        raid = gs.raid_mode()
        st = gs.stats_all()
        items = [disnake.ui.TextDisplay(f"## {ui_icon('guard')} Защита сервера · Sentinel")]
        items.append(disnake.ui.TextDisplay("\n".join(
            f"{ui_icon(G.MODULE_META[k][0])} {G.MODULE_META[k][1]}: "
            f"{ui_icon('check') if gs.module_on(k, G.MODULE_DEFAULTS.get(k, True)) else ui_icon('reject')}"
            for k in G.MODULE_META)))
        items.append(disnake.ui.TextDisplay(
            f"{ui_icon('raidmode')} Рейд-режим: **{'ВКЛ' if raid else 'выкл'}**\n"
            f"-# Заблокировано {st.get('blocked', 0)} · тайм-аутов {st.get('timeouts', 0)} · "
            f"банов {st.get('bans', 0)} · восстановлено {st.get('restored', 0)} · рейдеров {st.get('raiders_banned', 0)}"))
        items.append(disnake.ui.Separator())
        opts = [disnake.SelectOption(
            label=f"{G.MODULE_META[k][1]} — {'выкл' if gs.module_on(k, G.MODULE_DEFAULTS.get(k, True)) else 'вкл'}",
            value=k, emoji=_pe(G.MODULE_META[k][0]), description=G.MODULE_META[k][2][:100]) for k in G.MODULE_META]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("guard", "toggle"), placeholder="Переключить модуль…", options=opts)))
        B = disnake.ButtonStyle
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.danger if not raid else B.success,
                              label=("Рейд-режим ВКЛ" if not raid else "Рейд-режим выкл"),
                              emoji=_pe("raidmode"), custom_id=cid("guard", "raid")),
            disnake.ui.Button(style=B.secondary, label="Локдаун", emoji=_pe("antinuke"),
                              custom_id=cid("guard", "lock")),
            disnake.ui.Button(style=B.secondary, label="Снять локдаун", emoji=_pe("restore"),
                              custom_id=cid("guard", "unlock"))))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.primary, label="Вайтлист", emoji=_pe("check"),
                              custom_id=cid("guard", "goto", "wl")),
            disnake.ui.Button(style=B.primary, label="Рейдеры", emoji=_pe("raider"),
                              custom_id=cid("guard", "goto", "raiders")),
            disnake.ui.Button(style=B.secondary, label="Журнал", emoji=_pe("guard"),
                              custom_id=cid("guard", "goto", "log"))))
        return self._cont(items)

    def _panel_wl(self, uid) -> Panel:
        s = self._session(uid)
        wl = self.guard.wl_all()
        cur_lines = []
        for u, mods in list(wl.items())[:10]:
            m = "всё" if "all" in mods else ", ".join(G.MODULE_META.get(x, (None, x))[1] for x in mods)
            cur_lines.append(f"<@{u}> — {m}")
        who = f"<@{s['wl_user']}>" if s["wl_user"] else "— не выбран —"
        mods_txt = ("всё" if "all" in s["wl_mods"]
                    else ", ".join(G.MODULE_META.get(x, (None, x))[1] for x in sorted(s["wl_mods"])) or "— не выбраны —")
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('check')} Вайтлист (иммунитет по модулям)\n"
            f"-# Выбери участника и модули, для которых он не будет наказываться.\n"
            f"Участник: {who} · Модули: **{mods_txt}**")]
        if cur_lines:
            items.append(disnake.ui.TextDisplay("-# ТЕКУЩИЕ:\n" + "\n".join(cur_lines)))
        items.append(disnake.ui.ActionRow(disnake.ui.UserSelect(
            custom_id=cid("guard", "wluser"), placeholder="Выбрать участника…", max_values=1)))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("guard", "wlmods"), placeholder="Модули иммунитета…",
            min_values=0, max_values=len(G.MODULE_META) + 1, options=self._wl_module_opts(s["wl_mods"]))))
        B = disnake.ButtonStyle
        ready = bool(s["wl_user"] and s["wl_mods"])
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="Выдать", emoji=_pe("check"), disabled=not ready,
                              custom_id=cid("guard", "wlgrant")),
            disnake.ui.Button(style=B.danger, label="Забрать выбранное", emoji=_pe("reject"), disabled=not ready,
                              custom_id=cid("guard", "wlrevoke")),
            disnake.ui.Button(style=B.danger, label="Убрать совсем", disabled=(not s["wl_user"]),
                              custom_id=cid("guard", "wlclear")),
            disnake.ui.Button(style=B.secondary, label="Назад", emoji=_pe("prev"),
                              custom_id=cid("guard", "goto", "hub"))))
        return self._cont(items)

    def _panel_raiders(self, uid) -> Panel:
        s = self._session(uid)
        rs = self.guard.raider_list()
        who = f"<@{s['raider_user']}>" if s["raider_user"] else "— не выбран —"
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('raider')} Список рейдеров (глобальный автобан)\n"
            f"-# Выбран: {who}. Эти люди банятся автоматически при входе.")]
        if rs:
            items.append(disnake.ui.TextDisplay("-# В СПИСКЕ:\n" + "\n".join(
                f"<@{r['user_id']}> — {r['reason'] or '—'}" for r in rs[:12])))
        items.append(disnake.ui.ActionRow(disnake.ui.UserSelect(
            custom_id=cid("guard", "raideruser"), placeholder="Выбрать участника…", max_values=1)))
        B = disnake.ButtonStyle
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.danger, label="В рейдеры (бан)", emoji=_pe("raider"),
                              disabled=(not s["raider_user"]), custom_id=cid("guard", "raideradd")),
            disnake.ui.Button(style=B.success, label="Убрать", emoji=_pe("check"),
                              disabled=(not s["raider_user"]), custom_id=cid("guard", "raiderrm")),
            disnake.ui.Button(style=B.secondary, label="Назад", emoji=_pe("prev"),
                              custom_id=cid("guard", "goto", "hub"))))
        return self._cont(items)

    def _panel_log(self, uid) -> Panel:
        cur = self.guard.log_channel()
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('guard')} Журнал защиты\n"
            f"-# Текущий канал: {('<#%d>' % cur) if cur else 'не задан (по умолчанию — лог модерации)'}.\n"
            "Выбери канал, куда слать отчёты защиты.")]
        items.append(disnake.ui.ActionRow(disnake.ui.ChannelSelect(
            custom_id=cid("guard", "logset"), placeholder="Канал журнала…",
            channel_types=[disnake.ChannelType.text], max_values=1)))
        items.append(disnake.ui.ActionRow(disnake.ui.Button(
            style=disnake.ButtonStyle.secondary, label="Назад", emoji=_pe("prev"),
            custom_id=cid("guard", "goto", "hub"))))
        return self._cont(items)

    def _val_id(self, inter):
        try:
            return int(inter.values[0])
        except (TypeError, ValueError, IndexError):
            return None

    # ───── обработчики ─────
    @commands.Cog.listener("on_button_click")
    async def _guard_btn(self, inter):
        c = inter.component.custom_id or ""
        if not c.startswith("guard:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("🔒 Только владелец или обладатель доступа `guard`.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        guild = inter.guild
        if action == "goto":
            s.update(view=args[0], wl_user=None, wl_mods=set(), raider_user=None)
        elif action == "raid":
            self.guard.set_raid_mode(not self.guard.raid_mode())
        elif action in ("lock", "unlock"):
            await inter.response.defer()
            n = await self._lockdown(guild, action == "lock")
            await inter.edit_original_message(components=self._panel(inter.author.id).components)
            await self._glog(guild, "🔒 Локдаун" if action == "lock" else "🔓 Локдаун снят",
                             f"{ui_icon('antinuke' if action == 'lock' else 'restore')} Каналов: **{n}**.",
                             G.C_WARNING if action == "lock" else G.C_SUCCESS)
            return
        elif action == "wlgrant":
            for m in s["wl_mods"]:
                self.guard.wl_add(s["wl_user"], m)
            s["wl_mods"] = set()
        elif action == "wlrevoke":
            for m in s["wl_mods"]:
                self.guard.wl_remove(s["wl_user"], m)
            s["wl_mods"] = set()
        elif action == "wlclear":
            if s["wl_user"]:
                self.guard.wl_remove_all(s["wl_user"])
        elif action == "raideradd":
            if s["raider_user"]:
                self.guard.raider_add(s["raider_user"], "добавлен через панель")
                try:
                    u = guild.get_member(s["raider_user"]) or await self.bot.fetch_user(s["raider_user"])
                    if u:
                        await guild.ban(u, reason="Sentinel raider")
                except Exception:
                    pass
        elif action == "raiderrm":
            if s["raider_user"]:
                self.guard.raider_remove(s["raider_user"])
        await inter.response.edit_message(components=self._panel(inter.author.id).components)

    @commands.Cog.listener("on_dropdown")
    async def _guard_drop(self, inter):
        c = inter.component.custom_id or ""
        if not c.startswith("guard:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("🔒 Нет доступа.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        if action == "toggle":
            mod = inter.values[0]
            if mod in G.MODULE_META:
                self.guard.set_module(mod, not self.guard.module_on(mod, G.MODULE_DEFAULTS.get(mod, True)))
        elif action == "wluser":
            s["wl_user"] = self._val_id(inter)
        elif action == "wlmods":
            s["wl_mods"] = set(inter.values)
        elif action == "raideruser":
            s["raider_user"] = self._val_id(inter)
        elif action == "logset":
            cid_ = self._val_id(inter)
            if cid_:
                self.guard.set_log_channel(cid_)
        await inter.response.edit_message(components=self._panel(inter.author.id).components)

    # ═══════════════ ЕДИНАЯ КОМАНДА ═══════════════
    @commands.command(name="guard", aliases=["защита", "sentinel", "guardpanel", "защита-сервера"])
    async def guard_cmd(self, ctx):
        if not self._can(ctx.author):
            await ctx.send(embed=disnake.Embed(
                description="🔒 Защита доступна владельцу или по `!perm guard`.", color=ERROR_COLOR))
            return
        self._session(ctx.author.id).update(view="hub", wl_user=None, wl_mods=set(), raider_user=None)
        await ctx.send(components=self._panel(ctx.author.id).components)


def setup(bot: commands.Bot):
    bot.add_cog(GuardCog(bot))
