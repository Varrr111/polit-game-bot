"""
Живая статистика сервера + игровой год.

Стат-каналы (голосовые, только чтение) бот переименовывает:
  👥 Участников · 🤖 Ботов · 🌍 Держав · 📅 Год
ID каналов берутся из server_config (их создаёт !setupserver): STAT_MEMBERS,
STAT_BOTS, STAT_PLAYERS, STAT_YEAR.

Игровой год: 1 год = 2 реальных дня. !setyear <год> ставит текущий (полушаг 1/2).
Каждую полночь (00:00 МСК) +полушага: 1/2 → 2/2 → следующий год 1/2.

Переименование каналов Discord лимитирует (2/10 мин на канал), поэтому счётчики
обновляются раз в 10 минут, год — раз в сутки.
"""

import asyncio
import logging
from datetime import datetime, date

import disnake
from disnake.ext import commands, tasks

import config
from utils import Countries, ADMINISTRATOR, COMMAND_COLOR, ERROR_COLOR, SUCCESS_COLOR, WARNING_COLOR
from utils.serverconfig import rid, sget, sset
from utils.perms import has_command_access

log = logging.getLogger("serverstats")


class ServerStatsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.refresh_loop.start()

    def cog_unload(self):
        self.refresh_loop.cancel()

    # ───── игровой год ─────
    def get_year(self) -> tuple[int, int]:
        year = sget("GAME_YEAR")
        half = sget("GAME_HALF")
        if year is None:
            year = datetime.now(config.TZ).year
            half = 1
            sset("GAME_YEAR", year)
            sset("GAME_HALF", half)
        return int(year), int(half or 1)

    def set_year(self, year: int):
        sset("GAME_YEAR", year)
        sset("GAME_HALF", 1)
        sset("GAME_LAST_DATE", datetime.now(config.TZ).date().isoformat())

    def advance_year(self) -> tuple[int, int]:
        year, half = self.get_year()
        if half >= 2:
            year, half = year + 1, 1
        else:
            half = 2
        sset("GAME_YEAR", year)
        sset("GAME_HALF", half)
        return year, half

    def year_label(self) -> str:
        year, half = self.get_year()
        return f"{year} ({half}/2)"

    # ───── обновление стат-каналов ─────
    def _counts(self, guild: disnake.Guild) -> tuple[int, int, int]:
        bots = sum(1 for m in guild.members if m.bot)
        humans = max(0, guild.member_count - bots)
        players = len(self.countries.get_object_names())
        return humans, bots, players

    async def _rename(self, channel_id: int, name: str):
        if not channel_id:
            return
        ch = self.bot.get_channel(channel_id)
        if ch and ch.name != name:
            try:
                await ch.edit(name=name)
            except disnake.HTTPException:
                log.warning("Не удалось переименовать стат-канал %s", channel_id)

    async def refresh_stats(self):
        guild = self.bot.get_guild(config.GUILD_ID)
        if not guild:
            return
        humans, bots, players = self._counts(guild)
        await self._rename(rid("STAT_MEMBERS"), f"👥・Участников: {humans}")
        await self._rename(rid("STAT_BOTS"), f"🤖・Ботов: {bots}")
        await self._rename(rid("STAT_PLAYERS"), f"🌍・Держав: {players}")

    async def refresh_year_channel(self):
        await self._rename(rid("STAT_YEAR"), f"📅・Год: {self.year_label()}")

    # ───── циклы ─────
    async def _rollover_year(self):
        """Продвигает год при смене календарной даты (МСК). Надёжно на любой
        версии disnake — без tasks(time=…) с таймзоной (та падает на части хостов:
        'can't compare offset-naive and offset-aware times')."""
        today = datetime.now(config.TZ).date()
        last = sget("GAME_LAST_DATE")
        if not last:
            sset("GAME_LAST_DATE", today.isoformat())
            return
        try:
            delta = (today - date.fromisoformat(last)).days
        except ValueError:
            sset("GAME_LAST_DATE", today.isoformat())
            return
        if delta > 0:
            for _ in range(delta):          # на случай простоя — догнать пропущенные дни
                self.advance_year()
            sset("GAME_LAST_DATE", today.isoformat())
            await self.refresh_year_channel()
            log.info("Игровой год продвинут (+%d) → %s", delta, self.year_label())

    @tasks.loop(minutes=10)
    async def refresh_loop(self):
        await self.refresh_stats()
        await self._rollover_year()

    @refresh_loop.before_loop
    async def _before_refresh(self):
        await self.bot.wait_until_ready()

    # ───── команды ─────
    def _is_admin(self, ctx) -> bool:
        return has_command_access(ctx.author, ctx.command.name if ctx.command else "statsrefresh")

    @commands.command(name="setyear", aliases=["задать-год", "год-установить"])
    async def setyear_cmd(self, ctx: commands.Context, year: int):
        if not self._is_admin(ctx):
            await ctx.send(embed=disnake.Embed(description="Только администратор.", color=ERROR_COLOR))
            return
        if not (1 <= year <= 999999):
            await ctx.send(embed=disnake.Embed(description="Укажите корректный год.", color=ERROR_COLOR))
            return
        self.set_year(year)
        await self.refresh_year_channel()
        await ctx.send(embed=disnake.Embed(
            description=f"📅 Игровой год установлен: **{self.year_label()}**\n-# 1 год = 2 дня · авто-смена в 00:00 МСК",
            color=SUCCESS_COLOR))

    @commands.command(name="year", aliases=["год"])
    async def year_cmd(self, ctx: commands.Context):
        await ctx.send(embed=disnake.Embed(
            title="📅 Игровой год", description=f"Сейчас: **{self.year_label()}**\n-# 1 год = 2 дня",
            color=COMMAND_COLOR))

    @commands.command(name="statsrefresh", aliases=["обновить-статистику"])
    async def statsrefresh_cmd(self, ctx: commands.Context):
        if not self._is_admin(ctx):
            await ctx.send(embed=disnake.Embed(description="Только администратор.", color=ERROR_COLOR))
            return
        async with ctx.typing():
            await self.refresh_stats()
            await self.refresh_year_channel()
        await ctx.send(embed=disnake.Embed(description="Статистика обновлена.", color=SUCCESS_COLOR))

    @commands.command(name="reloadicons", aliases=["иконки", "обновить-иконки"])
    async def reloadicons_cmd(self, ctx: commands.Context, mode: str | None = None):
        """Догрузить недостающие кастом-эмодзи прямо из Discord и применить (без рестарта/скрипта).

        `!reloadicons`        — залить отсутствующие иконки + подхватить.
        `!reloadicons force`  — пере-залить ВСЕ (удалить и создать заново).
        """
        if not self._is_admin(ctx):
            await ctx.send(embed=disnake.Embed(description="Только администратор.", color=ERROR_COLOR))
            return
        from utils.resources import apply_custom_emojis, icon_manifest
        force = (mode or "").lower() in ("force", "форс", "replace", "пере", "all")
        try:
            existing = {e.name: e for e in await self.bot.fetch_application_emojis()}
        except Exception as e:
            await ctx.send(embed=disnake.Embed(
                description=f"Ошибка загрузки эмодзи: `{type(e).__name__}: {e}`", color=ERROR_COLOR))
            return

        manifest = icon_manifest()
        progress = await ctx.send(embed=disnake.Embed(
            description="⏳ Синхронизирую иконки… это может занять минуту.", color=COMMAND_COLOR))
        created = replaced = failed = skipped = 0
        fails: list[str] = []
        for slug, png in manifest:
            if not png.exists():
                skipped += 1
                continue
            old = existing.get(slug)
            was_present = old is not None
            if was_present and not force:
                continue  # уже есть — пропускаем (force пере-зальёт)
            ok = False
            for attempt in (1, 2, 3):
                try:
                    if old is not None:
                        await old.delete()
                        old = None
                    emoji = await self.bot.create_application_emoji(name=slug, image=png.read_bytes())
                    existing[slug] = emoji
                    ok = True
                    break
                except Exception:
                    if attempt < 3:
                        await asyncio.sleep(3)  # переждать rate-limit
            if ok:
                if was_present:
                    replaced += 1
                else:
                    created += 1
            else:
                failed += 1
                fails.append(slug)
            await asyncio.sleep(0.35)  # щадящий темп против rate-limit

        n = apply_custom_emojis({e.name: f"<:{e.name}:{e.id}>" for e in existing.values()})
        desc = (f"Залито новых: **{created}**" + (f", пере-залито: **{replaced}**" if force else "")
                + f"\nПодхвачено в коде: **{n}** · всего эмодзи в приложении: **{len(existing)}**")
        if failed:
            desc += f"\n⚠️ не удалось: **{failed}** ({', '.join(fails[:10])}) — повторите `!reloadicons`."
        if skipped and not n:
            desc += "\n-# Часть PNG отсутствует — сгенерируйте `scripts/fetch_icons.py`."
        await progress.edit(embed=disnake.Embed(
            title="🎨 Иконки синхронизированы",
            description=desc, color=SUCCESS_COLOR if n and not failed else WARNING_COLOR))


def setup(bot: commands.Bot):
    bot.add_cog(ServerStatsCog(bot))
