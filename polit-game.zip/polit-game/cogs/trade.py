"""
🔁 Общий рынок — торговля ресурсами между всеми странами.

  !trade / !рынок / !market — открыть рынок (меню).

Модель — книга заявок:
  • SELL-заявка: страна выставляет ресурс на продажу (ресурс резервируется/списывается),
    любой покупает по цене заявки — деньги идут продавцу, ресурс покупателю.
  • BUY-заявка: страна хочет купить ресурс (деньги резервируются), любой продаёт в неё.
Исполнение частичное: крупную покупку добираем из нескольких дешёвых заявок.
Отмена заявки возвращает резерв (ресурс/деньги).

Доступ — зарегистрированные страны. Всё через меню и окна (модалки).
"""

import time
import logging

import disnake
from disnake.ext import commands

from utils import (Trade, Diplomacy, Settings, Countries, Market, Buildings, CURRENCY,
                   COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR)
from utils.resources import (ui_icon, res_icon, res_label, res_value, RESOURCES,
                             STORAGE_BASE, STORAGE_PER_WAREHOUSE)
from utils.ui import Panel, cid, parse_cid
from utils.helpers import get_object, get_object_by_user, int_format, string_to_number, update_money

log = logging.getLogger("trade")
ALL_RES = list(RESOURCES.keys())
LIQUIDITY = 50_000   # объём, заметно двигающий курс мировой биржи
SPREAD = 0.05        # спред биржи (продаёшь чуть дешевле, покупаешь чуть дороже)


def _ic(n): return ui_icon(n)


def _pe(name):
    ic = ui_icon(name)
    return ic if (ic and ic.startswith("<")) else None


class TradeCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.t = Trade()
        self.s = Settings()
        self.market = Market()
        self.buildings = Buildings()
        self._ps: dict[int, dict] = {}
        self._owner: dict[int, int] = {}

    # ── деньги / ресурсы ──
    @staticmethod
    def _money(name) -> int:
        o = get_object(name)
        return int(getattr(o, "money", 0) or 0) if o else 0

    @staticmethod
    def _add_money(name, delta):
        update_money(name, int(delta))   # безопасный хелпер (прибавляет дельту)

    # ── мировая биржа (торговля с системой по динамическому курсу) ──
    def _price(self, res) -> int:
        return max(1, int(res_value(res) * self.market.get_factor(res)))

    def _world_sell(self, name, res, amount):
        have = self._res(name, res)
        amount = min(amount, have)
        if amount <= 0:
            return 0, 0
        price = self._price(res)
        gross = int(amount * price * (1 - SPREAD))
        self._add_res(name, res, -amount)
        update_money(name, gross)
        self.market.set_factor(res, self.market.get_factor(res) * (1 - min(0.5, amount / LIQUIDITY)))
        return amount, gross

    def _storage_cap(self, name) -> int:
        return STORAGE_BASE + self.buildings.get_count(name, "warehouse") * STORAGE_PER_WAREHOUSE

    def _world_buy(self, name, res, amount):
        if amount <= 0:
            return 0, 0
        room = max(0, self._storage_cap(name) - self._res(name, res))   # лимит склада как в !exchange
        amount = min(amount, room)
        if amount <= 0:
            return 0, 0
        price = self._price(res)
        cost = int(amount * price * (1 + SPREAD))
        if self._money(name) < cost:
            affordable = self._money(name) // int(price * (1 + SPREAD)) if price > 0 else 0
            amount = affordable
            cost = int(amount * price * (1 + SPREAD))
        if amount <= 0:
            return 0, 0
        update_money(name, -cost)
        self._add_res(name, res, amount)
        self.market.set_factor(res, self.market.get_factor(res) * (1 + min(0.5, amount / LIQUIDITY)))
        return amount, cost

    def _res(self, name, r) -> int:
        return self.s.get_resources(name).get(r, 0)

    def _add_res(self, name, r, delta):
        self.s.add_resource(name, r, int(delta))

    # ── исполнение сделок ──
    def _do_buy(self, buyer, resource, qty):
        """Покупатель берёт qty ресурса, добирая из дешёвых SELL-заявок."""
        room = max(0, self._storage_cap(buyer) - self._res(buyer, resource))   # не выше лимита склада
        qty = min(qty, room)
        bought = spent = 0
        for of in self.t.offers_by_resource(resource, "sell"):
            if qty <= 0:
                break
            if of["country"] == buyer:
                continue
            take = min(qty, of["amount"])
            budget = self._money(buyer)
            if take * of["price"] > budget:
                take = budget // of["price"] if of["price"] > 0 else take
            if take <= 0:
                break
            cost = take * of["price"]
            self._add_money(buyer, -cost)
            self._add_money(of["country"], cost)
            self._add_res(buyer, resource, take)        # ресурс был зарезервирован в заявке
            self.t.reduce_offer(of["id"], take)
            Diplomacy().log_trade(buyer, of["country"], cost, int(time.time()))  # торговля сближает
            bought += take; spent += cost; qty -= take
        return bought, spent

    def _do_sell_into_buys(self, seller, resource, qty):
        """Продавец отдаёт qty ресурса в самые дорогие BUY-заявки."""
        sold = earned = 0
        for of in self.t.offers_by_resource(resource, "buy"):
            if qty <= 0:
                break
            if of["country"] == seller:
                continue
            have = self._res(seller, resource)
            take = min(qty, of["amount"], have)
            if take <= 0:
                break
            proceeds = take * of["price"]
            self._add_res(seller, resource, -take)
            self._add_money(seller, proceeds)           # деньги были зарезервированы в заявке
            self._add_res(of["country"], resource, take)
            self.t.reduce_offer(of["id"], take)
            Diplomacy().log_trade(seller, of["country"], proceeds, int(time.time()))
            sold += take; earned += proceeds; qty -= take
        return sold, earned

    # ═══════════ команда ═══════════
    @commands.command(name="trade", aliases=["рынок", "market", "торговля"])
    async def trade_cmd(self, ctx):
        if not ctx.guild or not get_object_by_user(ctx.author.id):
            await ctx.send(embed=disnake.Embed(
                description="Сначала зарегистрируйте страну, чтобы торговать.", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(view="hub", resource=None)
        msg = await ctx.send(components=self._panel(ctx.author.id).components)
        self._owner[msg.id] = ctx.author.id

    def _session(self, uid):
        return self._ps.setdefault(uid, {"view": "hub", "resource": None})

    # ═══════════ панель ═══════════
    def _res_options(self, resources, selected):
        return [disnake.SelectOption(label=res_label(r)[:100], value=r, emoji=_pe_res(r),
                                     default=(r == selected)) for r in resources[:25]]

    def _offer_book(self, resource, side, me_name) -> str:
        offers = self.t.offers_by_resource(resource, side)
        if not offers:
            return f"-# Заявок на {'продажу' if side == 'sell' else 'покупку'} пока нет."
        head = "ПРОДАЮТ (дешевле — выгоднее купить):" if side == "sell" else "ПОКУПАЮТ (дороже — выгоднее продать):"
        lines = [f"-# {head}"]
        for of in offers[:8]:
            mark = " ← ты" if of["country"] == me_name else ""
            lines.append(f"{res_icon(resource)} **{int_format(of['amount'])}** по **{int_format(of['price'])}** "
                         f"{CURRENCY}/ед · {of['country']}{mark}")
        return "\n".join(lines)

    def _panel(self, uid, note=None) -> Panel:
        s = self._session(uid)
        me = get_object_by_user(uid)
        me_name = me.name if me else "—"
        B = disnake.ButtonStyle
        items = [disnake.ui.TextDisplay(f"## {_ic('trade')} Общий рынок")]
        if note:
            items.append(disnake.ui.TextDisplay(note))

        if s["view"] == "buy":
            on_market = self.t.resources_on_market() or ALL_RES
            items.append(disnake.ui.TextDisplay(
                f"{_ic('buy')} **Покупка.** Твои деньги: **{int_format(self._money(me_name))}** {CURRENCY}\n"
                "-# Выбери ресурс — увидишь, кто продаёт. Купишь — добор из самых дешёвых заявок."))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("trade", "pickres", "buy"), placeholder="Что купить…",
                options=self._res_options(on_market, s["resource"]))))
            if s["resource"]:
                items.append(disnake.ui.TextDisplay(self._offer_book(s["resource"], "sell", me_name)))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.success, label="Купить", emoji=_pe("buy"),
                                  disabled=not s["resource"], custom_id=cid("trade", "buy")),
                disnake.ui.Button(style=B.secondary, label="Разместить заявку на покупку", emoji=_pe("deal"),
                                  disabled=not s["resource"], custom_id=cid("trade", "makebuy")),
                disnake.ui.Button(style=B.secondary, label="Назад", custom_id=cid("trade", "goto", "hub"))))

        elif s["view"] == "sell":
            mine = [r for r, a in self.s.get_resources(me_name).items() if a > 0] or ALL_RES
            items.append(disnake.ui.TextDisplay(
                f"{_ic('sell')} **Продажа.** Выбери свой ресурс — увидишь, кто хочет купить.\n"
                "-# Можешь выставить свою заявку на продажу или продать сразу по заявкам покупателей."))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("trade", "pickres", "sell"), placeholder="Что продать…",
                options=self._res_options(mine, s["resource"]))))
            if s["resource"]:
                have = self._res(me_name, s["resource"])
                items.append(disnake.ui.TextDisplay(
                    f"{res_icon(s['resource'])} У тебя **{int_format(have)}** {res_label(s['resource'])}.\n"
                    + self._offer_book(s["resource"], "buy", me_name)))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.success, label="Выставить на продажу", emoji=_pe("sell"),
                                  disabled=not s["resource"], custom_id=cid("trade", "makesell")),
                disnake.ui.Button(style=B.secondary, label="Продать по заявкам", emoji=_pe("deal"),
                                  disabled=not s["resource"], custom_id=cid("trade", "sellinto")),
                disnake.ui.Button(style=B.secondary, label="Назад", custom_id=cid("trade", "goto", "hub"))))

        elif s["view"] == "myoffers":
            offers = self.t.my_offers(me_name)
            if not offers:
                items.append(disnake.ui.TextDisplay(f"{_ic('market')} У тебя нет активных заявок."))
            else:
                lines = []
                for of in offers[:10]:
                    kind = "Продажа" if of["side"] == "sell" else "Покупка"
                    lines.append(f"`#{of['id']}` {kind}: {res_icon(of['resource'])} **{int_format(of['amount'])}** "
                                 f"{res_label(of['resource'])} по **{int_format(of['price'])}** {CURRENCY}/ед")
                items.append(disnake.ui.TextDisplay("\n".join(lines)))
                opts = [disnake.SelectOption(label=f"#{of['id']} {res_label(of['resource'])} ×{of['amount']}"[:100],
                                             value=str(of["id"])) for of in offers[:25]]
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("trade", "cancelpick"), placeholder="Отменить заявку (вернёт резерв)…",
                    options=opts)))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.secondary, label="Назад", custom_id=cid("trade", "goto", "hub"))))

        elif s["view"] == "world":
            items.append(disnake.ui.TextDisplay(
                f"{_ic('market')} **Мировая биржа** — торговля с системой по курсу.\n"
                f"Казна: **{int_format(self._money(me_name))}** {CURRENCY}\n"
                "-# Продаёшь — курс вниз, покупаешь — вверх. Моментально, но со спредом."))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("trade", "pickres", "world"), placeholder="Выбрать ресурс…",
                options=self._res_options(ALL_RES, s["resource"]))))
            if s["resource"]:
                price = self._price(s["resource"])
                items.append(disnake.ui.TextDisplay(
                    f"{res_icon(s['resource'])} **{res_label(s['resource'])}** · курс **{int_format(price)}** "
                    f"{CURRENCY}/ед · у тебя **{int_format(self._res(me_name, s['resource']))}**"))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.primary, label="Продать системе", emoji=_pe("sell"),
                                  disabled=not s["resource"], custom_id=cid("trade", "worldsell")),
                disnake.ui.Button(style=B.success, label="Купить у системы", emoji=_pe("buy"),
                                  disabled=not s["resource"], custom_id=cid("trade", "worldbuy")),
                disnake.ui.Button(style=B.secondary, label="Назад", custom_id=cid("trade", "goto", "hub"))))

        else:  # hub
            res_mkt = self.t.resources_on_market()
            mkt = (", ".join(f"{res_icon(r)} {res_label(r)}" for r in res_mkt[:12]) if res_mkt
                   else "пока пусто — выставь первым!")
            items.append(disnake.ui.TextDisplay(
                f"**Твоя страна:** {me_name} · казна **{int_format(self._money(me_name))}** {CURRENCY}\n"
                f"-# Заявки стран сейчас: {mkt}\n\n"
                f"{_ic('market')} **Мировая биржа** — быстро купить/продать системе по курсу.\n"
                f"{_ic('deal')} **Сделки между странами** — заявки: покупай у любого, продавай любому."))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.secondary, label="Мировая биржа", emoji=_pe("market"),
                                  custom_id=cid("trade", "goto", "world")),
                disnake.ui.Button(style=B.success, label="Купить у стран", emoji=_pe("buy"),
                                  custom_id=cid("trade", "goto", "buy")),
                disnake.ui.Button(style=B.primary, label="Продать странам", emoji=_pe("sell"),
                                  custom_id=cid("trade", "goto", "sell"))))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.secondary, label="Мои заявки", emoji=_pe("market"),
                                  custom_id=cid("trade", "goto", "myoffers"))))

        p = Panel()
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(0xE8C260)))
        return p

    # ═══════════ guard ═══════════
    async def _guard(self, inter) -> bool:
        if not get_object_by_user(inter.author.id):
            await inter.response.send_message("🔒 Сначала зарегистрируйте страну.", ephemeral=True)
            return False
        msg = getattr(inter, "message", None)
        owner = self._owner.get(msg.id) if msg else None
        if owner is not None and owner != inter.author.id:
            await inter.response.send_message("🔒 Это не твой рынок — открой свой `!trade`.", ephemeral=True)
            return False
        return True

    # ═══════════ обработчики ═══════════
    @commands.Cog.listener("on_dropdown")
    async def _tr_drop(self, inter):
        c = inter.component.custom_id or ""
        if not c.startswith("trade:"):
            return
        if not await self._guard(inter):
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        if action == "pickres":
            s["resource"] = inter.values[0] if inter.values else None
        elif action == "cancelpick":
            await self._cancel_offer(inter, int(inter.values[0]))
            return
        await inter.response.edit_message(components=self._panel(inter.author.id).components)

    @commands.Cog.listener("on_button_click")
    async def _tr_btn(self, inter):
        c = inter.component.custom_id or ""
        if not c.startswith("trade:"):
            return
        if not await self._guard(inter):
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        if action == "goto":
            s.update(view=args[0], resource=None)
            await inter.response.edit_message(components=self._panel(inter.author.id).components)
            return
        if action in ("buy", "sellinto", "worldsell", "worldbuy"):
            titles = {"buy": "Купить у стран", "sellinto": "Продать по заявкам",
                      "worldsell": "Продать системе", "worldbuy": "Купить у системы"}
            await inter.response.send_modal(disnake.ui.Modal(
                title=titles[action],
                custom_id=cid("trade", f"modal_{action}", s["resource"] or ""),
                components=[disnake.ui.TextInput(label="Сколько единиц", custom_id="qty",
                                                 style=disnake.TextInputStyle.short, max_length=15, required=True)]))
            return
        if action in ("makesell", "makebuy"):
            await inter.response.send_modal(disnake.ui.Modal(
                title=("Заявка на продажу" if action == "makesell" else "Заявка на покупку"),
                custom_id=cid("trade", f"modal_{action}", s["resource"] or ""),
                components=[
                    disnake.ui.TextInput(label="Количество (единиц)", custom_id="amount",
                                         style=disnake.TextInputStyle.short, max_length=15, required=True),
                    disnake.ui.TextInput(label=f"Цена за единицу ({CURRENCY})", custom_id="price",
                                         style=disnake.TextInputStyle.short, max_length=15, required=True)]))
            return

    @commands.Cog.listener("on_modal_submit")
    async def _tr_modal(self, inter):
        c = inter.custom_id or ""
        if not c.startswith("trade:"):
            return
        me = get_object_by_user(inter.author.id)
        if not me:
            return
        _, action, args = parse_cid(c)
        resource = args[0] if args else None
        note = "Готово."
        if not resource:
            note = "Не выбран ресурс."
        elif action == "modal_buy":
            qty = self._num(inter.text_values.get("qty"))
            bought, spent = self._do_buy(me.name, resource, qty)
            note = (f"{_ic('buy')} Куплено **{int_format(bought)}** {res_label(resource)} за "
                    f"**{int_format(spent)}** {CURRENCY}." if bought else
                    "Не удалось купить (нет заявок, не хватает денег или склад полон).")
        elif action == "modal_sellinto":
            qty = self._num(inter.text_values.get("qty"))
            sold, earned = self._do_sell_into_buys(me.name, resource, qty)
            note = (f"{_ic('sell')} Продано **{int_format(sold)}** {res_label(resource)} за "
                    f"**{int_format(earned)}** {CURRENCY}." if sold else
                    "Не удалось продать (нет заявок на покупку или нет ресурса).")
        elif action == "modal_worldsell":
            amt, gross = self._world_sell(me.name, resource, self._num(inter.text_values.get("qty")))
            note = (f"{_ic('market')} Продано системе **{int_format(amt)}** {res_label(resource)} → "
                    f"**+{int_format(gross)}** {CURRENCY} (курс вниз)." if amt else
                    "Нечего продавать.")
        elif action == "modal_worldbuy":
            amt, cost = self._world_buy(me.name, resource, self._num(inter.text_values.get("qty")))
            note = (f"{_ic('market')} Куплено у системы **{int_format(amt)}** {res_label(resource)} → "
                    f"**−{int_format(cost)}** {CURRENCY} (курс вверх)." if amt else
                    "Не удалось купить (склад полон или нет средств).")
        elif action == "modal_makesell":
            amt = self._num(inter.text_values.get("amount"))
            price = self._num(inter.text_values.get("price"))
            if amt <= 0 or price <= 0:
                note = "Количество и цена должны быть положительными."
            elif self._res(me.name, resource) < amt:
                note = f"У тебя только {int_format(self._res(me.name, resource))} {res_label(resource)}."
            else:
                self._add_res(me.name, resource, -amt)   # резервируем товар
                oid = self.t.create_offer("sell", me.name, resource, amt, price, int(time.time()))
                note = f"{_ic('sell')} Заявка #{oid}: продаю **{int_format(amt)}** {res_label(resource)} по {int_format(price)}."
        elif action == "modal_makebuy":
            amt = self._num(inter.text_values.get("amount"))
            price = self._num(inter.text_values.get("price"))
            total = amt * price
            if amt <= 0 or price <= 0:
                note = "Количество и цена должны быть положительными."
            elif self._money(me.name) < total:
                note = f"Нужно {int_format(total)} {CURRENCY}, у тебя {int_format(self._money(me.name))}."
            else:
                self._add_money(me.name, -total)          # резервируем деньги
                oid = self.t.create_offer("buy", me.name, resource, amt, price, int(time.time()))
                note = f"{_ic('buy')} Заявка #{oid}: куплю **{int_format(amt)}** {res_label(resource)} по {int_format(price)}."
        try:
            if inter.response.is_done():
                await inter.followup.send(note, ephemeral=True)
            else:
                await inter.response.edit_message(components=self._panel(inter.author.id, note).components)
        except Exception:
            log.exception("trade modal")

    async def _cancel_offer(self, inter, offer_id):
        me = get_object_by_user(inter.author.id)
        of = self.t.get_offer(offer_id)
        if not me or not of or of["country"] != me.name:
            await inter.response.edit_message(components=self._panel(inter.author.id, "Это не твоя заявка.").components)
            return
        # возврат резерва
        if of["side"] == "sell":
            self._add_res(me.name, of["resource"], of["amount"])
            back = f"возвращено {int_format(of['amount'])} {res_label(of['resource'])}"
        else:
            self._add_money(me.name, of["amount"] * of["price"])
            back = f"возвращено {int_format(of['amount'] * of['price'])} {CURRENCY}"
        self.t.remove_offer(offer_id)
        await inter.response.edit_message(
            components=self._panel(inter.author.id, f"{_ic('cancel_x')} Заявка #{offer_id} отменена — {back}.").components)

    @staticmethod
    def _num(v) -> int:
        try:
            return max(0, int(string_to_number(v or "0")))
        except Exception:
            return 0


def _pe_res(r):
    ic = res_icon(r)
    return ic if (ic and ic.startswith("<")) else None


def setup(bot: commands.Bot):
    bot.add_cog(TradeCog(bot))
