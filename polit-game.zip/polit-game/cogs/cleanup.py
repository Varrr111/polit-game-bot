"""
🧹 Разовая зачистка массовых твинков (кик по дате входа) — с ЖЁСТКИМИ
гарантиями безопасности. Главное правило: бустеров НИКОГДА не трогаем.

  !cleanjoins                      — ПРЕДПРОСМОТР (ничего не кикает!): покажет,
                                     кого кикнет, сколько оставит, и ГАРАНТИЮ
                                     «бустеров в списке на кик = 0».
  !cleanjoins confirm              — выполнить кик (оставить 100, дата 12 окт).
  !cleanjoins confirm 100          — оставить 100.
  !cleanjoins confirm 100 2026-10-12  — явно задать дату (ISO, по МСК).

Защищены (НИКОГДА не кикаются): бустеры сервера, боты, владелец, и любой,
у кого есть права admin/kick/ban/manage_guild (штаб). Команда — ТОЛЬКО владелец.
"""

import asyncio
import datetime
import logging

import disnake
from disnake.ext import commands

from utils import SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, COMMAND_COLOR, Countries

log = logging.getLogger("cleanup")

MSK = datetime.timezone(datetime.timedelta(hours=3))
KICK_REASON = "Зачистка массовых твинков (массовый вход)"


class CleanupCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── безопасность ──────────────────────────────────────────────────────
    @staticmethod
    def _registered_ids() -> set[int]:
        """ID всех, кто зарегистрирован в игре (имеет страну) — это живые игроки."""
        ids: set[int] = set()
        try:
            for r in Countries()._query_all("SELECT user FROM countries"):
                try:
                    ids.add(int(r["user"]))
                except (TypeError, ValueError, KeyError):
                    pass
        except Exception:
            log.exception("Не удалось получить список зарегистрированных игроков")
        return ids

    @staticmethod
    def _is_protected(m: disnake.Member, guild: disnake.Guild, registered: set[int]) -> bool:
        """True = трогать НЕЛЬЗЯ ни при каких условиях."""
        if m.bot:
            return True
        if m.id == guild.owner_id:
            return True
        # БУСТЕР — главная защита. premium_since != None означает активный буст.
        if m.premium_since is not None:
            return True
        # зарегистрирован в игре (есть страна) — живой игрок
        if m.id in registered:
            return True
        # штаб / любой с опасными правами
        p = m.guild_permissions
        if p.administrator or p.kick_members or p.ban_members or p.manage_guild:
            return True
        return False

    @staticmethod
    def _target_date(date_arg: str) -> datetime.date:
        if date_arg:
            return datetime.date.fromisoformat(date_arg)
        now = datetime.datetime.now(MSK)
        return datetime.date(now.year, 10, 12)  # 12 октября текущего года

    def _cohort(self, guild: disnake.Guild, day: datetime.date, registered: set[int]):
        """Возвращает (кандидаты_на_кик, сколько_бустеров_в_этот_день,
        сколько_защищённых_в_этот_день, всего_в_этот_день)."""
        kickable: list[disnake.Member] = []
        boosters = protected = total = 0
        for m in guild.members:
            if not m.joined_at:
                continue
            if m.joined_at.astimezone(MSK).date() != day:
                continue
            total += 1
            if m.premium_since is not None:
                boosters += 1
            if self._is_protected(m, guild, registered):
                protected += 1
                continue
            kickable.append(m)
        kickable.sort(key=lambda x: x.joined_at)  # оставим самых ранних
        return kickable, boosters, protected, total

    # ── команда ───────────────────────────────────────────────────────────
    @commands.command(name="cleanjoins", aliases=["зачистка-входов", "чистка-твинков", "kickjoins"])
    async def cleanjoins_cmd(self, ctx: commands.Context, action: str = "",
                             keep: int = 100, date_arg: str = ""):
        # ТОЛЬКО владелец сервера — ставки высокие.
        if not ctx.guild or ctx.author.id != ctx.guild.owner_id:
            await ctx.send(embed=disnake.Embed(
                description="Эту команду может выполнять **только владелец сервера**.",
                color=ERROR_COLOR))
            return

        try:
            day = self._target_date(date_arg)
        except ValueError:
            await ctx.send(embed=disnake.Embed(
                description="Неверная дата. Формат: `ГГГГ-ММ-ДД`, напр. `2026-10-12`.",
                color=ERROR_COLOR))
            return
        if keep < 0:
            keep = 0

        # Грузим ВСЕХ участников, чтобы расчёт был точным (не по кэшу).
        loading = await ctx.send(embed=disnake.Embed(
            description="⏳ Загружаю список всех участников для точного расчёта…",
            color=COMMAND_COLOR))
        try:
            await ctx.guild.chunk()
        except Exception:
            log.exception("chunk() не удался — считаю по текущему кэшу")

        registered = self._registered_ids()
        kickable, boosters, protected, total = self._cohort(ctx.guild, day, registered)
        to_keep = kickable[:keep]
        to_kick = kickable[keep:]

        # защитная перепроверка: среди to_kick бустеров быть НЕ должно
        boosters_in_kick = sum(1 for m in to_kick if m.premium_since is not None)

        confirmed = action.lower() in ("confirm", "да", "yes", "подтвердить")

        # ── ПРЕДПРОСМОТР ──
        if not confirmed:
            desc = (
                f"**Дата входа (по МСК):** {day.isoformat()}\n"
                f"**Всего зашло в этот день:** {total}\n\n"
                f"🛡️ **Бустеров в этот день (под защитой, НЕ трогаем):** {boosters}\n"
                f"🛡️ **Прочих под защитой (игроки с регой/штаб/боты):** {protected - boosters}\n\n"
                f"**Кандидатов на кик:** {len(kickable)}\n"
                f"**Оставим (самых ранних):** {len(to_keep)}\n"
                f"**КИКНЕМ:** {len(to_kick)}\n\n"
                f"✅ **Бустеров в списке на кик:** {boosters_in_kick}  "
                f"{'(гарантия — ноль)' if boosters_in_kick == 0 else '⚠️ ОСТАНОВКА!'}\n\n"
                f"-# Проверь числа. Если верно — выполни:\n"
                f"**`!cleanjoins confirm {keep}"
                f"{(' ' + day.isoformat()) if date_arg else ''}`**"
            )
            await loading.edit(embed=disnake.Embed(
                title="🧹 Предпросмотр зачистки (ничего не кикнуто)",
                description=desc,
                color=WARNING_COLOR if to_kick else COMMAND_COLOR))
            return

        # ── ВЫПОЛНЕНИЕ ──
        if boosters_in_kick > 0:
            # теоретически невозможно, но на всякий случай — полный стоп
            await loading.edit(embed=disnake.Embed(
                title="⛔ ОСТАНОВЛЕНО",
                description=f"В списке на кик обнаружены бустеры ({boosters_in_kick}). "
                            "Кик отменён. Ничего не тронуто.", color=ERROR_COLOR))
            return
        if not to_kick:
            await loading.edit(embed=disnake.Embed(
                title="Некого кикать",
                description=f"Кандидатов на кик: {len(kickable)}, оставляем {keep}. Кикать нечего.",
                color=COMMAND_COLOR))
            return

        kicked = failed = skipped = 0
        total_kick = len(to_kick)
        await loading.edit(embed=disnake.Embed(
            title="🧹 Зачистка пошла…",
            description=f"Кикаю **{total_kick}** участников. Бустеры/игроки/штаб/боты защищены.\n"
                        f"Это займёт ~{int(total_kick * 0.4 / 60) + 1} мин.",
            color=WARNING_COLOR))

        for i, m in enumerate(to_kick, 1):
            # ФИНАЛЬНАЯ перепроверка прямо перед киком — пояс и подтяжки.
            if self._is_protected(m, ctx.guild, registered) or m.premium_since is not None:
                skipped += 1
                continue
            try:
                await m.kick(reason=KICK_REASON)
                kicked += 1
            except disnake.Forbidden:
                failed += 1  # роль выше бота / нет прав
            except disnake.HTTPException:
                failed += 1
            if i % 25 == 0:
                try:
                    await loading.edit(embed=disnake.Embed(
                        title="🧹 Зачистка идёт…",
                        description=f"Кикнуто **{kicked}** / {total_kick}  ·  "
                                    f"ошибок {failed}  ·  пропущено (защита) {skipped}",
                        color=WARNING_COLOR))
                except Exception:
                    pass
            await asyncio.sleep(0.4)  # быстрый темп; disnake сам ждёт при рейт-лимите

        await loading.edit(embed=disnake.Embed(
            title="✅ Зачистка завершена",
            description=(f"**Кикнуто:** {kicked}\n"
                         f"**Оставлено (не трогали):** {len(to_keep)}\n"
                         f"🛡️ **Бустеров защищено:** {boosters}\n"
                         f"**Пропущено защитой при кике:** {skipped}\n"
                         f"**Ошибок (роль выше бота/нет прав):** {failed}"),
            color=SUCCESS_COLOR))


def setup(bot: commands.Bot):
    bot.add_cog(CleanupCog(bot))
