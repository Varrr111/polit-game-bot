"""
Военная техника: именная техника стран, заводы, лицензии, производство из ресурсов.

Без кураторов — всё автоматически и без эксплойтов: название косметическое, а
ТИП/КЛАСС берутся из фиксированных списков (рецепт/цена/время — utils/equipment.py).
Производство требует ЗАВОДА нужного рода войск, стоит ресурсы+деньги и занимает
ВРЕМЯ (очередь). Больше заводов рода → быстрее.

  !equip / !техника        — хаб (образцы, заводы, производство, лицензии, арсенал)
  !arsenal / !арсенал      — склад техники страны
  !equip-remove <название> — АДМИН: снести образец

Регистрация: кнопка → род войск → тип → класс → модалка с названием.
Маршрутизация по custom_id "eq:".
"""

import time

import disnake
from disnake.ext import commands, tasks

from utils import (
    Equipment, Settings, Pmc, get_object, get_object_by_user, update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY,
    ADMINISTRATOR, MAIN_ECO_CURATOR, PROFILE_ROLE,
)
from utils.ui import Panel, cid, parse_cid
from utils.serverconfig import rid
from utils.perms import is_staff, has_command_access
from utils.resources import res_icon, res_label, ui_icon, action_icon
import utils.equipment as E

MAX_PRODUCE = 1000  # потолок партии за раз


def _emoji(s: str):
    try:
        return disnake.PartialEmoji.from_str(s)
    except Exception:
        return None


def dom_icon(domain: str) -> str:
    return ui_icon(E.plant_icon_slug(domain))


def _recipe_line(category: str, cls: str) -> str:
    rec = E.recipe_for(category, cls)
    parts = [f"{res_icon(r)} {int_format(q)}" for r, q in rec.items()]
    return "  ".join(parts) + f"  ·  **{int_format(E.price_for(category, cls))} {CURRENCY}**"


def _recipe_plain(category: str, cls: str) -> str:
    rec = E.recipe_for(category, cls)
    parts = [f"{q}×{res_label(r)}" for r, q in rec.items()]
    return (" + ".join(parts) + f" · {int_format(E.price_for(category, cls))} {CURRENCY}")[:100]


def _dur(sec: int) -> str:
    sec = int(sec)
    if sec < 3600:
        return f"{sec // 60} мин"
    h, m = sec // 3600, (sec % 3600) // 60
    return f"{h} ч {m} мин" if m else f"{h} ч"


# ─────────────────────────── ПАНЕЛИ ───────────────────────────
class EquipHub(Panel):
    def __init__(self, obj, owned, producible, plants: dict, queue):
        super().__init__(timeout=300)
        oid = obj.user
        plines = "  ".join(f"{dom_icon(d)} {E.domain_of_label(d)} `×{plants.get(d, 0)}`" for d in E.EQUIP_DOMAINS)
        header = (f"-# {getattr(obj, 'flag', '')} {obj.name}\n"
                  f"## {ui_icon('land')} Военная техника\n"
                  f"-# образцов **{len(owned)}/{E.MAX_EQUIPMENT_PER_COUNTRY}** · заводы: {plines}")
        items: list = [disnake.ui.TextDisplay(header), disnake.ui.Separator()]

        if owned:
            lines = [f"{E.cat_icon(r['category'])} **{r['name']}** · {E.cat_label(r['category'])} · {E.class_label(r['cls'])}"
                     for r in owned]
            items.append(disnake.ui.TextDisplay("-# ВАШИ ОБРАЗЦЫ\n" + "\n".join(lines)))
        else:
            items.append(disnake.ui.TextDisplay("-# Образцов ещё нет — зарегистрируйте первый."))

        licensed = [r for r in producible if r["owner"] != obj.name]
        if licensed:
            lines = [f"{E.cat_icon(r['category'])} **{r['name']}** · лицензия от {r['owner']}" for r in licensed]
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay("-# ПО ЛИЦЕНЗИИ\n" + "\n".join(lines)))

        if queue:
            lines = [f"{E.cat_icon(q['category'])} **{q['name']}** `×{int_format(q['count'])}` · готово <t:{q['ready_at']}:R>"
                     for q in queue]
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(f"-# 🏭 В ПРОИЗВОДСТВЕ\n" + "\n".join(lines)))

        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(label="Зарегистрировать", emoji=_emoji(ui_icon("register")), style=disnake.ButtonStyle.success,
                              custom_id=cid("eq", "reg", oid)),
            disnake.ui.Button(label="Заводы", emoji=_emoji(ui_icon("plant")), style=disnake.ButtonStyle.primary,
                              custom_id=cid("eq", "plants", oid)),
            disnake.ui.Button(label="Произвести", emoji=_emoji(action_icon("build")), style=disnake.ButtonStyle.primary,
                              custom_id=cid("eq", "prod", oid)),
            disnake.ui.Button(label="Лицензии", emoji=_emoji(ui_icon("license")), style=disnake.ButtonStyle.secondary,
                              custom_id=cid("eq", "lic", oid)),
            disnake.ui.Button(label="Арсенал", emoji=_emoji(ui_icon("storage")), style=disnake.ButtonStyle.secondary,
                              custom_id=cid("eq", "ars", oid)),
        ))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


def _domain_panel(oid: int) -> Panel:
    opts = [disnake.SelectOption(label=E.domain_of_label(d), value=d, emoji=_emoji(dom_icon(d)),
                                 description=f"{len(E.categories_in(d))} типов техники")
            for d in E.EQUIP_DOMAINS]
    p = Panel(timeout=300)
    p.add_item(disnake.ui.Container(
        disnake.ui.TextDisplay("## ➕ Регистрация техники\n-# Шаг 1 · род войск"),
        disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("eq", "regdom", oid), placeholder="Род войск", options=opts)),
        accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


def _category_panel(oid: int, domain: str) -> Panel:
    opts = [disnake.SelectOption(label=E.cat_label(k), value=k, emoji=_emoji(E.cat_icon(k)),
                                 description=_recipe_plain(k, "medium"))
            for k in E.categories_in(domain)[:25]]
    p = Panel(timeout=300)
    p.add_item(disnake.ui.Container(
        disnake.ui.TextDisplay(f"## ➕ {dom_icon(domain)} {E.domain_of_label(domain)}\n-# Шаг 2 · тип техники"),
        disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("eq", "regcat", oid, domain), placeholder="Тип техники", options=opts)),
        accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


def _class_panel(oid: int, category: str) -> Panel:
    opts = [disnake.SelectOption(label=f"{lbl} (×{mult})", value=key, description=_recipe_plain(category, key))
            for key, (lbl, mult) in E.EQUIP_CLASSES.items()]
    p = Panel(timeout=300)
    p.add_item(disnake.ui.Container(
        disnake.ui.TextDisplay(f"## ➕ {E.cat_icon(category)} {E.cat_label(category)}\n"
                               "-# Шаг 3 · класс → откроется форма названия"),
        disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("eq", "regcls", oid, category), placeholder="Класс", options=opts)),
        accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


# ─────────────────────────── МОДАЛКИ ───────────────────────────
class NameModal(disnake.ui.Modal):
    def __init__(self, cog, category: str, cls: str):
        self.cog, self.category, self.cls = cog, category, cls
        super().__init__(
            title="Регистрация техники", custom_id=cid("eq", "namemodal", category, cls),
            components=[disnake.ui.TextInput(
                label=f"Название ({E.cat_label(category)}, {E.class_label(cls)})", custom_id="name",
                style=disnake.TextInputStyle.short, min_length=E.NAME_MIN, max_length=E.NAME_MAX,
                placeholder="например: Leopard 2")])

    async def callback(self, inter: disnake.ModalInteraction):
        await self.cog.finish_register(inter, self.category, self.cls, inter.text_values["name"])


class CountModal(disnake.ui.Modal):
    def __init__(self, cog, equipment_id: int, name: str):
        self.cog, self.equipment_id = cog, equipment_id
        super().__init__(
            title=f"Производство · {name[:30]}", custom_id=cid("eq", "countmodal", equipment_id),
            components=[disnake.ui.TextInput(label="Количество", custom_id="count",
                                             style=disnake.TextInputStyle.short, max_length=6)])

    async def callback(self, inter: disnake.ModalInteraction):
        await self.cog.finish_produce(inter, self.equipment_id, inter.text_values["count"])


class OfferModal(disnake.ui.Modal):
    def __init__(self, cog, equipment_id: int, name: str):
        self.cog, self.equipment_id = cog, equipment_id
        super().__init__(
            title=f"Продажа лицензии · {name[:24]}", custom_id=cid("eq", "offermodal", equipment_id),
            components=[
                disnake.ui.TextInput(label="Кому (название страны)", custom_id="buyer",
                                     style=disnake.TextInputStyle.short, max_length=40),
                disnake.ui.TextInput(label="Цена лицензии ($)", custom_id="price",
                                     style=disnake.TextInputStyle.short, max_length=15)])

    async def callback(self, inter: disnake.ModalInteraction):
        await self.cog.finish_offer(inter, self.equipment_id, inter.text_values["buyer"], inter.text_values["price"])


# ─────────────────────────── КОГ ───────────────────────────
class EquipmentCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.equip = Equipment()
        self.settings = Settings()
        self.complete_production.start()

    def cog_unload(self):
        self.complete_production.cancel()

    async def cog_check(self, ctx: commands.Context) -> bool:
        if not ctx.guild:
            return False
        if is_staff(ctx.author):
            return True
        if MAIN_ECO_CURATOR and ctx.guild.get_role(MAIN_ECO_CURATOR) in ctx.author.roles:
            return True
        if ctx.author.get_role(rid("PROFILE_ROLE", PROFILE_ROLE)):
            return True
        if get_object_by_user(ctx.author.id):
            return True
        await ctx.send(embed=disnake.Embed(description="Вы не зарегистрированы — откройте панель регистрации.", color=ERROR_COLOR))
        return False

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CheckFailure):
            return
        raise error

    # ───── фоновое завершение производства ─────
    @tasks.loop(minutes=1)
    async def complete_production(self):
        try:
            now = int(time.time())
            for q in self.equip.queue_ready(now):
                self.equip.add_stock(q["country"], q["equipment_id"], q["count"])
                self.equip.queue_remove(q["id"])
        except Exception:
            import traceback
            traceback.print_exc()

    @complete_production.before_loop
    async def _before_complete(self):
        await self.bot.wait_until_ready()

    def _hub(self, obj) -> EquipHub:
        return EquipHub(obj, self.equip.by_owner(obj.name), self.equip.producible(obj.name),
                        self.equip.get_plants(obj.name), self.equip.queue_for(obj.name))

    # ───── команды ─────
    @commands.command(name="equip", aliases=["техника", "врт"])
    async def equip_cmd(self, ctx):
        obj = get_object_by_user(ctx.author.id)
        if not obj:
            await ctx.send(embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR))
            return
        await ctx.send(components=self._hub(obj).components)

    @commands.command(name="arsenal", aliases=["арсенал", "склад-техники"])
    async def arsenal_cmd(self, ctx):
        obj = get_object_by_user(ctx.author.id)
        pmc_cog = self.bot.get_cog("PmcCog")
        pm = Pmc().by_user(ctx.author.id) if not obj and pmc_cog else None
        if pm:   # ЧВК: арсенал именных моделей стран
            await ctx.send(components=pmc_cog.arsenal_panel(pm["name"]).components)
            return
        if not obj:
            await ctx.send(embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR))
            return
        await ctx.send(embed=self._arsenal_embed(obj))

    @commands.command(name="equip-remove", aliases=["техника-снести", "equipremove"])
    async def equip_remove_cmd(self, ctx, *, name: str | None = None):
        if not has_command_access(ctx.author, "equip-remove"):
            await ctx.send(embed=disnake.Embed(description="Нет доступа к этой команде (`!perm`).", color=ERROR_COLOR))
            return
        if not name:
            await ctx.send(embed=disnake.Embed(description="`!equip-remove <название>`", color=ERROR_COLOR))
            return
        row = self.equip.get_by_name(name.strip())
        if not row:
            await ctx.send(embed=disnake.Embed(description=f"Образец «{name}» не найден.", color=ERROR_COLOR))
            return
        self.equip.remove(row["id"])
        await ctx.send(embed=disnake.Embed(
            description=f"🗑️ **{row['name']}** ({row['owner']}) удалён вместе с лицензиями, складом и очередью.",
            color=SUCCESS_COLOR))

    def _arsenal_embed(self, obj) -> disnake.Embed:
        stock = self.equip.arsenal(obj.name)
        if not stock:
            return disnake.Embed(title=f"📦 Арсенал {obj.name}",
                                 description="Техники нет. Произведите через `!equip`.", color=WARNING_COLOR)
        by_dom: dict[str, list] = {}
        for r in stock:
            by_dom.setdefault(E.cat_domain(r["category"]), []).append(r)
        emb = disnake.Embed(title=f"📦 Арсенал {obj.name}", color=COMMAND_COLOR)
        for d in E.EQUIP_DOMAINS:
            rows = by_dom.get(d)
            if not rows:
                continue
            val = "\n".join(f"{E.cat_icon(r['category'])} **{r['name']}** ({E.class_label(r['cls'])}) — `×{int_format(r['count'])}`"
                            for r in rows)
            emb.add_field(name=f"{E.domain_of_label(d)}", value=val, inline=False)
        return emb

    def _types_embed(self) -> disnake.Embed:
        emb = disnake.Embed(title="📘 Каталог техники (средний класс)",
                            description="-# класс множит рецепт/цену/время: "
                            + " · ".join(f"{lbl} ×{m}" for lbl, m in E.EQUIP_CLASSES.values()),
                            color=COMMAND_COLOR)
        for d, (plabel, slug, cost, prec) in E.EQUIP_DOMAINS.items():
            lines = [f"{E.cat_icon(k)} **{E.cat_label(k)}** — {_recipe_line(k, 'medium')} · ⏱ {_dur(E._cat(k)[5])}"
                     for k in E.categories_in(d)]
            emb.add_field(name=f"{E.domain_of_label(d)} · завод {int_format(cost)} {CURRENCY}",
                          value="\n".join(lines)[:1024], inline=False)
        return emb

    # ───── заводы ─────
    def _plants_panel(self, obj) -> Panel:
        plants = self.equip.get_plants(obj.name)
        items: list = [disnake.ui.TextDisplay(f"## {ui_icon('plant')} Военные заводы\n"
                                              "-# нужен завод рода войск, чтобы производить его технику")]
        for d, (plabel, slug, cost, prec) in E.EQUIP_DOMAINS.items():
            rec = "  ".join(f"{res_icon(r)} {int_format(q)}" for r, q in prec.items())
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"{dom_icon(d)} **{plabel}** · {E.domain_of_label(d)} `×{plants.get(d, 0)}`\n"
                f"-# цена: {rec}  ·  **{int_format(cost)} {CURRENCY}**"))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(*[
            disnake.ui.Button(label=E.domain_of_label(d), emoji=_emoji(dom_icon(d)), style=disnake.ButtonStyle.success,
                              custom_id=cid("eq", "plantbuild", obj.user, d))
            for d in E.EQUIP_DOMAINS]))
        p = Panel(timeout=300)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    async def _do_plant_build(self, inter, obj, domain: str):
        cost = E.plant_cost(domain)
        recipe = E.plant_recipe(domain)
        have = self.settings.get_resources(obj.name)
        fresh = get_object(obj.name)
        missing = [f"{res_icon(r)} {res_label(r)} — нужно {int_format(q)}, есть {int_format(have.get(r, 0))}"
                   for r, q in recipe.items() if have.get(r, 0) < q]
        if (fresh.money if fresh else 0) < cost:
            missing.append(f"💰 деньги — нужно {int_format(cost)} {CURRENCY}")
        if missing:
            await inter.response.send_message(embed=disnake.Embed(
                title="Недостаточно на завод", description="\n".join(missing), color=ERROR_COLOR), ephemeral=True)
            return
        for r, q in recipe.items():
            self.settings.add_resource(obj.name, r, -q)
        update_money(obj.name, -cost)
        self.equip.add_plant(obj.name, domain, 1)
        await inter.response.send_message(embed=disnake.Embed(
            title="🏭 Завод построен",
            description=f"**{E.plant_label(domain)}** (всего ×{self.equip.plant_count(obj.name, domain)})\n"
                        f"-# −{int_format(cost)} {CURRENCY} · теперь можно производить {E.domain_of_label(domain).lower()}",
            color=SUCCESS_COLOR), ephemeral=True)

    # ───── регистрация / производство / лицензии ─────
    async def finish_register(self, inter, category: str, cls: str, name_raw: str):
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        if self.equip.count_owned(obj.name) >= E.MAX_EQUIPMENT_PER_COUNTRY:
            await inter.response.send_message(embed=disnake.Embed(
                description=f"Лимит образцов ({E.MAX_EQUIPMENT_PER_COUNTRY}).", color=ERROR_COLOR), ephemeral=True)
            return
        ok, res = E.valid_name(name_raw)
        if not ok:
            await inter.response.send_message(embed=disnake.Embed(description=res, color=ERROR_COLOR), ephemeral=True)
            return
        if self.equip.name_taken(res):
            await inter.response.send_message(embed=disnake.Embed(
                description=f"Название «{res}» уже занято.", color=ERROR_COLOR), ephemeral=True)
            return
        if E.REGISTER_FEE:
            if (get_object(obj.name).money if get_object(obj.name) else 0) < E.REGISTER_FEE:
                await inter.response.send_message(embed=disnake.Embed(
                    description=f"Нужно {int_format(E.REGISTER_FEE)} {CURRENCY}.", color=ERROR_COLOR), ephemeral=True)
                return
            update_money(obj.name, -E.REGISTER_FEE)
        eid = self.equip.register(res, category, cls, obj.name, int(time.time()))
        if not eid:
            await inter.response.send_message(embed=disnake.Embed(description="Имя занято.", color=ERROR_COLOR), ephemeral=True)
            return
        await inter.response.send_message(embed=disnake.Embed(
            title="✅ Образец зарегистрирован",
            description=(f"{E.cat_icon(category)} **{res}**\n-# {E.cat_label(category)} · {E.class_label(cls)}\n"
                         f"Рецепт/шт: {_recipe_line(category, cls)}\n"
                         f"-# нужен **{E.plant_label(E.cat_domain(category))}** · производство: `!equip`"),
            color=SUCCESS_COLOR), ephemeral=True)

    async def finish_produce(self, inter, equipment_id: int, count_raw: str):
        obj = get_object_by_user(inter.author.id)
        row = self.equip.get(equipment_id)
        if not obj or not row:
            await inter.response.send_message("Образец не найден.", ephemeral=True)
            return
        if not self.equip.has_license(equipment_id, obj.name):
            await inter.response.send_message(embed=disnake.Embed(
                description=f"Нет лицензии на **{row['name']}**.", color=ERROR_COLOR), ephemeral=True)
            return
        un = self.bot.get_cog("UNCog")
        if un and un.embargoed(obj.name):
            await inter.response.send_message(embed=disnake.Embed(
                description=f"{ui_icon('un_embargo')} Действует оружейное эмбарго ООН — производство техники запрещено.",
                color=ERROR_COLOR), ephemeral=True)
            return
        domain = E.cat_domain(row["category"])
        plants = self.equip.plant_count(obj.name, domain)
        if plants < 1:
            await inter.response.send_message(embed=disnake.Embed(
                description=f"Нужен **{E.plant_label(domain)}** ({E.domain_of_label(domain)}). Постройте в `!equip` → Заводы.",
                color=ERROR_COLOR), ephemeral=True)
            return
        try:
            count = int(str(count_raw).strip())
        except ValueError:
            count = 0
        if count < 1:
            await inter.response.send_message(embed=disnake.Embed(description="Количество ≥ 1.", color=ERROR_COLOR), ephemeral=True)
            return
        count = min(count, MAX_PRODUCE)

        recipe = E.recipe_for(row["category"], row["cls"])
        price = E.price_for(row["category"], row["cls"])
        total_cost = price * count
        have = self.settings.get_resources(obj.name)
        fresh = get_object(obj.name)
        missing = [f"{res_icon(r)} {res_label(r)} — нужно {int_format(q * count)}, есть {int_format(have.get(r, 0))}"
                   for r, q in recipe.items() if have.get(r, 0) < q * count]
        if (fresh.money if fresh else 0) < total_cost:
            missing.append(f"💰 деньги — нужно {int_format(total_cost)} {CURRENCY}, есть {int_format(fresh.money if fresh else 0)}")
        if missing:
            await inter.response.send_message(embed=disnake.Embed(
                title="Недостаточно для производства", description="\n".join(missing), color=ERROR_COLOR), ephemeral=True)
            return

        for r, q in recipe.items():
            self.settings.add_resource(obj.name, r, -q * count)
        update_money(obj.name, -total_cost)
        now = int(time.time())
        secs = E.time_for(row["category"], row["cls"], count, plants)
        ready_at = now + secs
        self.equip.queue_add(obj.name, equipment_id, count, now, ready_at)

        spent = "  ".join(f"{res_icon(r)} −{int_format(q * count)}" for r, q in recipe.items())
        await inter.response.send_message(embed=disnake.Embed(
            title="🏭 Производство запущено",
            description=(f"{E.cat_icon(row['category'])} **{row['name']}** `×{int_format(count)}`\n"
                         f"-# списано: {spent}  ·  −{int_format(total_cost)} {CURRENCY}\n"
                         f"-# заводов рода: {plants} · время {_dur(secs)} · готово <t:{ready_at}:R>"),
            color=SUCCESS_COLOR), ephemeral=True)

    async def finish_offer(self, inter, equipment_id: int, buyer_raw: str, price_raw: str):
        obj = get_object_by_user(inter.author.id)
        row = self.equip.get(equipment_id)
        if not obj or not row or row["owner"] != obj.name:
            await inter.response.send_message("Это не ваш образец.", ephemeral=True)
            return
        buyer = get_object(buyer_raw.strip())
        if not buyer:
            await inter.response.send_message(embed=disnake.Embed(
                description=f"Страна «{buyer_raw}» не найдена.", color=ERROR_COLOR), ephemeral=True)
            return
        if buyer.name == obj.name:
            await inter.response.send_message(embed=disnake.Embed(
                description="Нельзя продать самому себе.", color=ERROR_COLOR), ephemeral=True)
            return
        if self.equip.has_license(equipment_id, buyer.name):
            await inter.response.send_message(embed=disnake.Embed(
                description=f"У **{buyer.name}** уже есть лицензия.", color=WARNING_COLOR), ephemeral=True)
            return
        try:
            price = max(0, int(str(price_raw).strip().replace(" ", "")))
        except ValueError:
            await inter.response.send_message(embed=disnake.Embed(description="Цена — число.", color=ERROR_COLOR), ephemeral=True)
            return
        self.equip.add_offer(equipment_id, buyer.name, price, int(time.time()))
        await inter.response.send_message(embed=disnake.Embed(
            title="📜 Оффер отправлен",
            description=f"**{row['name']}** → **{buyer.name}** за **{int_format(price)} {CURRENCY}**\n"
                        f"-# покупатель примет в `!equip` → Лицензии",
            color=SUCCESS_COLOR), ephemeral=True)

    def _produce_panel(self, obj) -> Panel:
        producible = self.equip.producible(obj.name)
        p = Panel(timeout=300)
        if not producible:
            p.add_item(disnake.ui.Container(
                disnake.ui.TextDisplay("## 🏭 Производство\n-# Нет образцов — зарегистрируйте или купите лицензию."),
                accent_colour=disnake.Colour(WARNING_COLOR)))
            return p
        opts = [disnake.SelectOption(label=f"{r['name']} · {E.cat_label(r['category'])}"[:100], value=str(r["id"]),
                                     emoji=_emoji(E.cat_icon(r["category"])),
                                     description=_recipe_plain(r["category"], r["cls"])) for r in producible[:25]]
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(f"## {action_icon('build')} Производство\n"
                                   "-# выберите образец → количество (нужен завод рода войск)"),
            disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("eq", "prodsel", obj.user), placeholder="Что производить", options=opts)),
            accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    def _license_panel(self, obj) -> Panel:
        owned = self.equip.by_owner(obj.name)
        offers = self.equip.offers_for(obj.name)
        items: list = [disnake.ui.TextDisplay(f"## {ui_icon('license')} Лицензии")]
        if offers:
            lines = [f"{E.cat_icon(o['category'])} **{o['name']}** от {o['owner']} — **{int_format(o['price'])} {CURRENCY}**"
                     for o in offers]
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay("-# ПРЕДЛОЖЕНИЯ ВАМ\n" + "\n".join(lines)))
            items.append(disnake.ui.ActionRow(*[
                disnake.ui.Button(label=f"Купить: {o['name'][:20]}", style=disnake.ButtonStyle.success,
                                  custom_id=cid("eq", "licbuy", obj.user, o["equipment_id"])) for o in offers[:5]]))
        if owned:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay("-# ПРОДАТЬ СВОЮ ЛИЦЕНЗИЮ"))
            opts = [disnake.SelectOption(label=f"{r['name']} · {E.cat_label(r['category'])}"[:100], value=str(r["id"]))
                    for r in owned[:25]]
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("eq", "licsell", obj.user), placeholder="Образец для продажи лицензии", options=opts)))
        if not offers and not owned:
            items.append(disnake.ui.TextDisplay("-# Пока нечего: ни офферов вам, ни своих образцов."))
        p = Panel(timeout=300)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    # ───── роутеры ─────
    def _owner_guard(self, inter, args) -> bool:
        oid = int(args[0]) if args and args[0].isdigit() else None
        return not (oid and inter.author.id != oid)

    @commands.Cog.listener()
    async def on_button_click(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("eq:"):
            return
        _, action, args = parse_cid(c)
        if not self._owner_guard(inter, args):
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны — откройте панель регистрации.", ephemeral=True)
            return
        if action == "reg":
            await inter.response.send_message(components=_domain_panel(obj.user).components, ephemeral=True)
        elif action == "plants":
            await inter.response.send_message(components=self._plants_panel(obj).components, ephemeral=True)
        elif action == "plantbuild" and len(args) >= 2:
            await self._do_plant_build(inter, obj, args[1])
        elif action == "prod":
            await inter.response.send_message(components=self._produce_panel(obj).components, ephemeral=True)
        elif action == "lic":
            await inter.response.send_message(components=self._license_panel(obj).components, ephemeral=True)
        elif action == "ars":
            await inter.response.send_message(embed=self._arsenal_embed(obj), ephemeral=True)
        elif action == "licbuy" and len(args) >= 2 and args[1].isdigit():
            await self._do_license_buy(inter, obj, int(args[1]))

    async def _do_license_buy(self, inter, obj, equipment_id: int):
        offer = self.equip.get_offer(equipment_id, obj.name)
        row = self.equip.get(equipment_id)
        if not offer or not row:
            await inter.response.send_message(embed=disnake.Embed(description="Оффер неактуален.", color=ERROR_COLOR), ephemeral=True)
            return
        if self.equip.has_license(equipment_id, obj.name):
            self.equip.delete_offer(equipment_id, obj.name)
            await inter.response.send_message(embed=disnake.Embed(description="Лицензия уже есть.", color=WARNING_COLOR), ephemeral=True)
            return
        un = self.bot.get_cog("UNCog")
        if un and un.embargoed(obj.name):
            await inter.response.send_message(embed=disnake.Embed(
                description=f"{ui_icon('un_embargo')} Оружейное эмбарго ООН: покупать лицензии запрещено.",
                color=ERROR_COLOR), ephemeral=True)
            return
        price = offer["price"]
        fresh = get_object(obj.name)
        if (fresh.money if fresh else 0) < price:
            await inter.response.send_message(embed=disnake.Embed(
                description=f"Нужно {int_format(price)} {CURRENCY}.", color=ERROR_COLOR), ephemeral=True)
            return
        update_money(obj.name, -price)
        update_money(row["owner"], price)
        self.equip.grant_license(equipment_id, obj.name)
        self.equip.delete_offer(equipment_id, obj.name)
        await inter.response.send_message(embed=disnake.Embed(
            title="📜 Лицензия куплена",
            description=f"{E.cat_icon(row['category'])} **{row['name']}** от {row['owner']}\n"
                        f"-# −{int_format(price)} {CURRENCY} · производство: `!equip`",
            color=SUCCESS_COLOR), ephemeral=True)

    @commands.Cog.listener()
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("eq:"):
            return
        _, action, args = parse_cid(c)
        if not self._owner_guard(inter, args):
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны — откройте панель регистрации.", ephemeral=True)
            return
        value = inter.values[0]
        if action == "regdom":
            await inter.response.edit_message(components=_category_panel(obj.user, value).components)
        elif action == "regcat":
            await inter.response.edit_message(components=_class_panel(obj.user, value).components)
        elif action == "regcls" and len(args) >= 2:
            await inter.response.send_modal(NameModal(self, args[1], value))
        elif action == "prodsel":
            row = self.equip.get(int(value)) if value.isdigit() else None
            if not row:
                await inter.response.send_message("Образец не найден.", ephemeral=True)
                return
            await inter.response.send_modal(CountModal(self, row["id"], row["name"]))
        elif action == "licsell":
            row = self.equip.get(int(value)) if value.isdigit() else None
            if not row or row["owner"] != obj.name:
                await inter.response.send_message("Это не ваш образец.", ephemeral=True)
                return
            await inter.response.send_modal(OfferModal(self, row["id"], row["name"]))


def setup(bot: commands.Bot):
    bot.add_cog(EquipmentCog(bot))
