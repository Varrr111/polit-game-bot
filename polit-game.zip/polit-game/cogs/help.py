"""
Красивая справка — !help (Components V2, кастом-иконки).

Хаб с кнопками-разделами; клик по разделу показывает его команды с описаниями.
Маршрутизация по custom_id "help:…", состояние не хранится (раздел закодирован
в custom_id), поэтому панель работает и после перезапуска.
"""

import disnake
from disnake.ext import commands

from utils import COMMAND_COLOR, PREFIX
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon

# ── Разделы: key -> (иконка-слаг, название, вступление, [(вызов, описание)]) ──
CATEGORIES: dict[str, tuple] = {
    "reg": ("register", "Регистрация и профиль",
            "Создание страны и просмотр состояния.", [
        ("панель регистрации", "выберите свободную страну в канале регистрации и начните игру"),
        ("!balance", "ваш профиль: казна, доход, состояние, армия  ·  алиас: !бал"),
        ("!state", "государство: счастье, стабильность, идеология, религия"),
        ("!unregister", "снять свою регистрацию (себя — сам, других — админ)"),
    ]),
    "eco": ("money", "Экономика",
            "Баланс, заработок и переводы.", [
        ("!balance", "показать баланс страны  ·  алиасы: !бал, !b"),
        ("!work", "разовый заработок (кулдаун 1 час)"),
        ("!pay <@игрок> <сумма>", "перевести деньги другой стране"),
    ]),
    "res": ("storage", "Ресурсы и производство",
            "Добыча, переработка, биржа и стройка.", [
        ("!resources", "склад ресурсов страны  ·  алиас: !рес"),
        ("!deposits", "геология: какие залежи есть у страны"),
        ("!build", "строить заводы и постройки"),
        ("!buildings", "список ваших построек"),
        ("!craft", "переработка сырья в продукцию"),
        ("!exchange", "биржа: купить/продать ресурсы"),
    ]),
    "dev": ("upgrade", "Развитие",
            "Ветки прокачки, повышающие доход.", [
        ("!develop", "развитие: 12 веток (торговля, промышленность, наука…), уровни и синергии"),
    ]),
    "equip": ("plant", "Техника",
              "Производство военной техники и арсенал.", [
        ("!equip", "заводы родов войск, производство, лицензии  ·  алиас: !техника"),
        ("!arsenal", "ваш арсенал произведённой техники"),
        ("!equip-remove", "снести единицу техники"),
    ]),
    "army": ("soldier", "Армия",
             "Призыв, соединения, боеспособность.", [
        ("!army", "здания (казарма/академия/штаб), призыв л/с, 13 соединений, боевые статы  ·  алиас: !армия"),
    ]),
    "pol": ("gov", "Политика и государство",
            "Идеология, религия, счастье и стабильность.", [
        ("!state", "состояние государства и политический строй  ·  алиас: !страна"),
        ("!invest", "вложить деньги в счастье/стабильность  ·  алиас: !вложить"),
    ]),
    "map": ("globe", "Карта мира",
            "Политическая карта всей планеты.", [
        ("!map", "прислать карту мира  ·  алиас: !карта"),
        ("!year", "текущий игровой год (1 год = 2 дня)  ·  алиас: !год"),
    ]),
    "news": ("ev_social", "Мировые новости",
             "Отыгровка событий с разбором ИИ.", [
        ("пиши в #мировые-новости", "новость: ≥50 символов + картинка, до 3 в сутки"),
        ("ИИ-разбор", "бот создаёт ветку и начисляет реалистичные последствия"),
        ("важно", "нет новостей 3 дня → страна снимается автоматически"),
    ]),
    "war": ("war", "Война и дипломатия",
            "Ультиматумы, санкции, шпионаж и полноценная ИИ-война.", [
        ("!war", "война через меню: объявить, план, статус, мир  ·  алиас: !война"),
        ("!warplan <id>", "подать план боя на раунд (можно в ЛС)"),
        ("!ultimatum", "потребовать уступок под угрозой"),
        ("!diplo", "дипломатия: отношения, договоры, посольства, кризисы  ·  алиас: !дипломатия"),
        ("!альянс", "альянсы: военные блоки и экономические союзы, устав, голосования  ·  алиас: !alliance"),
        ("!карта блоки", "карта военных блоков  ·  `!карта экономика` — экономических союзов"),
        ("!чвк", "ЧВК: бойцы, модели стран, чёрный рынок, контракты; для стран — заказы, продажа техники, лицензии, санкции, разведка  ·  алиас: !pmc"),
        ("!чвк-рейтинг", "рейтинг ЧВК мира  ·  профиль ЧВК — !balance @ЧВК"),
        ("!наследие", "Наследие: провозглашение исторических держав (Австро-Венгрия, Армянская империя…)  ·  алиас: !legacy"),
        ("!ии [страна]", "ИИ-государства: разведка армии, соседи для войны  ·  алиас: !npc"),
        ("!оон", "ООН: проекты резолюций, Генассамблея и Совбез с вето, ИИ-секретариат  ·  алиас: !un"),
        ("!атом", "атомная программа: АЭС, обогащение, своя боеголовка, испытание, удар  ·  алиас: !nuclear"),
        ("!sanctions", "экономические санкции (3 пакета)  ·  алиас: !санкции"),
        ("!spy", "шпионаж и разведка  ·  алиас: !шпионаж"),
    ]),
    "trade": ("trade", "Рынок и торговля",
              "Мировая биржа + сделки между странами.", [
        ("!рынок", "рынок: биржа и заявки покупки/продажи  ·  алиасы: !trade, !market"),
        ("!exchange", "быстрая мировая биржа  ·  алиас: !биржа"),
    ]),
    "admin": ("command", "Админ и кураторы",
              "Команды для администрации и ведущих.", [
        ("!console", "бог-режим: выдать деньги/ресурсы/армию/изменить состояние  ·  алиас: !god"),
        ("!мод [@участник]", "панель модерации: варн, тайм-аут, кик, бан, разбан (права по действиям — !perm)"),
        ("!warn/!timeout/!kick/!ban @у причина", "быстрая модерация текстом; !unban id, !warns, !clearwarns"),
        ("!очистить N [@участник]", "удалить последние N сообщений (до 500) · алиас: !clear"),
        ("!warmap", "редактор карты: ручная передача областей (война)"),
        ("!setupserver", "построить сервер с нуля (роли, каналы, права)"),
        ("!setyear <год>", "задать игровой год"),
        ("!regpanel", "выставить панель регистрации"),
        ("!collectnow / !eventnow", "форс-прогон дохода / событий"),
        ("!statsrefresh", "обновить стат-каналы"),
        ("!add-money / !remove-money", "выдать / забрать деньги"),
    ]),
}

ORDER = ["reg", "eco", "res", "dev", "equip", "army", "pol", "map", "war", "trade", "news", "admin"]
SHORT = {"reg": "Профиль", "eco": "Экономика", "res": "Ресурсы", "dev": "Развитие",
         "equip": "Техника", "army": "Армия", "pol": "Политика", "map": "Карта",
         "war": "Война", "trade": "Торговля", "news": "Новости", "admin": "Админ"}


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


class HelpCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _home(self) -> Panel:
        total = sum(len(CATEGORIES[k][3]) for k in ORDER)
        items = [
            disnake.ui.TextDisplay(
                f"## {ui_icon('globe') or '🌍'}  Nova Order · Справка\n"
                f"-# Военно-политическая стратегия · префикс `{PREFIX}`\n"
                f"**{total}** команд в **{len(ORDER)}** разделах — выбери раздел кнопкой ниже 👇"),
            disnake.ui.Separator(),
        ]
        btns = []
        for key in ORDER:
            slug = CATEGORIES[key][0]
            btns.append(disnake.ui.Button(style=disnake.ButtonStyle.secondary,
                                          label=SHORT[key], emoji=_pe(slug),
                                          custom_id=cid("help", "cat", key)))
        # раскладываем по рядам максимум 5 в ряд
        for i in range(0, len(btns), 5):
            items.append(disnake.ui.ActionRow(*btns[i:i + 5]))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(
            "-# 📖 Как играть — читай гайд в инфо-канале · 🗞️ новости пиши прямо в канал мировых новостей."))
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    def _category(self, key: str) -> Panel:
        slug, title, intro, cmds = CATEGORIES[key]
        lines = "\n".join(f"{ui_icon('up') or '▸'} **`{usage}`**\n-# {desc}" for usage, desc in cmds)
        items = [
            disnake.ui.TextDisplay(f"## {ui_icon(slug) or '•'} {title}\n{intro}"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(lines),
            disnake.ui.Separator(),
            disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.primary, label="⟵ Все разделы", custom_id=cid("help", "home"))),
        ]
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    @commands.Cog.listener("on_button_click")
    async def _help_buttons(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("help:"):
            return
        _, action, args = parse_cid(c)
        if action == "home":
            await inter.response.edit_message(components=self._home().components)
        elif action == "cat" and args and args[0] in CATEGORIES:
            await inter.response.edit_message(components=self._category(args[0]).components)

    @commands.command(name="help", aliases=["помощь", "хелп", "команды", "h"])
    async def help_cmd(self, ctx: commands.Context):
        await ctx.send(components=self._home().components)


def setup(bot: commands.Bot):
    bot.add_cog(HelpCog(bot))
