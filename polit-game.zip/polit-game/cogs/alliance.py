"""
🛡️ АЛЬЯНСЫ — !alliance / !альянс

Блоки стран двух типов (страна может быть в одном военном И одном экономическом):
  • ВОЕННЫЙ БЛОК — коллективная оборона (зов всем членам), объединённое командование
    (+сила в общей войне), военные базы (проход через земли членов), обмен разведданными.
  • ЭКОНОМИЧЕСКИЙ СОЮЗ — общий рынок (+доход за члена), таможенный союз, единая
    санкционная политика (коалиция по кнопке), валютный союз (щит от санкций).
  • Общий фонд (оба типа): взнос % дохода в казну, субсидии членам по голосованию.

УПРАВЛЕНИЕ: лидер выносит решения на голосование (приём/исключение, статьи устава);
любой член — субсидия себе и вотум недоверия лидеру; не-член — заявка на вступление.

СПЛОЧЁННОСТЬ (часовой цикл): дрейф к равновесию из отношений членов, общего строя,
общего врага и глубины устава; толчки — верность/отказ на зов, шпионаж против своих,
исключения. Сила всех статей × сплочённость; ниже порога — паралич блока.

СВЯЗИ: дипломатия (равновесие отношений, зов в войну, проход), война (сила стороны),
ультиматумы (сила блока), санкции (запрет внутри союза + коалиция), шпионаж
(контрразведка, удар по блоку), экономика (строки авто-дохода), новости (ИИ-контекст),
карта (!map блоки). Публично — #альянсы (CH_ALLIANCE, фолбэк — #дипломатия).
Только кастом-иконки (ui_icon в тексте, emoji= в кнопках/опциях).
"""

import asyncio
import logging
import re
import time
from collections import Counter

import disnake
from disnake.ext import commands, tasks

from utils import (
    Countries, Politics, Diplomacy, Sanctions, War, Alliances, Cooldown,
    update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
import utils.alliance as A
import utils.diplomacy as D

log = logging.getLogger("alliance")

_PAGE = 25


def _pe(slug: str):
    """UI-слаг → PartialEmoji для emoji= кнопок/селектов (или None)."""
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _sign(v: float) -> str:
    return f"+{v:.0f}" if v > 0 else f"{v:.0f}"


def _num(text: str) -> int | None:
    t = (text or "").strip().lower().replace(" ", "").replace("_", "").replace(",", "")
    mult = 1
    while t.endswith("k") or t.endswith("к"):
        mult *= 1000
        t = t[:-1]
    try:
        v = int(float(t) * mult)
    except ValueError:
        return None
    return v if v > 0 else None


class _Dummy:
    flag = "🏳️"
    user = 0
    money = 0


class AllianceCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.politics = Politics()
        self.dip = Diplomacy()
        self.sanc = Sanctions()
        self.war = War()
        self.al = Alliances()
        self.cooldown = Cooldown()
        self._sessions: dict[int, dict] = {}
        self._migrated = False
        self.bloc_tick.start()

    def cog_unload(self):
        self.bloc_tick.cancel()

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    # ───── сессия ─────
    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "bloc": None, "act": None, "subject": None, "page": 0, "vote": None}
            self._sessions[uid] = s
        return s

    def _actor(self, uid: int):
        return self.countries.get_object_by_user(uid)

    def _obj(self, name: str):
        return self.countries.get_object(name) or _Dummy()

    # ═══════════════ ПОМОЩНИКИ БЛОКА ═══════════════
    @staticmethod
    def _tag(b) -> str:
        return f"[{b['tag']}] {b['name']}"

    @staticmethod
    def _arts(b) -> list[str]:
        return A.parse_articles(b["articles"])

    @staticmethod
    def _mult(b) -> float:
        return A.cohesion_mult(b["cohesion"] or 0)

    def _works(self, b, art: str) -> float:
        """Сила статьи (0 — статьи нет или блок парализован)."""
        if not b or art not in self._arts(b):
            return 0.0
        return self._mult(b)

    def _kicon(self, kind: str) -> str:
        return ui_icon(A.KINDS[kind]["icon"]) if kind in A.KINDS else ui_icon("alliance")

    def _flags(self, names, limit: int = 12) -> str:
        out = " ".join(f"{self._obj(n).flag}" for n in names[:limit])
        return out + (f" +{len(names) - limit}" if len(names) > limit else "")

    def _ratified(self, b, country: str, now: int) -> bool:
        return now - self.al.joined_at(b["id"], country) >= A.RATIFY_S

    def _join_block(self, b, country: str, now: int) -> str:
        """Почему страна не может вступить в блок (пусто — может)."""
        if not self.countries.get_object(country):
            return "страна не найдена"
        kind = b["kind"]
        if self.al.bloc_of(country, kind):
            return f"уже состоит в блоке типа «{A.KINDS[kind]['short']}»"
        members = self.al.members(b["id"])
        if country in members:
            return "уже член блока"
        if len(members) >= A.KINDS[kind]["max_members"]:
            return f"блок заполнен ({A.KINDS[kind]['max_members']})"
        if self.cooldown.get_cooldown(f"blocleave_{kind}", country) > now:
            left = int(self.cooldown.get_cooldown(f"blocleave_{kind}", country) - now)
            return f"недавно вышла из блока (ещё {left // 3600}ч)"
        if kind == "military" and self.war.active_for(country):
            return "страна воюет — в военный блок посреди войны не принимают"
        need = A.KINDS[kind]["min_rel"]
        cold = [m for m in members if self.dip.get_relation(country, m) < need]
        if cold:
            return f"отношения ниже {_sign(need)} с: {', '.join(cold[:3])}"
        return ""

    def _channel(self):
        ch_id = rid("CH_ALLIANCE", 0) or rid("CH_DIPLO", 0)
        if not ch_id:
            return None
        g = self.bot.get_guild(GUILD_ID)
        return (g.get_channel(ch_id) if g else None) or self.bot.get_channel(ch_id)

    async def _post(self, desc: str, color=COMMAND_COLOR):
        channel = self._channel()
        if not channel:
            return
        try:
            await channel.send(embed=disnake.Embed(description=desc, color=color))
        except Exception:
            pass

    async def _dm(self, country: str, components=None, text: str | None = None):
        o = self.countries.get_object(country)
        if not o or not getattr(o, "user", 0):
            return
        user = self.bot.get_user(o.user)
        if user is None:
            try:
                user = await self.bot.fetch_user(o.user)
            except Exception:
                return
        try:
            if components is not None:
                await user.send(components=components)
            else:
                await user.send(text)
        except Exception:
            pass

    async def _dm_members(self, b, text: str, skip: tuple = ()):
        for m in self.al.members(b["id"]):
            if m not in skip:
                await self._dm(m, text=text)

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('alliance')} Альянсы")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _back(self, label="⟵ В хаб", to="hub"):
        return disnake.ui.Button(style=disnake.ButtonStyle.secondary, label=label,
                                 custom_id=cid("aln", "goto", to))

    def _note_panel(self, text: str, color=COMMAND_COLOR) -> Panel:
        return self._container([disnake.ui.TextDisplay(text)], color)

    def _render(self, uid: int, note=None) -> Panel:
        s = self._session(uid)
        actor = self._actor(uid)
        if not actor:
            return self._container(self._head(note) + [disnake.ui.TextDisplay(
                "-# У вас нет страны. Откройте панель регистрации, чтобы играть.")], WARNING_COLOR)
        b = self.al.get(s["bloc"]) if s["bloc"] else None
        if s["view"] in ("bloc", "act", "vote") and (not b or b["status"] != "active"):
            s.update(view="hub", bloc=None, act=None, vote=None)
            note = note or f"{ui_icon('reject')} Блок больше не существует."
        view = s["view"]
        if view == "world":
            return self._panel_world(uid, actor, note)
        if view == "bloc":
            return self._panel_bloc(uid, actor, b, note)
        if view == "act":
            return self._panel_act(uid, actor, b, note)
        if view == "vote":
            return self._panel_vote_in(uid, actor, b, note)
        return self._panel_hub(uid, actor, note)

    # — хаб —
    def _panel_hub(self, uid, actor, note=None):
        me = actor.name
        now = int(time.time())
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {actor.flag} {me}\n"
            "-# Страна может состоять в **одном военном** и **одном экономическом** блоке одновременно."))
        B = disnake.ButtonStyle
        rows = []
        for kind in A.KIND_KEYS:
            meta = A.KINDS[kind]
            b = self.al.bloc_of(me, kind)
            items.append(disnake.ui.Separator())
            if b:
                members = self.al.members(b["id"])
                lead = " · вы лидер" if b["leader"] == me else ""
                votes = len(self.al.open_votes(b["id"]))
                items.append(disnake.ui.TextDisplay(
                    f"{self._kicon(kind)} **{meta['label']}** · **{self._tag(b)}**{lead}\n"
                    f"{ui_icon('cohesion')} Сплочённость {A.coh_bar(b['cohesion'])} **{b['cohesion']:.0f}** "
                    f"· {A.coh_word(b['cohesion'])}\n"
                    f"{self._flags(members)} · членов **{len(members)}/{meta['max_members']}**"
                    + (f" · {ui_icon('vote')} голосований: **{votes}**" if votes else "")))
                rows.append(disnake.ui.Button(style=B.primary, label=f"Открыть: {meta['label'].lower()}",
                                              emoji=_pe(meta["icon"]), custom_id=cid("aln", "open", b["id"])))
            else:
                cd = self.cooldown.get_cooldown(f"blocleave_{kind}", me) > now
                items.append(disnake.ui.TextDisplay(
                    f"{self._kicon(kind)} **{meta['label']}** — вы не состоите.\n-# {meta['desc']} "
                    f"Основать: **{int_format(meta['found_money'])} {CURRENCY}** + **{meta['found_inf']}** дипкапитала."))
                rows.append(disnake.ui.Button(style=B.success, label=f"Основать: {meta['label'].lower()}",
                                              emoji=_pe(meta["icon"]), disabled=cd,
                                              custom_id=cid("aln", "found", kind)))
        invites = self.al.invites_for(me)
        if invites:
            items.append(disnake.ui.Separator())
            lines = []
            for inv in invites[:3]:
                b = self.al.get(inv["bloc_id"])
                if b:
                    lines.append(f"{self._kicon(b['kind'])} **{self._tag(b)}** ({A.KINDS[b['kind']]['short']})")
            items.append(disnake.ui.TextDisplay(f"{ui_icon('invite')} **Приглашения:** " + " · ".join(lines)
                                                + "\n-# Ответить — в ЛС-сообщении приглашения."))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(*rows))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.secondary, label="Блоки мира", emoji=_pe("globe"),
                              custom_id=cid("aln", "goto", "world")),
            disnake.ui.Button(style=B.secondary, label="Обновить", emoji=_pe("reload"),
                              custom_id=cid("aln", "goto", "hub"))))
        items.append(disnake.ui.TextDisplay(
            "-# Сила статей устава зависит от сплочённости: ссоры, отказы и шпионаж против своих её подтачивают."))
        return self._container(items)

    # — блоки мира —
    def _panel_world(self, uid, actor, note=None):
        items = self._head(note)
        blocs = self.al.active()
        if not blocs:
            items.append(disnake.ui.TextDisplay("-# В мире пока нет ни одного блока. Станьте первыми."))
            items.append(disnake.ui.ActionRow(self._back()))
            return self._container(items)
        for kind in A.KIND_KEYS:
            lst = [b for b in blocs if b["kind"] == kind]
            if not lst:
                continue
            lines = []
            for b in lst[:10]:
                members = self.al.members(b["id"])
                lines.append(f"**{self._tag(b)}** · {self._flags(members, 8)} · "
                             f"{ui_icon('cohesion')} {b['cohesion']:.0f}")
            items.append(disnake.ui.TextDisplay(f"### {self._kicon(kind)} {A.KINDS[kind]['plural']}\n"
                                                + "\n".join(lines)))
        opts = [disnake.SelectOption(
            label=f"[{b['tag']}] {b['name']}"[:100], value=str(b["id"]), emoji=_pe(A.KINDS[b["kind"]]["icon"]),
            description=f"{A.kind_label(b['kind'])} · членов {len(self.al.members(b['id']))}"[:100])
            for b in blocs[:_PAGE]]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("aln", "pickbloc"), placeholder="Открыть блок…", options=opts)))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — страница блока —
    def _panel_bloc(self, uid, actor, b, note=None):
        me = actor.name
        now = int(time.time())
        kind = b["kind"]
        meta = A.KINDS[kind]
        members = self.al.members(b["id"])
        is_member = me in members
        is_leader = b["leader"] == me
        mult = self._mult(b)
        arts = self._arts(b)
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {self._kicon(kind)} {self._tag(b)}\n"
            f"-# {meta['label']} · основан <t:{b['created_at']}:D>\n"
            f"{ui_icon('leader')} Лидер: {self._obj(b['leader']).flag} **{b['leader']}**\n"
            f"{ui_icon('cohesion')} Сплочённость {A.coh_bar(b['cohesion'])} **{b['cohesion']:.0f}/100** · "
            f"{A.coh_word(b['cohesion'])} · сила статей **{int(mult * 100)}%**"
            + (f"\n{ui_icon('treasury')} Казна: **{int_format(b['treasury'] or 0)} {CURRENCY}**"
               if "fund" in arts or (b["treasury"] or 0) > 0 else "")))
        ml = []
        for r in self.al.member_rows(b["id"]):
            n = r["country"]
            mark = ui_icon("leader") if n == b["leader"] else (
                ui_icon("ratify") if now - (r["joined_at"] or 0) < A.RATIFY_S else ui_icon("check"))
            rel = f" · {_sign(self.dip.get_relation(me, n))}" if is_member and n != me else ""
            ml.append(f"{mark} {self._obj(n).flag} **{n}**{rel}")
        items.append(disnake.ui.TextDisplay(
            f"-# ЧЛЕНЫ · {len(members)}/{meta['max_members']}\n" + "\n".join(ml)
            + (f"\n-# {ui_icon('ratify')} — ратификация {A.RATIFY_S // 3600}ч: оборона ещё не действует"
               if kind == "military" and any(now - (r["joined_at"] or 0) < A.RATIFY_S
                                             for r in self.al.member_rows(b["id"])) else "")))
        al = []
        for art in meta["articles"]:
            am = A.ARTICLES[art]
            on = art in arts
            core = " · базовая" if art == meta["core"] else ""
            al.append(f"{ui_icon(am['icon']) if on else ui_icon('lock')} "
                      f"{'**' + am['label'] + '**' if on else am['label']}{core}"
                      + (f" — {am['desc']}" if on else ""))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"{ui_icon('charter')} **Устав**\n" + "\n".join(al)))
        if mult == 0:
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon('exposed')} **Блок парализован** — сплочённость ниже {A.COH_PARALYSIS:.0f}, "
                f"статьи не работают. Поднимайте отношения между членами."))
        B = disnake.ButtonStyle
        votes = self.al.open_votes(b["id"])
        if is_member and votes:
            items.append(disnake.ui.Separator())
            opts = []
            for v in votes[:_PAGE]:
                vm = A.VOTES.get(v["kind"], {"label": v["kind"], "icon": "vote"})
                mine = self.al.ballots(v["id"]).get(me)
                status = "вы: за" if mine is True else ("вы: против" if mine is False else "ждёт вашего голоса")
                opts.append(disnake.SelectOption(
                    label=f"{vm['label']}: {self._vote_subject(v)}"[:100], value=str(v["id"]),
                    emoji=_pe(vm["icon"]), description=status[:100]))
            items.append(disnake.ui.TextDisplay(f"{ui_icon('vote')} **Открытые голосования: {len(votes)}**"))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("aln", "pickvote"), placeholder="Открыть голосование…", options=opts)))
        items.append(disnake.ui.Separator())
        if is_member:
            acts = []
            if is_leader:
                acts += [("invite", "Пригласить страну", "invite"), ("expel", "Исключить члена", "expel"),
                         ("art_add", "Принять статью устава", "charter"),
                         ("art_rem", "Отменить статью устава", "charter"),
                         ("handover", "Передать лидерство", "leader")]
            else:
                acts.append(("leader", "Вотум недоверия лидеру", "leader"))
            if "fund" in arts:
                acts.append(("grant", "Запросить субсидию из фонда", "treasury"))
            acts.append(("deposit", "Внести в казну", "coins"))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("aln", "act"), placeholder="Действие…",
                options=[disnake.SelectOption(label=l, value=k, emoji=_pe(ic)) for k, l, ic in acts])))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.danger, label="Выйти из блока", emoji=_pe("leave_bloc"),
                                  custom_id=cid("aln", "leave", b["id"])),
                disnake.ui.Button(style=B.secondary, label="Обновить", emoji=_pe("reload"),
                                  custom_id=cid("aln", "open", b["id"])),
                self._back()))
        else:
            block = self._join_block(b, me, now)
            pending = self.al.open_vote_like(b["id"], "apply", me)
            items.append(disnake.ui.TextDisplay(
                (f"{ui_icon('reject')} Вступить нельзя: {block}." if block else
                 f"{ui_icon('vote')} Заявка уже на голосовании." if pending else
                 f"{ui_icon('invite')} Можно подать заявку — члены блока проголосуют.")
                + f"\n-# Условие: отношения от **{_sign(meta['min_rel'])}** с каждым членом."))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.success, label="Подать заявку", emoji=_pe("invite"),
                                  disabled=bool(block or pending), custom_id=cid("aln", "apply", b["id"])),
                self._back("⟵ К блокам", "world")))
        return self._container(items)

    def _vote_subject(self, v) -> str:
        if v["kind"] in ("art_add", "art_rem"):
            return A.article_label(v["subject"])
        if v["kind"] == "grant":
            return f"{v['subject']} · {int_format(v['amount'])} {CURRENCY}"
        return v["subject"]

    # — выбор субъекта действия лидера —
    def _act_options(self, actor, b, act: str) -> list[tuple[str, str, str]]:
        """→ [(value, label, description)] для селекта действия."""
        me = actor.name
        now = int(time.time())
        members = self.al.members(b["id"])
        arts = self._arts(b)
        if act == "invite":
            out = []
            names = sorted((n for n in self.countries.get_object_names() if n not in members),
                           key=lambda n: -self.dip.get_relation(me, n))
            for n in names:
                if self._join_block(b, n, now) or self.al.open_vote_like(b["id"], "invite", n):
                    continue
                out.append((n, f"{self._obj(n).flag} {n}", f"отношения {_sign(self.dip.get_relation(me, n))}"))
            return out
        if act in ("expel", "handover"):
            return [(n, f"{self._obj(n).flag} {n}", "член блока") for n in members if n != me]
        if act == "leader":
            return [(n, f"{self._obj(n).flag} {n}", "новый лидер") for n in members if n != b["leader"]]
        if act == "art_add":
            return [(k, A.article_label(k), A.ARTICLES[k]["desc"]) for k in A.articles_for(b["kind"])
                    if k not in arts]
        if act == "art_rem":
            return [(k, A.article_label(k), A.ARTICLES[k]["desc"]) for k in arts
                    if k != A.KINDS[b["kind"]]["core"]]
        return []

    def _panel_act(self, uid, actor, b, note=None):
        s = self._session(uid)
        act = s["act"]
        titles = {"invite": ("invite", "Пригласить страну",
                             "Кандидаты — страны с отношениями не ниже порога со всеми членами. Решают члены."),
                  "expel": ("expel", "Исключить члена", "Исключение — голосованием, без исключаемого."),
                  "art_add": ("charter", "Принять статью устава",
                              f"Каждая доп. статья — {A.COH_PER_ARTICLE:.0f} к равновесию сплочённости."),
                  "art_rem": ("charter", "Отменить статью устава", "Базовую статью отменить нельзя."),
                  "handover": ("leader", "Передать лидерство", "Сразу, без голосования."),
                  "leader": ("leader", "Вотум недоверия", "Выберите нового лидера — члены проголосуют.")}
        icon, title, hint = titles.get(act, ("vote", "Действие", ""))
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(f"### {ui_icon(icon)} {title} · {self._tag(b)}\n-# {hint}"))
        opts = self._act_options(actor, b, act)
        pages = max(1, (len(opts) + _PAGE - 1) // _PAGE)
        s["page"] = max(0, min(s["page"], pages - 1))
        page = opts[s["page"] * _PAGE:(s["page"] + 1) * _PAGE]
        if page:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("aln", "subj"), placeholder="Выберите…",
                options=[disnake.SelectOption(label=l[:100], value=v[:100], description=d[:100],
                                              default=(v == s["subject"])) for v, l, d in page])))
        else:
            items.append(disnake.ui.TextDisplay("-# Подходящих вариантов нет."))
        if s["subject"]:
            if act in ("art_add", "art_rem"):
                items.append(disnake.ui.TextDisplay(
                    f"{ui_icon(A.ARTICLES[s['subject']]['icon'])} **{A.article_label(s['subject'])}** — "
                    f"{A.ARTICLES[s['subject']]['desc']}"))
            else:
                items.append(disnake.ui.TextDisplay(f"Выбрано: {self._obj(s['subject']).flag} **{s['subject']}**"))
        B = disnake.ButtonStyle
        row = [disnake.ui.Button(style=B.success, emoji=_pe("vote" if act != "handover" else "leader"),
                                 label="Передать" if act == "handover" else "На голосование",
                                 disabled=not s["subject"], custom_id=cid("aln", "go"))]
        if pages > 1:
            row.append(disnake.ui.Button(style=B.primary, emoji=_pe("prev"), disabled=s["page"] == 0,
                                         custom_id=cid("aln", "page", "prev")))
            row.append(disnake.ui.Button(style=B.primary, emoji=_pe("next"), disabled=s["page"] >= pages - 1,
                                         custom_id=cid("aln", "page", "next")))
        row.append(disnake.ui.Button(style=B.secondary, label="⟵ К блоку", custom_id=cid("aln", "open", b["id"])))
        items.append(disnake.ui.ActionRow(*row))
        return self._container(items)

    # — голосование —
    def _electorate(self, v, b) -> list[str]:
        members = self.al.members(b["id"])
        if v["kind"] == "expel":
            members = [m for m in members if m != v["subject"]]
        return members

    def _vote_body(self, v, b, viewer: str | None) -> list:
        vm = A.VOTES.get(v["kind"], {"label": v["kind"], "icon": "vote"})
        ballots = self.al.ballots(v["id"])
        elect = self._electorate(v, b)
        yes = sum(1 for c, y in ballots.items() if y and c in elect)
        no = sum(1 for c, y in ballots.items() if not y and c in elect)
        extra = ""
        if v["kind"] in ("art_add", "art_rem"):
            extra = f"\n-# {A.ARTICLES.get(v['subject'], {}).get('desc', '')}"
        elif v["kind"] == "grant":
            extra = f"\n-# В казне сейчас {int_format(b['treasury'] or 0)} {CURRENCY}."
        elif v["kind"] in ("invite", "apply"):
            o = self.countries.get_object(v["subject"])
            if o and viewer:
                extra = f"\n-# Ваши отношения с кандидатом: **{_sign(self.dip.get_relation(viewer, v['subject']))}**"
        return [disnake.ui.TextDisplay(
            f"## {ui_icon(vm['icon'])} Голосование · {self._tag(b)}\n"
            f"**{vm['label']}:** {self._vote_subject(v)}{extra}\n"
            f"-# Инициатор: {self._obj(v['initiator']).flag} {v['initiator']} · до <t:{v['deadline']}:R>\n"
            f"{ui_icon('accept')} За: **{yes}** · {ui_icon('reject')} Против: **{no}** · "
            f"голосующих **{len(elect)}** (нужно больше половины)")]

    def _panel_vote_in(self, uid, actor, b, note=None):
        s = self._session(uid)
        v = self.al.get_vote(s["vote"]) if s["vote"] else None
        if not v or v["bloc_id"] != b["id"]:
            s["view"] = "bloc"
            return self._panel_bloc(uid, actor, b, note)
        items = self._head(note) + self._vote_body(v, b, actor.name)
        items.append(self._ballot_row(v, b, actor.name) or disnake.ui.TextDisplay(self._vote_state(v, actor.name)))
        items.append(disnake.ui.ActionRow(disnake.ui.Button(
            style=disnake.ButtonStyle.secondary, label="⟵ К блоку", custom_id=cid("aln", "open", b["id"]))))
        return self._container(items)

    def _vote_state(self, v, viewer: str) -> str:
        if v["status"] != "open":
            return f"-# Голосование завершено: **{'принято' if v['status'] == 'passed' else 'отклонено'}**."
        mine = self.al.ballots(v["id"]).get(viewer)
        if mine is None:
            return "-# Вы не голосуете по этому вопросу."
        return f"-# Ваш голос: **{'за' if mine else 'против'}**. Ждём остальных."

    def _ballot_row(self, v, b, viewer: str):
        if v["status"] != "open" or viewer not in self._electorate(v, b):
            return None
        if viewer in self.al.ballots(v["id"]):
            return None
        return disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, label="За", emoji=_pe("accept"),
                              custom_id=cid("aln", "bal", v["id"], "y")),
            disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Против", emoji=_pe("reject"),
                              custom_id=cid("aln", "bal", v["id"], "n")))

    def _vote_dm_panel(self, vid: int, viewer: str, result: str | None = None) -> Panel:
        v = self.al.get_vote(vid)
        b = self.al.get(v["bloc_id"]) if v else None
        if not v or not b:
            return self._note_panel(f"{ui_icon('reject')} Голосование не найдено.", WARNING_COLOR)
        items = self._vote_body(v, b, viewer)
        if result:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(result))
        row = self._ballot_row(v, b, viewer)
        items.append(row or disnake.ui.TextDisplay(self._vote_state(v, viewer)))
        return self._container(items)

    def _invite_panel(self, iid: int, result: str | None = None) -> Panel:
        inv = self.al.get_invite(iid)
        b = self.al.get(inv["bloc_id"]) if inv else None
        if not inv or not b:
            return self._note_panel(f"{ui_icon('reject')} Приглашение не найдено.", WARNING_COLOR)
        meta = A.KINDS[b["kind"]]
        members = self.al.members(b["id"])
        arts = ", ".join(A.article_label(a) for a in self._arts(b)) or "—"
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('invite')} Приглашение в блок\n"
            f"{self._kicon(b['kind'])} **{self._tag(b)}** — {meta['label'].lower()} — приглашает вас вступить.\n"
            f"{self._flags(members)} · членов **{len(members)}** · {ui_icon('cohesion')} сплочённость "
            f"**{b['cohesion']:.0f}**\n{ui_icon('charter')} Устав: {arts}"
            + (f"\n-# Коллективная оборона заработает через {A.RATIFY_S // 3600}ч после вступления (ратификация)."
               if b["kind"] == "military" else ""))]
        if result:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(result))
        elif inv["status"] == "pending":
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Вступить", emoji=_pe("accept"),
                                  custom_id=cid("aln", "inv", iid, "yes")),
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Отказаться", emoji=_pe("reject"),
                                  custom_id=cid("aln", "inv", iid, "no"))))
            items.append(disnake.ui.TextDisplay(f"-# Приглашение действует {A.INVITE_TTL // 3600} часа."))
        else:
            items.append(disnake.ui.TextDisplay(f"-# Приглашение закрыто ({inv['status']})."))
        return self._container(items)

    # ═══════════════ МОДАЛКИ ═══════════════
    def _found_modal(self, kind: str):
        return disnake.ui.Modal(
            title=f"Основать: {A.KINDS[kind]['label']}"[:45], custom_id=cid("aln", "mfound", kind),
            components=[
                disnake.ui.TextInput(label="Название блока", custom_id="name", style=disnake.TextInputStyle.short,
                                     placeholder="Северный оборонительный союз", min_length=3,
                                     max_length=A.NAME_MAX, required=True),
                disnake.ui.TextInput(label=f"Тег ({A.TAG_MIN}–{A.TAG_MAX} букв)", custom_id="tag",
                                     style=disnake.TextInputStyle.short, placeholder="СОС",
                                     min_length=A.TAG_MIN, max_length=A.TAG_MAX, required=True)])

    def _money_modal(self, bid: int, mode: str):
        title = "Субсидия из фонда" if mode == "grant" else "Взнос в казну блока"
        return disnake.ui.Modal(
            title=title, custom_id=cid("aln", "mmoney", bid, mode),
            components=[disnake.ui.TextInput(label="Сумма", custom_id="val", style=disnake.TextInputStyle.short,
                                             placeholder="например 50000000 или 50kk", required=True)])

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _aln_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("aln:"):
            return
        s = self._session(inter.author.id)
        actor = self._actor(inter.author.id)
        _, action, _ = parse_cid(c)
        v = inter.values[0] if inter.values else None
        b = self.al.get(s["bloc"]) if s["bloc"] else None
        # действия, открывающие модалку, — без defer
        if action == "act" and actor and b and v in ("grant", "deposit"):
            await inter.response.send_modal(self._money_modal(b["id"], v))
            return
        await self._defer(inter)
        note = None
        if not actor or v is None:
            pass
        elif action == "pickbloc" and v.isdigit():
            s.update(view="bloc", bloc=int(v), act=None, subject=None)
        elif action == "pickvote" and v.isdigit():
            s.update(view="vote", vote=int(v))
        elif action == "act":
            s.update(view="act", act=v, subject=None, page=0)
        elif action == "subj":
            s["subject"] = v
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    @commands.Cog.listener("on_button_click")
    async def _aln_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("aln:"):
            return
        _, action, args = parse_cid(c)
        if action == "found" and args and args[0] in A.KINDS:
            await inter.response.send_modal(self._found_modal(args[0]))
            return
        # персистентные ЛС-сообщения
        if action == "bal":
            await self._on_ballot(inter, args)
            return
        if action == "inv":
            await self._on_invite_answer(inter, args)
            return
        if action == "sjoin":
            await self._on_sanction_join(inter, args)
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        actor = self._actor(inter.author.id)
        note = None
        if not actor:
            pass
        elif action == "goto":
            s.update(view=args[0] if args else "hub", act=None, subject=None, vote=None, page=0)
            if s["view"] == "hub":
                s["bloc"] = None
        elif action == "open" and args and args[0].isdigit():
            s.update(view="bloc", bloc=int(args[0]), act=None, subject=None, vote=None)
        elif action == "page":
            s["page"] += 1 if args and args[0] == "next" else -1
        elif action == "go":
            note = await self._do_act(actor, s)
        elif action == "apply" and args and args[0].isdigit():
            note = await self._apply(actor, int(args[0]))
        elif action == "leave" and args and args[0].isdigit():
            b = self.al.get(int(args[0]))
            if b and actor.name in self.al.members(b["id"]):
                note = await self._leave(b, actor.name, "вышла")
                s.update(view="hub", bloc=None)
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    @commands.Cog.listener("on_modal_submit")
    async def _aln_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("aln:"):
            return
        _, action, args = parse_cid(c)
        actor = self._actor(inter.author.id)
        s = self._session(inter.author.id)
        if not actor:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        if action == "mfound" and args:
            note, bid = await self._found(actor, args[0], inter.text_values.get("name", ""),
                                          inter.text_values.get("tag", ""))
            if bid:
                s.update(view="bloc", bloc=bid)
        elif action == "mmoney" and len(args) >= 2 and args[0].isdigit():
            val = _num(inter.text_values.get("val", ""))
            b = self.al.get(int(args[0]))
            if val is None or not b:
                note = f"{ui_icon('reject')} Неверная сумма."
            elif args[1] == "grant":
                note = await self._start_vote(b, "grant", actor.name, val, actor.name)
            else:
                note = await self._deposit(actor, b, val)
            s.update(view="bloc", bloc=int(args[0]), act=None)
        else:
            return
        try:
            await inter.response.edit_message(components=self._render(inter.author.id, note).components)
        except Exception:
            await inter.response.send_message(components=self._render(inter.author.id, note).components)

    # ═══════════════ ДЕЙСТВИЯ ═══════════════
    async def _found(self, actor, kind: str, name: str, tag: str) -> tuple[str, int]:
        me = actor.name
        now = int(time.time())
        if kind not in A.KINDS:
            return f"{ui_icon('reject')} Неизвестный тип блока.", 0
        meta = A.KINDS[kind]
        name = re.sub(r"\s+", " ", name or "").strip()[:A.NAME_MAX]
        tag = re.sub(r"[^\wА-Яа-яЁё]", "", tag or "").upper()[:A.TAG_MAX]
        if len(name) < 3 or len(tag) < A.TAG_MIN:
            return f"{ui_icon('reject')} Нужны название (от 3 символов) и тег ({A.TAG_MIN}–{A.TAG_MAX} букв).", 0
        if self.al.bloc_of(me, kind):
            return f"{ui_icon('reject')} Вы уже состоите в блоке этого типа.", 0
        if self.cooldown.get_cooldown(f"blocleave_{kind}", me) > now:
            return f"{ui_icon('reject')} Вы недавно вышли из блока — подождите.", 0
        if kind == "military" and self.war.active_for(me):
            return f"{ui_icon('reject')} Во время войны военный блок не основать.", 0
        if self.al.name_taken(name, tag):
            return f"{ui_icon('reject')} Название или тег уже заняты.", 0
        fresh = self.countries.get_object(me)
        inf, _rep = self.dip.get_state(me)
        if (fresh.money or 0) < meta["found_money"]:
            return f"{ui_icon('reject')} Нужно {int_format(meta['found_money'])} {CURRENCY}.", 0
        if inf < meta["found_inf"]:
            return f"{ui_icon('reject')} Нужно {meta['found_inf']} дипкапитала.", 0
        update_money(me, -meta["found_money"])
        self.dip.add_influence(me, -meta["found_inf"])
        bid = self.al.create(kind, name, tag, me, A.COH_START, now)
        self.al.set_articles(bid, A.dump_articles([meta["core"]]))
        b = self.al.get(bid)
        await self._post(
            f"{self._kicon(kind)} {actor.flag} **{me}** основывает {meta['label'].lower()} **{self._tag(b)}**.\n"
            f"-# Базовая статья: {A.article_label(meta['core'])}. Страны с хорошими отношениями могут подать заявку "
            f"через `!альянс` → «Блоки мира».", SUCCESS_COLOR)
        return (f"{ui_icon('check')} Блок **{self._tag(b)}** основан. Пригласите страны "
                f"(«Действие… → Пригласить») — без членов блок распадётся через {A.SOLO_TTL // 3600}ч."), bid

    async def _do_act(self, actor, s) -> str:
        b = self.al.get(s["bloc"]) if s["bloc"] else None
        act, subject = s["act"], s["subject"]
        me = actor.name
        if not b or me not in self.al.members(b["id"]) or not subject:
            return f"{ui_icon('reject')} Действие недоступно."
        valid = {v for v, _l, _d in self._act_options(actor, b, act)}
        if subject not in valid:
            return f"{ui_icon('reject')} Вариант больше недоступен."
        leader_only = act in ("invite", "expel", "art_add", "art_rem", "handover")
        if leader_only and b["leader"] != me:
            return f"{ui_icon('reject')} Это решение выносит только лидер."
        s.update(view="bloc", act=None, subject=None)
        if act == "handover":
            self.al.set_leader(b["id"], subject)
            await self._post(f"{ui_icon('leader')} **{self._tag(b)}**: {actor.flag} **{me}** передаёт лидерство "
                             f"{self._obj(subject).flag} **{subject}**.")
            await self._dm(subject, text=f"{ui_icon('leader')} Вы — новый лидер блока **{self._tag(b)}**.")
            return f"{ui_icon('leader')} Лидерство передано {subject}."
        return await self._start_vote(b, act, subject, 0, me)

    async def _apply(self, actor, bid: int) -> str:
        b = self.al.get(bid)
        if not b or b["status"] != "active":
            return f"{ui_icon('reject')} Блок не найден."
        block = self._join_block(b, actor.name, int(time.time()))
        if block:
            return f"{ui_icon('reject')} {block}."
        return await self._start_vote(b, "apply", actor.name, 0, actor.name)

    async def _deposit(self, actor, b, amount: int) -> str:
        if actor.name not in self.al.members(b["id"]):
            return f"{ui_icon('reject')} Вы не член блока."
        fresh = self.countries.get_object(actor.name)
        if (fresh.money or 0) < amount:
            return f"{ui_icon('reject')} Недостаточно средств."
        update_money(actor.name, -amount)
        total = self.al.add_treasury(b["id"], amount)
        return f"{ui_icon('treasury')} Внесено {int_format(amount)} {CURRENCY}. В казне: {int_format(total)} {CURRENCY}."

    # ───── голосования ─────
    async def _start_vote(self, b, kind: str, subject: str, amount: int, initiator: str) -> str:
        now = int(time.time())
        if kind == "grant":
            if "fund" not in self._arts(b):
                return f"{ui_icon('reject')} В уставе нет статьи «Общий фонд»."
            if amount < A.GRANT_MIN or amount > (b["treasury"] or 0):
                return (f"{ui_icon('reject')} Сумма должна быть от {int_format(A.GRANT_MIN)} и не больше казны "
                        f"({int_format(b['treasury'] or 0)} {CURRENCY}).")
        if self.al.open_vote_like(b["id"], kind, subject):
            return f"{ui_icon('reject')} Такое голосование уже идёт."
        vid = self.al.create_vote(b["id"], kind, subject, amount, initiator, now, now + A.VOTE_TTL)
        v = self.al.get_vote(vid)
        if initiator in self._electorate(v, b):
            self.al.cast(vid, initiator, True)
        if await self._evaluate(vid, final=False):
            v = self.al.get_vote(vid)
            return (f"{ui_icon('vote')} Решение принято сразу (большинство). "
                    if v["status"] == "passed" else f"{ui_icon('reject')} Решение отклонено. ") + self._last_result
        vm = A.VOTES[kind]
        for m in self._electorate(v, b):
            if m != initiator:
                await self._dm(m, components=self._vote_dm_panel(vid, m).components)
        return (f"{ui_icon('vote')} «{vm['label']}: {self._vote_subject(v)}» вынесено на голосование "
                f"({A.VOTE_TTL // 3600}ч). Члены получили бюллетени в ЛС.")

    _last_result = ""

    async def _evaluate(self, vid: int, final: bool) -> bool:
        """Проверка исхода. True — голосование закрыто (и эффект применён)."""
        v = self.al.get_vote(vid)
        if not v or v["status"] != "open":
            return False
        b = self.al.get(v["bloc_id"])
        if not b or b["status"] != "active":
            self.al.close_vote(vid, "failed")
            return True
        elect = self._electorate(v, b)
        ballots = self.al.ballots(vid)
        yes = sum(1 for c, y in ballots.items() if y and c in elect)
        no = sum(1 for c, y in ballots.items() if not y and c in elect)
        outcome = A.vote_outcome(yes, no, len(elect), final)
        if not outcome:
            return False
        self.al.close_vote(vid, outcome)
        self._last_result = await self._apply_vote(v, b, outcome == "passed")
        return True

    async def _apply_vote(self, v, b, passed: bool) -> str:
        kind, subj = v["kind"], v["subject"]
        vm = A.VOTES.get(kind, {"label": kind, "icon": "vote"})
        now = int(time.time())
        tag = self._tag(b)
        if not passed:
            res = f"{ui_icon('reject')} **{tag}**: отклонено — {vm['label'].lower()}: {self._vote_subject(v)}."
            if kind == "apply":
                await self._dm(subj, text=f"{ui_icon('reject')} Блок **{tag}** отклонил вашу заявку.")
            await self._dm_members(b, res)
            return res
        if kind == "invite":
            block = self._join_block(b, subj, now)
            if block:
                res = f"{ui_icon('reject')} **{tag}**: пригласить {subj} нельзя — {block}."
            else:
                iid = self.al.create_invite(b["id"], subj, now, now + A.INVITE_TTL)
                await self._dm(subj, components=self._invite_panel(iid).components)
                res = f"{ui_icon('invite')} **{tag}** приглашает {self._obj(subj).flag} **{subj}** — ждём ответа."
                await self._post(res)
        elif kind == "apply":
            block = self._join_block(b, subj, now)
            if block:
                res = f"{ui_icon('reject')} Заявка {subj} одобрена, но вступить нельзя: {block}."
                await self._dm(subj, text=res)
            else:
                res = await self._join(b, subj)
        elif kind == "expel":
            if subj in self.al.members(b["id"]):
                self.al.remove_member(b["id"], subj)
                self.al.add_cohesion(b["id"], A.COH_EXPEL)
                self.cooldown.set_cooldown(f"blocleave_{b['kind']}", now + A.LEAVE_CD, subj)
                if b["leader"] == subj:
                    await self._fix_leader(b)
                res = f"{ui_icon('expel')} **{tag}** исключает {self._obj(subj).flag} **{subj}** из блока."
                await self._post(res, WARNING_COLOR)
                await self._dm(subj, text=f"{ui_icon('expel')} Вас исключили из блока **{tag}**.")
            else:
                res = f"{ui_icon('reject')} {subj} уже не в блоке."
        elif kind in ("art_add", "art_rem"):
            arts = set(self._arts(b))
            if kind == "art_add":
                arts.add(subj)
            elif subj != A.KINDS[b["kind"]]["core"]:
                arts.discard(subj)
            self.al.set_articles(b["id"], A.dump_articles(arts))
            word = "принимает" if kind == "art_add" else "отменяет"
            res = f"{ui_icon('charter')} **{tag}** {word} статью устава: **{A.article_label(subj)}**."
            await self._post(res)
        elif kind == "grant":
            fresh = self.al.get(b["id"])
            if v["amount"] > (fresh["treasury"] or 0) or subj not in self.al.members(b["id"]):
                res = f"{ui_icon('reject')} **{tag}**: субсидия {subj} не выдана — не хватает казны."
            else:
                self.al.add_treasury(b["id"], -v["amount"])
                update_money(subj, v["amount"])
                res = (f"{ui_icon('treasury')} **{tag}** выделяет {self._obj(subj).flag} **{subj}** субсидию "
                       f"**{int_format(v['amount'])} {CURRENCY}** из общего фонда.")
                await self._post(res, SUCCESS_COLOR)
        elif kind == "leader":
            if subj in self.al.members(b["id"]):
                old = b["leader"]
                self.al.set_leader(b["id"], subj)
                res = (f"{ui_icon('leader')} **{tag}**: вотум недоверия — лидером становится "
                       f"{self._obj(subj).flag} **{subj}** вместо {old}.")
                await self._post(res, WARNING_COLOR)
            else:
                res = f"{ui_icon('reject')} {subj} уже не в блоке."
        else:
            res = ""
        if res:
            await self._dm_members(b, res, skip=(subj,) if kind in ("apply",) else ())
        return res

    async def _on_ballot(self, inter, args):
        await self._defer(inter)
        actor = self._actor(inter.author.id)
        if not actor or len(args) < 2 or not args[0].isdigit():
            return
        vid = int(args[0])
        v = self.al.get_vote(vid)
        b = self.al.get(v["bloc_id"]) if v else None
        me = actor.name
        note = None
        if v and b and v["status"] == "open" and me in self._electorate(v, b) and me not in self.al.ballots(vid):
            self.al.cast(vid, me, args[1] == "y")
            if await self._evaluate(vid, final=False):
                note = self._last_result
            else:
                note = f"{ui_icon('check')} Голос учтён."
        s = self._session(inter.author.id)
        # голосовали из панели — вернём панель голосования, из ЛС-бюллетеня — бюллетень
        if s["view"] == "vote" and s["vote"] == vid and b:
            await inter.edit_original_message(components=self._render(inter.author.id, note).components)
        else:
            await inter.edit_original_message(components=self._vote_dm_panel(vid, me, note).components)

    async def _on_invite_answer(self, inter, args):
        await self._defer(inter)
        actor = self._actor(inter.author.id)
        if not actor or len(args) < 2 or not args[0].isdigit():
            return
        iid = int(args[0])
        inv = self.al.get_invite(iid)
        b = self.al.get(inv["bloc_id"]) if inv else None
        if not inv or inv["status"] != "pending" or inv["country"] != actor.name or not b or b["status"] != "active":
            await inter.edit_original_message(components=self._invite_panel(iid).components)
            return
        if args[1] != "yes":
            self.al.set_invite_status(iid, "declined")
            await self._dm_members(b, f"{ui_icon('reject')} {actor.flag} **{actor.name}** отклонила приглашение "
                                      f"в **{self._tag(b)}**.")
            note = f"{ui_icon('reject')} Вы отклонили приглашение."
        else:
            block = self._join_block(b, actor.name, int(time.time()))
            if block:
                note = f"{ui_icon('reject')} Вступить нельзя: {block}."
            else:
                self.al.set_invite_status(iid, "accepted")
                note = await self._join(b, actor.name)
        await inter.edit_original_message(components=self._invite_panel(iid, note).components)

    async def _join(self, b, country: str) -> str:
        now = int(time.time())
        self.al.add_member(b["id"], country, now)
        o = self._obj(country)
        ratify = (f"\n-# Коллективная оборона для новичка вступит в силу через {A.RATIFY_S // 3600}ч (ратификация)."
                  if b["kind"] == "military" else "")
        res = f"{self._kicon(b['kind'])} {o.flag} **{country}** вступает в **{self._tag(b)}**!{ratify}"
        await self._post(res, SUCCESS_COLOR)
        await self._dm_members(b, res, skip=(country,))
        return res

    async def _leave(self, b, country: str, how: str) -> str:
        now = int(time.time())
        members = [m for m in self.al.members(b["id"]) if m != country]
        self.al.remove_member(b["id"], country)
        self.cooldown.set_cooldown(f"blocleave_{b['kind']}", now + A.LEAVE_CD, country)
        for m in members:
            self.dip.add_relation(country, m, A.LEAVE_REL_HIT)
        await self._post(f"{ui_icon('leave_bloc')} {self._obj(country).flag} **{country}** {how} из "
                         f"**{self._tag(b)}**.", WARNING_COLOR)
        if not members:
            self.al.dissolve(b["id"])
            await self._post(f"{ui_icon('split')} Блок **{self._tag(b)}** прекратил существование.", WARNING_COLOR)
        elif b["leader"] == country:
            await self._fix_leader(b)
        return (f"{ui_icon('leave_bloc')} Вы вышли из **{self._tag(b)}**. Вступить в блок этого типа можно "
                f"через {A.LEAVE_CD // 3600}ч.")

    async def _fix_leader(self, b):
        members = self.al.members(b["id"])
        if not members:
            return
        new = members[0]   # старейший член
        self.al.set_leader(b["id"], new)
        await self._post(f"{ui_icon('leader')} **{self._tag(b)}**: новым лидером становится "
                         f"{self._obj(new).flag} **{new}**.")
        await self._dm(new, text=f"{ui_icon('leader')} Вы — новый лидер блока **{self._tag(b)}**.")

    # ═══════════════ API ДЛЯ ДРУГИХ МЕХАНИК ═══════════════
    def bloc_of(self, country: str, kind: str):
        return self.al.bloc_of(country, kind)

    def defense_allies(self, defender: str, aggressor: str) -> list[tuple[str, dict]]:
        """Кого звать в войну: ратифицированные члены военного блока жертвы (статья обороны работает)."""
        b = self.al.bloc_of(defender, "military")
        if not b or not self._works(b, "defense"):
            return []
        now = int(time.time())
        return [(m, b) for m in self.al.members(b["id"])
                if m not in (defender, aggressor) and self._ratified(b, m, now)]

    def base_partners(self, country: str) -> list[str]:
        """Право прохода по статье «Военные базы»."""
        b = self.al.bloc_of(country, "military")
        if not b or not self._works(b, "bases"):
            return []
        return [m for m in self.al.members(b["id"]) if m != country]

    def command_mult(self, side_members: list[str]) -> float:
        """Объединённое командование: ≥2 члена одного блока на одной стороне войны."""
        best = 1.0
        seen = set()
        for m in side_members:
            b = self.al.bloc_of(m, "military")
            if not b or b["id"] in seen:
                continue
            seen.add(b["id"])
            n = sum(1 for x in side_members if x in set(self.al.members(b["id"])))
            w = self._works(b, "command")
            if n >= 2 and w:
                best = max(best, 1.0 + A.COMMAND_BONUS * w)
        return round(best, 3)

    def umbrella_protectors(self, country: str) -> list[str]:
        """Ядерные державы военного блока страны, если в уставе есть «Ядерный зонтик»."""
        b = self.al.bloc_of(country, "military")
        nuc = self.bot.get_cog("NuclearCog")
        if not b or not nuc or not self._works(b, "umbrella"):
            return []
        return [m for m in self.al.members(b["id"]) if m != country and nuc.status_of(m) == "power"]

    def ult_allies(self, country: str) -> list[tuple[str, float]]:
        """Члены военного блока и вес их силы для ультиматумов (× сплочённость)."""
        b = self.al.bloc_of(country, "military")
        if not b:
            return []
        w = A.ULT_WEIGHT * self._mult(b)
        return [(m, w) for m in self.al.members(b["id"]) if m != country] if w else []

    def counter_bonus(self, country: str) -> int:
        b = self.al.bloc_of(country, "military")
        return A.intel_bonus(self._works(b, "intel")) if b else 0

    def sanction_shield(self, country: str) -> float:
        b = self.al.bloc_of(country, "economic")
        return round(A.CURRENCY_SHIELD * self._works(b, "currency"), 3) if b else 0.0

    def income_lines(self, country: str, total_income: int) -> list[tuple[str, int]]:
        """Строки авто-дохода от блоков. Взносы в фонд сразу зачисляются в казну."""
        out = []
        base = total_income
        eco = self.al.bloc_of(country, "economic")
        if eco and base > 0:
            others = len(self.al.members(eco["id"])) - 1
            w = self._works(eco, "market")
            if w and others > 0:
                d = round(base * (A.market_mult(others, w) - 1))
                if d:
                    out.append((f"Общий рынок [{eco['tag']}]", d))
            w = self._works(eco, "customs")
            if w:
                d = round(base * A.CUSTOMS_BONUS * w)
                if d:
                    out.append((f"Таможенный союз [{eco['tag']}]", d))
        for b in self.al.blocs_of(country):
            if "fund" in self._arts(b) and base > 0 and self._mult(b) > 0:
                fee = round(base * A.FUND_RATE)
                if fee:
                    self.al.add_treasury(b["id"], fee)
                    out.append((f"Взнос в фонд [{b['tag']}]", -fee))
        return out

    def can_sanction(self, sanctioner: str, target: str) -> str:
        """Санкции против члена своего экономического союза запрещены."""
        b = self.al.bloc_of(sanctioner, "economic")
        if b and target in self.al.members(b["id"]):
            return f"{target} — член вашего экономического союза **{self._tag(b)}**. Санкции внутри союза невозможны."
        return ""

    def snapshot(self) -> dict:
        """Снимок блоков для расчёта равновесия отношений (один раз на тик)."""
        member_of: dict[str, dict[str, int]] = {}
        arts: dict[int, list] = {}
        mults: dict[int, float] = {}
        for b in self.al.active():
            arts[b["id"]] = self._arts(b)
            mults[b["id"]] = self._mult(b)
            for m in self.al.members(b["id"]):
                member_of.setdefault(m, {})[b["kind"]] = b["id"]
        # конфронтация военных блоков: член X воюет/санкционирует члена Y
        rivals = set()
        hostile = [(w["attacker"], w["defender"]) for w in self.war.all_active()]
        hostile += [(s["sanctioner"], s["target"]) for s in self.sanc.all_active()]
        for x, y in hostile:
            bx = member_of.get(x, {}).get("military")
            by = member_of.get(y, {}).get("military")
            if bx and by and bx != by:
                rivals.add(tuple(sorted((bx, by))))
        return {"member_of": member_of, "arts": arts, "mults": mults, "rivals": rivals}

    def relation_factors(self, a: str, b: str, snap: dict) -> list[tuple[str, float]]:
        f = []
        ma, mb = snap["member_of"].get(a, {}), snap["member_of"].get(b, {})
        if ma.get("military") and ma.get("military") == mb.get("military"):
            f.append(("Один военный блок", A.EQ_SAME_MIL))
        if ma.get("economic") and ma.get("economic") == mb.get("economic"):
            f.append(("Один экономический союз", A.EQ_SAME_ECO))
        xa, xb = ma.get("military"), mb.get("military")
        if xa and xb and tuple(sorted((xa, xb))) in snap["rivals"]:
            f.append(("Противостояние блоков", A.EQ_RIVAL_BLOCS))
        return f

    def trade_k(self, a: str, b: str, snap: dict) -> float:
        """Таможенный союз: торговля внутри союза сближает сильнее."""
        ea = snap["member_of"].get(a, {}).get("economic")
        if ea and ea == snap["member_of"].get(b, {}).get("economic") and "customs" in snap["arts"].get(ea, []) \
                and snap["mults"].get(ea, 0) > 0:
            return A.CUSTOMS_TRADE_K
        return 1.0

    def context(self, country: str) -> str:
        """Блоки страны — для ИИ (новости, арбитр войны)."""
        lines = []
        for b in self.al.blocs_of(country):
            members = [m for m in self.al.members(b["id"]) if m != country]
            lines.append(f"{A.kind_label(b['kind'])} {self._tag(b)} (сплочённость {b['cohesion']:.0f}"
                         f"{', лидер' if b['leader'] == country else ''}): члены — {', '.join(members) or 'нет'}; "
                         f"устав — {', '.join(A.article_label(x) for x in self._arts(b))}.")
        return "\n".join(lines) or "В блоках не состоит."

    def map_palette(self, kind: str) -> tuple[dict, list]:
        """→ ({страна: rgb}, [(тег, имя, rgb, членов)]) для карты блоков."""
        palette, legend = {}, []
        for b in self.al.active(kind):
            col = A.bloc_color(b["color_idx"] or 0)
            members = self.al.members(b["id"])
            for m in members:
                palette[m] = col
            legend.append((b["tag"], b["name"], col, len(members)))
        return palette, legend

    # ───── хуки событий других механик ─────
    async def on_war_declared(self, aggressor: str, defender: str) -> str:
        """Война внутри блока = предательство: агрессора исключают, репутация падает."""
        notes = []
        for b in self.al.blocs_of(aggressor):
            if defender in self.al.members(b["id"]):
                self.al.remove_member(b["id"], aggressor)
                self.cooldown.set_cooldown(f"blocleave_{b['kind']}", int(time.time()) + A.LEAVE_CD, aggressor)
                self.dip.add_reputation(aggressor, A.BETRAYAL_REP)
                self.al.add_cohesion(b["id"], A.COH_EXPEL)
                await self._post(
                    f"{ui_icon('betrayal')} **РАСКОЛ В БЛОКЕ {self._tag(b)}.** {self._obj(aggressor).flag} "
                    f"**{aggressor}** напала на члена блока {self._obj(defender).flag} **{defender}** и "
                    f"исключена. Репутация {A.BETRAYAL_REP}.", ERROR_COLOR)
                if b["leader"] == aggressor:
                    await self._fix_leader(b)
                if not self.al.members(b["id"]):
                    self.al.dissolve(b["id"])
                notes.append(f"{ui_icon('betrayal')} Вы исключены из {self._tag(b)} за нападение на члена блока.")
        return "\n".join(notes)

    def on_call_result(self, ally: str, defender: str, joined: bool):
        b = self.al.bloc_of(defender, "military")
        if b and ally in self.al.members(b["id"]):
            self.al.add_cohesion(b["id"], A.COH_CALL_JOIN if joined else A.COH_CALL_REFUSE)

    async def on_spy_exposed(self, actor: str, target: str):
        for b in self.al.blocs_of(actor):
            if target in self.al.members(b["id"]):
                self.al.add_cohesion(b["id"], A.COH_SPY_EXPOSED)
                await self._post(f"{ui_icon('exposed')} Скандал в **{self._tag(b)}**: {self._obj(actor).flag} "
                                 f"**{actor}** шпионила против союзника {self._obj(target).flag} **{target}**. "
                                 f"Сплочённость блока {A.COH_SPY_EXPOSED:.0f}.", WARNING_COLOR)

    async def on_sanctions_imposed(self, sanctioner: str, target: str, pkgs: list[str]) -> str:
        """Единая санкционная политика: остальным членам — предложение присоединиться."""
        b = self.al.bloc_of(sanctioner, "economic")
        if not b or not self._works(b, "sanctions") or target in self.al.members(b["id"]):
            return ""
        asked = []
        for m in self.al.members(b["id"]):
            if m in (sanctioner, target) or self.sanc.active_between(m, target):
                continue
            await self._dm(m, components=self._sanction_offer(b, sanctioner, target, pkgs).components)
            asked.append(m)
        if not asked:
            return ""
        return f"{ui_icon('sanctions')} Партнёры по **{self._tag(b)}** получили предложение присоединиться: " \
               f"{', '.join(asked)}."

    def _sanction_offer(self, b, sanctioner: str, target: str, pkgs: list[str], result: str | None = None) -> Panel:
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('sanctions')} Единая санкционная политика · {self._tag(b)}\n"
            f"{self._obj(sanctioner).flag} **{sanctioner}** ввела санкции против {self._obj(target).flag} "
            f"**{target}** и призывает партнёров по союзу присоединиться.\n"
            f"-# Коалиция складывает рычаги — удар по цели сильнее, а цена каждому ниже. "
            f"Присоединение — те же пакеты за ваш счёт; сплочённость союза +{A.COH_SANCTION_JOIN:.0f}.")]
        if result:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(result))
        else:
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.danger, label="Присоединиться к санкциям", emoji=_pe("sanctions"),
                custom_id=cid("aln", "sjoin", b["id"], target, "+".join(pkgs))[:100])))
        return self._container(items, WARNING_COLOR)

    async def _on_sanction_join(self, inter, args):
        await self._defer(inter)
        actor = self._actor(inter.author.id)
        if not actor or len(args) < 3 or not args[0].isdigit():
            return
        b = self.al.get(int(args[0]))
        target, pkgs = args[1], [p for p in args[2].split("+") if p]
        sc = self.bot.get_cog("SanctionsCog")
        if not b or not sc:
            note = f"{ui_icon('reject')} Недоступно."
        else:
            ok, note = await sc.impose_for(actor, target, pkgs)
            if ok:
                self.al.add_cohesion(b["id"], A.COH_SANCTION_JOIN)
        head = f"## {ui_icon('sanctions')} Единая санкционная политика" + (f" · {self._tag(b)}" if b else "")
        await inter.edit_original_message(components=self._note_panel(
            f"{head}\nСанкции против {self._obj(target).flag} **{target}**.\n\n{note}",
            SUCCESS_COLOR if note and "reject" not in note else WARNING_COLOR).components)

    # ═══════════════ ЧАСОВОЙ ЦИКЛ ═══════════════
    def _cohesion_target(self, b, members: list[str], enemies: dict) -> float:
        pairs = [(x, y) for i, x in enumerate(members) for y in members[i + 1:]]
        avg_rel = (sum(self.dip.get_relation(x, y) for x, y in pairs) / len(pairs)) if pairs else 40.0
        ideos = [self.politics.get(m)[0] for m in members]
        ideos = [i for i in ideos if i and i != "none"]
        share = (Counter(ideos).most_common(1)[0][1] / len(members)) if ideos and len(members) > 1 else 0.0
        foes = Counter(f for m in members for f in enemies.get(m, set()) if f not in members)
        common = any(n >= 2 for n in foes.values())
        extra = max(0, len(self._arts(b)) - 1)
        return A.cohesion_target(avg_rel, share, common, extra)

    async def _migrate_old_alliances(self):
        """Разовая миграция: парный «Военный союз» → ненападение + право прохода."""
        now = int(time.time())
        rows = self.dip._query_all("SELECT * FROM diplo_treaties WHERE kind = 'alliance' AND status IN ('active', 'pending')")
        for t in rows:
            if t["status"] == "pending":
                self.dip.set_treaty_status(t["id"], "rejected", now)
                self.dip.add_influence(t["proposer"], t["cost"] or 0)
                continue
            self.dip.set_treaty_status(t["id"], "ended", now)
            for kind in ("nonaggr", "transit"):
                if not self.dip.treaty_between(t["a"], t["b"], kind):
                    tid = self.dip.propose(kind, t["a"], t["b"], 0, now)
                    self.dip.set_treaty_status(tid, "active", now)
            for x, y in ((t["a"], t["b"]), (t["b"], t["a"])):
                await self._dm(x, text=(
                    f"{ui_icon('alliance')} **Военные союзы реформированы.** Ваш союз с {self._obj(y).flag} **{y}** "
                    f"преобразован в пакт о ненападении + право прохода. Чтобы снова защищать друг друга — "
                    f"создайте военный блок: `!альянс`."))

    async def _tick(self, now: int):
        if not self._migrated:
            self._migrated = True
            try:
                await self._migrate_old_alliances()
            except Exception:
                log.exception("миграция старых союзов")
        enemies: dict[str, set] = {}
        for w in self.war.all_active():
            enemies.setdefault(w["attacker"], set()).add(w["defender"])
            enemies.setdefault(w["defender"], set()).add(w["attacker"])
        for sx in self.sanc.all_active():
            enemies.setdefault(sx["sanctioner"], set()).add(sx["target"])
        alive = set(self.countries.get_object_names())
        for b in self.al.active():
            for m in self.al.members(b["id"]):
                if m not in alive:
                    self.al.remove_member(b["id"], m)
            members = self.al.members(b["id"])
            if not members:
                self.al.dissolve(b["id"])
                await self._post(f"{ui_icon('split')} Блок **{self._tag(b)}** распался.", WARNING_COLOR)
                continue
            if b["leader"] not in members:
                await self._fix_leader(b)
            if len(members) == 1 and now - (b["created_at"] or now) > A.SOLO_TTL:
                self.al.dissolve(b["id"])
                await self._post(f"{ui_icon('split')} Блок **{self._tag(b)}** распущен — за "
                                 f"{A.SOLO_TTL // 3600}ч к нему никто не присоединился.", WARNING_COLOR)
                await self._dm(members[0], text=f"{ui_icon('split')} Ваш блок **{self._tag(b)}** распущен: "
                                                f"никто не вступил.")
                continue
            old = b["cohesion"] or 0
            target = self._cohesion_target(b, members, enemies)
            new = A.drift(old, target)
            if new != old:
                self.al.set_cohesion(b["id"], new)
            if old >= A.COH_PARALYSIS > new:
                await self._post(f"{ui_icon('split')} **{self._tag(b)}** парализован: сплочённость упала ниже "
                                 f"{A.COH_PARALYSIS:.0f}, статьи устава перестали действовать.", ERROR_COLOR)
            elif new >= A.COH_PARALYSIS > old:
                await self._post(f"{ui_icon('cohesion')} **{self._tag(b)}** преодолел кризис — устав снова действует.",
                                 SUCCESS_COLOR)
        for v in self.al.votes_due(now):
            try:
                await self._evaluate(v["id"], final=True)
            except Exception:
                log.exception("голосование #%s", v["id"])
        for inv in self.al.invites_due(now):
            self.al.set_invite_status(inv["id"], "expired")

    @tasks.loop(hours=1)
    async def bloc_tick(self):
        try:
            await self._tick(int(time.time()))
        except Exception:
            log.exception("сбой цикла альянсов")

    @bloc_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="alliance", aliases=["альянс", "альянсы", "блок", "блоки", "bloc"])
    async def alliance_cmd(self, ctx: commands.Context):
        actor = self._actor(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(
                description="Альянсы доступны только зарегистрированным странам. Откройте панель регистрации.",
                color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(view="hub", bloc=None, act=None, subject=None, page=0, vote=None)
        try:
            await ctx.author.send(components=self._render(ctx.author.id).components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(
                description="Не могу написать в ЛС. Включите личные сообщения от участников сервера "
                            "и повторите `!альянс`.", color=WARNING_COLOR))
            return
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('alliance')} Панель альянсов отправлена вам в **личные сообщения**.",
                color=COMMAND_COLOR), delete_after=12)


def setup(bot: commands.Bot):
    bot.add_cog(AllianceCog(bot))
