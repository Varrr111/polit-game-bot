"""
🚫 САНКЦИИ — !sanctions

Страна/коалиция бьёт по экономике другой без войны. Сила ∝ рычагу санкционеров
(коалиция складывается), ВЗАИМНАЯ ЦЕНА санкционеру ∝ 1/его рычаг (давить гиганта
в одиночку бьёт по тебе же — Ватикан не задушит США). 3 пакета: финансовые,
эмбарго, технологические. Тяжёлые санкции бьют по счастью/легитимности цели →
оппозиция → смена режима (связка с политикой). Контригра: устойчивость, новые
партнёры, контрсанкции. Снимает только санкционер.

Эффекты дохода считаются почасовым циклом и пишутся в sanction_effect (экономика
читает дёшево). Публичный канал #санкции. Только кастом-иконки.
"""

import logging
import time

import disnake
from disnake.ext import commands, tasks

import config
from utils import (
    Countries, Politics, CountryUpgrades, Cooldown, Sanctions,
    update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
from utils.upgrades import country_income, country_gdp
import utils.sanctions as SA
import utils.politics as POL

log = logging.getLogger("sanctions")

_PAGE = 25


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


class SanctionsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.politics = Politics()
        self.upgrades = CountryUpgrades()
        self.cooldown = Cooldown()
        self.sanc = Sanctions()
        self._sessions: dict[int, dict] = {}
        self.sanction_tick.start()

    def cog_unload(self):
        self.sanction_tick.cancel()

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    # ───── сессия / сила ─────
    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"target": None, "packages": set()}
            self._sessions[uid] = s
        return s

    def _actor(self, uid: int):
        return self.countries.get_object_by_user(uid)

    def _power(self, name: str, cache: dict | None = None) -> float:
        if cache is not None and name in cache:
            return cache[name]
        gdp = country_gdp(name)   # динамический ВВП (растёт с ветками развития)
        dev = sum(self.upgrades.get_levels(name).values())
        p = SA.econ_power(country_income(name), gdp, dev)
        if cache is not None:
            cache[name] = p
        return p

    # ───── пересчёт эффекта для одной страны ─────
    def _recompute(self, name: str, now: int, cache: dict):
        res = self.sanc.get_resilience(name)
        # давление на доход (как цель)
        pressure = 0.0
        for s in self.sanc.active_against(name):
            lev = SA.leverage(self._power(s["sanctioner"], cache), self._power(name, cache))
            pressure += SA.target_pressure(lev, SA.packages_weight((s["packages"] or "").split(",")), res)
        target_mult = SA.target_income_mult(pressure)
        # взаимная цена (как санкционер)
        cost = 0.0
        for s in self.sanc.active_by(name):
            lev = SA.leverage(self._power(name, cache), self._power(s["target"], cache))
            cost += SA.cost_pressure(lev, SA.packages_weight((s["packages"] or "").split(",")))
        cost_mult = SA.cost_income_mult(cost)
        self.sanc.set_effect(name, target_mult, cost_mult, now)
        return target_mult, cost_mult

    # ═══════════════ ПАНЕЛЬ ═══════════════
    def _cont(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _panel(self, actor) -> Panel:
        name = actor.name
        oid = actor.user
        tmult, cmult = self.sanc.effect_of(name)
        res = self.sanc.get_resilience(name)
        against = self.sanc.active_against(name)
        by = self.sanc.active_by(name)
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('sanctions')} Санкции · {actor.flag} {name}")]
        # статус цели
        line = (f"{ui_icon('financial')} Санкции против вас: доход **×{tmult:.2f}** "
                f"({SA.mult_word(tmult)})\n"
                f"{ui_icon('embargo')} Ваши санкции (цена вам): доход **×{cmult:.2f}**\n"
                f"{ui_icon('resilience')} Экономическая устойчивость: **{int(res)}/100**")
        items.append(disnake.ui.TextDisplay(line))
        if against:
            who = ", ".join(f"{(self.countries.get_object(s['sanctioner']) or _Dummy()).flag}"
                            f"{s['sanctioner']}" for s in against[:8])
            items.append(disnake.ui.TextDisplay(f"-# ПРОТИВ ВАС ({len(against)}): {who}"))
        if by:
            whom = ", ".join(f"{(self.countries.get_object(s['target']) or _Dummy()).flag}"
                             f"{s['target']}" for s in by[:8])
            items.append(disnake.ui.TextDisplay(f"-# ВЫ САНКЦИОНИРУЕТЕ ({len(by)}): {whom}"))
        items.append(disnake.ui.Separator())
        B = disnake.ButtonStyle
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.danger, label="Ввести санкции", emoji=_pe("sanctions"),
                              custom_id=cid("sanc", "impose", oid)),
            disnake.ui.Button(style=B.secondary, label="Снять санкции", emoji=_pe("accept"),
                              disabled=(not by), custom_id=cid("sanc", "lift", oid)),
            disnake.ui.Button(style=B.success, label="Устойчивость", emoji=_pe("resilience"),
                              custom_id=cid("sanc", "resil", oid))))
        return self._cont(items)

    def _impose_panel(self, uid, actor) -> Panel:
        s = self._session(uid)
        items = [disnake.ui.TextDisplay(f"## {ui_icon('sanctions')} Ввести санкции")]
        names = sorted(n for n in self.countries.get_object_names() if n != actor.name)
        topts = []
        for n in names[:25]:
            o = self.countries.get_object(n)
            topts.append(disnake.SelectOption(label=f"{o.flag} {n}"[:100], value=n,
                                              default=(n == s["target"])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("sanc", "tgt"), placeholder="Цель санкций…", options=topts)))
        if s["target"]:
            cache = {}
            lev = SA.leverage(self._power(actor.name, cache), self._power(s["target"], cache))
            tobj = self.countries.get_object(s["target"])
            w = SA.packages_weight(list(s["packages"]))
            res = self.sanc.get_resilience(s["target"])
            # прогноз (только от этой одной санкции, без учёта чужих)
            pred_t = SA.target_income_mult(SA.target_pressure(lev, w, res))
            pred_c = SA.cost_income_mult(SA.cost_pressure(lev, w)) if w else 1.0
            items.append(disnake.ui.TextDisplay(
                f"-# Цель: {tobj.flag} {s['target']} · ваш рычаг **×{lev:.2f}**\n"
                f"{ui_icon('financial')} Прогноз удара по цели: доход **×{pred_t:.2f}**\n"
                f"{ui_icon('embargo')} Ваша цена: доход **×{pred_c:.2f}** · стоимость ввода "
                f"**{int_format(SA.packages_cost(list(s['packages'])))} {CURRENCY}**"))
            popts = [disnake.SelectOption(
                label=SA.PACKAGES[k]["label"], value=k, emoji=_pe(SA.PACKAGES[k]["icon"]),
                description=f"{SA.PACKAGES[k]['desc']}"[:100], default=(k in s["packages"]))
                for k in SA.PACKAGE_KEYS]
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("sanc", "pkg"), placeholder="Пакеты санкций…",
                min_values=0, max_values=len(popts), options=popts)))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Ввести",
                                  emoji=_pe("sanctions"), disabled=(not s["packages"]),
                                  custom_id=cid("sanc", "go"))))
        return self._cont(items, WARNING_COLOR)

    def _lift_panel(self, actor) -> Panel:
        by = self.sanc.active_by(actor.name)
        items = [disnake.ui.TextDisplay(f"## {ui_icon('accept')} Снять санкции")]
        if not by:
            items.append(disnake.ui.TextDisplay("-# Вы ни против кого не ввели санкции."))
            return self._cont(items)
        opts = []
        for s in by[:25]:
            t = self.countries.get_object(s["target"])
            pk = ", ".join(SA.package_label(p) for p in (s["packages"] or "").split(",") if p)
            opts.append(disnake.SelectOption(label=f"{(t.flag + ' ') if t else ''}{s['target']}"[:100],
                                             value=str(s["id"]), description=pk[:100]))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("sanc", "liftsel"), placeholder="Какие санкции снять…", options=opts)))
        return self._cont(items)

    def _resil_panel(self, actor) -> Panel:
        res = self.sanc.get_resilience(actor.name)
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('resilience')} Экономическая устойчивость\n"
            f"-# Текущая: **{int(res)}/100** · снижает укус санкций (импортозамещение).\n"
            f"-# Цена: **{int_format(SA.RESILIENCE_COST_PER_PT)} {CURRENCY}** за +1. Медленно спадает.")]
        B = disnake.ButtonStyle
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="+5", custom_id=cid("sanc", "buyres", "5")),
            disnake.ui.Button(style=B.success, label="+10", custom_id=cid("sanc", "buyres", "10")),
            disnake.ui.Button(style=B.success, label="+25", custom_id=cid("sanc", "buyres", "25"))))
        return self._cont(items)

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    def _guard(self, inter, args):
        oid = int(args[0]) if args and args[0].isdigit() else None
        return not (oid and inter.author.id != oid)

    @commands.Cog.listener("on_button_click")
    async def _sanc_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("sanc:"):
            return
        _, action, args = parse_cid(c)
        actor = self._actor(inter.author.id)
        if not actor:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        if action in ("impose", "lift", "resil") and not self._guard(inter, args):
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        if action == "impose":
            self._session(inter.author.id).update(target=None, packages=set())
            await inter.response.send_message(components=self._impose_panel(inter.author.id, actor).components, ephemeral=True)
        elif action == "lift":
            await inter.response.send_message(components=self._lift_panel(actor).components, ephemeral=True)
        elif action == "resil":
            await inter.response.send_message(components=self._resil_panel(actor).components, ephemeral=True)
        elif action == "go":
            await self._do_impose(inter, actor)
        elif action == "buyres":
            await self._buy_resilience(inter, actor, int(args[0]))

    @commands.Cog.listener("on_dropdown")
    async def _sanc_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("sanc:"):
            return
        _, action, _ = parse_cid(c)
        actor = self._actor(inter.author.id)
        if not actor:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        if action == "tgt":
            s["target"] = inter.values[0]
            await inter.response.edit_message(components=self._impose_panel(inter.author.id, actor).components)
        elif action == "pkg":
            s["packages"] = set(inter.values)
            await inter.response.edit_message(components=self._impose_panel(inter.author.id, actor).components)
        elif action == "liftsel":
            await self._do_lift(inter, actor, int(inter.values[0]))

    # ───── действия ─────
    async def _do_impose(self, inter, actor):
        await self._defer(inter)
        s = self._session(inter.author.id)
        target = s["target"]; pkgs = sorted(s["packages"])
        tobj = self.countries.get_object(target) if target else None
        if not tobj or target == actor.name or not pkgs:
            await inter.edit_original_message(components=self._impose_panel(inter.author.id, actor).components)
            return
        ok, note = await self.impose_for(actor, target, pkgs)
        if ok:
            s.update(target=None, packages=set())
        await inter.edit_original_message(components=self._cont(
            [disnake.ui.TextDisplay(note)], SUCCESS_COLOR if ok else WARNING_COLOR).components)

    async def impose_for(self, actor, target: str, pkgs: list[str]) -> tuple[bool, str]:
        """Ввод санкций страной actor (панель или присоединение к коалиции блока). → (ok, текст)."""
        actor = self.countries.get_object(actor.name) or actor
        tobj = self.countries.get_object(target) if target else None
        pkgs = sorted(p for p in pkgs if p in SA.PACKAGES)
        now = int(time.time())
        if not tobj or target == actor.name or not pkgs:
            return False, f"{ui_icon('reject')} Цель или пакеты недоступны."
        if self.sanc.active_between(actor.name, target):
            return False, (f"{ui_icon('reject')} Против {tobj.flag} {target} у вас уже есть санкции. "
                           "Сначала снимите их.")
        al = self.bot.get_cog("AllianceCog")
        block = al.can_sanction(actor.name, target) if al else ""
        if block:
            return False, f"{ui_icon('reject')} {block}"
        cdleft = int(self.cooldown.get_cooldown("sanctions", actor.name) - now)
        if cdleft > 0:
            return False, f"{ui_icon('sanctions')} Перезарядка: ещё {cdleft // 60}м."
        cost = SA.packages_cost(pkgs)
        if actor.money < cost:
            return False, f"{ui_icon('financial')} Нужно {int_format(cost)} {CURRENCY} на ввод санкций."
        update_money(actor.name, -cost)
        self.cooldown.set_cooldown("sanctions", now + SA.IMPOSE_COOLDOWN, actor.name)
        self.sanc.impose(actor.name, target, ",".join(pkgs), now)
        # мгновенный пересчёт эффекта обеих сторон
        cache = {}
        self._recompute(target, now, cache)
        self._recompute(actor.name, now, cache)
        await self._post_public(actor, tobj, pkgs, imposed=True)
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("sanctions", actor.name, target, f"{actor.name} ввела санкции против {target}")
        dip = self.bot.get_cog("DiplomacyCog")
        notes = [await dip.on_sanctions_imposed(actor.name, target) if dip else ""]
        if al:
            notes.append(await al.on_sanctions_imposed(actor.name, target, pkgs))
        extra = "\n".join(n for n in notes if n)
        return True, (f"{ui_icon('sanctions')} Санкции против {tobj.flag} {target} введены "
                      "и опубликованы в #санкции." + (f"\n{extra}" if extra else ""))

    async def _do_lift(self, inter, actor, sid):
        await self._defer(inter)
        s = self.sanc.get(sid)
        if not s or s["sanctioner"] != actor.name or s["status"] != "active":
            await inter.edit_original_message(components=self._lift_panel(actor).components)
            return
        target = s["target"]
        self.sanc.lift(sid)
        now = int(time.time())
        cache = {}
        self._recompute(target, now, cache)
        self._recompute(actor.name, now, cache)
        tobj = self.countries.get_object(target)
        if tobj:
            await self._post_public(actor, tobj, (s["packages"] or "").split(","), imposed=False)
        await inter.edit_original_message(components=self._cont(
            [disnake.ui.TextDisplay(f"{ui_icon('accept')} Санкции против {target} сняты.")], SUCCESS_COLOR).components)

    async def _buy_resilience(self, inter, actor, points):
        await self._defer(inter)
        fresh = self.countries.get_object(actor.name)
        cur = self.sanc.get_resilience(actor.name)
        points = min(points, int(SA.RESILIENCE_MAX - cur))
        cost = points * SA.RESILIENCE_COST_PER_PT
        if points <= 0:
            ok, note = False, "Устойчивость уже на максимуме."
        elif fresh.money < cost:
            ok, note = False, f"{ui_icon('financial')} Недостаточно средств: нужно {int_format(cost)} {CURRENCY}."
        else:
            update_money(actor.name, -cost)
            self.sanc.set_resilience(actor.name, cur + points)
            self._recompute(actor.name, int(time.time()), {})  # устойчивость снижает укус
            ok, note = True, (f"{ui_icon('resilience')} Устойчивость {int(cur)} → "
                              f"**{int(cur + points)}** (−{int_format(cost)} {CURRENCY})")
        await inter.edit_original_message(components=self._cont(
            [disnake.ui.TextDisplay(note)], SUCCESS_COLOR if ok else WARNING_COLOR).components)

    # ───── публичный канал ─────
    def _channel(self):
        ch_id = rid("CH_SANCTIONS", 0)
        if not ch_id:
            return None
        g = self.bot.get_guild(GUILD_ID)
        return (g.get_channel(ch_id) if g else None) or self.bot.get_channel(ch_id)

    async def _post_public(self, actor, tobj, pkgs, imposed: bool):
        channel = self._channel()
        if not channel:
            return
        pk = " · ".join(f"{ui_icon(SA.PACKAGES[p]['icon'])} {SA.package_label(p)}"
                        for p in pkgs if p in SA.PACKAGES)
        if imposed:
            desc = (f"{ui_icon('sanctions')} {actor.flag} **{actor.name}** вводит санкции против "
                    f"{tobj.flag} **{tobj.name}**:\n{pk}")
            color = ERROR_COLOR
        else:
            desc = (f"{ui_icon('accept')} {actor.flag} **{actor.name}** снимает санкции с "
                    f"{tobj.flag} **{tobj.name}**.")
            color = SUCCESS_COLOR
        try:
            await channel.send(embed=disnake.Embed(description=desc, color=color))
        except Exception:
            pass

    # ═══════════════ ЧАСОВОЙ ПЕРЕСЧЁТ + ВНУТРЕННИЙ УДАР ═══════════════
    @tasks.loop(hours=1)
    async def sanction_tick(self):
        try:
            now = int(time.time())
            cache: dict = {}
            for obj in self.countries.all_objects():
                try:
                    name = obj.name
                    target_mult, _cost = self._recompute(name, now, cache)
                    # устойчивость медленно спадает
                    res = self.sanc.get_resilience(name)
                    if res > 0:
                        self.sanc.set_resilience(name, max(0.0, res - SA.RESILIENCE_DECAY_PER_H))
                    # внутренний удар по политике при тяжёлых санкциях
                    depth = SA.bite_depth(target_mult)
                    if depth > 0:
                        self._apply_bite(name, obj, depth)
                except Exception:
                    log.exception("санкц. тик для %s", getattr(obj, "name", "?"))
        except Exception:
            log.exception("сбой цикла санкций")

    def _apply_bite(self, name, obj, depth):
        hap = _clamp((getattr(obj, "happiness", 50.0) or 0.0) - SA.BITE_HAP_PER_H * depth, 0, 100)
        self.countries.update_object(name, happiness=round(hap, 2))
        st = self.politics.get_state(name)
        self.politics.set_legitimacy(name, _clamp(st["legitimacy"] - SA.BITE_LEGIT_PER_H * depth, 0, 100))
        self.politics.set_opposition(name, _clamp(st["opposition"] + SA.BITE_OPP_PER_H * depth, 0, 100))

    @sanction_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="sanctions", aliases=["санкции", "sanction", "санкция"])
    async def sanctions_cmd(self, ctx: commands.Context):
        actor = self._actor(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(
                description="Санкции доступны только зарегистрированным странам.", color=ERROR_COLOR))
            return
        await ctx.send(components=self._panel(actor).components)


class _Dummy:
    flag = "🏳️"


def setup(bot: commands.Bot):
    bot.add_cog(SanctionsCog(bot))
