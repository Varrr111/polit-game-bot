"""
Государство: строй, религия, счастье, стабильность и ЛЕГИТИМНОСТЬ — живые.

Смена строя — ПРОЦЕСС, а не кнопка:
  • Реформа — только к соседнему строю (карта IDEOLOGY_ADJACENCY), при высоких
    стабильности/легитимности → переходный период (доход −15% через Effects).
  • Революция — к любому строю, только в кризис, бросок на успех, огромный риск
    (крах показателей, гражданская война, шанс провала).
  • Условия под каждый строй; религия «липкая» (волнения по религиозности).
  • Оппозиция крепнет при низкой легитимности и может СВЕРГНУТЬ режим (с предупреждениями).

  !state — панель государства · !invest <стаб|счастье> <сумма>

Только кастом-иконки (ui_icon / P.ideo_icon / P.rel_icon).
"""

import asyncio
import random
import time

import disnake
from disnake.ext import commands, tasks

from utils import (
    Countries, Politics, Effects, Army, CountryUpgrades,
    get_object, get_object_by_user, update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY,
    MAIN_ECO_CURATOR, PROFILE_ROLE, GUILD_ID, INCOME_CHANNEL,
)
from utils.ui import Panel, cid, parse_cid
from utils.serverconfig import rid
from utils.perms import is_staff
from utils.resources import ui_icon
from utils.upgrades import country_income
import utils.politics as P


def _emoji(s: str):
    try:
        return disnake.PartialEmoji.from_str(s)
    except Exception:
        return None


def _pe(slug: str):
    return _emoji(ui_icon(slug))


def _ctx_of(name: str) -> dict:
    """Состояние страны для проверки условий строя."""
    o = get_object(name)
    dev = sum(CountryUpgrades().get_levels(name).values())
    army = len(Army().formations_for(name))
    ideo, rel = Politics().get(name)
    return {"happiness": getattr(o, "happiness", 0) or 0,
            "stability": getattr(o, "stability", 0) or 0,
            "dev": dev, "army": army, "religion": rel}


# ─────────────────────────── ГЛАВНАЯ ПАНЕЛЬ ───────────────────────────
class StatePanel(Panel):
    def __init__(self, obj, st: dict, income: int, avatar_url: str | None = None):
        super().__init__(timeout=300)
        oid = obj.user
        ideology, religion = st["ideology"], st["religion"]
        legit = st["legitimacy"]; opp = st["opposition"]
        hap = getattr(obj, "happiness", 100.0) or 0.0
        stab = getattr(obj, "stability", 100.0) or 0.0
        im = P.income_multiplier(ideology, stab)
        now = int(time.time())
        in_transition = st["transition_until"] > now and st["transition_to"]

        header = (f"-# {getattr(obj, 'flag', '')} {obj.name}\n"
                  f"## {ui_icon('gov')} Государство\n"
                  f"-# {P.ideo_label(ideology)}  ·  {P.rel_label(religion)}")
        items: list = []
        if avatar_url:
            items.append(disnake.ui.Section(disnake.ui.TextDisplay(header),
                                            accessory=disnake.ui.Thumbnail(avatar_url)))
        else:
            items.append(disnake.ui.TextDisplay(header))

        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(
            f"-# КАЗНА\n# {int_format(obj.money)} {CURRENCY}\n"
            f"-# {ui_icon('up')} +{int_format(income)} {CURRENCY}/ч"
            + (f" · {ui_icon('reform')} идёт переход (доход −{int((1-P.REFORM_INCOME_MULT)*100)}%)" if in_transition else "")))

        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(
            f"{ui_icon('happy')} **Счастье** {P.bar(hap)} `{int(hap)}` · {P.mood_word(hap)}\n"
            f"{ui_icon('stability')} **Стабильность** {P.bar(stab)} `{int(stab)}` · {P.order_word(stab)}\n"
            f"{ui_icon('legitimacy')} **Легитимность** {P.bar(legit)} `{int(legit)}` · {P.legit_word(legit)}"))

        if opp > 10:
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon('opposition')} **Оппозиция** {P.bar(opp)} `{int(opp)}` · {P.opposition_word(opp)}"))

        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(
            f"-# МОДИФИКАТОРЫ ДОХОДА\n"
            f"{P.ideo_icon(ideology)} строй ×{P.ideo(ideology)['income']:.2f} · "
            f"{ui_icon('stability')} стабильность ×{P.stability_factor(stab):.2f}  →  **итог ×{im:.2f}**\n"
            f"-# {P.ideo(ideology)['desc']}"))

        items.append(disnake.ui.Separator())
        if in_transition:
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon('reform')} **Политический переход** к "
                f"**{P.ideo(st['transition_to'])['label']}** — завершится <t:{st['transition_until']}:R>."))
        else:
            B = disnake.ButtonStyle
            crisis = P.revolution_allowed(stab, legit)
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(label="Реформа", emoji=_pe("reform"), style=B.primary,
                                  custom_id=cid("state", "reform", oid)),
                disnake.ui.Button(label="Революция", emoji=_pe("revolution"), style=B.danger,
                                  disabled=(not crisis), custom_id=cid("state", "revo", oid)),
                disnake.ui.Button(label="Религия", emoji=_pe("gov"), style=B.secondary,
                                  custom_id=cid("state", "rel", oid))))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(label="Вложить в стабильность", emoji=_pe("stability"),
                              style=disnake.ButtonStyle.success, custom_id=cid("state", "invs", oid)),
            disnake.ui.Button(label="Вложить в счастье", emoji=_pe("happy"),
                              style=disnake.ButtonStyle.success, custom_id=cid("state", "invh", oid))))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


# ─────────────────────────── КОГ ───────────────────────────
class StateCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.politics = Politics()
        self.effects = Effects()
        from utils import Cooldown
        self.cooldown = Cooldown()
        self.politics_tick.start()

    def cog_unload(self):
        self.politics_tick.cancel()

    async def cog_check(self, ctx: commands.Context) -> bool:
        if not ctx.guild:
            return False
        if is_staff(ctx.author):
            return True
        if MAIN_ECO_CURATOR and ctx.guild.get_role(MAIN_ECO_CURATOR) in ctx.author.roles:
            return True
        if ctx.author.get_role(rid("PROFILE_ROLE", PROFILE_ROLE)):
            return True
        if get_object_by_user(ctx.author.id):
            return True
        await ctx.send(embed=disnake.Embed(description="Вы не зарегистрированы — откройте панель регистрации.", color=ERROR_COLOR))
        return False

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CheckFailure):
            return
        raise error

    def _income_of(self, obj) -> int:
        base = country_income(obj.name)
        ideology, _ = self.politics.get(obj.name)
        mult = P.income_multiplier(ideology, getattr(obj, "stability", 100.0) or 0.0)
        eff = self.effects.income_mult(obj.name, int(time.time()))
        return int(base * mult * eff)

    def _panel(self, obj, avatar_url=None) -> StatePanel:
        st = self.politics.get_state(obj.name)
        return StatePanel(obj, st, self._income_of(obj), avatar_url)

    # ───── команды ─────
    @commands.command(name="state", aliases=["государство", "профиль", "гос", "страна"])
    async def state_cmd(self, ctx):
        obj = get_object_by_user(ctx.author.id)
        if not obj:
            await ctx.send(embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR))
            return
        await ctx.send(components=self._panel(obj, ctx.author.display_avatar.url).components)

    @commands.command(name="invest", aliases=["вложить", "инвест"])
    async def invest_cmd(self, ctx, target: str | None = None, amount: str | None = None):
        obj = get_object_by_user(ctx.author.id)
        if not obj:
            await ctx.send(embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR))
            return
        t = (target or "").lower()
        if t in ("стабильность", "стаб", "stab", "s"):
            field, cost = "stability", P.INVEST_COST_PER_STAB
        elif t in ("счастье", "сч", "hap", "h"):
            field, cost = "happiness", P.INVEST_COST_PER_HAP
        else:
            await ctx.send(embed=disnake.Embed(
                description="`!invest стабильность <сумма>` или `!invest счастье <сумма>`", color=ERROR_COLOR))
            return
        try:
            money = int(str(amount).replace(" ", ""))
        except (TypeError, ValueError):
            await ctx.send(embed=disnake.Embed(description="Укажите сумму числом.", color=ERROR_COLOR))
            return
        await ctx.send(embed=self._do_invest(obj, field, cost, money))

    def _do_invest(self, obj, field: str, cost: int, money: int) -> disnake.Embed:
        fresh = get_object(obj.name)
        cur = getattr(fresh, field, 0.0) or 0.0
        if cur >= 100:
            return disnake.Embed(description="Показатель уже на максимуме (100).", color=WARNING_COLOR)
        if money < cost:
            return disnake.Embed(description=f"Минимум {int_format(cost)} {CURRENCY} (хватит на +1).", color=ERROR_COLOR)
        if fresh.money < money:
            return disnake.Embed(description=f"Недостаточно средств: нужно {int_format(money)} {CURRENCY}.", color=ERROR_COLOR)
        points = min(money // cost, int(100 - cur))
        if points <= 0:
            return disnake.Embed(description="Показатель уже на максимуме.", color=WARNING_COLOR)
        spent = points * cost
        update_money(obj.name, -spent)
        self.countries.update_object(obj.name, **{field: round(cur + points, 2)})
        word = "стабильность" if field == "stability" else "счастье"
        icon = ui_icon("stability") if field == "stability" else ui_icon("happy")
        return disnake.Embed(
            description=f"{icon} **{word}** {int(cur)} → **{int(cur + points)}** (+{points})\n-# −{int_format(spent)} {CURRENCY}",
            color=SUCCESS_COLOR)

    # ═══════════════ СУБ-ПАНЕЛИ (эфемерные) ═══════════════
    def _reform_panel(self, name: str, target: str | None = None) -> Panel:
        o = get_object(name)
        st = self.politics.get_state(name)
        ideo = st["ideology"]; legit = st["legitimacy"]
        stab = getattr(o, "stability", 0) or 0
        ok, reason = P.reform_ready(stab, legit)
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('reform')} Реформа\n"
            f"-# Текущий строй: {P.ideo_label(ideo)}\n"
            f"-# Переход к **соседнему** строю. Длительность {P.REFORM_DURATION_H} ч, "
            f"доход −{int((1-P.REFORM_INCOME_MULT)*100)}%, цена {int_format(P.REFORM_COST)} {CURRENCY}.")]
        if not ok:
            items.append(disnake.ui.TextDisplay(f"{ui_icon('reject')} Реформа недоступна: {reason}."))
            return self._cont(items, WARNING_COLOR)
        ctx = _ctx_of(name)
        avail = []
        for t in P.reform_targets(ideo):
            if t == ideo:
                continue
            met, _r = P.check_requirements(t, ctx)
            if met:
                avail.append(t)
        if not avail:
            items.append(disnake.ui.TextDisplay(f"{ui_icon('reject')} Нет доступных соседних строёв "
                                                "(условия не выполнены)."))
            return self._cont(items, WARNING_COLOR)
        opts = [disnake.SelectOption(label=P.ideo(t)["label"], value=t, emoji=_pe_pol(t),
                                     description=P.ideo(t)["desc"][:100], default=(t == target))
                for t in avail]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("state", "rsel"), placeholder="Выберите новый строй…", options=opts)))
        if target and target in avail:
            items.append(disnake.ui.TextDisplay(
                f"-# Переход к **{P.ideo(target)['label']}** · {P.ideo(target)['desc']}"))
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.success, label="Начать реформу", emoji=_pe("reform"),
                custom_id=cid("state", "rgo", target))))
        return self._cont(items)

    def _revo_panel(self, name: str, target: str | None = None) -> Panel:
        o = get_object(name)
        st = self.politics.get_state(name)
        ideo = st["ideology"]; legit = st["legitimacy"]
        stab = getattr(o, "stability", 0) or 0
        army = len(Army().formations_for(name))
        funds_ratio = (o.money / P.REVOLUTION_COST) if P.REVOLUTION_COST else 0
        chance = P.revolution_success_chance(army, funds_ratio, stab)
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('revolution')} Революция\n"
            f"-# Насильственная смена строя на ЛЮБОЙ — только в кризис.\n"
            f"{ui_icon('up')} Шанс успеха: **~{chance:.0f}%** · цена {int_format(P.REVOLUTION_COST)} {CURRENCY}\n"
            f"-# При провале деньги сгорают, режим шатается. При успехе — крах показателей и риск "
            f"гражданской войны ({int(P.REVOLUTION_CIVILWAR)}%).")]
        if not P.revolution_allowed(stab, legit):
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon('reject')} Революция возможна только в кризис "
                f"(стабильность ≤ {int(P.REVOLUTION_STAB_MAX)} или легитимность ≤ {int(P.REVOLUTION_LEGIT_MAX)})."))
            return self._cont(items, WARNING_COLOR)
        ctx = _ctx_of(name)
        avail = [t for t in P.IDEOLOGIES if t != ideo and P.check_requirements(t, ctx)[0]]
        if not avail:
            items.append(disnake.ui.TextDisplay(f"{ui_icon('reject')} Нет строёв, условия которых выполнены."))
            return self._cont(items, WARNING_COLOR)
        opts = [disnake.SelectOption(label=P.ideo(t)["label"], value=t, emoji=_pe_pol(t),
                                     description=P.ideo(t)["desc"][:100], default=(t == target))
                for t in avail[:25]]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("state", "vsel"), placeholder="Знамя революции…", options=opts)))
        if target and target in avail:
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.danger, label=f"Поднять революцию ({P.ideo(target)['label']})",
                emoji=_pe("revolution"), custom_id=cid("state", "vgo", target))))
        return self._cont(items, WARNING_COLOR)

    def _rel_panel(self, name: str, target: str | None = None) -> Panel:
        st = self.politics.get_state(name)
        ideo = st["ideology"]; religion = st["religion"]
        hap_hit, stab_hit = P.religion_change_hits(ideo, religion)
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('gov')} Смена религии\n"
            f"-# Текущая: {P.rel_label(religion)} · религиозность **{int(P.religiosity(ideo, religion))}**\n"
            f"-# Смена вызовет волнения: счастье −{hap_hit:.0f}, стабильность −{stab_hit:.0f} · "
            f"цена {int_format(P.RELIGION_CHANGE_COST)} {CURRENCY}")]
        opts = [disnake.SelectOption(label=P.rel(t)["label"], value=t, emoji=_pe_rel(t),
                                     description=P.rel(t)["desc"][:100], default=(t == target))
                for t in P.RELIGIONS if t != religion]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("state", "lsel"), placeholder="Новая государственная религия…", options=opts)))
        if target and target in P.RELIGIONS:
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.danger, label=f"Сменить на {P.rel(target)['label']}",
                emoji=_pe("gov"), custom_id=cid("state", "lgo", target))))
        return self._cont(items)

    def _cont(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=300)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    # ═══════════════ ИСПОЛНЕНИЕ ═══════════════
    def _cooldown_left(self, name: str) -> int:
        return int(self.cooldown.get_cooldown("regime", name) - time.time())

    def _start_reform(self, name: str, target: str) -> tuple[bool, str]:
        o = get_object(name)
        st = self.politics.get_state(name)
        if st["transition_until"] > time.time():
            return False, "Переход уже идёт."
        if not P.can_reform(st["ideology"], target):
            return False, "К этому строю нельзя перейти реформой."
        ok, reason = P.reform_ready(getattr(o, "stability", 0) or 0, st["legitimacy"])
        if not ok:
            return False, reason
        met, r = P.check_requirements(target, _ctx_of(name))
        if not met:
            return False, r
        if o.money < P.REFORM_COST:
            return False, f"Нужно {int_format(P.REFORM_COST)} {CURRENCY}."
        now = int(time.time())
        update_money(name, -P.REFORM_COST)
        until = now + P.REFORM_DURATION_H * 3600
        self.politics.start_transition(name, target, until, "reform")
        self.effects.add(name, "income_mult", P.REFORM_INCOME_MULT, until)
        return True, (f"{ui_icon('reform')} Реформа начата. Переход к **{P.ideo(target)['label']}** "
                      f"завершится <t:{until}:R>. Доход снижен на время перехода.")

    def _do_revolution(self, name: str, target: str) -> tuple[bool, str]:
        o = get_object(name)
        st = self.politics.get_state(name)
        stab = getattr(o, "stability", 0) or 0
        if not P.revolution_allowed(stab, st["legitimacy"]):
            return False, "Революция возможна только в кризис."
        met, r = P.check_requirements(target, _ctx_of(name))
        if not met:
            return False, r
        if o.money < P.REVOLUTION_COST:
            return False, f"Нужно {int_format(P.REVOLUTION_COST)} {CURRENCY}."
        update_money(name, -P.REVOLUTION_COST)
        army = len(Army().formations_for(name))
        chance = P.revolution_success_chance(army, o.money / P.REVOLUTION_COST, stab)
        self.cooldown.set_cooldown("regime", int(time.time()) + P.CHANGE_COOLDOWN, name)
        if random.uniform(0, 100) <= chance:
            self.politics.set_ideology(name, target)
            self.politics.clear_transition(name)
            self.politics.set_legitimacy(name, P.REVOLUTION_WIN_LEGIT)
            self.politics.set_opposition(name, 0)
            new_hap = P.clamp((getattr(o, "happiness", 0) or 0) + P.REVOLUTION_WIN_HAP)
            self.countries.update_object(name, stability=P.REVOLUTION_WIN_STAB, happiness=round(new_hap, 2))
            extra = ""
            if random.uniform(0, 100) <= P.REVOLUTION_CIVILWAR:
                loss = int(o.money * 0.1)
                if loss > 0:
                    update_money(name, -loss)
                self.countries.update_object(name, stability=P.clamp(P.REVOLUTION_WIN_STAB - 10))
                extra = f"\n{ui_icon('revolution')} Вспыхнула **гражданская война**: −{int_format(loss)} {CURRENCY}, хаос."
            return True, (f"{ui_icon('revolution')} **РЕВОЛЮЦИЯ УДАЛАСЬ!** Установлен **{P.ideo(target)['label']}**. "
                          f"Показатели в крахе — новому режиму нужно время." + extra)
        else:
            new_stab = P.clamp(stab + P.REVOLUTION_FAIL_STAB)
            self.countries.update_object(name, stability=new_stab)
            self.politics.set_legitimacy(name, P.clamp(st["legitimacy"] + P.REVOLUTION_FAIL_LEGIT))
            self.politics.set_opposition(name, P.clamp(st["opposition"] + 15))
            return True, (f"{ui_icon('reject')} **Революция подавлена.** Деньги потрачены впустую, "
                          f"режим устоял, но пошатнулся.")

    def _change_religion(self, name: str, target: str) -> tuple[bool, str]:
        o = get_object(name)
        st = self.politics.get_state(name)
        if target == st["religion"]:
            return False, "Эта религия уже установлена."
        if self._cooldown_left(name) > 0:
            return False, "Менять строй/религию можно раз в сутки."
        if o.money < P.RELIGION_CHANGE_COST:
            return False, f"Нужно {int_format(P.RELIGION_CHANGE_COST)} {CURRENCY}."
        hap_hit, stab_hit = P.religion_change_hits(st["ideology"], st["religion"])
        update_money(name, -P.RELIGION_CHANGE_COST)
        self.politics.set_religion(name, target)
        new_hap = P.clamp((getattr(o, "happiness", 0) or 0) - hap_hit)
        new_stab = P.clamp((getattr(o, "stability", 0) or 0) - stab_hit)
        self.countries.update_object(name, happiness=round(new_hap, 2), stability=round(new_stab, 2))
        self.cooldown.set_cooldown("regime", int(time.time()) + P.CHANGE_COOLDOWN, name)
        return True, (f"{ui_icon('gov')} Государственная религия → **{P.rel(target)['label']}**. "
                      f"Волнения: счастье −{hap_hit:.0f}, стабильность −{stab_hit:.0f}.")

    # ═══════════════ РОУТЕРЫ ═══════════════
    def _guard(self, inter, args):
        oid = int(args[0]) if args and args[0].isdigit() else None
        return not (oid and inter.author.id != oid)

    @commands.Cog.listener("on_button_click")
    async def _state_buttons(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("state:"):
            return
        _, action, args = parse_cid(c)
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны — откройте панель регистрации.", ephemeral=True)
            return
        # главная панель — только владелец (oid в custom_id)
        if action in ("reform", "revo", "rel", "invs", "invh"):
            if not self._guard(inter, args):
                await inter.response.send_message("Это не ваша панель.", ephemeral=True)
                return
        name = obj.name
        if action == "reform":
            await inter.response.send_message(components=self._reform_panel(name).components, ephemeral=True)
        elif action == "revo":
            await inter.response.send_message(components=self._revo_panel(name).components, ephemeral=True)
        elif action == "rel":
            await inter.response.send_message(components=self._rel_panel(name).components, ephemeral=True)
        elif action == "invs":
            await inter.response.send_message(embed=self._do_invest(obj, "stability", P.INVEST_COST_PER_STAB, P.INVEST_COST_PER_STAB * 5), ephemeral=True)
        elif action == "invh":
            await inter.response.send_message(embed=self._do_invest(obj, "happiness", P.INVEST_COST_PER_HAP, P.INVEST_COST_PER_HAP * 5), ephemeral=True)
        elif action == "rgo":
            ok, note = self._start_reform(name, args[0])
            await inter.response.edit_message(components=self._result_panel(note, ok).components)
        elif action == "vgo":
            ok, note = self._do_revolution(name, args[0])
            if ok:
                try:
                    from cogs.registration import update_country_nick
                    await update_country_nick(self.bot, name)
                except Exception:
                    pass
            await inter.response.edit_message(components=self._result_panel(note, ok).components)
        elif action == "lgo":
            ok, note = self._change_religion(name, args[0])
            await inter.response.edit_message(components=self._result_panel(note, ok).components)

    def _result_panel(self, note: str, ok: bool) -> Panel:
        return self._cont([disnake.ui.TextDisplay(note + "\n-# Откройте `!state`, чтобы увидеть обновление.")],
                          SUCCESS_COLOR if ok else WARNING_COLOR)

    @commands.Cog.listener("on_dropdown")
    async def _state_dropdowns(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("state:"):
            return
        _, action, _ = parse_cid(c)
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        v = inter.values[0]
        if action == "rsel":
            await inter.response.edit_message(components=self._reform_panel(obj.name, v).components)
        elif action == "vsel":
            await inter.response.edit_message(components=self._revo_panel(obj.name, v).components)
        elif action == "lsel":
            await inter.response.edit_message(components=self._rel_panel(obj.name, v).components)

    # ═══════════════ ЧАСОВОЙ ЦИКЛ ═══════════════
    @tasks.loop(hours=1)
    async def politics_tick(self):
        try:
            channel = None
            guild = self.bot.get_guild(GUILD_ID)
            if guild:
                channel = guild.get_channel(INCOME_CHANNEL) or self.bot.get_channel(INCOME_CHANNEL)
            now = int(time.time())
            reports = []
            nick_updates: list[str] = []
            for obj in self.countries.all_objects():
                try:
                    reports.append(self._tick_country(obj, now, nick_updates))
                except Exception:
                    import traceback
                    traceback.print_exc()
            reports = [r for r in reports if r]
            # обновить ники тем, у кого сменился строй (реформа завершилась / свержение)
            for nm in set(nick_updates):
                try:
                    from cogs.registration import update_country_nick
                    await update_country_nick(self.bot, nm)
                except Exception:
                    pass
            if reports and channel is not None:
                emb = disnake.Embed(title="Политическая сводка", color=WARNING_COLOR)
                for name, flag, events in reports[:20]:
                    emb.add_field(name=f"{flag} {name}", value="\n".join(f"• {e}" for e in events), inline=False)
                try:
                    await channel.send(embed=emb)
                except Exception:
                    pass
        except Exception:
            import traceback
            traceback.print_exc()

    def _tick_country(self, obj, now, nick_updates=None):
        name = obj.name
        st = self.politics.get_state(name)
        ideology, religion = st["ideology"], st["religion"]
        hap = getattr(obj, "happiness", 100.0) or 0.0
        stab = getattr(obj, "stability", 100.0) or 0.0
        legit = st["legitimacy"]; opp = st["opposition"]
        events = []

        # завершение перехода (реформа)
        if st["transition_until"] and now >= st["transition_until"] and st["transition_to"]:
            target = st["transition_to"]
            self.politics.set_ideology(name, target)
            self.politics.clear_transition(name)
            hap = P.clamp(hap + P.REFORM_SETTLE_HAP)
            stab = P.clamp(stab + P.REFORM_SETTLE_STAB)
            legit = P.REFORM_LEGIT_AFTER
            ideology = target
            if nick_updates is not None:
                nick_updates.append(name)  # строй сменился → обновить ник
            events.append(f"{ui_icon('reform')} реформа завершена: новый строй **{P.ideo(target)['label']}**")

        # дрейф счастья/стабильности к равновесию
        hap = P.drift(hap, P.target_happiness(ideology, religion), P.HAP_STEP)
        stab = P.drift(stab, P.target_stability(ideology, religion, hap), P.STAB_STEP)
        # дрейф легитимности (с учётом перехода)
        tgt_legit = P.target_legitimacy(hap, stab)
        if st["transition_until"] > now:
            tgt_legit = P.clamp(tgt_legit - P.LEGIT_TRANSITION_DRAG * 3)
        legit = P.drift(legit, tgt_legit, P.LEGIT_STEP)

        # оппозиция
        if legit < P.OPPOSITION_LEGIT_LOW:
            opp = P.clamp(opp + P.OPPOSITION_GROW)
        else:
            opp = P.clamp(opp - P.OPPOSITION_DECAY)

        # события краёв
        fresh = get_object(name)
        money = fresh.money if fresh else 0
        if hap < 20 and random.random() < 0.5:
            stab = P.clamp(stab - 6)
            events.append(f"{ui_icon('opposition')} протесты · −6 стабильности")
        if stab < 25 and random.random() < 0.45:
            loss = int(money * 0.04)
            if loss > 0:
                update_money(name, -loss)
            events.append(f"{ui_icon('revolution')} беспорядки · −{int_format(loss)} {CURRENCY}")
        if stab > 85 and hap > 75 and random.random() < 0.4:
            gain = 3_000_000
            update_money(name, gain)
            events.append(f"{ui_icon('up')} национальный подъём · +{int_format(gain)} {CURRENCY}")

        # предупреждения оппозиции / СВЕРЖЕНИЕ
        if opp >= P.OPPOSITION_OVERTHROW:
            new_ideo = _OPP_FLIP.get(ideology, "democracy")
            self.politics.set_ideology(name, new_ideo)
            self.politics.clear_transition(name)
            legit = 35.0
            opp = 0.0
            hap = P.clamp(hap - 10)
            stab = P.clamp(stab - 20)
            ideology = new_ideo
            if nick_updates is not None:
                nick_updates.append(name)  # строй сменился насильно → обновить ник
            events.append(f"{ui_icon('opposition')} **СВЕРЖЕНИЕ!** Оппозиция взяла власть — "
                          f"установлен **{P.ideo(new_ideo)['label']}**")
        elif opp >= P.OPPOSITION_DANGER:
            events.append(f"{ui_icon('opposition')} режим на грани: оппозиция **{int(opp)}** — поднимите легитимность!")
        elif opp >= P.OPPOSITION_WARN:
            events.append(f"{ui_icon('opposition')} оппозиция крепнет ({int(opp)})")

        self.countries.update_object(name, happiness=round(hap, 2), stability=round(stab, 2))
        self.politics.set_legitimacy(name, legit)
        self.politics.set_opposition(name, opp)
        if events:
            return (name, getattr(obj, "flag", "🏳️"),
                    events + [f"-# счастье {int(hap)} · стабильность {int(stab)} · легитимность {int(legit)}"])
        return None

    @politics_tick.before_loop
    async def _before_politics(self):
        await self.bot.wait_until_ready()
        await asyncio.sleep(1800)


# строй, к которому приводит свержение (репрессивные → народ к демократии; свободные → силовик)
_OPP_FLIP = {
    "authoritarian": "democracy", "fascism": "democracy", "monarchy": "democracy",
    "communism": "democracy", "theocracy": "democracy",
    "democracy": "authoritarian", "liberalism": "authoritarian",
    "socialism": "authoritarian", "technocracy": "authoritarian", "none": "democracy",
}


def _pe_pol(key: str):
    return _emoji(P.ideo_icon(key))


def _pe_rel(key: str):
    return _emoji(P.rel_icon(key))


def setup(bot: commands.Bot):
    bot.add_cog(StateCog(bot))
