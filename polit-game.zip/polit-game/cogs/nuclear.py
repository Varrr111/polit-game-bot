"""
☢️ АТОМНАЯ ПРОГРАММА — !nuclear / !атом

ПАНЕЛЬ В ЛС: статус по ДНЯО, ступени исследований, АЭС и топливо, обогащение и
арсенал, «Ядерный клуб», ядерный удар.

  • Ступени (utils/nuclear.STAGES): I физика → II центрифуги (мирный трек: АЭС,
    завод ТВЭЛ) → III оружейное обогащение → IV конструкция заряда (военный трек).
  • Военный трек участника ДНЯО — тайный: каждый час шанс разоблачения.
    Разоблачение — санкции, обвал отношений, casus belli для всех. Можно свернуть.
  • АЭС: +доход и дипкапитал, но содержание, расход ядерного топлива и аварии.
  • Каскады центрифуг превращают уран в оружейный уран (кг).
  • Своя боеголовка: регистрация (название, тип, мощность) → заявка на ИСПЫТАНИЕ →
    АРБИТР (сейчас штаб, позже ИИ-ООН: _submit_to_arbiter) → ядерная держава →
    производство боеголовок.
  • Удар в войне: носитель из арсенала техники, перехват ПВО цели, катастрофа для
    мира, ответный удар цели и «ядерного зонтика» её блока.

СВЯЗИ: ресурсы (уран, ядерное топливо), экономика (строки дохода/содержания),
дипломатия (равновесие: нарушитель ДНЯО, ядерный удар), ультиматумы (сдерживание),
альянсы (статья «Ядерный зонтик»), шпионаж (саботаж/вскрытие программы), война
(удар по фронту), новости (ИИ видит публичный статус). Канал CH_NUCLEAR.
Только кастом-иконки (ui_icon в тексте, emoji= в кнопках/опциях).
"""

import asyncio
import logging
import random
import re
import time

import disnake
from disnake.ext import commands, tasks

import config
from utils import (
    Countries, Diplomacy, Settings, Spy, War, Army, Equipment, Effects, Nuclear, Cooldown,
    CountryUpgrades, update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon, res_icon
from utils.serverconfig import rid
from utils.perms import is_staff
import utils.nuclear as N
import utils.upgrades as UP

log = logging.getLogger("nuclear")

_DAY = 86400
FUEL = "ядерное топливо"
URANIUM = "уран"


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _bar(frac: float, width: int = 10) -> str:
    filled = round(max(0.0, min(1.0, frac)) * width)
    return "▰" * filled + "▱" * (width - filled)


class _Dummy:
    flag = "🏳️"
    user = 0
    money = 0
    stability = 50.0
    happiness = 50.0
    population = 0


class NuclearCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.dip = Diplomacy()
        self.settings = Settings()
        self.spy = Spy()
        self.war = War()
        self.army = Army()
        self.equip = Equipment()
        self.effects = Effects()
        self.nuc = Nuclear()
        self.upg = CountryUpgrades()
        self.cooldown = Cooldown()
        self._sessions: dict[int, dict] = {}
        self.nuke_tick.start()

    def cog_unload(self):
        self.nuke_tick.cancel()

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "confirm": None, "design": None, "war": None, "carrier": None, "mode": "front"}
            self._sessions[uid] = s
        return s

    def _actor(self, uid: int):
        return self.countries.get_object_by_user(uid)

    def _obj(self, name: str):
        return self.countries.get_object(name) or _Dummy()

    def _state(self, name: str):
        hist = bool(config.COUNTRIES_ROSTER.get(name, (0,) * 6)[5]) if name in config.COUNTRIES_ROSTER else False
        self.nuc.ensure(name, historic=hist)
        return self.nuc.get(name)

    # ═══════════════ ПРАВИЛА ═══════════════
    def _stage_block(self, name: str, st, idx: int) -> str:
        """Почему нельзя начать ступень idx (пусто — можно)."""
        meta = N.stage_meta(idx)
        if not meta:
            return "все ступени пройдены"
        if st["research"]:
            return "уже идёт исследование"
        if st["status"] == "frozen" and meta["track"] == "war" and \
                int(time.time()) - (st["status_at"] or 0) < 7 * _DAY:
            return "программа под контролем МАГАТЭ (7 дней после сворачивания)"
        levels = self.upg.get_levels(name)
        miss = [f"{UP.BRANCHES[b]['label']} {lvl}" for b, lvl in meta["req"].items() if levels.get(b, 0) < lvl]
        if miss:
            return "нужно развитие: " + ", ".join(miss)
        o = self._obj(name)
        if (o.stability or 0) < meta["min_stab"]:
            return f"стабильность ниже {meta['min_stab']}"
        if (o.money or 0) < meta["cost"]:
            return f"нужно {int_format(meta['cost'])} {CURRENCY}"
        if meta["uranium"] and self.settings.get_resources(name).get(URANIUM, 0) < meta["uranium"]:
            return f"нужно {int_format(meta['uranium'])} урана"
        return ""

    def _is_power(self, st) -> bool:
        return bool(st) and st["status"] == "power"

    def _covert(self, st) -> bool:
        return bool(st) and st["status"] in ("covert", "exposed")

    def _world_recon(self, exclude: str) -> int:
        best = 0
        for n in self.countries.get_object_names():
            if n != exclude:
                best = max(best, self.spy.get_agency(n)[0])
        return best

    def _counter(self, name: str) -> int:
        spy = self.bot.get_cog("SpyCog")
        try:
            return spy._eff_counter(name, int(time.time())) if spy else self.spy.get_agency(name)[1]
        except Exception:
            return self.spy.get_agency(name)[1]

    def _expose_risk(self, name: str, st) -> float:
        if not st or st["status"] != "covert":
            return 0.0
        idx = st["stage"] + (1 if st["research"] in ("weapons", "warhead") else 0)
        if idx < 3:
            return 0.0
        return N.expose_chance(idx, self._world_recon(name), self._counter(name), st["cascades"] or 0)

    # ═══════════════ КАНАЛ / ЛС ═══════════════
    def _channel(self, key: str = "CH_NUCLEAR"):
        ch_id = rid(key, 0) or (rid("CH_DIPLO", 0) if key == "CH_NUCLEAR" else 0)
        if not ch_id:
            return None
        g = self.bot.get_guild(GUILD_ID)
        return (g.get_channel(ch_id) if g else None) or self.bot.get_channel(ch_id)

    async def _post(self, desc: str, color=COMMAND_COLOR):
        ch = self._channel()
        if not ch:
            return
        try:
            await ch.send(embed=disnake.Embed(description=desc, color=color))
        except Exception:
            pass

    async def _dm(self, country: str, components=None, text: str | None = None):
        o = self.countries.get_object(country)
        if not o or not getattr(o, "user", 0):
            return
        user = self.bot.get_user(o.user)
        if user is None:
            try:
                user = await self.bot.fetch_user(o.user)
            except Exception:
                return
        try:
            if components is not None:
                await user.send(components=components)
            else:
                await user.send(text)
        except Exception:
            pass

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('nuclear')} Атомная программа")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _back(self, label="⟵ В хаб", to="hub"):
        return disnake.ui.Button(style=disnake.ButtonStyle.secondary, label=label, custom_id=cid("nuc", "goto", to))

    def _note_panel(self, text: str, color=COMMAND_COLOR) -> Panel:
        return self._container([disnake.ui.TextDisplay(text)], color)

    def _render(self, uid: int, note=None) -> Panel:
        s = self._session(uid)
        actor = self._actor(uid)
        if not actor:
            return self._container(self._head(note) + [disnake.ui.TextDisplay(
                "-# У вас нет страны. Откройте панель регистрации, чтобы играть.")], WARNING_COLOR)
        st = self._state(actor.name)
        v = s["view"]
        if v == "npp":
            return self._panel_npp(actor, st, note)
        if v == "arsenal":
            return self._panel_arsenal(uid, actor, st, note)
        if v == "club":
            return self._panel_club(actor, note)
        if v == "strike":
            return self._panel_strike(uid, actor, st, note)
        return self._panel_hub(uid, actor, st, note)

    def _stages_line(self, st, now: int) -> str:
        out = []
        for i, meta in enumerate(N.STAGES):
            if i < st["stage"]:
                mark = ui_icon("check")
            elif st["research"] == meta["key"]:
                mark = ui_icon("research")
            else:
                mark = ui_icon("lock")
            out.append(f"{mark} {N.ROMAN[i]} {meta['label']}")
        test_mark = ui_icon("check") if st["status"] == "power" else ui_icon("lock")
        out.append(f"{test_mark} V Ядерное испытание")
        return "\n".join(out)

    # — хаб —
    def _panel_hub(self, uid, actor, st, note=None):
        s = self._session(uid)
        me = actor.name
        now = int(time.time())
        status = st["status"]
        items = self._head(note)
        shown = N.public_status(status)
        secret = (f"\n{ui_icon('violator')} **Тайно:** военный трек. Риск разоблачения **~{self._expose_risk(me, st) * 100:.1f}%/ч**"
                  if status == "covert" else "")
        items.append(disnake.ui.TextDisplay(
            f"### {actor.flag} {me}\n"
            f"{ui_icon(N.npt_icon(shown))} Статус: **{N.npt_label(shown)}**{secret}"))
        items.append(disnake.ui.Separator())
        prog = ""
        if st["research"]:
            meta = N.STAGE_BY_KEY[st["research"]]
            total = meta["hours"] * N.H
            left = max(0, st["research_until"] - now)
            prog = (f"\n{ui_icon('research')} Идёт: **{meta['label']}** {_bar(1 - left / total)} "
                    f"готово <t:{st['research_until']}:R>")
        items.append(disnake.ui.TextDisplay(f"-# СТУПЕНИ\n{self._stages_line(st, now)}{prog}"))
        wh = self.nuc.warheads(me)
        res = self.settings.get_resources(me)
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(
            f"{ui_icon('atomic')} АЭС: **{st['fueled']}/{st['plants']}** работают"
            + (f" · строится ещё 1 (<t:{st['plant_until']}:R>)" if st["plant_until"] else "") + "\n"
            f"{res_icon(URANIUM)} Уран: **{int_format(res.get(URANIUM, 0))}** · "
            f"{res_icon(FUEL)} Топливо: **{int_format(res.get(FUEL, 0))}**"
            + (f"\n{ui_icon('heu')} Оружейный уран: **{st['heu']:.1f} кг** · {ui_icon('centrifuge')} каскадов **{st['cascades']}**"
               if st["stage"] >= N.WEAPONS_STAGE or st["heu"] else "")
            + (f"\n{ui_icon('warhead')} Боеголовок: **{wh}**" if wh or st["status"] == "power" else "")))
        B = disnake.ButtonStyle
        idx = st["stage"]
        meta = N.stage_meta(idx)
        rows = []
        if meta and not st["research"]:
            block = self._stage_block(me, st, idx)
            war_entry = meta["track"] == "war" and status in ("member", "frozen")
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon(meta['icon'])} **Следующая ступень: {N.ROMAN[idx]} {meta['label']}** — {meta['desc']}\n"
                f"-# Цена **{int_format(meta['cost'])} {CURRENCY}**"
                + (f" + **{int_format(meta['uranium'])}** урана" if meta["uranium"] else "")
                + f" · {meta['hours']}ч · развитие: "
                + ", ".join(f"{UP.BRANCHES[b]['label']} {l}" for b, l in meta["req"].items())
                + (f"\n{ui_icon('reject')} {block}" if block else "")))
            if war_entry and s["confirm"] == meta["key"]:
                items.append(disnake.ui.TextDisplay(
                    f"{ui_icon('violator')} **Это нарушение ДНЯО.** Программа станет тайной: каждый час разведка мира "
                    f"может её вскрыть — санкции, обвал отношений, casus belli для всех. Продолжить?"))
                rows.append(disnake.ui.ActionRow(
                    disnake.ui.Button(style=B.danger, label="Да, начать тайно", emoji=_pe("violator"),
                                      custom_id=cid("nuc", "research", meta["key"], "yes")),
                    disnake.ui.Button(style=B.secondary, label="Отмена", custom_id=cid("nuc", "goto", "hub"))))
            else:
                rows.append(disnake.ui.ActionRow(disnake.ui.Button(
                    style=B.danger if meta["track"] == "war" else B.success,
                    label=f"Начать: {meta['label']}", emoji=_pe(meta["icon"]), disabled=bool(block),
                    custom_id=cid("nuc", "research", meta["key"], "ask" if war_entry else "yes"))))
        elif not meta and status not in ("power",):
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon('nuke_test')} Все ступени пройдены. Зарегистрируйте боеголовку и подайте заявку на "
                f"**испытание** в разделе «Обогащение и арсенал»."))
        items.append(disnake.ui.Separator())
        items.extend(rows)
        nav = [disnake.ui.Button(style=B.primary, label="АЭС и топливо", emoji=_pe("atomic"),
                                 custom_id=cid("nuc", "goto", "npp"))]
        if st["stage"] >= N.WEAPONS_STAGE or st["status"] == "power":
            nav.append(disnake.ui.Button(style=B.primary, label="Обогащение и арсенал", emoji=_pe("warhead"),
                                         custom_id=cid("nuc", "goto", "arsenal")))
        nav.append(disnake.ui.Button(style=B.secondary, label="Ядерный клуб", emoji=_pe("nuke_club"),
                                     custom_id=cid("nuc", "goto", "club")))
        items.append(disnake.ui.ActionRow(*nav))
        row2 = []
        if st["status"] == "power":
            row2.append(disnake.ui.Button(style=B.danger, label="Ядерный удар", emoji=_pe("launch"),
                                          custom_id=cid("nuc", "goto", "strike")))
        if self._covert(st):
            row2.append(disnake.ui.Button(style=B.secondary, label="Свернуть военную программу", emoji=_pe("inspect"),
                                          custom_id=cid("nuc", "freeze")))
        row2.append(disnake.ui.Button(style=B.secondary, label="Обновить", emoji=_pe("reload"),
                                      custom_id=cid("nuc", "goto", "hub")))
        items.append(disnake.ui.ActionRow(*row2))
        return self._container(items)

    # — АЭС —
    def _fuel_per_plant(self, st) -> int:
        return int(N.NPP_FUEL * (N.NPP_FUEL_OWN_ENRICH if st["stage"] >= N.PEACE_STAGES else 1.0))

    def _panel_npp(self, actor, st, note=None):
        me = actor.name
        items = self._head(note)
        per = self._fuel_per_plant(st)
        fuel = self.settings.get_resources(me).get(FUEL, 0)
        risk = N.accident_chance(actor.stability or 0) * 100
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('atomic')} АЭС · {actor.flag} {me}\n"
            f"Станций: **{st['plants']}/{N.NPP_MAX}** · работают: **{st['fueled']}**\n"
            f"{ui_icon('up')} Доход: **+{N.NPP_INCOME * 100:.0f}%** за работающую станцию · "
            f"{ui_icon('influence')} +{N.NPP_INFLUENCE} дипкапитала/ч\n"
            f"{ui_icon('down')} Содержание: **{int_format(N.NPP_UPKEEP)} {CURRENCY}/ч** за станцию\n"
            f"{res_icon(FUEL)} Расход топлива: **{per}/ч** на станцию · на складе **{int_format(fuel)}** "
            f"(хватит на ~{fuel // max(1, per * max(1, st['plants']))}ч)\n"
            f"{ui_icon('accident')} Риск аварии: **~{risk:.2f}%/ч** на станцию (растёт при стабильности ниже 40)"))
        items.append(disnake.ui.TextDisplay(
            f"-# Топливо делает **Завод ТВЭЛ** из урана и электроники (`!resources` → «Строить»), "
            f"его можно купить на `!рынок`. Без топлива станция заглушена: бонуса нет, но и аварий нет."))
        block = ""
        if st["stage"] < 1:
            block = "нужна ступень I «Ядерная физика»"
        elif st["plants"] >= N.NPP_MAX:
            block = f"лимит {N.NPP_MAX} станций"
        elif st["plant_until"]:
            block = "уже идёт стройка"
        elif (actor.money or 0) < N.NPP_COST:
            block = f"нужно {int_format(N.NPP_COST)} {CURRENCY}"
        if block:
            items.append(disnake.ui.TextDisplay(f"{ui_icon('reject')} Построить нельзя: {block}."))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, emoji=_pe("atomic"),
                              label=f"Построить АЭС · {int_format(N.NPP_COST)}", disabled=bool(block),
                              custom_id=cid("nuc", "npp")),
            self._back()))
        return self._container(items)

    # — обогащение и арсенал —
    def _panel_arsenal(self, uid, actor, st, note=None):
        s = self._session(uid)
        me = actor.name
        items = self._head(note)
        uran = self.settings.get_resources(me).get(URANIUM, 0)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('enrich')} Обогащение\n"
            f"{ui_icon('heu')} Оружейный уран: **{st['heu']:.1f} кг**\n"
            f"{ui_icon('centrifuge')} Каскадов: **{st['cascades']}/{N.CASCADE_MAX}** — каждый ест "
            f"**{N.CASCADE_URANIUM_H}** урана/ч и даёт **{N.CASCADE_HEU_H} кг**/ч\n"
            f"{res_icon(URANIUM)} Уран на складе: **{int_format(uran)}**"
            + (f"\n{ui_icon('violator')} Каждый каскад повышает риск разоблачения." if st["status"] == "covert" else "")))
        designs = self.nuc.designs(me)
        lines = []
        for d in designs:
            k = N.WARHEAD_KINDS[d["kind"]]
            lines.append(f"{ui_icon('warhead')} **{d['name']}** · {k['label'].lower()} · {N.kt_word(d['yield_kt'])} · "
                         f"на складе **{self.nuc.stock(d['id'])}**" + ("" if d["tested"] else " · не испытана"))
        q = self.nuc.queue(me)
        if q:
            lines += [f"{ui_icon('research')} В производстве: {r['count']} шт. — готово <t:{r['ready_at']}:R>" for r in q[:3]]
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"### {ui_icon('warhead')} Боеголовки\n"
                                            + ("\n".join(lines) if lines else "-# Моделей ещё нет.")))
        B = disnake.ButtonStyle
        row = [disnake.ui.Button(style=B.primary, emoji=_pe("centrifuge"),
                                 label=f"Каскад +1 · {int_format(N.CASCADE_COST)}",
                                 disabled=st["stage"] < N.WEAPONS_STAGE or st["cascades"] >= N.CASCADE_MAX,
                                 custom_id=cid("nuc", "cascade"))]
        row.append(disnake.ui.Button(style=B.success, emoji=_pe("warhead"), label="Зарегистрировать боеголовку",
                                     disabled=st["stage"] < N.DESIGN_STAGE or len(designs) >= N.DESIGN_MAX,
                                     custom_id=cid("nuc", "design")))
        items.append(disnake.ui.ActionRow(*row))
        if designs:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("nuc", "pickdesign"), placeholder="Выберите модель…",
                options=[disnake.SelectOption(
                    label=d["name"][:100], value=str(d["id"]), emoji=_pe("warhead"),
                    description=f"{N.kind_label(d['kind'])} · {N.kt_word(d['yield_kt'])} · "
                                f"{N.WARHEAD_KINDS[d['kind']]['heu']} кг урана"[:100],
                    default=(str(d["id"]) == str(s["design"]))) for d in designs])))
            sel = self.nuc.design(int(s["design"])) if s["design"] else None
            if sel and sel["country"] == me:
                pend = self.nuc.pending_test(me)
                acts = []
                if st["status"] == "power" and sel["tested"]:
                    acts.append(disnake.ui.Button(style=B.success, emoji=_pe("warhead"), label="Произвести…",
                                                  custom_id=cid("nuc", "produce", sel["id"])))
                elif st["status"] != "power":
                    acts.append(disnake.ui.Button(
                        style=B.danger, emoji=_pe("nuke_test"),
                        label="Заявка уже у арбитра" if pend else "Запросить испытание",
                        disabled=bool(pend) or st["stage"] < N.DESIGN_STAGE,
                        custom_id=cid("nuc", "test", sel["id"])))
                elif not sel["tested"]:
                    acts.append(disnake.ui.Button(style=B.danger, emoji=_pe("nuke_test"),
                                                  label="Испытать модель", disabled=bool(pend),
                                                  custom_id=cid("nuc", "test", sel["id"])))
                if acts:
                    items.append(disnake.ui.ActionRow(*acts))
        items.append(disnake.ui.TextDisplay(
            "-# Испытание делает страну ядерной державой. Решение принимает арбитр (штаб сервера), "
            "только после испытания модели её можно производить."))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — ядерный клуб —
    def _panel_club(self, actor, note=None):
        items = self._head(note)
        powers, historic, violators, frozen = [], [], [], []
        for r in self.nuc.all():
            o = self.countries.get_object(r["country"])
            if not o:
                continue
            st = N.public_status(r["status"])
            line = f"{o.flag} **{r['country']}**"
            if st == "power":
                powers.append(line + (f" · с <t:{r['status_at']}:D>" if r["status_at"] else ""))
            elif st == "historic":
                historic.append(line)
            elif st == "exposed":
                violators.append(line)
            elif st == "frozen":
                frozen.append(line)
        blocks = [
            (f"{ui_icon('nuke_club')} **Ядерные державы**", powers, "пока ни одной — испытаний не было"),
            (f"{ui_icon('deterrence')} **Признанные программы** (исторические державы)", historic, "нет"),
            (f"{ui_icon('violator')} **Нарушители ДНЯО**", violators, "нет"),
            (f"{ui_icon('inspect')} **Свернули программу**", frozen, "нет"),
        ]
        for title, rows, empty in blocks:
            items.append(disnake.ui.TextDisplay(f"{title}\n" + (" · ".join(rows) if rows else f"-# {empty}")))
        items.append(disnake.ui.TextDisplay("-# Тайные программы здесь не видны — их вскрывает разведка."))
        items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — удар —
    def _my_wars(self, me: str) -> list[tuple[int, str]]:
        """→ [(war_id, враг)] — войны, где страна главная сторона или союзник."""
        out = []
        for w in self.war.all_active():
            if me == w["attacker"]:
                out.append((w["id"], w["defender"]))
            elif me == w["defender"]:
                out.append((w["id"], w["attacker"]))
        for r in self.war.ally_wars():
            if r["country"] == me:
                out.append((r["war_id"], r["attacker"] if r["side"] == "def" else r["defender"]))
        return out

    def _retaliation_targets(self, me: str) -> list[str]:
        now = int(time.time())
        out = []
        for st in self.nuc.strikes_since(now - N.RETALIATE_H * N.H):
            if self.cooldown.get_cooldown(f"nukeret_{st['attacker']}", me) > now:
                out.append(st["attacker"])
        return sorted(set(out))

    def _panel_strike(self, uid, actor, st, note=None):
        s = self._session(uid)
        me = actor.name
        items = self._head(note)
        if st["status"] != "power":
            items.append(disnake.ui.TextDisplay(f"{ui_icon('reject')} Удар доступен только ядерной державе."))
            items.append(disnake.ui.ActionRow(self._back()))
            return self._container(items, ERROR_COLOR)
        wars = self._my_wars(me)
        ret = [t for t in self._retaliation_targets(me) if t not in {e for _w, e in wars}]
        targets = [(str(w), e, f"война #{w}") for w, e in wars] + [(f"r:{t}", t, "ответный удар") for t in ret]
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('launch')} Ядерный удар\n"
            f"{ui_icon('fallout')} Последствия для вас: репутация **в ноль**, отношения со всеми **{N.STRIKE_REL_SHOCK}**, "
            f"паника **{N.STRIKE_SELF_STAB}** стабильности, мировой шок экономики, ответный удар цели и её блока."))
        if not targets:
            items.append(disnake.ui.TextDisplay("-# Вы не ведёте войну — удар невозможен."))
            items.append(disnake.ui.ActionRow(self._back()))
            return self._container(items, ERROR_COLOR)
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("nuc", "swar"), placeholder="Цель…",
            options=[disnake.SelectOption(label=f"{self._obj(e).flag} {e}"[:100], value=v, emoji=_pe("war"),
                                          description=d[:100], default=(v == s["war"]))
                     for v, e, d in targets[:25]])))
        designs = [d for d in self.nuc.designs(me) if d["tested"] and self.nuc.stock(d["id"]) > 0]
        if designs:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("nuc", "sdes"), placeholder="Боеголовка…",
                options=[disnake.SelectOption(
                    label=d["name"][:100], value=str(d["id"]), emoji=_pe("warhead"),
                    description=f"{N.kt_word(d['yield_kt'])} · на складе {self.nuc.stock(d['id'])}"[:100],
                    default=(str(d["id"]) == str(s["design"]))) for d in designs])))
        else:
            items.append(disnake.ui.TextDisplay("-# Нет готовых боеголовок."))
        des = self.nuc.design(int(s["design"])) if s["design"] and str(s["design"]).isdigit() else None
        counts = self.equip.category_counts(me)
        carriers = [k for k, c in N.CARRIERS.items() if counts.get(k, 0) > 0 and (not des or des["kind"] in c["kinds"])]
        if carriers:
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("nuc", "scar"), placeholder="Носитель…",
                options=[disnake.SelectOption(
                    label=N.CARRIERS[k]["label"], value=k, emoji=_pe("launch"),
                    description=f"в арсенале {counts.get(k, 0)}" + (" · расходуется" if N.CARRIERS[k]["spent"] else ""),
                    default=(k == s["carrier"])) for k in carriers])))
        else:
            items.append(disnake.ui.TextDisplay(
                "-# Нет подходящих носителей: баллистические/крылатые ракеты, бомбардировщики или атомные подлодки (`!equip`)."))
        is_ret = bool(s["war"]) and str(s["war"]).startswith("r:")
        modes = [("city", "По тылу и городам", "население, экономика, стабильность")]
        if not is_ret:
            modes.insert(0, ("front", "По фронту", "армия противника и его союзников"))
        if s["mode"] not in [m for m, _l, _d in modes]:
            s["mode"] = modes[0][0]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("nuc", "smode"), placeholder="Тип удара…",
            options=[disnake.SelectOption(label=l, value=m, description=d, emoji=_pe("fallout"),
                                          default=(m == s["mode"])) for m, l, d in modes])))
        ready = bool(s["war"]) and des is not None and s["carrier"] in carriers
        if ready:
            target = self._strike_target(me, s)
            p = N.intercept_chance(s["carrier"], self.equip.category_counts(target)) if target else 0
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon('intercept')} Шанс перехвата ПВО цели: **~{p * 100:.0f}%**"))
        cd = int(self.cooldown.get_cooldown("nukestrike", me) - time.time())
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.danger, emoji=_pe("launch"),
                              label=("ПУСК…" if cd <= 0 else f"Перезарядка {N.fmt_dur(cd)}"),
                              disabled=not ready or cd > 0, custom_id=cid("nuc", "launch")),
            self._back()))
        return self._container(items, ERROR_COLOR)

    def _strike_target(self, me: str, s) -> str | None:
        v = str(s["war"] or "")
        if v.startswith("r:"):
            return v[2:]
        for w, e in self._my_wars(me):
            if str(w) == v:
                return e
        return None

    # ═══════════════ МОДАЛКИ ═══════════════
    def _design_modal(self):
        return disnake.ui.Modal(
            title="Регистрация боеголовки", custom_id=cid("nuc", "mdesign"),
            components=[
                disnake.ui.TextInput(label="Название модели", custom_id="name", style=disnake.TextInputStyle.short,
                                     placeholder="Например: Гром-1", min_length=N.NAME_MIN, max_length=N.NAME_MAX),
                disnake.ui.TextInput(label="Тип: тактическая / стратегическая", custom_id="kind",
                                     style=disnake.TextInputStyle.short, placeholder="тактическая", max_length=16),
                disnake.ui.TextInput(label="Мощность, кт (такт. 1–50, страт. 100–1000)", custom_id="yield",
                                     style=disnake.TextInputStyle.short, placeholder="20", max_length=5)])

    def _count_modal(self, did: int):
        return disnake.ui.Modal(
            title="Производство боеголовок", custom_id=cid("nuc", "mprod", did),
            components=[disnake.ui.TextInput(label="Количество", custom_id="n", style=disnake.TextInputStyle.short,
                                             placeholder="1", max_length=3)])

    def _launch_modal(self):
        return disnake.ui.Modal(
            title="Подтверждение пуска", custom_id=cid("nuc", "mlaunch"),
            components=[disnake.ui.TextInput(label="Введите слово ПУСК", custom_id="word",
                                             style=disnake.TextInputStyle.short, placeholder="ПУСК", max_length=8)])

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _nuc_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("nuc:"):
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        v = inter.values[0] if inter.values else None
        if action == "pickdesign" or action == "sdes":
            s["design"] = v
            if action == "sdes":
                s["carrier"] = None
        elif action == "swar":
            s["war"] = v
        elif action == "scar":
            s["carrier"] = v
        elif action == "smode":
            s["mode"] = v
        await inter.edit_original_message(components=self._render(inter.author.id).components)

    @commands.Cog.listener("on_button_click")
    async def _nuc_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("nuc:"):
            return
        _, action, args = parse_cid(c)
        if action == "arb":
            await self._on_arbiter(inter, args)
            return
        if action == "retal":
            await self._defer(inter)
            s = self._session(inter.author.id)
            s.update(view="strike", war=args[0] if args else None, mode="city", design=None, carrier=None)
            await inter.edit_original_message(components=self._render(inter.author.id).components)
            return
        if action == "design":
            await inter.response.send_modal(self._design_modal())
            return
        if action == "produce" and args and args[0].isdigit():
            await inter.response.send_modal(self._count_modal(int(args[0])))
            return
        if action == "launch":
            await inter.response.send_modal(self._launch_modal())
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        actor = self._actor(inter.author.id)
        note = None
        if not actor:
            pass
        elif action == "goto":
            s.update(view=args[0] if args else "hub", confirm=None)
        elif action == "research" and len(args) >= 2:
            if args[1] == "ask":
                s["confirm"] = args[0]
            else:
                s["confirm"] = None
                note = await self._start_research(actor, args[0])
        elif action == "npp":
            note = await self._build_npp(actor)
        elif action == "cascade":
            note = self._buy_cascade(actor)
        elif action == "test" and args and args[0].isdigit():
            note = await self._request_test(actor, int(args[0]))
        elif action == "freeze":
            note = await self._freeze(actor)
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    @commands.Cog.listener("on_modal_submit")
    async def _nuc_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("nuc:"):
            return
        _, action, args = parse_cid(c)
        actor = self._actor(inter.author.id)
        if not actor:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        if action == "mdesign":
            note = self._register_design(actor, inter.text_values)
        elif action == "mprod" and args and args[0].isdigit():
            note = self._produce(actor, int(args[0]), inter.text_values.get("n", ""))
        elif action == "mlaunch":
            if (inter.text_values.get("word", "") or "").strip().upper() != "ПУСК":
                note = f"{ui_icon('reject')} Пуск отменён: кодовое слово не введено."
            else:
                await inter.response.defer()
                note = await self._launch(actor, s)
                await inter.edit_original_message(components=self._render(inter.author.id, note).components)
                return
        else:
            return
        await inter.response.edit_message(components=self._render(inter.author.id, note).components)

    # ═══════════════ ДЕЙСТВИЯ ═══════════════
    async def _start_research(self, actor, key: str) -> str:
        me = actor.name
        st = self._state(me)
        idx = st["stage"]
        meta = N.stage_meta(idx)
        if not meta or meta["key"] != key:
            return f"{ui_icon('reject')} Эта ступень сейчас недоступна."
        block = self._stage_block(me, st, idx)
        if block:
            return f"{ui_icon('reject')} {block}."
        now = int(time.time())
        update_money(me, -meta["cost"])
        if meta["uranium"]:
            self.settings.add_resource(me, URANIUM, -meta["uranium"])
        kw = {"research": key, "research_until": now + meta["hours"] * N.H}
        if meta["track"] == "war" and st["status"] in ("member", "frozen"):
            kw.update(status="covert", status_at=now)
        self.nuc.update(me, **kw)
        if meta["track"] == "peace":
            await self._post(f"{ui_icon(meta['icon'])} {actor.flag} **{me}** запускает мирную атомную программу: "
                             f"**{meta['label']}**.")
        tail = (" Программа тайная — следите за риском разоблачения." if kw.get("status") == "covert" else "")
        return f"{ui_icon(meta['icon'])} Начато: **{meta['label']}**, готово <t:{kw['research_until']}:R>.{tail}"

    async def _build_npp(self, actor) -> str:
        me = actor.name
        st = self._state(me)
        if st["stage"] < 1:
            return f"{ui_icon('reject')} Нужна ступень I «Ядерная физика»."
        if st["plants"] >= N.NPP_MAX or st["plant_until"]:
            return f"{ui_icon('reject')} Сейчас строить нельзя."
        fresh = self.countries.get_object(me)
        if (fresh.money or 0) < N.NPP_COST:
            return f"{ui_icon('reject')} Нужно {int_format(N.NPP_COST)} {CURRENCY}."
        update_money(me, -N.NPP_COST)
        until = int(time.time()) + N.NPP_BUILD_H * N.H
        self.nuc.update(me, plant_until=until)
        return f"{ui_icon('atomic')} Стройка АЭС начата — готово <t:{until}:R>. Запаситесь ядерным топливом."

    def _buy_cascade(self, actor) -> str:
        me = actor.name
        st = self._state(me)
        if st["stage"] < N.WEAPONS_STAGE or st["cascades"] >= N.CASCADE_MAX:
            return f"{ui_icon('reject')} Каскад недоступен."
        fresh = self.countries.get_object(me)
        if (fresh.money or 0) < N.CASCADE_COST:
            return f"{ui_icon('reject')} Нужно {int_format(N.CASCADE_COST)} {CURRENCY}."
        update_money(me, -N.CASCADE_COST)
        self.nuc.update(me, cascades=st["cascades"] + 1)
        return f"{ui_icon('centrifuge')} Запущен каскад №{st['cascades'] + 1}. Нужен уран: {N.CASCADE_URANIUM_H}/ч."

    def _register_design(self, actor, tv: dict) -> str:
        me = actor.name
        st = self._state(me)
        if st["stage"] < N.DESIGN_STAGE:
            return f"{ui_icon('reject')} Нужна ступень IV «Конструкция заряда»."
        if len(self.nuc.designs(me)) >= N.DESIGN_MAX:
            return f"{ui_icon('reject')} Лимит моделей: {N.DESIGN_MAX}."
        name = re.sub(r"\s+", " ", tv.get("name", "")).strip()[:N.NAME_MAX]
        raw_kind = (tv.get("kind", "") or "").strip().lower()
        kind = "strategic" if raw_kind.startswith(("с", "s")) else "tactical" if raw_kind.startswith(("т", "t")) else None
        try:
            kt = int(re.sub(r"\D", "", tv.get("yield", "") or "0") or 0)
        except ValueError:
            kt = 0
        if len(name) < N.NAME_MIN or not kind:
            return f"{ui_icon('reject')} Нужны название и тип («тактическая» или «стратегическая»)."
        k = N.WARHEAD_KINDS[kind]
        if not k["min"] <= kt <= k["max"]:
            return f"{ui_icon('reject')} Мощность {k['label'].lower()} боеголовки: {k['min']}–{k['max']} кт."
        if self.nuc.design_name_taken(name):
            return f"{ui_icon('reject')} Такое название уже занято."
        self.nuc.add_design(me, name, kind, kt, int(time.time()))
        return (f"{ui_icon('warhead')} Модель **{name}** ({k['label'].lower()}, {N.kt_word(kt)}) зарегистрирована. "
                f"Дальше — испытание.")

    def _produce(self, actor, did: int, raw: str) -> str:
        me = actor.name
        st = self._state(me)
        d = self.nuc.design(did)
        try:
            n = max(1, min(20, int(re.sub(r"\D", "", raw) or 0)))
        except ValueError:
            n = 0
        if not d or d["country"] != me or not d["tested"] or st["status"] != "power" or n <= 0:
            return f"{ui_icon('reject')} Производство недоступно."
        un = self.bot.get_cog("UNCog")
        if un and un.embargoed(me):
            return f"{ui_icon('un_embargo')} Действует оружейное эмбарго ООН — производство запрещено."
        k = N.WARHEAD_KINDS[d["kind"]]
        heu, cost = k["heu"] * n, k["cost"] * n
        fresh = self.countries.get_object(me)
        if st["heu"] < heu:
            return f"{ui_icon('reject')} Нужно {heu} кг оружейного урана (есть {st['heu']:.1f})."
        if (fresh.money or 0) < cost:
            return f"{ui_icon('reject')} Нужно {int_format(cost)} {CURRENCY}."
        update_money(me, -cost)
        self.nuc.add_heu(me, -heu)
        ready = int(time.time()) + k["hours"] * N.H
        self.nuc.enqueue(me, did, n, ready)
        return f"{ui_icon('warhead')} В производстве {n} × **{d['name']}** — готово <t:{ready}:R>."

    async def _freeze(self, actor) -> str:
        me = actor.name
        st = self._state(me)
        if not self._covert(st):
            return f"{ui_icon('reject')} Военной программы нет."
        was_exposed = st["status"] == "exposed"
        for d in self.nuc.designs(me):
            self.nuc.add_stock(d["id"], -10 ** 6)
        self.nuc._execute("DELETE FROM nuke_queue WHERE country = ?", (me,))
        self.nuc._execute("DELETE FROM nuke_designs WHERE country = ?", (me,))
        research = st["research"] if st["research"] in ("physics", "centrifuge") else ""
        self.nuc.update(me, status="frozen", status_at=int(time.time()), stage=min(st["stage"], N.PEACE_STAGES),
                        heu=0, cascades=0, research=research, research_until=st["research_until"] if research else 0)
        if was_exposed:
            self.dip.add_reputation(me, N.FREEZE_REP)
            await self._post(f"{ui_icon('inspect')} {actor.flag} **{me}** сворачивает военную ядерную программу и "
                             f"пускает инспекторов МАГАТЭ. Репутация +{N.FREEZE_REP}.", SUCCESS_COLOR)
        return (f"{ui_icon('inspect')} Военная программа свёрнута: оружейный уран, каскады и модели уничтожены, "
                f"ступени III–IV сброшены. Возобновить можно через 7 дней.")

    # ───── испытание и арбитр ─────
    async def _request_test(self, actor, did: int) -> str:
        me = actor.name
        st = self._state(me)
        d = self.nuc.design(did)
        if not d or d["country"] != me or d["tested"]:
            return f"{ui_icon('reject')} Модель недоступна."
        if st["stage"] < N.DESIGN_STAGE:
            return f"{ui_icon('reject')} Нужна ступень IV."
        if self.nuc.pending_test(me):
            return f"{ui_icon('reject')} Заявка уже у арбитра."
        need = N.WARHEAD_KINDS[d["kind"]]["heu"] * N.TEST_HEU_MULT
        if st["heu"] < need:
            return f"{ui_icon('reject')} Для испытания нужно {need:.0f} кг оружейного урана (есть {st['heu']:.1f})."
        tid = self.nuc.create_test(me, did, int(time.time()))
        ok = await self._submit_to_arbiter(tid)
        if not ok:
            self.nuc.decide_test(tid, "void", "system", "арбитр недоступен")
            return f"{ui_icon('reject')} Арбитр недоступен (не настроен канал штаба). Сообщите администрации."
        return (f"{ui_icon('nuke_test')} Заявка на испытание **{d['name']}** отправлена арбитру. "
                f"Вам придёт решение в ЛС.")

    def _arbiter_panel(self, tid: int, result: str | None = None) -> Panel:
        t = self.nuc.test(tid)
        if not t:
            return self._note_panel("Заявка не найдена.", WARNING_COLOR)
        d = self.nuc.design(t["design_id"])
        st = self.nuc.get(t["country"])
        o = self._obj(t["country"])
        risk = self._expose_risk(t["country"], st) if st else 0
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('nuke_test')} Заявка на ядерное испытание\n"
            f"{o.flag} **{t['country']}** просит провести испытание и стать ядерной державой.\n"
            f"{ui_icon('warhead')} Модель: **{d['name'] if d else '—'}** · "
            f"{N.kind_label(d['kind']) if d else ''} · {N.kt_word(d['yield_kt']) if d else ''}\n"
            f"{ui_icon(N.npt_icon(st['status'] if st else 'member'))} Реальный статус: "
            f"**{N.npt_label(st['status']) if st else '—'}**"
            + (" (тайная программа)" if st and st["status"] == "covert" else "")
            + f"\n{ui_icon('stability')} Стабильность **{o.stability:.0f}** · {ui_icon('heu')} уран **{st['heu']:.1f} кг**"
            + (f" · риск разоблачения {risk * 100:.1f}%/ч" if risk else "")
            + "\n-# Арбитр решает, станет ли страна ядерной державой. Позже это решение перейдёт к ИИ-ООН.")]
        if result:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(result))
        elif t["status"] == "pending":
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Одобрить испытание", emoji=_pe("nuke_test"),
                                  custom_id=cid("nuc", "arb", tid, "ok")),
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Отклонить", emoji=_pe("reject"),
                                  custom_id=cid("nuc", "arb", tid, "no"))))
        else:
            items.append(disnake.ui.TextDisplay(f"-# Решение принято: {t['status']} ({t['decided_by']})."))
        return self._container(items, WARNING_COLOR)

    async def _submit_to_arbiter(self, tid: int) -> bool:
        """ШОВ АРБИТРА: сначала ИИ-ООН (вердикт + час на вето штаба), без ИИ — штаб кнопками."""
        un = self.bot.get_cog("UNCog")
        if un:
            try:
                if await un.judge_test(tid):
                    return True
            except Exception:
                log.exception("ИИ-ООН: испытание #%s", tid)
        ch = self._channel("CH_LOG") or self._channel("CH_NUCLEAR")
        if not ch:
            return False
        try:
            await ch.send(components=self._arbiter_panel(tid).components)
            return True
        except Exception:
            log.exception("арбитр: отправка заявки #%s", tid)
            return False

    async def _on_arbiter(self, inter, args):
        if not is_staff(inter.author):
            await inter.response.send_message("Решение принимает только штаб.", ephemeral=True)
            return
        await self._defer(inter)
        if len(args) < 2 or not args[0].isdigit():
            return
        tid = int(args[0])
        note = await self._decide_test(tid, args[1] == "ok", str(inter.author))
        await inter.edit_original_message(components=self._arbiter_panel(tid, note).components)

    async def _decide_test(self, tid: int, approve: bool, by: str) -> str:
        t = self.nuc.test(tid)
        if not t or t["status"] != "pending":
            return "Заявка уже закрыта."
        country = t["country"]
        d = self.nuc.design(t["design_id"])
        st = self.nuc.get(country)
        o = self.countries.get_object(country)
        if not approve or not d or not st or not o:
            self.nuc.decide_test(tid, "rejected", by)
            await self._dm(country, text=f"{ui_icon('reject')} Арбитр отклонил заявку на испытание "
                                         f"**{d['name'] if d else ''}**. Подать новую можно позже.")
            return f"{ui_icon('reject')} Отклонено ({by})."
        need = N.WARHEAD_KINDS[d["kind"]]["heu"] * N.TEST_HEU_MULT
        if st["heu"] < need:
            self.nuc.decide_test(tid, "rejected", by, "не хватило урана")
            await self._dm(country, text=f"{ui_icon('reject')} Испытание сорвано: не хватает оружейного урана.")
            return f"{ui_icon('reject')} У страны уже нет нужного урана — отклонено."
        now = int(time.time())
        first = st["status"] != "power"
        self.nuc.decide_test(tid, "approved", by)
        self.nuc.add_heu(country, -need)
        self.nuc.set_tested(d["id"])
        self.nuc.update(country, status="power", status_at=now if first else st["status_at"])
        if first:
            self.dip.add_reputation(country, N.TEST_REP)
            for other in self.countries.get_object_names():
                if other != country:
                    self.dip.add_relation(country, other, N.TEST_REL_SHOCK)
        head = (f"{ui_icon('nuke_test')} **ЯДЕРНОЕ ИСПЫТАНИЕ.** {o.flag} **{country}** взорвала заряд "
                f"**{d['name']}** мощностью **{N.kt_word(d['yield_kt'])}**.")
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("nuke_test", country, "", f"{country} провела ядерное испытание {N.kt_word(d['yield_kt'])}")
        tail = (f"\nСтрана становится **ядерной державой**. Сейсмографы мира фиксируют взрыв; "
                f"отношения со всеми {N.TEST_REL_SHOCK}, репутация {N.TEST_REP}." if first else
                "\nНовая модель прошла испытание.")
        await self._post(head + tail, ERROR_COLOR)
        await self._dm(country, text=head + tail + "\nТеперь модель можно производить: `!атом` → «Обогащение и арсенал».")
        return f"{ui_icon('check')} Одобрено ({by}). Испытание проведено."

    # ───── разоблачение ─────
    async def expose(self, country: str, by: str | None = None) -> bool:
        st = self.nuc.get(country)
        if not st or st["status"] != "covert":
            return False
        now = int(time.time())
        self.nuc.update(country, status="exposed", status_at=now)
        self.dip.add_reputation(country, N.EXPOSE_REP)
        for other in self.countries.get_object_names():
            if other != country:
                self.dip.add_relation(country, other, N.EXPOSE_REL_SHOCK)
        self.effects.add(country, "income_mult", N.EXPOSE_INCOME, now + N.EXPOSE_INCOME_H * N.H)
        o = self._obj(country)
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("nuke_expose", country, by or "", f"У {country} вскрыта тайная военная ядерная программа")
        who = f" Разведка {self._obj(by).flag} **{by}** передала доказательства МАГАТЭ." if by else \
            " Спутники зафиксировали каскады центрифуг."
        await self._post(
            f"{ui_icon('violator')} **НАРУШЕНИЕ ДНЯО.** У {o.flag} **{country}** вскрыта тайная военная ядерная "
            f"программа.{who}\n{ui_icon('sanctions')} Международные санкции: доход ×{N.EXPOSE_INCOME} на "
            f"{N.EXPOSE_INCOME_H}ч · репутация {N.EXPOSE_REP} · отношения со всеми {N.EXPOSE_REL_SHOCK}.\n"
            f"-# Любая страна вправе считать это поводом к войне (`!casus`).", ERROR_COLOR)
        await self._dm(country, text=f"{ui_icon('violator')} Ваша военная ядерная программа **раскрыта**. "
                                     f"Можно продолжить открыто или свернуть её (`!атом`).")
        return True

    # ───── удар ─────
    async def _launch(self, actor, s) -> str:
        me = actor.name
        now = int(time.time())
        st = self._state(me)
        if st["status"] != "power":
            return f"{ui_icon('reject')} Вы не ядерная держава."
        if self.cooldown.get_cooldown("nukestrike", me) > now:
            return f"{ui_icon('reject')} Пусковые установки перезаряжаются."
        target = self._strike_target(me, s)
        is_ret = str(s["war"] or "").startswith("r:")
        wc = self.bot.get_cog("WarCog")
        if not target or not (self.countries.get_object(target) or (wc and wc.is_npc(target))):
            return f"{ui_icon('reject')} Цель недоступна."
        if is_ret and target not in self._retaliation_targets(me):
            return f"{ui_icon('reject')} Окно ответного удара закрыто."
        d = self.nuc.design(int(s["design"])) if s["design"] and str(s["design"]).isdigit() else None
        if not d or d["country"] != me or not d["tested"] or self.nuc.stock(d["id"]) <= 0:
            return f"{ui_icon('reject')} Нет готовой боеголовки."
        car = s["carrier"]
        if car not in N.CARRIERS or d["kind"] not in N.CARRIERS[car]["kinds"] or \
                self.equip.category_counts(me).get(car, 0) <= 0:
            return f"{ui_icon('reject')} Носитель недоступен."
        mode = "city" if is_ret else (s["mode"] or "front")
        war_id = 0 if is_ret else int(s["war"])
        un = self.bot.get_cog("UNCog")
        if un and war_id and un.ceasefire(war_id):
            return f"{ui_icon('peace')} В этой войне действует прекращение огня ООН."
        self.cooldown.set_cooldown("nukestrike", now + 6 * N.H, me)
        self.nuc.add_stock(d["id"], -1)
        p = N.intercept_chance(car, self.equip.category_counts(target))
        intercepted = random.random() < p
        if N.CARRIERS[car]["spent"] or intercepted:
            self.equip.take_category(me, car, 1)
        self.nuc.log_strike(me, target, war_id, d["name"], d["yield_kt"], car, mode, intercepted, now)
        if un:
            un.log("nuke_strike", me, target, f"{me} нанесла ядерный удар по {target} ({N.kt_word(d['yield_kt'])}"
                                              f"{', перехвачен' if intercepted else ''})", war_id)
        o, t = self._obj(me), self._obj(target)
        # мировая реакция наступает при любом пуске — мир видит запуск
        self.dip.set_reputation(me, 0)
        for other in self.countries.get_object_names():
            if other != me:
                self.dip.add_relation(me, other, N.STRIKE_REL_SHOCK)
        self.countries.update_object(me, stability=max(0.0, (o.stability or 0) + N.STRIKE_SELF_STAB))
        al = self.bot.get_cog("AllianceCog")
        if al:
            for b in al.al.blocs_of(me):
                al.al.add_cohesion(b["id"], N.STRIKE_COH_HIT)
        carrier = N.CARRIERS[car]["label"].lower()
        if intercepted:
            res = (f"{ui_icon('intercept')} ПВО {t.flag} **{target}** перехватила ядерный заряд **{d['name']}** "
                   f"({carrier}). Взрыва не было, но мир видел пуск.")
            await self._post(f"{ui_icon('launch')} **ЯДЕРНЫЙ ПУСК.** {o.flag} **{me}** атаковала {t.flag} **{target}**.\n"
                             + res, ERROR_COLOR)
            await self._dm(target, text=f"{ui_icon('intercept')} По вам выпущен ядерный заряд — **перехвачен**.")
            await self._offer_retaliation(me, target)
            return res
        lines = []
        if mode == "front":
            frac = N.front_damage(d["kind"], d["yield_kt"])
            w = self.war.get_war(war_id)
            mine_att = bool(w) and (me == w["attacker"] or me in self.war.allies_of(war_id, "att"))
            enemy_side = "def" if mine_att else "att"
            enemies = [target] + (self.war.allies_of(war_id, enemy_side) if w else [])
            dead = 0
            wc = self.bot.get_cog("WarCog")
            for c in enemies:
                if wc and wc.is_npc(c):          # ИИ-государство: соединений в БД нет — бьём по силам армии
                    wc.npc_damage(c, frac)
                    dead += int(round(frac * 10))
                    continue
                for f in self.army.formations_for(c):
                    if self.army.damage_formation(f["id"], frac):
                        dead += 1
            lines.append(f"{ui_icon('losses')} Армия противника потеряла **{int(frac * 100)}%** сил, "
                         f"разбито соединений: **{dead}**.")
            if w:
                fr = self.war.current_front(war_id, "D" if mine_att else "A")   # области врага на нашем направлении
                if fr:
                    self.war.set_siege(war_id, fr["region"], min(99.0, (fr["siege"] or 0) + 40))
                    lines.append(f"{ui_icon('front')} Оборона на участке «{fr['name']}» прорвана (осада +40%).")
        else:
            dmg = N.city_damage(d["kind"], d["yield_kt"])
            wc = self.bot.get_cog("WarCog")
            if wc and wc.is_npc(target):         # ИИ-государство: население из ростера, удар — по армии и морали
                t_pop = config.COUNTRIES_ROSTER.get(target, (0, 0, 0, 0))[3]
                wc.npc_damage(target, dmg["pop"] * 4)
                wc._wear(target, dmg["stab"])
                killed = int(t_pop * dmg["pop"])
                lines.append(f"{ui_icon('fallout')} Погибли и ранены **{int_format(killed)}** человек; армия и "
                             f"моральный дух ИИ-государства подорваны.")
            else:
                killed = int((t.population or 0) * dmg["pop"])
                self.countries.update_object(
                    target, population=max(0, (t.population or 0) - killed),
                    happiness=max(0.0, (t.happiness or 0) - dmg["happy"]),
                    stability=max(0.0, (t.stability or 0) - dmg["stab"]))
                self.effects.add(target, "income_mult", dmg["income"], now + dmg["hours"] * N.H)
                lines.append(f"{ui_icon('fallout')} Погибли и ранены **{int_format(killed)}** человек; счастье "
                             f"−{dmg['happy']}, стабильность −{dmg['stab']}; доход ×{dmg['income']} на {dmg['hours']}ч "
                             f"(радиоактивное заражение).")
        shock = N.WORLD_SHOCK_BIG if d["yield_kt"] >= N.WORLD_SHOCK_KT else N.WORLD_SHOCK
        for other in self.countries.get_object_names():
            self.effects.add(other, "income_mult", shock, now + N.WORLD_SHOCK_H * N.H)
        lines.append(f"{ui_icon('down')} Мировые рынки обрушились: доход **всех** стран ×{shock} на {N.WORLD_SHOCK_H}ч.")
        body = "\n".join(lines)
        await self._post(
            f"{ui_icon('launch')} **ЯДЕРНЫЙ УДАР.** {o.flag} **{me}** применила **{d['name']}** "
            f"({N.kt_word(d['yield_kt'])}, {carrier}) по {t.flag} **{target}** — "
            f"{'по фронту' if mode == 'front' else 'по тылу'}.\n{body}\n"
            f"-# Репутация {me} обнулена, отношения со всем миром {N.STRIKE_REL_SHOCK}.", ERROR_COLOR)
        await self._dm(target, text=f"{ui_icon('launch')} {o.flag} **{me}** нанесла по вам ядерный удар.\n{body}")
        self.bot.dispatch("map_dirty")
        await self._offer_retaliation(me, target)
        return f"{ui_icon('launch')} Удар нанесён.\n{body}"

    async def _offer_retaliation(self, attacker: str, target: str):
        """Цель (если ядерная держава) и ядерные члены её блока со «Ядерным зонтиком» получают право ответа."""
        now = int(time.time())
        responders = []
        tst = self.nuc.get(target)
        if tst and tst["status"] == "power" and self.nuc.warheads(target) > 0:
            responders.append(target)
        al = self.bot.get_cog("AllianceCog")
        if al:
            responders += [m for m in al.umbrella_protectors(target)
                           if m not in (target, attacker) and self.nuc.warheads(m) > 0]
        for r in dict.fromkeys(responders):
            self.cooldown.set_cooldown(f"nukeret_{attacker}", now + N.RETALIATE_H * N.H, r)
            p = self._container([
                disnake.ui.TextDisplay(
                    f"## {ui_icon('launch')} Право ответного удара\n"
                    f"{self._obj(attacker).flag} **{attacker}** применила ядерное оружие против "
                    f"{self._obj(target).flag} **{target}**"
                    + (" — союзника под вашим ядерным зонтиком." if r != target else ".")
                    + f"\nОкно ответа: **{N.RETALIATE_H}ч**. Ответ — тоже ядерный удар со всеми последствиями."),
                disnake.ui.ActionRow(disnake.ui.Button(
                    style=disnake.ButtonStyle.danger, label="Открыть пульт ответа", emoji=_pe("launch"),
                    custom_id=cid("nuc", "retal", f"r:{attacker}")))], ERROR_COLOR)
            await self._dm(r, components=p.components)

    # ═══════════════ API ДЛЯ ДРУГИХ МЕХАНИК ═══════════════
    def status_of(self, country: str) -> str:
        st = self.nuc.get(country)
        return N.public_status(st["status"]) if st else "member"

    def deter_mult(self, country: str) -> float:
        """Сдерживание для ультиматумов: свой арсенал или ядерный зонтик блока."""
        st = self.nuc.get(country)
        own = N.deterrence(self.nuc.warheads(country)) if st and st["status"] == "power" else 1.0
        al = self.bot.get_cog("AllianceCog")
        if al:
            for m in al.umbrella_protectors(country):
                ext = N.deterrence(self.nuc.warheads(m))
                own = max(own, 1.0 + (ext - 1.0) * N.UMBRELLA_SHARE)
        return round(own, 3)

    def income_lines(self, country: str, total_income: int) -> list[tuple[str, int]]:
        st = self.nuc.get(country)
        if not st:
            return []
        out = []
        if st["fueled"] and total_income > 0:
            out.append(("АЭС (мирный атом)", round(total_income * N.NPP_INCOME * st["fueled"])))
        if st["plants"]:
            out.append(("Содержание АЭС", -N.NPP_UPKEEP * st["plants"]))
        wh = self.nuc.warheads(country)
        if wh:
            out.append(("Ядерный арсенал", -N.WARHEAD_UPKEEP * wh))
        return [(l, d) for l, d in out if d]

    def snapshot(self) -> dict:
        now = int(time.time())
        violators = {r["country"] for r in self.nuc.all() if r["status"] == "exposed"}
        strikers = {r["attacker"] for r in self.nuc.strikes_since(now - 14 * _DAY)}
        return {"violators": violators, "strikers": strikers}

    def relation_factors(self, a: str, b: str, snap: dict) -> list[tuple[str, float]]:
        f = []
        if a in snap["violators"] or b in snap["violators"]:
            f.append(("Нарушение ДНЯО", N.EQ_VIOLATOR))
        if a in snap["strikers"] or b in snap["strikers"]:
            f.append(("Применение ядерного оружия", -30))
        return f

    def context(self, country: str) -> str:
        st = self.nuc.get(country)
        if not st:
            return "Атомной программы нет."
        pub = N.public_status(st["status"])
        parts = [f"Статус: {N.npt_label(pub)}"]
        if st["plants"]:
            parts.append(f"АЭС: {st['plants']}")
        if pub == "power":
            parts.append("ядерное оружие есть")
        return "; ".join(parts) + "."

    def casus_lines(self) -> list[str]:
        out = []
        for r in self.nuc.all():
            if r["status"] == "exposed":
                o = self.countries.get_object(r["country"])
                if o:
                    out.append(f"{ui_icon('violator')} {o.flag} **{r['country']}** · нарушение ДНЯО — повод для всех")
        now = int(time.time())
        for s in self.nuc.strikes_since(now - 30 * _DAY)[:5]:
            out.append(f"{ui_icon('launch')} **{s['attacker']}** → **{s['target']}** · ядерный удар "
                       f"{max(0, (now - s['ts']) // _DAY)} дн. назад")
        return out

    def dossier_line(self, country: str) -> str:
        st = self.nuc.get(country)
        if not st:
            return "программы нет"
        real = N.npt_label(st["status"]) + (" (тайно!)" if st["status"] == "covert" else "")
        return (f"{real} · ступеней {st['stage']}/4 · АЭС {st['plants']} · каскадов {st['cascades']} · "
                f"оружейный уран {st['heu']:.0f} кг · боеголовок {self.nuc.warheads(country)}")

    def sabotage(self, target: str) -> str:
        """Шпионская операция «Саботаж ядерной программы». → строка итога."""
        st = self.nuc.get(target)
        now = int(time.time())
        if not st:
            return "У цели нет атомной программы."
        if st["research"]:
            delay = random.randint(12, 24) * N.H
            self.nuc.update(target, research_until=st["research_until"] + delay)
            return f"Исследование «{N.STAGE_BY_KEY[st['research']]['label']}» отброшено на {delay // N.H}ч."
        if st["cascades"]:
            self.nuc.update(target, cascades=st["cascades"] - 1)
            return "Вирус вывел из строя каскад центрифуг (−1)."
        if st["fueled"]:
            self.effects.add(target, "nuke_risk", N.ACC_SABOTAGE_BONUS, now + _DAY)
            return "Сбой систем управления АЭС: риск аварии резко вырос на сутки."
        return "Объектов для саботажа не нашлось."

    # ═══════════════ ЧАСОВОЙ ЦИКЛ ═══════════════
    async def _accident(self, name: str, st, major: bool):
        o = self._obj(name)
        now = int(time.time())
        if major:
            killed = int((o.population or 0) * 0.01)
            self.countries.update_object(name, population=max(0, (o.population or 0) - killed),
                                         happiness=max(0.0, (o.happiness or 0) - 15),
                                         stability=max(0.0, (o.stability or 0) - 10))
            self.nuc.update(name, plants=max(0, st["plants"] - 1), fueled=max(0, st["fueled"] - 1))
            self.effects.add(name, "income_mult", 0.75, now + 72 * N.H)
            await self._post(f"{ui_icon('accident')} **ТЯЖЁЛАЯ АВАРИЯ НА АЭС.** {o.flag} **{name}**: взрыв реактора, "
                             f"зона отчуждения. Пострадали **{int_format(killed)}** человек, станция потеряна, "
                             f"доход ×0.75 на 72ч.", ERROR_COLOR)
        else:
            self.countries.update_object(name, happiness=max(0.0, (o.happiness or 0) - 5))
            self.effects.add(name, "income_mult", 0.9, now + 24 * N.H)
            await self._post(f"{ui_icon('accident')} Инцидент на АЭС в {o.flag} **{name}**: выброс, эвакуация "
                             f"посёлка. Счастье −5, доход ×0.9 на сутки.", WARNING_COLOR)

    async def _tick(self, now: int):
        objs = {o.name: o for o in self.countries.all_objects()}
        for name in objs:
            self._state(name)
        for st in self.nuc.all():
            name = st["country"]
            o = objs.get(name)
            if not o:
                continue
            # исследования
            if st["research"] and st["research_until"] <= now:
                meta = N.STAGE_BY_KEY[st["research"]]
                self.nuc.update(name, stage=st["stage"] + 1, research="", research_until=0)
                await self._dm(name, text=f"{ui_icon(meta['icon'])} Ступень **{meta['label']}** освоена! `!атом`")
                if meta["track"] == "peace":
                    await self._post(f"{ui_icon(meta['icon'])} {o.flag} **{name}** освоила: **{meta['label']}**.")
            # стройка АЭС
            if st["plant_until"] and st["plant_until"] <= now:
                self.nuc.update(name, plants=st["plants"] + 1, plant_until=0)
                await self._post(f"{ui_icon('atomic')} {o.flag} **{name}** вводит в строй новую АЭС.")
            st = self.nuc.get(name)
            # топливо АЭС
            fueled = 0
            if st["plants"]:
                per = self._fuel_per_plant(st)
                have = self.settings.get_resources(name).get(FUEL, 0)
                fueled = min(st["plants"], have // per if per else 0)
                if fueled:
                    self.settings.add_resource(name, FUEL, -fueled * per)
                    self.dip.add_influence(name, N.NPP_INFLUENCE * fueled)
            if fueled != st["fueled"]:
                self.nuc.update(name, fueled=fueled)
            # аварии
            extra = sum(r["value"] for r in self.effects.active(name, now) if r["kind"] == "nuke_risk")
            p = N.accident_chance(o.stability or 0, extra)
            for _ in range(fueled):
                if random.random() < p:
                    await self._accident(name, self.nuc.get(name), random.random() < N.ACC_MAJOR_SHARE)
                    break
            # каскады
            if st["cascades"] and st["stage"] >= N.WEAPONS_STAGE and st["status"] != "frozen":
                have = self.settings.get_resources(name).get(URANIUM, 0)
                run = min(st["cascades"], have // N.CASCADE_URANIUM_H)
                if run:
                    self.settings.add_resource(name, URANIUM, -run * N.CASCADE_URANIUM_H)
                    self.nuc.add_heu(name, run * N.CASCADE_HEU_H)
            # разоблачение тайной программы
            risk = self._expose_risk(name, self.nuc.get(name))
            if risk and random.random() < risk:
                await self.expose(name)
        for q in self.nuc.queue_due(now):
            self.nuc.add_stock(q["design_id"], q["count"])
            self.nuc.queue_done(q["id"])
            d = self.nuc.design(q["design_id"])
            await self._dm(q["country"], text=f"{ui_icon('warhead')} Готово: {q['count']} × **{d['name'] if d else '?'}**.")

    @tasks.loop(hours=1)
    async def nuke_tick(self):
        try:
            await self._tick(int(time.time()))
        except Exception:
            log.exception("сбой цикла атомной программы")

    @nuke_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="nuclear", aliases=["атом", "ядерка", "ядерная", "nuke", "аэс"])
    async def nuclear_cmd(self, ctx: commands.Context):
        actor = self._actor(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(
                description="Атомная программа доступна только зарегистрированным странам.", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(view="hub", confirm=None, design=None, war=None, carrier=None, mode="front")
        try:
            await ctx.author.send(components=self._render(ctx.author.id).components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(
                description="Не могу написать в ЛС. Включите личные сообщения и повторите `!атом`.",
                color=WARNING_COLOR))
            return
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('nuclear')} Пульт атомной программы отправлен вам в **личные сообщения**.",
                color=COMMAND_COLOR), delete_after=12)


def setup(bot: commands.Bot):
    bot.add_cog(NuclearCog(bot))
