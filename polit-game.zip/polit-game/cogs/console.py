"""
СУПЕР-КОНСОЛЬ АДМИНА (бог-режим) — !console

Единая панель управления всем в боте над выбранной страной: деньги, состояние
(счастье/стабильность/население/территория/налог), ресурсы (любой — любое кол-во),
развитие (уровни веток), армия (л/с, здания, заводы техники), политика
(идеология/религия). Точные значения вводятся через модалки.

Стиль — Components V2 (как остальные панели), кастом-эмодзи через ui_icon/res_icon
(в тексте) и emoji= (в кнопках/селектах). Состояние сессии — в памяти на админа.
Только администратор/куратор.
"""

import logging

import disnake
from disnake.ext import commands

from utils import (
    Countries, Settings, CountryUpgrades, Army, Equipment, Politics,
    ADMINISTRATOR, COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY,
    int_format, string_to_number,
)
from utils.ui import Panel, cid, parse_cid
from utils.perms import has_command_access
from utils.resources import ui_icon, res_icon, res_label, RESOURCE_SLUG
import utils.upgrades as UP
import utils.politics as POL
import utils.army as ARM

log = logging.getLogger("console")

_PAGE = 25
RESOURCES = list(RESOURCE_SLUG.keys())
BRANCHES = list(UP.BRANCHES.keys())
IDEOLOGIES = list(POL.IDEOLOGIES.keys())
RELIGIONS = list(POL.RELIGIONS.keys())
ARMY_BLDS = list(ARM.ARMY_BUILDINGS.keys())
PLANT_DOMAINS = {"land": "Сухопутные", "air": "Авиация", "naval": "Флот", "missile": "Ракетные"}


def _pe(slug: str):
    """UI-слаг -> PartialEmoji для emoji= кнопок/селектов (или None)."""
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _num(raw: str):
    raw = (raw or "").strip().replace(" ", "")
    try:
        return int(float(raw))
    except (ValueError, TypeError):
        pass
    try:
        v = string_to_number(raw)
        return int(v) if v is not None else None
    except Exception:
        return None


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


class ConsoleCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.settings = Settings()
        self.upgrades = CountryUpgrades()
        self.army = Army()
        self.equip = Equipment()
        self.politics = Politics()
        self._sessions: dict[int, dict] = {}

    # ───── доступ/сессия ─────
    def _is_admin(self, ctx) -> bool:
        return has_command_access(ctx.author, "console")

    def _guard(self, inter) -> bool:
        return has_command_access(inter.author, "console")

    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"target": None, "cat": None, "tpage": 0,
                 "resource": None, "branch": None, "armybld": None, "plantdom": None}
            self._sessions[uid] = s
        return s

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _summary(self, name: str) -> str:
        o = self.countries.get_object(name)
        if not o:
            return "Страна не найдена."
        ideo, rel = self.politics.get(name)
        return (f"### {o.flag} {o.name}\n"
                f"{ui_icon('money')} Баланс: **{int_format(o.money)} {CURRENCY}**\n"
                f"{ui_icon('happy')} Счастье: **{o.happiness:.0f}** · "
                f"{ui_icon('stability')} Стабильность: **{o.stability:.0f}**\n"
                f"{ui_icon('globe')} Население: **{int_format(o.population)}** · "
                f"Территория: **{int_format(o.territory)}** км²\n"
                f"{ui_icon('gov')} {POL.ideo_label(ideo)} · {POL.rel_label(rel)}")

    def _panel(self, s: dict, note: str | None = None) -> Panel:
        """Главный маршрутизатор панелей по состоянию сессии."""
        if not s["target"]:
            return self._panel_target(s, note)
        cat = s["cat"]
        if cat == "eco":
            return self._panel_eco(s, note)
        if cat == "state":
            return self._panel_state(s, note)
        if cat == "res":
            return self._panel_res(s, note)
        if cat == "dev":
            return self._panel_dev(s, note)
        if cat == "army":
            return self._panel_army(s, note)
        if cat == "pol":
            return self._panel_pol(s, note)
        return self._panel_hub(s, note)

    def _head(self, note):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('command') or '🛠️'} Супер-консоль · бог-режим")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    # — выбор страны —
    def _panel_target(self, s, note=None):
        items = self._head(note)
        names = sorted(self.countries.get_object_names())
        if not names:
            items.append(disnake.ui.TextDisplay("-# Нет зарегистрированных стран."))
            return self._container(items, WARNING_COLOR)
        pages = max(1, (len(names) + _PAGE - 1) // _PAGE)
        s["tpage"] = _clamp(s["tpage"], 0, pages - 1)
        page = names[s["tpage"] * _PAGE:(s["tpage"] + 1) * _PAGE]
        items.append(disnake.ui.TextDisplay(f"-# ВЫБЕРИТЕ СТРАНУ · стр. {s['tpage']+1}/{pages}"))
        opts = []
        for nm in page:
            o = self.countries.get_object(nm)
            opts.append(disnake.SelectOption(label=f"{(o.flag + ' ') if o else ''}{nm}"[:100], value=nm))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("con", "target"), placeholder="Выберите страну…", options=opts)))
        if pages > 1:
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.primary, label="◀ Пред.",
                                  disabled=(s["tpage"] == 0), custom_id=cid("con", "tpage", "prev")),
                disnake.ui.Button(style=disnake.ButtonStyle.primary, label="След. ▶",
                                  disabled=(s["tpage"] >= pages - 1), custom_id=cid("con", "tpage", "next"))))
        return self._container(items)

    def _hub_buttons(self):
        B = disnake.ButtonStyle
        return [
            disnake.ui.ActionRow(
                disnake.ui.Button(style=B.secondary, label="Экономика", emoji=_pe("money"),
                                  custom_id=cid("con", "cat", "eco")),
                disnake.ui.Button(style=B.secondary, label="Состояние", emoji=_pe("happy"),
                                  custom_id=cid("con", "cat", "state")),
                disnake.ui.Button(style=B.secondary, label="Ресурсы", emoji=_pe("storage"),
                                  custom_id=cid("con", "cat", "res"))),
            disnake.ui.ActionRow(
                disnake.ui.Button(style=B.secondary, label="Развитие", emoji=_pe("upgrade"),
                                  custom_id=cid("con", "cat", "dev")),
                disnake.ui.Button(style=B.secondary, label="Армия", emoji=_pe("soldier"),
                                  custom_id=cid("con", "cat", "army")),
                disnake.ui.Button(style=B.secondary, label="Политика", emoji=_pe("gov"),
                                  custom_id=cid("con", "cat", "pol"))),
            disnake.ui.ActionRow(
                disnake.ui.Button(style=B.danger, label="🔁 Сменить страну",
                                  custom_id=cid("con", "changetarget"))),
        ]

    def _panel_hub(self, s, note=None):
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(self._summary(s["target"])))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay("-# ВЫБЕРИТЕ РАЗДЕЛ УПРАВЛЕНИЯ"))
        items += self._hub_buttons()
        return self._container(items)

    def _back_row(self):
        return disnake.ui.ActionRow(disnake.ui.Button(
            style=disnake.ButtonStyle.secondary, label="⟵ В меню", custom_id=cid("con", "hub")))

    # — экономика —
    def _panel_eco(self, s, note=None):
        B = disnake.ButtonStyle
        o = self.countries.get_object(s["target"])
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('money')} Экономика · {o.flag} {o.name}\n"
            f"Баланс: **{int_format(o.money)} {CURRENCY}** · налог с населения: **{o.tax_from_popul}**"))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="Выдать $", emoji=_pe("up"),
                              custom_id=cid("con", "m", "money", "add")),
            disnake.ui.Button(style=B.danger, label="Забрать $", emoji=_pe("down"),
                              custom_id=cid("con", "m", "money", "sub")),
            disnake.ui.Button(style=B.primary, label="Задать $",
                              custom_id=cid("con", "m", "money", "set")),
            disnake.ui.Button(style=B.secondary, label="Задать налог",
                              custom_id=cid("con", "m", "tax", "set"))))
        items.append(self._back_row())
        return self._container(items)

    # — состояние —
    def _panel_state(self, s, note=None):
        B = disnake.ButtonStyle
        o = self.countries.get_object(s["target"])
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('happy')} Состояние · {o.flag} {o.name}\n"
            f"{ui_icon('happy')} Счастье: **{o.happiness:.0f}** · "
            f"{ui_icon('stability')} Стабильность: **{o.stability:.0f}**\n"
            f"{ui_icon('globe')} Население: **{int_format(o.population)}** · "
            f"Территория: **{int_format(o.territory)}** км²"))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.primary, label="Счастье", emoji=_pe("happy"),
                              custom_id=cid("con", "m", "happiness", "set")),
            disnake.ui.Button(style=B.primary, label="Стабильность", emoji=_pe("stability"),
                              custom_id=cid("con", "m", "stability", "set")),
            disnake.ui.Button(style=B.primary, label="Население",
                              custom_id=cid("con", "m", "population", "set")),
            disnake.ui.Button(style=B.primary, label="Территория",
                              custom_id=cid("con", "m", "territory", "set"))))
        items.append(self._back_row())
        return self._container(items)

    # — ресурсы —
    def _panel_res(self, s, note=None):
        o = self.countries.get_object(s["target"])
        have = self.settings.get_resources(s["target"])
        lines = "  ".join(f"{res_icon(r)} {int_format(have.get(r, 0))}" for r in RESOURCES)
        sel = s["resource"]
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('storage')} Ресурсы · {o.flag} {o.name}\n{lines}\n"
            f"-# Выбран ресурс: **{res_label(sel) if sel else '—'}**"))
        opts = [disnake.SelectOption(label=res_label(r), value=r, emoji=_pe_res(r),
                                     default=(r == sel)) for r in RESOURCES]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("con", "resselect"), placeholder="Выберите ресурс…", options=opts)))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, label="Выдать/изменить кол-во",
                              emoji=_pe("storage"), disabled=(sel is None),
                              custom_id=cid("con", "m", "res", "add")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="⟵ В меню",
                              custom_id=cid("con", "hub"))))
        return self._container(items)

    # — развитие —
    def _panel_dev(self, s, note=None):
        o = self.countries.get_object(s["target"])
        levels = self.upgrades.get_levels(s["target"])
        sel = s["branch"]
        lines = "\n".join(
            f"{UP.BRANCHES[b]['label']}: **{levels.get(b, 0)}**/{len(UP.BRANCHES[b]['levels'])}"
            for b in BRANCHES)
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('upgrade')} Развитие · {o.flag} {o.name}\n{lines}\n"
            f"-# Выбрана ветка: **{UP.BRANCHES[sel]['label'] if sel else '—'}**"))
        opts = [disnake.SelectOption(label=UP.BRANCHES[b]["label"], value=b, default=(b == sel))
                for b in BRANCHES[:25]]
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("con", "devselect"), placeholder="Выберите ветку…", options=opts)))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, label="Задать уровень",
                              disabled=(sel is None), custom_id=cid("con", "m", "dev", "set")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="⟵ В меню",
                              custom_id=cid("con", "hub"))))
        return self._container(items)

    # — армия —
    def _panel_army(self, s, note=None):
        B = disnake.ButtonStyle
        o = self.countries.get_object(s["target"])
        pool = self.army.get_pool(s["target"])
        blds = self.army.get_buildings(s["target"])
        plants = self.equip.get_plants(s["target"])
        bl = " · ".join(f"{ARM.bld_icon(k)} {ARM.bld_label(k)}: {blds.get(k, 0)}" for k in ARMY_BLDS)
        pl = " · ".join(f"{ui_icon(d)} {PLANT_DOMAINS[d]}: {plants.get(d, 0)}" for d in PLANT_DOMAINS)
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('soldier')} Армия · {o.flag} {o.name}\n"
            f"{ui_icon('recruit')} Личный состав (пул): **{int_format(pool)}**\n{bl}\n{pl}\n"
            f"-# Здание: **{ARM.bld_label(s['armybld']) if s['armybld'] else '—'}** · "
            f"Завод: **{PLANT_DOMAINS.get(s['plantdom'], '—')}**"))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("con", "armybld"), placeholder="Армейское здание…",
            options=[disnake.SelectOption(label=ARM.bld_label(k), value=k, emoji=_pe_arm(k),
                                          default=(k == s["armybld"])) for k in ARMY_BLDS])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("con", "plantdom"), placeholder="Завод техники (домен)…",
            options=[disnake.SelectOption(label=PLANT_DOMAINS[d], value=d, emoji=_pe(d),
                                          default=(d == s["plantdom"])) for d in PLANT_DOMAINS])))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="Выдать л/с", emoji=_pe("recruit"),
                              custom_id=cid("con", "m", "pool", "add")),
            disnake.ui.Button(style=B.primary, label="+ Здание", disabled=(s["armybld"] is None),
                              custom_id=cid("con", "m", "armybld", "add")),
            disnake.ui.Button(style=B.primary, label="+ Завод", disabled=(s["plantdom"] is None),
                              custom_id=cid("con", "m", "plant", "add")),
            disnake.ui.Button(style=B.secondary, label="⟵ В меню", custom_id=cid("con", "hub"))))
        return self._container(items)

    # — политика —
    def _panel_pol(self, s, note=None):
        o = self.countries.get_object(s["target"])
        ideo, rel = self.politics.get(s["target"])
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('gov')} Политика · {o.flag} {o.name}\n"
            f"Идеология: **{POL.ideo_label(ideo)}** · Религия: **{POL.rel_label(rel)}**"))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("con", "ideo"), placeholder="Сменить идеологию…",
            options=[disnake.SelectOption(label=POL.IDEOLOGIES[k]["label"], value=k,
                                          default=(k == ideo)) for k in IDEOLOGIES])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("con", "rel"), placeholder="Сменить религию…",
            options=[disnake.SelectOption(label=POL.RELIGIONS[k]["label"], value=k,
                                          default=(k == rel)) for k in RELIGIONS])))
        items.append(self._back_row())
        return self._container(items)

    # ═══════════════ МОДАЛКИ ═══════════════
    def _modal(self, field, mode, title, label, default=""):
        return disnake.ui.Modal(
            title=title[:45], custom_id=cid("con", "modal", field, mode),
            components=[disnake.ui.TextInput(
                label=label[:45], custom_id="val", style=disnake.TextInputStyle.short,
                placeholder="например 1000000 или 1kk", required=True, value=str(default))])

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _con_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("con:"):
            return
        if not self._guard(inter):
            await inter.response.send_message("Только администратор.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        v = inter.values[0]
        if action == "target":
            s.update(target=v, cat=None)
        elif action == "resselect":
            s["resource"] = v
        elif action == "devselect":
            s["branch"] = v
        elif action == "armybld":
            s["armybld"] = v
        elif action == "plantdom":
            s["plantdom"] = v
        elif action == "ideo":
            self.politics.set_ideology(s["target"], v)
            await inter.response.edit_message(
                components=self._panel(s, f"✅ Идеология: {POL.ideo_label(v)}").components)
            return
        elif action == "rel":
            self.politics.set_religion(s["target"], v)
            await inter.response.edit_message(
                components=self._panel(s, f"✅ Религия: {POL.rel_label(v)}").components)
            return
        await inter.response.edit_message(components=self._panel(s).components)

    @commands.Cog.listener("on_button_click")
    async def _con_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("con:"):
            return
        if not self._guard(inter):
            await inter.response.send_message("Только администратор.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        if action == "tpage":
            s["tpage"] += 1 if args and args[0] == "next" else -1
            await inter.response.edit_message(components=self._panel(s).components)
        elif action == "changetarget":
            s.update(target=None, cat=None)
            await inter.response.edit_message(components=self._panel(s).components)
        elif action == "hub":
            s["cat"] = None
            await inter.response.edit_message(components=self._panel(s).components)
        elif action == "cat":
            s["cat"] = args[0]
            await inter.response.edit_message(components=self._panel(s).components)
        elif action == "m":
            await self._open_modal(inter, s, args[0], args[1])

    async def _open_modal(self, inter, s, field, mode):
        o = self.countries.get_object(s["target"])
        titles = {
            ("money", "add"): ("Выдать деньги", "Сколько прибавить"),
            ("money", "sub"): ("Забрать деньги", "Сколько отнять"),
            ("money", "set"): ("Задать баланс", "Новый баланс"),
            ("tax", "set"): ("Задать налог", "Налог с населения"),
            ("happiness", "set"): ("Задать счастье", "0–100"),
            ("stability", "set"): ("Задать стабильность", "0–100"),
            ("population", "set"): ("Задать население", "Новое население"),
            ("territory", "set"): ("Задать территорию", "км²"),
            ("res", "add"): (f"Ресурс: {res_label(s['resource'] or '')}", "На сколько изменить (можно −)"),
            ("dev", "set"): ("Задать уровень ветки", f"0–{len(UP.BRANCHES[s['branch']]['levels']) if s['branch'] else 5}"),
            ("pool", "add"): ("Выдать личный состав", "Сколько прибавить"),
            ("armybld", "add"): ("Добавить здание", "Сколько"),
            ("plant", "add"): ("Добавить завод", "Сколько"),
        }
        title, label = titles.get((field, mode), ("Значение", "Число"))
        await inter.response.send_modal(self._modal(field, mode, title, label))

    @commands.Cog.listener("on_modal_submit")
    async def _con_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("con:modal:"):
            return
        if not self._guard(inter):
            await inter.response.send_message("Только администратор.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, _, args = parse_cid(c)
        field, mode = args[0], args[1]
        val = _num(inter.text_values.get("val", ""))
        if val is None:
            await inter.response.send_message("⚠️ Неверное число.", ephemeral=True)
            return
        name = s["target"]
        note = self._apply(name, s, field, mode, val)
        await inter.response.edit_message(components=self._panel(s, note).components)

    def _apply(self, name, s, field, mode, val) -> str:
        o = self.countries.get_object(name)
        if field == "money":
            if mode == "add":
                self.countries.update_object(name, money=val)
            elif mode == "sub":
                self.countries.update_object(name, money=-val)
            else:
                self.countries.update_object(name, money=val - o.money)
            return f"✅ Баланс → {int_format(self.countries.get_object(name).money)} {CURRENCY}"
        if field == "tax":
            self.countries.update_object(name, tax_from_popul=val)
            return f"✅ Налог → {val}"
        if field in ("happiness", "stability"):
            val = _clamp(val, 0, 100)
            self.countries.update_object(name, **{field: float(val)})
            return f"✅ {field} → {val}"
        if field in ("population", "territory"):
            self.countries.update_object(name, **{field: max(0, val)})
            return f"✅ {field} → {int_format(max(0, val))}"
        if field == "res":
            self.settings.add_resource(name, s["resource"], val)
            cur = self.settings.get_resources(name).get(s["resource"], 0)
            return f"✅ {res_label(s['resource'])} → {int_format(cur)}"
        if field == "dev":
            maxlvl = len(UP.BRANCHES[s["branch"]]["levels"])
            lvl = _clamp(val, 0, maxlvl)
            self.upgrades.set_level(name, s["branch"], lvl)
            return f"✅ {UP.BRANCHES[s['branch']]['label']} → ур. {lvl}"
        if field == "pool":
            self.army.add_pool(name, val)
            return f"✅ Личный состав → {int_format(self.army.get_pool(name))}"
        if field == "armybld":
            self.army.add_building(name, s["armybld"], val)
            return f"✅ {ARM.bld_label(s['armybld'])}: +{val}"
        if field == "plant":
            self.equip.add_plant(name, s["plantdom"], val)
            return f"✅ Завод ({PLANT_DOMAINS[s['plantdom']]}): +{val}"
        return "Готово."

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="console", aliases=["консоль", "админка", "god", "админ-панель"])
    async def console_cmd(self, ctx: commands.Context):
        if not self._is_admin(ctx):
            await ctx.send(embed=disnake.Embed(description="Только администратор.", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(target=None, cat=None, tpage=0, resource=None, branch=None, armybld=None, plantdom=None)
        await ctx.send(components=self._panel(s).components)


def _pe_res(name: str):
    try:
        return disnake.PartialEmoji.from_str(res_icon(name))
    except Exception:
        return None


def _pe_arm(key: str):
    try:
        return disnake.PartialEmoji.from_str(ARM.bld_icon(key))
    except Exception:
        return None


def setup(bot: commands.Bot):
    bot.add_cog(ConsoleCog(bot))
