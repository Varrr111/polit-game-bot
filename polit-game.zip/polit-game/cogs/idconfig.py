"""
Настройка ID каналов/ролей через Discord (не через config.py).

Проблема: ID в config.py — это КОД, и деплой обновлений перезаписывает его,
сбрасывая настройки. Решение: храним ID в БД (server_config, файл game.db в
.gitignore — деплой его не трогает). Весь код читает их через serverconfig.rid,
а config.py остаётся лишь фолбэком.

  !setchannel <что> [#канал]  — задать игровой канал (по умолч. текущий)
  !setrole держава [@роль]    — задать роль «Держава»
  !serverids                  — показать все сохранённые ID
  !resetid <что>              — убрать переопределение (вернуться к config.py)
  !importconfig               — разом сохранить текущие значения config.py в БД
"""

import disnake
from disnake.ext import commands

import config
from utils import (
    MapState, ADMINISTRATOR, COMMAND_COLOR, ERROR_COLOR, SUCCESS_COLOR,
    INCOME_CHANNEL, EVENTS_CHANNEL, WORLD_NEWS_CHANNEL, PROFILE_ROLE, LOG_CHANNEL,
)
from utils.serverconfig import rid, sset, sget, all_config
from utils.perms import has_command_access

# друж. имя → ключ в server_config
CHANNELS = {
    "доходы": "CH_INCOME", "income": "CH_INCOME",
    "события": "CH_EVENTS", "events": "CH_EVENTS",
    "новости": "CH_NEWS", "news": "CH_NEWS",
    "регистрация": "CH_REGISTER", "register": "CH_REGISTER",
    "карта": "CH_MAP", "map": "CH_MAP",
    "шпионаж": "CH_SPY", "spy": "CH_SPY",
    "ультиматумы": "CH_ULTIMATUM", "ultimatum": "CH_ULTIMATUM",
    "санкции": "CH_SANCTIONS", "sanctions": "CH_SANCTIONS",
    "дипломатия": "CH_DIPLO", "diplo": "CH_DIPLO",
    "альянсы": "CH_ALLIANCE", "alliance": "CH_ALLIANCE", "блоки": "CH_ALLIANCE",
    "атом": "CH_NUCLEAR", "ядерная-программа": "CH_NUCLEAR", "nuclear": "CH_NUCLEAR",
    "чвк": "CH_PMC", "pmc": "CH_PMC",
    "оон-новости": "CH_UN_NEWS", "новости-оон": "CH_UN_NEWS",
    "оон-резолюции": "CH_UN_RES", "резолюции-оон": "CH_UN_RES",
    "оон-совбез": "CH_UN_SC", "совбез-оон": "CH_UN_SC",
    "оон-чат": "CH_UN_GA", "генассамблея-оон": "CH_UN_GA",
    "войны": "CH_WAR", "война": "CH_WAR", "war": "CH_WAR",
    "рынок": "CH_TRADE", "торговля": "CH_TRADE", "trade": "CH_TRADE",
    "гайд": "CH_GUIDE", "guide": "CH_GUIDE", "справка": "CH_GUIDE",
    "правила": "CH_RULES", "rules": "CH_RULES",
    "лог-игра": "CH_LOG", "log": "CH_LOG",
    "лог-вход": "CH_LOG_JOINS", "joins": "CH_LOG_JOINS",
    "лог-сообщения": "CH_LOG_MESSAGES", "messages": "CH_LOG_MESSAGES",
    "лог-модерация": "CH_LOG_MOD", "mod": "CH_LOG_MOD",
    "лог-голос": "CH_LOG_VOICE", "voice": "CH_LOG_VOICE",
}
ROLES = {"зарегистрирован": "PROFILE_ROLE", "registered": "PROFILE_ROLE",
         "держава": "PROFILE_ROLE", "player": "PROFILE_ROLE", "игрок": "PROFILE_ROLE",
         "участник": "ROLE_MEMBER", "member": "ROLE_MEMBER",
         "регистрация-роль": "ROLE_REGISTERING", "registering": "ROLE_REGISTERING",
         "чвк": "ROLE_PMC", "pmc": "ROLE_PMC"}

# для !importconfig и !serverids: ключ БД → значение-фолбэк из config.py
FALLBACKS = {
    "CH_INCOME": INCOME_CHANNEL, "CH_EVENTS": EVENTS_CHANNEL,
    "CH_NEWS": WORLD_NEWS_CHANNEL, "PROFILE_ROLE": PROFILE_ROLE, "CH_LOG": LOG_CHANNEL,
}
_CH_LABEL = {v: k for k, v in CHANNELS.items() if not k.isascii()}  # ключ → рус. имя


def _err(t):
    return disnake.Embed(description=t, color=ERROR_COLOR)


class IDConfigCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _is_admin(self, ctx) -> bool:
        return has_command_access(ctx.author, ctx.command.name if ctx.command else "serverids")

    @commands.command(name="setchannel", aliases=["задать-канал", "setch"])
    async def setchannel_cmd(self, ctx, what: str = "", channel: disnake.abc.GuildChannel = None):
        if not self._is_admin(ctx):
            await ctx.send(embed=_err("Только администратор."))
            return
        key = CHANNELS.get(what.lower())
        if not key:
            await ctx.send(embed=_err(
                "Укажите что: `доходы` `события` `новости` `регистрация` `карта` "
                "`лог-игра` `лог-вход` `лог-сообщения` `лог-модерация` `лог-голос`.\n"
                "-# Пример: `!setchannel доходы #доходы` (или без канала — текущий)"))
            return
        ch = channel or ctx.channel
        if isinstance(ch, disnake.CategoryChannel):
            await ctx.send(embed=_err("Это категория — укажите текстовый канал."))
            return
        sset(key, ch.id)
        if key == "CH_MAP":
            MapState().set_location(ch.id, None)
            self.bot.dispatch("map_dirty")
        await ctx.send(embed=disnake.Embed(
            description=f"✅ **{what}** → {ch.mention}\n-# `{key} = {ch.id}` сохранено в БД (переживёт деплой).",
            color=SUCCESS_COLOR))

    @commands.command(name="setrole", aliases=["задать-роль"])
    async def setrole_cmd(self, ctx, what: str = "", role: disnake.Role = None):
        if not self._is_admin(ctx):
            await ctx.send(embed=_err("Только администратор."))
            return
        key = ROLES.get(what.lower())
        if not key or not role:
            await ctx.send(embed=_err("Пример: `!setrole зарегистрирован @Зарегистрирован`\n"
                                      "Роли: `зарегистрирован`, `участник`, `регистрация-роль`."))
            return
        sset(key, role.id)
        await ctx.send(embed=disnake.Embed(
            description=f"✅ роль **{what}** → {role.mention}\n-# `{key} = {role.id}` сохранено в БД.",
            color=SUCCESS_COLOR))

    @commands.command(name="serverids", aliases=["ids", "настройки-id"])
    async def serverids_cmd(self, ctx):
        if not self._is_admin(ctx):
            await ctx.send(embed=_err("Только администратор."))
            return
        stored = all_config()
        lines = []
        seen = set()
        for key in dict.fromkeys(list(CHANNELS.values()) + list(ROLES.values())):
            if key in seen:
                continue
            seen.add(key)
            val = stored.get(key)
            is_role = key == "PROFILE_ROLE" or key.startswith("ROLE_")
            if val:
                try:
                    _id = int(val)
                except (TypeError, ValueError):
                    _id = 0
                obj = None
                if ctx.guild and _id:
                    obj = ctx.guild.get_role(_id) if is_role else ctx.guild.get_channel(_id)
                if obj is not None:
                    lines.append(f"`{key}` → {obj.mention}  ·  в БД ✅")
                else:
                    kind = "роль" if is_role else "канал"
                    lines.append(f"`{key}` → ⚠️ {kind} с ID `{_id}` не найден(а) на сервере  ·  в БД")
            else:
                fb = FALLBACKS.get(key, 0)
                lines.append(f"`{key}` → фолбэк config.py (`{fb}`)  ·  не в БД")
        await ctx.send(embed=disnake.Embed(
            title="🗂️ Привязки ID",
            description="\n".join(lines) + "\n\n-# «в БД ✅» — переживают деплой. "
                        "Остальные берутся из config.py (сбросятся при заливке кода).",
            color=COMMAND_COLOR))

    @commands.command(name="resetid", aliases=["сбросить-id"])
    async def resetid_cmd(self, ctx, what: str = ""):
        if not self._is_admin(ctx):
            await ctx.send(embed=_err("Только администратор."))
            return
        key = CHANNELS.get(what.lower()) or ROLES.get(what.lower()) or what.upper()
        from utils import ServerConfig
        ServerConfig()._execute("DELETE FROM server_config WHERE key = ?", (key,))
        await ctx.send(embed=disnake.Embed(
            description=f"Переопределение `{key}` убрано — вернулись к config.py.", color=SUCCESS_COLOR))

    @commands.command(name="autoconfig", aliases=["автонастройка", "привязать-id", "bindids", "autobind"])
    async def autoconfig_cmd(self, ctx):
        """Авто-привязка: находит каналы/роли сервера ПО ИМЕНАМ и сохраняет их ID в БД.
        Удобно, если сервер уже собран (или !serverids показывает «не в БД»)."""
        if not self._is_admin(ctx):
            await ctx.send(embed=_err("Нет доступа к этой команде (`!perm`)."))
            return
        if not ctx.guild:
            return
        import re
        from cogs.serversetup import STRUCTURE, ROLES as SS_ROLES, STAR_GRANT_KEYS
        from utils import CommandPerms

        def norm(name: str) -> str:
            if "・" in name:
                name = name.split("・")[-1]
            return re.sub(r"[^0-9A-Za-zА-Яа-яЁё \-]+", "", name).strip().lower()

        # имя-канала → ключ (по STRUCTURE)
        chan_map = {}
        for _cat, _vis, chans in STRUCTURE:
            for _ctype, cname, ckey, _ro in chans:
                if ckey:
                    chan_map[norm(cname)] = ckey
        # каналы, которых нет в STRUCTURE (война/рынок/гайд и т.п.) — ловим по названиям
        for nm, key in {
            "войны": "CH_WAR", "война": "CH_WAR", "war": "CH_WAR",
            "рынок": "CH_TRADE", "торговля": "CH_TRADE", "биржа": "CH_TRADE", "trade": "CH_TRADE",
            "гайд": "CH_GUIDE", "guide": "CH_GUIDE", "справка": "CH_GUIDE",
            "информация": "CH_GUIDE", "инфо": "CH_GUIDE", "как-играть": "CH_GUIDE",
            "шпионаж": "CH_SPY", "spy": "CH_SPY",
            "правила": "CH_RULES", "rules": "CH_RULES",
            "ультиматумы": "CH_ULTIMATUM", "ультиматум": "CH_ULTIMATUM",
            "санкции": "CH_SANCTIONS", "sanctions": "CH_SANCTIONS",
            "дипломатия": "CH_DIPLO", "diplo": "CH_DIPLO",
            "альянсы": "CH_ALLIANCE", "alliance": "CH_ALLIANCE",
            "ядерная-программа": "CH_NUCLEAR", "nuclear": "CH_NUCLEAR",
            "чвк": "CH_PMC", "pmc": "CH_PMC",
            "новости-оон": "CH_UN_NEWS", "резолюции-оон": "CH_UN_RES",
            "совбез-оон": "CH_UN_SC", "генассамблея-оон": "CH_UN_GA",
        }.items():
            chan_map.setdefault(norm(nm), key)
        # стат-каналы меняют цифру в имени → матчим по ключевому слову
        STAT_KW = {"участник": "STAT_MEMBERS", "бот": "STAT_BOTS",
                   "держав": "STAT_PLAYERS", "год": "STAT_YEAR"}
        role_map = {norm(rname): rkey for rkey, rname, *_ in SS_ROLES}

        bound: dict[str, int] = {}
        for ch in ctx.guild.channels:
            if isinstance(ch, disnake.CategoryChannel):
                continue   # категории не привязываем («📜 ИНФОРМАЦИЯ» совпадала с ключом гайда)
            nm = norm(ch.name)
            key = chan_map.get(nm)
            if key and key.startswith("CH_") and not isinstance(ch, disnake.TextChannel):
                key = None   # игровые CH_* — только текстовые каналы
            if not key and getattr(ch, "type", None) == disnake.ChannelType.voice:
                for kw, k in STAT_KW.items():
                    if kw in nm:
                        key = k
                        break
            if key and key not in bound:
                sset(key, ch.id)
                bound[key] = ch.id
        for role in ctx.guild.roles:
            key = role_map.get(norm(role.name))
            if key and key not in bound:
                sset(key, role.id)
                bound[key] = role.id

        # игровая роль регистрации
        if "ROLE_REGISTERED" in bound:
            sset("PROFILE_ROLE", bound["ROLE_REGISTERED"])
            bound["PROFILE_ROLE"] = bound["ROLE_REGISTERED"]
        # карта
        if "CH_MAP" in bound:
            MapState().set_location(bound["CH_MAP"], None)
            self.bot.dispatch("map_dirty")
        # авто-выдача штабу доступа ко всем админ-командам (!perm '*')
        cp = CommandPerms()
        granted = 0
        for k in STAR_GRANT_KEYS:
            if k in bound:
                cp.grant("*", "role", bound[k])
                granted += 1

        # отчёт: что не нашлось
        want_ch = set(chan_map.values()) | set(STAT_KW.values())
        want_role = {"PROFILE_ROLE", "ROLE_MEMBER", "ROLE_REGISTERING"}
        missing = sorted((want_ch | want_role) - set(bound))
        n_ch = sum(1 for k in bound if k.startswith("CH_") or k.startswith("STAT_"))
        n_role = sum(1 for k in bound if k.startswith("ROLE_") or k == "PROFILE_ROLE")
        e = disnake.Embed(
            title="🧩 Авто-привязка завершена",
            description=(f"Сохранено в БД: **{n_ch}** каналов, **{n_role}** ролей.\n"
                        f"Штабу выдан доступ ко всем командам: **{granted}** ролей.\n"
                        + (f"\n⚠️ Не найдено по именам: {', '.join(f'`{m}`' for m in missing)}\n"
                           "-# Задайте вручную: `!setchannel …` / `!setrole …`." if missing else
                           "\n✅ Всё найдено и привязано.")
                        + "\n\nПроверить: `!serverids`."),
            color=SUCCESS_COLOR)
        await ctx.send(embed=e)

    @commands.command(name="importconfig", aliases=["импорт-конфига", "сохранить-конфиг"])
    async def importconfig_cmd(self, ctx):
        """Снимок текущих ID из config.py в БД — чтобы деплой их больше не сбрасывал."""
        if not self._is_admin(ctx):
            await ctx.send(embed=_err("Только администратор."))
            return
        n = 0
        for key, val in FALLBACKS.items():
            if val and not sget(key):   # не затираем уже заданное вручную
                sset(key, val)
                n += 1
        mch = MapState().get_channel_id()
        await ctx.send(embed=disnake.Embed(
            title="📥 Конфиг сохранён в БД",
            description=(f"Перенесено значений из config.py: **{n}**.\n"
                        f"Канал карты (MapState): {'<#%d>' % mch if mch else '—'}\n\n"
                        "Теперь эти ID живут в базе и **деплой кода их не сбросит**. "
                        "Проверить: `!serverids`."),
            color=SUCCESS_COLOR))


def setup(bot: commands.Bot):
    bot.add_cog(IDConfigCog(bot))
