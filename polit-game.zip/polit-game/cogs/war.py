"""
⚔️ Война (Этап 2) — всё ведёт бот, без кураторов.

Объявление: !war declare <страна> <повод>  (нужна общая граница ИЛИ флот для десанта).
Планы:      !warplan <id> <текст>  (можно в ЛС боту — скрытно от врага).
Ход:        как только ОБЕ стороны подали план — бот разбирает раунд (ИИ читает
            оба плана, код считает бой по реальным статам соединений), двигает
            фронт по областям, списывает потери техники/л-с, тратит экономику,
            утомляет народ (стабильность), обновляет карту. Дедлайн раунда 24ч.
Прочее:     !war status <id> · !war list · !war peace <id>.

ИИ влияет только на тактический перевес (±15%) — слабый не «выговорит» победу.
"""

import asyncio
import json
import logging
import time

import disnake
from disnake.ext import commands, tasks

import config
from utils import (War, Army, Countries, MapState, Equipment, Npc, Effects, CURRENCY,
                   COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR)
from utils import war as WE
import utils.army as ARM
import utils.npc as NPC
import utils.equipment as E
import utils.worldmap as WM
from utils.worldmap import resolve_a3, region_name
from utils.serverconfig import rid
from utils.resources import ui_icon
from utils.ui import Panel, cid, parse_cid
from utils.helpers import get_object, get_object_by_user, int_format

log = logging.getLogger("war")

ROUND_DEADLINE = 24 * 3600      # сек до авто-разбора, если одна сторона молчит
UPKEEP_ROUND_MULT = 1.0        # множитель содержания за раунд войны
MIN_ARMY_POWER = 50            # ниже — армия считается разбитой (коллапс)
NEWBIE_WAR_PROTECT = 2 * 86400  # первые 2 дня после регистрации — без войн между игроками
CEDE = -1                       # «репарации» −1 в предложении мира = уступка занятых областей (капитуляция ИИ)


class _NpcRef:
    """Сторона войны — ИИ-государство (в БД стран его нет)."""
    def __init__(self, name: str):
        self.name = name
        self.flag = config.COUNTRIES_ROSTER.get(name, ("🏳️",))[0]


def _ic(name: str) -> str:
    return ui_icon(name)


def _bar(pct: float, width: int = 12) -> str:
    """Визуальная шкала прогресса: ▰▰▰▱▱ 30%."""
    pct = max(0.0, min(100.0, pct))
    filled = round(pct / 100 * width)
    return "▰" * filled + "▱" * (width - filled)


class WarCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.war = War()
        self.army = Army()
        self.equip = Equipment()
        self._ps: dict[int, dict] = {}   # сессии панели !war
        self._owner: dict[int, int] = {}  # message_id панели -> uid владельца (чужой не кликнет)
        self._resolving: set[int] = set()  # войны, раунд которых СЕЙЧАС разбирается (анти-даблклик)
        self.deadline_loop.start()

    def cog_unload(self):
        self.deadline_loop.cancel()

    # ═══════════ ИИ-страны (незанятые государства) ═══════════
    def is_npc(self, name: str) -> bool:
        """Сторона — ИИ-государство: страна из ростера, не занятая игроком и не исчезнувшая."""
        return bool(name) and name in config.COUNTRIES_ROSTER and not get_object(name) \
            and not Npc().is_dissolved(name)

    def npc_name(self, raw: str) -> str | None:
        """Ввод игрока → имя ИИ-страны (без учёта регистра)."""
        q = (raw or "").strip().lower()
        for n in config.COUNTRIES_ROSTER:
            if n.lower() == q and self.is_npc(n):
                return n
        return None

    def npc_power(self, name: str, baseline: bool = False) -> dict:
        """Боевая мощь ИИ-страны: реальная армия × готовность × оставшиеся силы × качество × мораль.
        Те же категории техники и статы, что у игроков (utils/army.COMBAT).
        baseline=True — «потенциал» страны (полные силы, норм. мораль) без чтения/создания состояния ИИ:
        годится и для стран игроков (мобилизационный потенциал — сдерживает агрессию ИИ)."""
        r = config.COUNTRIES_ROSTER[name]
        pers, cats, q = NPC.base_military(name, r[3], r[4])
        if baseline:
            k, morale = NPC.READINESS, 70.0
        else:
            st = Npc().state(name)
            k = NPC.READINESS * max(0.0, st["strength"] if st["strength"] is not None else 1.0)
            morale = st["morale"] if st["morale"] is not None else 70.0
        qm, mm = NPC.QUALITY_MULT.get(q, 1.0), ARM.morale_mult(morale, morale)
        atk = arm = hp = 0.0
        dom = {"land": 0.0, "air": 0.0, "naval": 0.0, "missile": 0.0}
        for cat, n in cats.items():
            ca, cd, ch = ARM.cat_combat(cat)
            u = n * k
            a, d, h = ca * u * qm * mm, cd * u * qm, ch * u * qm * mm
            atk += a; arm += d; hp += h
            dk = E.cat_domain(cat)
            dom[dk] = dom.get(dk, 0.0) + WE.combat_power(a, d, h)
        inf = pers * k / 1000
        ia, iarm, ih = inf * ARM.INF_ATTACK * qm * mm, inf * ARM.INF_ARMOR * qm, inf * ARM.INF_HP * qm * mm
        atk += ia; arm += iarm; hp += ih
        dom["land"] += WE.combat_power(ia, iarm, ih)
        return {"atk": int(atk), "arm": int(arm), "hp": int(hp), "dom": dom, "upkeep": 0,
                "forms": [], "stab": morale, "npc": True}

    def npc_damage(self, name: str, frac: float):
        """Потери ИИ-страны: доля сил и мораль (восстанавливаются вне войны — cogs/npc.py)."""
        st = Npc().state(name)
        frac = max(0.0, min(1.0, frac))
        Npc().set(name, strength=round(max(0.0, (st["strength"] or 0) * (1 - frac)), 4),
                  morale=round(max(10.0, (st["morale"] or 70) - frac * 25), 2))

    @staticmethod
    def newbie_left(name: str) -> int:
        """Сколько секунд ещё действует защита новичка (0 — нет; старые страны без отметки — не новички)."""
        reg = Npc().registered_at(name)
        return max(0, int(reg + NEWBIE_WAR_PROTECT - time.time())) if reg else 0

    def _npc_autoplan(self, war_id: int):
        """ИИ-сторона подаёт план текущего раунда (по доктрине, без вызова ИИ)."""
        w = self.war.get_war(war_id)
        if not w or w["status"] != "active":
            return
        rnd = w["round_no"] + 1
        for side, name in (("att", w["attacker"]), ("def", w["defender"])):
            if not self.is_npc(name) or self.war.plan_for(war_id, rnd, side):
                continue
            other = "def" if side == "att" else "att"
            mine = self._side_power(war_id, name, side)
            enemy = self._side_power(war_id, w["defender"] if side == "att" else w["attacker"], other)
            plan = NPC.plan_for(NPC.doctrine(name), WE.combat_power(mine["atk"], mine["arm"], mine["hp"]),
                                WE.combat_power(enemy["atk"], enemy["arm"], enemy["hp"]), side == "att")
            self.war.submit_plan(war_id, rnd, side, name, plan, "[]", int(time.time()))

    async def _npc_after_round(self, war_id: int):
        """После раунда: ИИ подаёт следующий план; разбитый ИИ сам просит мира, уступая занятое."""
        w = self.war.get_war(war_id)
        if not w or w["status"] != "active":
            return
        self._npc_autoplan(war_id)
        offer, _rep = self.war.get_peace_offer(war_id)
        for name in (w["attacker"], w["defender"]):
            if not self.is_npc(name) or offer:
                continue
            st = Npc().state(name)
            if (st["strength"] or 0) < NPC.PEACE_STRENGTH:
                self.war.set_peace_offer(war_id, name, CEDE)
                opp = w["defender"] if name == w["attacker"] else w["attacker"]
                await self._dm_country(opp, f"{_ic('peace')} ИИ-государство **{name}** разбито и просит мира "
                                            f"(война #{war_id}): готово уступить занятые вами области. "
                                            f"Прими через `!war` → «Мои войны» или `!war peace {war_id}`.")

    def _npc_peace_reply(self, war_id: int, offerer: str, reparations: int) -> bool:
        """Решение ИИ по предложению мира игрока. True — принимает."""
        w = self.war.get_war(war_id)
        npc = w["defender"] if offerer == w["attacker"] else w["attacker"]
        if reparations > 0:            # жёсткие условия возможны лишь при доминировании ≥90% → капитуляция
            return True
        st = Npc().state(npc)
        npc_attacking = npc == w["attacker"]
        npc_gains = self.war.captured_count(war_id, "D" if npc_attacking else "A")
        return ((st["strength"] or 0) < 0.6 or w["round_no"] >= NPC.WHITE_PEACE_ROUNDS
                or (npc_attacking and npc_gains == 0 and w["round_no"] >= 2))

    async def _npc_check_dissolve(self, w):
        """ИИ-страна без единой области исчезает с карты и из регистрации."""
        ov = MapState().overrides()
        for name in (w["attacker"], w["defender"]):
            if not self.is_npc(name):
                continue
            a3 = resolve_a3(name)
            if a3 and not WM.owned_regions(a3, ov):
                Npc().set(name, dissolved=1)
                guild = self.bot.get_guild(config.GUILD_ID) if getattr(config, "GUILD_ID", 0) else None
                if guild:
                    await self._broadcast(guild, disnake.Embed(
                        title="ГОСУДАРСТВО ПРЕКРАТИЛО СУЩЕСТВОВАНИЕ",
                        description=f"{_ic('defeat')} **{name}** полностью аннексирована и исчезает с карты мира. "
                                    f"Занять эту страну больше нельзя.", color=0x2E3440))

    # ═══════════ боевая мощь страны ═══════════
    def _army_power(self, country: str) -> dict:
        """Суммарные боевые статы ГОТОВЫХ соединений страны + домены + содержание."""
        if self.is_npc(country):
            return self.npc_power(country)
        obj = get_object(country)
        academy = self.army.building_count(country, "academy")
        hap = getattr(obj, "happiness", 100.0) or 0.0
        stab = getattr(obj, "stability", 100.0) or 0.0
        now = time.time()
        atk = arm = hp = upkeep = 0
        dom = {"land": 0.0, "air": 0.0, "naval": 0.0, "missile": 0.0}
        forms = []
        for f in self.army.formations_for(country):
            if (f["ready_at"] or 0) > now:
                continue  # ещё слаживается
            t = f["template"]
            # считаем по ФАКТИЧЕСКОЙ технике + личному составу соединения (не по шаблону)
            a, d, h = self._formation_combat_actual(f, academy, hap, stab)
            atk += a; arm += d; hp += h
            dom[ARM.form_domain(t)] = dom.get(ARM.form_domain(t), 0) + WE.combat_power(a, d, h)
            upkeep += ARM.formation_upkeep(t)
            forms.append(f["id"])
        lgc = self.bot.get_cog("LegacyCog")
        m = lgc.army_mult(country) if lgc else 1.0   # «Наследие»: бонус легендарной державы к силе армии
        train = [r["value"] for r in Effects().active(country, int(time.time())) if r["kind"] == "army_train"]
        if train:
            m *= max(train)                          # инструкторы ЧВК: временный бонус к силе армии
        if m != 1.0:
            atk, arm, hp = int(atk * m), int(arm * m), int(hp * m)
            dom = {k: v * m for k, v in dom.items()}
        return {"atk": atk, "arm": arm, "hp": hp, "dom": dom, "upkeep": upkeep,
                "forms": forms, "stab": stab}

    def _side_power(self, war_id: int, main: str, side: str) -> dict:
        """Мощь стороны войны = главная страна + вступившие союзники (общий бой).
        Потери ложатся на все соединения стороны; мораль/стабильность — главной страны."""
        p = self._army_power(main)
        p = {**p, "dom": dict(p["dom"]), "forms": list(p["forms"]), "members": [main],
             "upkeeps": {main: p["upkeep"]}}
        pmc = self.bot.get_cog("PmcCog")
        for ally in self.war.allies_of(war_id, side):
            if pmc and pmc.is_pmc(ally):       # ЧВК по контракту: её бойцы и техника
                q = pmc.power(ally)
            elif not get_object(ally):
                continue
            else:
                q = self._army_power(ally)
            p["atk"] += q["atk"]; p["arm"] += q["arm"]; p["hp"] += q["hp"]
            for k, v in q["dom"].items():
                p["dom"][k] = p["dom"].get(k, 0) + v
            p["forms"] += q["forms"]
            p["members"].append(ally)
            p["upkeeps"][ally] = q["upkeep"]
        # объединённое командование военного блока: ≥2 члена блока на одной стороне
        al = self.bot.get_cog("AllianceCog")
        cm = al.command_mult(p["members"]) if al else 1.0
        if cm > 1.0:
            p["atk"] = round(p["atk"] * cm); p["arm"] = round(p["arm"] * cm); p["hp"] = round(p["hp"] * cm)
            p["dom"] = {k: v * cm for k, v in p["dom"].items()}
        p["command_mult"] = cm
        return p

    def _diplo_brief(self, war_id: int, att: str, deff: str, ap: dict, dp: dict) -> str:
        """Дипломатическая сводка для ИИ-арбитра: союзники, право прохода, ось наступления."""
        dip = self.bot.get_cog("DiplomacyCog")
        lines = []
        for name, p in ((att, ap), (deff, dp)):
            allies = [m for m in p["members"] if m != name]
            transit = dip.transit_partners(name) if dip else []
            cm = p.get("command_mult", 1.0)
            lines.append(f"{name}: союзники в бою — {', '.join(allies) or 'нет'}; "
                         f"право прохода через — {', '.join(transit) or 'НИКОГО'}"
                         + (f"; объединённое командование блока (+{round((cm - 1) * 100)}% к силе)" if cm > 1 else "")
                         + ".")
        for name in (att, deff):
            if self.is_npc(name):
                lines.append(f"{name} — ИИ-государство: реальная армия страны ({NPC.doctrine(name)}), "
                             f"план составлен по доктрине.")
        nuc = self.bot.get_cog("NuclearCog")
        if nuc:
            ctx_of = lambda n: "ИИ-государство" if self.is_npc(n) else nuc.context(n)  # noqa: E731
            lines.append(f"Ядерный статус: {att} — {ctx_of(att)} {deff} — {ctx_of(deff)}")
        via = self.war.get_via(war_id)
        lines.append(f"Ось наступления {att}: " + (f"через земли {via} (право прохода есть)." if via
                                                     else "напрямую через общую границу или морем."))
        return "\n".join(lines)

    def join_as_ally(self, war_id: int, ally: str, side: str = "def") -> tuple[bool, str]:
        """Союзник вступает в войну (зов союзника — на стороне обороны; ЧВК — на стороне заказчика)."""
        w = self.war.get_war(war_id)
        if not w or w["status"] != "active":
            return False, "Эта война уже закончилась."
        if self.war.is_participant(war_id, ally):
            return False, "Вы уже участвуете в этой войне."
        self.war.add_ally(war_id, ally, side, int(time.time()))
        main = w["defender"] if side == "def" else w["attacker"]
        return True, f"Ваши силы воюют в войне #{war_id} вместе с **{main}**."

    def _formation_combat_actual(self, f, academy: int, hap: float, stab: float) -> tuple:
        """Боевые статы соединения по ЕГО РЕАЛЬНОЙ технике (каждая единица = cat_combat
        своей категории) + личный состав + академия + мораль. Потери техники/л-с
        напрямую снижают мощь. Откат на шаблон, если техника не распознаётся (тест wargear)."""
        t = f["template"]
        atk = arm = hp = 0
        resolved = 0
        for e in self.army.formation_equipment(f["id"]):
            eq = self.equip.get(e["equipment_id"])
            cat = eq["category"] if eq else None
            if cat:
                ca, cd, ch = ARM.cat_combat(cat)
                cnt = e["count"] or 0
                atk += ca * cnt; arm += cd * cnt; hp += ch * cnt
                resolved += cnt
        if resolved == 0:
            # техника не распознана (напр. синтетический wargear) → по шаблону × укомплектованность
            a, d, h = ARM.formation_combat(t, academy, hap, stab)
            tmpl_pers = ARM.form_personnel(t) or 1
            pr = min(1.0, max(0.0, (f["personnel"] or 0) / tmpl_pers))
            req_total = sum(ARM.form_required(t).values())
            cur_total = sum(e["count"] for e in self.army.formation_equipment(f["id"]))
            er = min(1.0, cur_total / req_total) if req_total else 1.0
            r = max(0.1, 0.5 * pr + 0.5 * er)
            return int(a * r), int(d * r), int(h * r)
        # вклад личного состава + качество (академия) + мораль (счастье/стабильность)
        k = (f["personnel"] or 0) // 1000
        atk += k * ARM.INF_ATTACK; arm += k * ARM.INF_ARMOR; hp += k * ARM.INF_HP
        q = ARM.quality_mult(academy); m = ARM.morale_mult(hap, stab)
        return int(atk * q * m), int(arm * q), int(hp * q * m)

    # ═══════════ объявление войны ═══════════
    @commands.command(name="war", aliases=["война", "войну"])
    async def war_cmd(self, ctx: commands.Context, action: str = "", *, rest: str = ""):
        action = (action or "").lower()
        if action in ("declare", "объявить", "объявить-войну"):
            await self._declare(ctx, rest)
        elif action in ("status", "статус"):
            await self._status(ctx, rest)
        elif action in ("list", "список"):
            await self._list(ctx)
        elif action in ("peace", "мир"):
            await self._peace(ctx, rest)
        elif action in ("resolve", "разбор") and ctx.author.guild_permissions.manage_guild:
            await self._force_resolve(ctx, rest)
        elif action in ("aitest", "иитест", "ai"):
            await self._aitest(ctx)
        else:
            # голый !war (или непонятное) → удобная панель с меню
            if not get_object_by_user(ctx.author.id):
                await ctx.send(embed=disnake.Embed(
                    description="Сначала зарегистрируйте страну, чтобы вести войну.", color=ERROR_COLOR))
                return
            s = self._session(ctx.author.id)
            s.update(view="hub", target=None, casus=None, war_id=None, cpage=0)
            msg = await ctx.send(components=self._panel(ctx.author.id).components)
            self._owner[msg.id] = ctx.author.id   # панель принадлежит открывшему

    async def _declare(self, ctx, rest: str):
        parts = rest.split(maxsplit=1)
        if not parts:
            await ctx.send(embed=disnake.Embed(
                description="Укажите цель и повод: `!war declare <страна> <повод>`. Проще — открой `!war`.",
                color=ERROR_COLOR))
            return
        target = parts[0]
        casus = parts[1].strip() if len(parts) > 1 else ""
        ok, note, _wid = await self._core_declare(ctx.author, ctx.guild, target, casus)
        await ctx.send(embed=disnake.Embed(description=note, color=SUCCESS_COLOR if ok else ERROR_COLOR))

    async def _core_declare(self, author, guild, target_name: str, casus: str, force_reach: bool = False):
        """Общая логика объявления войны (для текста и панели). → (ok, note, war_id).
        force_reach — союзник вступает по зову: общая граница не нужна (фронт через союзника)."""
        me = get_object_by_user(author.id)
        if not me:
            return False, "Сначала зарегистрируйте страну.", 0
        if not target_name:
            return False, "Не выбрана страна-цель.", 0
        defender = get_object(target_name)
        npc = False
        if not defender:
            nn = self.npc_name(target_name)
            if not nn:
                return False, f"Страна «{target_name}» не найдена (или уже исчезла с карты).", 0
            if self.war.active_for(nn):
                return False, f"ИИ-государство **{nn}** уже ведёт войну — дождитесь её окончания.", 0
            defender, npc = _NpcRef(nn), True
        if defender.name == me.name:
            return False, "Нельзя объявить войну себе.", 0
        # защита новичков: первые 2 дня — без войн между игроками (с ИИ-странами можно)
        if not npc and not force_reach:
            left = self.newbie_left(me.name)
            if left:
                return False, (f"Первые 2 дня после регистрации — время развития: войну игрокам объявлять нельзя "
                               f"(ещё {left // 3600}ч). Воевать с ИИ-государствами можно."), 0
            left = self.newbie_left(defender.name)
            if left:
                return False, (f"**{defender.name}** — новичок под защитой ещё {left // 3600}ч: "
                               f"первые 2 дня на новые страны нападать нельзя."), 0
        if not (casus or "").strip():
            return False, "Нужен повод (casus belli).", 0
        if self.war.active_between(me.name, defender.name):
            return False, "Между вами уже идёт война.", 0
        a3, d3 = resolve_a3(me.name), resolve_a3(defender.name)
        if not a3 or not d3:
            return False, "Не удалось сопоставить страну с картой.", 0
        overrides = MapState().overrides()
        land = WE.land_adjacent(a3, d3, overrides)
        naval = self._army_power(me.name)["dom"].get("naval", 0) > 0
        via = None   # партнёр по праву прохода/союзу, через чьи земли идёт наступление
        dip = self.bot.get_cog("DiplomacyCog")
        if not land and not naval and dip:
            for partner in dip.transit_partners(me.name):
                p3 = resolve_a3(partner)
                if partner != defender.name and p3 and WE.land_adjacent(p3, d3, overrides):
                    via = partner
                    break
        if not land and not naval and not via and not force_reach:
            return False, (f"Нет общей границы с {defender.name}, нет флота для морского десанта "
                           f"и нет права прохода через соседа (`!diplo`)."), 0
        # при наступлении через земли партнёра ось фронта идёт от ЕГО границы
        src3 = resolve_a3(via) if (via and not land) else a3
        front_d = WE.build_front(src3 or a3, d3, overrides)   # области обороняющегося — цели атакующего
        front_a = WE.build_front(d3, a3, overrides)   # области атакующего — цели контрнаступления
        if not front_d:
            return False, "У цели нет областей на карте.", 0

        wid = self.war.create_war(me.name, defender.name, casus.strip(), int(time.time()))
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("war_declared", me.name, defender.name,
                   f"{me.name} объявила войну {defender.name} (повод: {casus.strip()[:80]})", wid)
        if via and not land:
            self.war.set_via(wid, via)
        for i, fr in enumerate(front_d):
            self.war.add_front(wid, fr["region"], fr["name"], i, fr["is_capital"], side="D")
        for i, fr in enumerate(front_a):
            self.war.add_front(wid, fr["region"], fr["name"], i, fr["is_capital"], side="A")

        if npc:
            self._npc_autoplan(wid)   # ИИ сразу подаёт план первого раунда
        desc = (f"{_ic('war_declare')} **{me.name}** объявляет войну "
                f"{'ИИ-государству' if npc else 'стране'} **{defender.name}**!\n"
                f"**Повод:** {casus.strip()}\n"
                f"**Фронт:** {len(front_d)} областей обороны противника"
                f"{'' if land else (f' (через земли {via})' if via else (' (союзный фронт)' if force_reach else ' (морской десант)'))}. "
                f"Обе стороны могут наступать — "
                f"кто сильнее в раунде, тот и продавливает фронт.\n\n"
                + (f"Армией **{defender.name}** командует ИИ: реальные вооружённые силы страны, план уже подан. "
                   f"Подайте свой план через **`!war`** → «Подать план» (или `!warplan {wid} <план>`)."
                   if npc else
                   f"Оба командующих — подайте план первого раунда через **`!war`** → «Подать план» "
                   f"(или `!warplan {wid} <план>`, можно в ЛС)."))
        e = disnake.Embed(title="⚔️ ВОЙНА ОБЪЯВЛЕНА", description=desc, color=0xC0392B)
        e.set_footer(text=f"Война #{wid} · раунд 1")
        await self._broadcast(guild, e)
        await self._dm_country(defender.name,
                               f"{_ic('war_declare')} Вам объявлена война: **{me.name}** → **{defender.name}**.\n"
                               f"Повод: {casus.strip()}\nОткройте `!war` → «Подать план».")
        dip_note = ""
        if dip:
            try:
                dip_note = await dip.on_war_declared(me.name, defender.name, wid, casus.strip())
            except Exception:
                log.exception("дипломатия: хук объявления войны #%s", wid)
        return True, (f"{_ic('victory')} Война #{wid} объявлена против **{defender.name}**."
                      + (f"\n{dip_note}" if dip_note else "")), wid

    async def npc_declare(self, npc: str, target: str, casus: str) -> int:
        """ИИ-государство само объявляет войну соседу-игроку (вызывает cogs/npc.py). → id войны или 0."""
        if not self.is_npc(npc) or not get_object(target) or self.war.active_for(npc) \
                or self.war.active_between(npc, target):
            return 0
        a3, d3 = resolve_a3(npc), resolve_a3(target)
        ov = MapState().overrides()
        if not a3 or not d3 or not WE.land_adjacent(a3, d3, ov):
            return 0
        front_d = WE.build_front(a3, d3, ov)   # области игрока — цели ИИ
        front_a = WE.build_front(d3, a3, ov)   # области ИИ — цели контрнаступления игрока
        if not front_d or not front_a:
            return 0
        wid = self.war.create_war(npc, target, casus, int(time.time()))
        for i, fr in enumerate(front_d):
            self.war.add_front(wid, fr["region"], fr["name"], i, fr["is_capital"], side="D")
        for i, fr in enumerate(front_a):
            self.war.add_front(wid, fr["region"], fr["name"], i, fr["is_capital"], side="A")
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("war_declared", npc, target, f"ИИ-государство {npc} напало на {target} (повод: {casus})", wid)
        self._npc_autoplan(wid)
        guild = self.bot.get_guild(config.GUILD_ID) if getattr(config, "GUILD_ID", 0) else None
        e = disnake.Embed(title="⚔️ ВОЙНА ОБЪЯВЛЕНА", color=0xC0392B, description=(
            f"{_ic('war_declare')} ИИ-государство **{npc}** объявляет войну стране **{target}**!\n"
            f"**Повод:** {casus}\n**Фронт:** {len(front_d)} областей {target}. Армией {npc} командует ИИ.\n\n"
            f"**{target}**, подайте план обороны через **`!war`** → «Подать план» (или `!warplan {wid} <план>`). "
            f"Раунд разберётся через 24ч и без вашего плана."))
        e.set_footer(text=f"Война #{wid} · раунд 1")
        if guild:
            await self._broadcast(guild, e)
        await self._dm_country(target, f"{_ic('war_declare')} На вас напало ИИ-государство **{npc}** "
                                       f"(повод: {casus}). Война #{wid} — подайте план обороны в `!war`.")
        dip = self.bot.get_cog("DiplomacyCog")
        if dip:
            try:
                await dip.on_war_declared(npc, target, wid, casus)   # зов союзников жертвы по военному блоку
            except Exception:
                log.exception("дипломатия: хук нападения ИИ #%s", wid)
        return wid

    # ═══════════ приём плана ═══════════
    @commands.command(name="warplan", aliases=["план", "warp", "план-войны"])
    async def warplan_cmd(self, ctx: commands.Context, war_id: int = 0, *, plan: str = ""):
        ok, note = await self._core_plan(ctx.author, war_id, plan)
        await ctx.send(embed=disnake.Embed(description=note, color=SUCCESS_COLOR if ok else ERROR_COLOR))

    async def _core_plan(self, author, war_id: int, plan: str):
        """Общая логика приёма плана (текст и панель). → (ok, note)."""
        me = get_object_by_user(author.id)
        if not me:
            return False, "Сначала зарегистрируйте страну."
        w = self.war.get_war(war_id)
        if not w or w["status"] != "active":
            return False, "Активная война с таким id не найдена."
        if me.name == w["attacker"]:
            side = "att"
        elif me.name == w["defender"]:
            side = "def"
        else:
            return False, "Вы не участник этой войны."
        if not (plan or "").strip():
            return False, "Опишите план действий."
        un = self.bot.get_cog("UNCog")
        if un and un.ceasefire(war_id):
            return False, f"Действует прекращение огня ООН ещё {un.ceasefire(war_id) // 3600}ч — раунды запрещены."
        rnd = w["round_no"] + 1
        committed = json.dumps(self._army_power(me.name)["forms"])
        self.war.submit_plan(war_id, rnd, side, me.name, plan.strip()[:1500], committed, int(time.time()))
        self._npc_autoplan(war_id)   # противник-ИИ (если есть) уже подал план — раунд разберётся сразу
        if self.war.both_plans_in(war_id, rnd):
            # разбор (с вызовом ИИ) уводим в фон, чтобы не держать 3-сек. окно ответа
            asyncio.create_task(self._resolve(war_id, rnd))
            return True, (f"{_ic('warplan')} План принят. Обе стороны готовы — **раунд {rnd} разбирается**, "
                          "отчёт появится в канале войн через несколько секунд.")
        return True, f"{_ic('warplan')} План на раунд {rnd} принят для **{me.name}**. Ждём план противника."

    # ═══════════ разбор раунда ═══════════
    async def _resolve(self, war_id: int, rnd: int):
        """Защищённая обёртка: не допускает повторного/параллельного разбора раунда."""
        if war_id in self._resolving:
            return
        w = self.war.get_war(war_id)
        if not w or w["status"] != "active" or w["round_no"] >= rnd:
            return  # война неактивна или этот раунд уже разобран
        self._resolving.add(war_id)
        try:
            await self._resolve_impl(war_id, rnd)
        finally:
            self._resolving.discard(war_id)
        try:
            await self._npc_after_round(war_id)   # ИИ: план следующего раунда / просьба о мире
        except Exception:
            log.exception("ИИ-сторона после раунда войны #%s", war_id)

    async def _resolve_impl(self, war_id: int, rnd: int):
        w = self.war.get_war(war_id)
        if not w or w["status"] != "active":
            return
        att, deff = w["attacker"], w["defender"]
        ap = self._side_power(war_id, att, "att")
        dp = self._side_power(war_id, deff, "def")
        a3, d3 = resolve_a3(att), resolve_a3(deff)

        pa = self.war.plan_for(war_id, rnd, "att")
        pd = self.war.plan_for(war_id, rnd, "def")
        att_plan = pa["plan"] if pa else ""
        def_plan = pd["plan"] if pd else ""
        snapshot = (f"Атакующий {att}: атака {ap['atk']}, броня {ap['arm']}, живучесть {ap['hp']}, "
                    f"авиация {int(ap['dom'].get('air', 0))}, флот {int(ap['dom'].get('naval', 0))}. "
                    f"Обороняющийся {deff}: атака {dp['atk']}, броня {dp['arm']}, живучесть {dp['hp']}, "
                    f"авиация {int(dp['dom'].get('air', 0))}, флот {int(dp['dom'].get('naval', 0))}.\n"
                    f"ДИПЛОМАТИЯ:\n{self._diplo_brief(war_id, att, deff, ap, dp)}")
        adj = await WE.adjudicate(att_plan, def_plan, snapshot)
        edge = adj["edge"]

        # кто взял верх в раунде (с учётом доменов и тактики ИИ)
        att_won, a_score, d_score = WE.clash(
            (ap["atk"], ap["arm"], ap["hp"]), (dp["atk"], dp["arm"], dp["hp"]),
            ap["dom"], dp["dom"], edge)

        if att_won:
            winner, loser, w3, side = att, deff, a3, "D"
            w_pow, l_pow, w_forms, l_forms = a_score, d_score, ap["forms"], dp["forms"]
            w_missile, l_stab = ap["dom"].get("missile", 0), dp["stab"]
            l_power_raw = WE.combat_power(dp["atk"], dp["arm"], dp["hp"])
        else:
            winner, loser, w3, side = deff, att, d3, "A"
            w_pow, l_pow, w_forms, l_forms = d_score, a_score, dp["forms"], ap["forms"]
            w_missile, l_stab = dp["dom"].get("missile", 0), ap["stab"]
            l_power_raw = WE.combat_power(ap["atk"], ap["arm"], ap["hp"])

        target = self.war.current_front(war_id, side)
        if not target:
            await self._finish(war_id, winner, reason="все области противника захвачены")
            return

        fort = WE.fortification(bool(target["is_capital"]), dev=0, stability=l_stab)
        fort = WE.effective_fort(fort, w_missile, l_power_raw)
        overext = WE.overextension(self.war.captured_count(war_id, side), self.war.fronts_total(war_id, side))
        res = WE.push(w_pow, l_pow, fort=fort, overext=overext, siege_progress=target["siege"] or 0)

        # потери: победитель раунда теряет меньше, проигравший больше
        w_dead = self._apply_losses(winner, w_forms, res["winner_loss"])
        l_dead = self._apply_losses(loser, l_forms, res["loser_loss"])
        pmc = self.bot.get_cog("PmcCog")
        if pmc:   # ЧВК в бою несут такие же потери, как их сторона
            for side_p, frac in ((ap, res["winner_loss"] if att_won else res["loser_loss"]),
                                 (dp, res["loser_loss"] if att_won else res["winner_loss"])):
                for m in side_p["members"][1:]:
                    if pmc.is_pmc(m):
                        pmc.damage(m, frac)

        captured_capital = False
        if res["captured"]:
            self.war.capture_front(war_id, target["region"])
            MapState().set_occupied(target["region"], w3)   # ОККУПАЦИЯ (красный+полоски), не аннексия
            self.bot.dispatch("map_dirty")
            captured_capital = bool(target["is_capital"])
        else:
            self.war.set_siege(war_id, target["region"], res["siege_progress"])

        # усталость: проигравший народ устаёт сильнее
        self._wear(loser, WE.WEARINESS_BASE + WE.WEARINESS_LOSER)
        self._wear(winner, WE.WEARINESS_BASE)
        loser_side = dp if att_won else ap
        for p in (ap, dp):   # союзники устают вдвое меньше и платят своё содержание
            for m in p["members"][1:]:
                tired = WE.WEARINESS_BASE + (WE.WEARINESS_LOSER if p is loser_side else 0)
                self._wear(m, tired / 2)
            for m, up in p["upkeeps"].items():
                self._spend(m, int(up * UPKEEP_ROUND_MULT))

        self.war.set_round(war_id, rnd)
        outcome = "ЗАХВАТ" if res["captured"] else f"осада {res['siege_progress']:.0f}%"
        self.war.log(war_id, rnd, f"{winner} → {target['name']}: {outcome}", int(time.time()))

        guild = self.bot.get_guild(config.GUILD_ID) if getattr(config, "GUILD_ID", 0) else None
        await self._report(guild, w, rnd, winner, loser, side, target, res, adj, w_dead, l_dead, ap, dp, att_won)

        # условия окончания
        if captured_capital:
            await self._finish(war_id, winner, reason=f"взята столица — {target['name']}")
            return
        if not self.war.current_front(war_id, side):
            await self._finish(war_id, winner, reason="все области противника захвачены")
            return
        if WE.combat_power(ap["atk"], ap["arm"], ap["hp"]) < MIN_ARMY_POWER:
            await self._finish(war_id, deff, reason="армия атакующего разбита")
            return
        if WE.combat_power(dp["atk"], dp["arm"], dp["hp"]) < MIN_ARMY_POWER:
            await self._finish(war_id, att, reason="армия обороняющегося разбита")

    def _apply_losses(self, country: str, forms: list, frac: float) -> int:
        """Наносит потери соединениям; возвращает число разбитых. Часть потерянной
        техники уходит трофеями на чёрный рынок ЧВК."""
        if self.is_npc(country):
            self.npc_damage(country, frac)
            return int(round(frac * 10))     # условные «разбитые бригады» ИИ-армии
        dead = 0
        lost: dict = {}
        for fid in forms:
            if self.army.damage_formation(fid, frac, lost):
                dead += 1
        pmc = self.bot.get_cog("PmcCog")
        if pmc and lost:
            try:
                pmc.add_trophies(lost)
            except Exception:
                log.exception("трофеи ЧВК")
        return dead

    def _wear(self, country: str, delta: float):
        if self.is_npc(country):
            st = Npc().state(country)
            Npc().set(country, morale=round(max(10.0, (st["morale"] or 70) - delta), 2))
            return
        obj = get_object(country)
        if not obj:
            return
        new = max(0.0, (getattr(obj, "stability", 100.0) or 0.0) - delta)
        Countries().update_object(country, stability=new)

    def _spend(self, country: str, amount: int):
        if amount <= 0:
            return
        obj = get_object(country)
        if not obj:
            return
        # update_object(money=..) трактует значение как ДЕЛЬТУ; списываем не больше, чем есть
        spend = min(int(amount), int(getattr(obj, "money", 0) or 0))
        if spend > 0:
            Countries().update_object(country, money=-spend)

    def _settle_occupation(self, att: str, deff: str, annex: str | None):
        """Разбор оккупаций при окончании войны: annex (a3) — кто АННЕКСИРУЕТ занятое
        (его оккупации становятся его территорией), остальное снимается. None — всё откат."""
        ms = MapState()
        for country in (att, deff):
            a3 = resolve_a3(country)
            if not a3:
                continue
            for r in ms.occupied_by(a3):
                if annex and a3 == annex:
                    ms.set_owner(r, annex)
                ms.clear_occupied(r)
        self.bot.dispatch("map_dirty")

    async def _finish(self, war_id: int, winner: str, reason: str = ""):
        w = self.war.get_war(war_id)
        if not w or w["status"] != "active":
            return
        loser = w["defender"] if winner == w["attacker"] else w["attacker"]
        # тотальная победа — победитель аннексирует всё, что оккупировал
        self._settle_occupation(w["attacker"], w["defender"], resolve_a3(winner))
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("annex", winner, loser, f"{winner} победила {loser} в войне №{war_id} и аннексирует занятое", war_id)
        self.war.end_war(war_id, winner, int(time.time()))
        guild = self.bot.get_guild(config.GUILD_ID) if getattr(config, "GUILD_ID", 0) else None
        cap = self.war.captured_count(war_id)
        e = disnake.Embed(
            title="🏆 ВОЙНА ОКОНЧЕНА",
            description=(f"{_ic('victory')} Победитель: **{winner}**  ·  поражение: **{loser}**\n"
                        f"{('Причина: ' + reason + '.') if reason else ''}\n"
                        f"Захвачено областей: **{cap}**. Карта обновлена."),
            color=0x2E9BD6)
        e.set_footer(text=f"Война #{war_id}")
        if guild:
            await self._broadcast(guild, e)
        await self._npc_check_dissolve(w)

    # ═══════════ отчёт ═══════════
    async def _report(self, guild, w, rnd, winner, loser, side, target, res, adj, w_dead, l_dead, ap, dp, att_won):
        att, deff = w["attacker"], w["defender"]
        counter = (side == "A")   # защитник контрнаступает
        narr = adj.get("narrative") or self._fallback_narr(winner, loser, target, res)
        head = (f"{_ic('victory')} Раунд {rnd} · {target['name']}"
                f"{' ' + _ic('siege') + ' СТОЛИЦА' if target['is_capital'] else ''}")
        lines = [narr, ""]
        # кто есть кто в этой войне
        lines.append(f"⚔️ Атакует войну: **{att}**  ·  🛡️ Обороняется: **{deff}**"
                     + ("  —  но в этом раунде защитник перешёл в **контрнаступление**!" if counter else ""))
        allies_a, allies_d = ap["members"][1:], dp["members"][1:]
        if allies_a or allies_d:
            lines.append(f"{_ic('alliance')} Союзники — "
                         + (f"атаки: **{', '.join(allies_a)}** " if allies_a else "")
                         + (f"обороны: **{', '.join(allies_d)}**" if allies_d else ""))
        if adj.get("special"):
            lines.append(f"{_ic('war')} *{adj['special']}*")
        verb = "наступает на" if not counter else "контратакует в"
        if res["captured"]:
            lines.append(f"{_ic('victory')} **{winner}** взял область **{target['name']}**! Фронт сдвинут вглубь.")
        elif res["stalled"]:
            lines.append(f"{_ic('defense_op')} **{loser}** удержал рубеж **{target['name']}** — прорыва нет.\n"
                         f"{_bar(res['siege_progress'])} **{res['siege_progress']:.0f}%**")
        else:
            lines.append(f"{_ic('siege')} **{winner}** {verb} **{target['name']}**\n"
                         f"{_bar(res['siege_progress'])} **{res['siege_progress']:.0f}%** (нужно 100%)")
        lines.append(
            f"{_ic('losses')} Потери — **{winner}**: разбито соединений **{w_dead}** "
            f"(−{int(res['winner_loss']*100)}%) · **{loser}**: **{l_dead}** (−{int(res['loser_loss']*100)}%)")
        lines.append(f"{_ic('exhaustion')} Народ **{loser}** устал сильнее (стабильность падает).")
        if adj.get("ai"):
            who = "у атакующего" if adj["edge"] > 0 else "у обороны" if adj["edge"] < 0 else "поровну"
            lines.append(f"🧠 ИИ оценил планы — тактический перевес: **{adj['edge']:+.2f}** ({who}).")
        else:
            lines.append(f"-# 🧠 ИИ не ответил — бой по числам. Причина: {adj.get('err') or 'неизвестно'}")
        a_cap = self.war.captured_count(w["id"], "D")
        d_cap = self.war.captured_count(w["id"], "A")
        lines.append(f"-# Силы — {att}: {int(ap['atk'])}/{int(ap['arm'])}/{int(ap['hp'])} · "
                     f"{deff}: {int(dp['atk'])}/{int(dp['arm'])}/{int(dp['hp'])} (атака/броня/живуч.)")
        lines.append(f"-# Захвачено: {att} забрал **{a_cap}** обл. · {deff} забрал **{d_cap}** обл. "
                     f"Следующий раунд: `!warplan {w['id']} <план>`.")
        e = disnake.Embed(title=head, description="\n".join(lines)[:4000], color=0xC0392B)
        e.set_footer(text=f"Война #{w['id']} · раунд {rnd}")
        if guild:
            await self._broadcast(guild, e)

    def _fallback_narr(self, winner, loser, target, res):
        if res["captured"]:
            return f"Войска **{winner}** прорвали оборону и заняли **{target['name']}**."
        if res["stalled"]:
            return f"Оборона **{loser}** у «{target['name']}» выстояла, отбив натиск **{winner}**."
        return f"Войска **{winner}** медленно продавливают оборону **{loser}** у «{target['name']}»."

    # ═══════════ статус / список / мир ═══════════
    async def _status(self, ctx, rest):
        try:
            wid = int(rest.split()[0])
        except (ValueError, IndexError):
            await ctx.send(embed=disnake.Embed(description="Укажите id: `!war status <id>`.", color=ERROR_COLOR))
            return
        w = self.war.get_war(wid)
        if not w:
            await ctx.send(embed=disnake.Embed(description="Война не найдена.", color=ERROR_COLOR))
            return
        att, deff = w["attacker"], w["defender"]
        aD, tD = self.war.captured_count(wid, "D"), self.war.fronts_total(wid, "D")
        aA, tA = self.war.captured_count(wid, "A"), self.war.fronts_total(wid, "A")
        curD = self.war.current_front(wid, "D")
        curA = self.war.current_front(wid, "A")
        lines = [f"{_ic('war')} ⚔️ Атакует: **{att}**  ·  🛡️ Обороняется: **{deff}** · статус: {w['status']}",
                 f"Повод: {w['casus']} · Раунд: {w['round_no']}",
                 f"{_ic('front')} **{att}** захватил **{aD}/{tD}** областей {deff}",
                 f"{_ic('front')} **{deff}** захватил **{aA}/{tA}** областей {att} (контрнаступление)"]
        if curD:
            lines.append(f"{_ic('siege')} Рубеж {att}: **{curD['name']}** "
                         f"({'столица' if curD['is_capital'] else 'осада'} {curD['siege'] or 0:.0f}%)")
        if curA:
            lines.append(f"{_ic('siege')} Рубеж {deff}: **{curA['name']}** "
                         f"({'столица' if curA['is_capital'] else 'осада'} {curA['siege'] or 0:.0f}%)")
        if w["status"] != "active" and w["winner"]:
            lines.append(f"{_ic('victory')} Победитель: **{w['winner']}**")
        await ctx.send(embed=disnake.Embed(title=f"Война #{wid}", description="\n".join(lines),
                                           color=COMMAND_COLOR))

    async def _list(self, ctx):
        wars = self.war.all_active()
        if not wars:
            await ctx.send(embed=disnake.Embed(description=f"{_ic('peace')} Активных войн нет.",
                                               color=COMMAND_COLOR))
            return
        lines = [f"`#{w['id']}` {_ic('war')} **{w['attacker']}** → **{w['defender']}** · раунд {w['round_no']}"
                 for w in wars]
        await ctx.send(embed=disnake.Embed(title="⚔️ Активные войны", description="\n".join(lines),
                                           color=COMMAND_COLOR))

    DOMINATION = 0.9   # доля захваченных областей врага, дающая право на жёсткие условия

    def _domination(self, war_id: int, country: str) -> float:
        """Какую долю областей ВРАГА захватила страна (0..1). Атакующий берёт side D, защитник — side A."""
        w = self.war.get_war(war_id)
        if not w:
            return 0.0
        side = "D" if country == w["attacker"] else "A"
        total = self.war.fronts_total(war_id, side)
        return (self.war.captured_count(war_id, side) / total) if total else 0.0

    async def _peace(self, ctx, rest):
        parts = rest.split()
        try:
            wid = int(parts[0])
        except (ValueError, IndexError):
            await ctx.send(embed=disnake.Embed(
                description="`!war peace <id>` — предложить/принять мир · "
                            "`!war peace <id> <репарации>` — при доминировании потребовать выплату · "
                            "`!war peace <id> decline` — отклонить.", color=ERROR_COLOR))
            return
        action, rep = "toggle", 0
        if len(parts) > 1:
            if parts[1].lower() in ("decline", "отклонить", "нет"):
                action = "decline"
            else:
                try:
                    from utils.helpers import string_to_number
                    rep = int(string_to_number(parts[1]))
                except Exception:
                    rep = 0
        ok, note = await self._core_peace(ctx.author, ctx.guild, wid, action, rep)
        await ctx.send(embed=disnake.Embed(description=note, color=SUCCESS_COLOR if ok else ERROR_COLOR))

    async def _conclude_peace(self, w, acceptor: str, offerer: str, off_rep: int, guild):
        """Заключение мира: acceptor принял условия offerer.
        off_rep > 0 — репарации + offerer аннексирует занятое; CEDE — offerer (ИИ) уступает: acceptor
        аннексирует занятое им; 0 — белый мир, оккупированное возвращается владельцам."""
        war_id = w["id"]
        paid = 0
        if off_rep > 0:
            aobj = get_object(acceptor)
            paid = min(int(off_rep), int(getattr(aobj, "money", 0) or 0))   # у ИИ-страны казны нет → 0
            self._spend(acceptor, paid)
            if paid and get_object(offerer):
                Countries().update_object(offerer, money=paid)   # money = ДЕЛЬТА (прибавится)
            annex, winner = resolve_a3(offerer), offerer
        elif off_rep == CEDE:
            annex, winner = resolve_a3(acceptor), acceptor
        else:
            annex, winner = None, None
        self._settle_occupation(w["attacker"], w["defender"], annex)
        self.war.end_war(war_id, winner, int(time.time()), status="peace")
        self.war.clear_peace_offer(war_id)
        if off_rep > 0:
            terms = (f" **{offerer}** аннексирует занятые области" +
                     (f", репарации **{int_format(paid)}** выплачены." if paid else
                      (" (казны у ИИ-государства нет — только территория)." if self.is_npc(acceptor) else ".")))
        elif off_rep == CEDE:
            terms = f" **{offerer}** капитулирует: **{acceptor}** аннексирует занятые области."
        else:
            terms = " Белый мир — оккупированные области возвращены владельцам."
        if winner:
            un = self.bot.get_cog("UNCog")
            if un:
                un.log("annex", winner, acceptor if winner == offerer else offerer,
                       f"{winner} по итогам войны №{war_id} аннексирует занятое", war_id)
        e = disnake.Embed(title="🕊️ МИР ЗАКЛЮЧЁН", description=(
            f"{_ic('peace')} **{w['attacker']}** и **{w['defender']}** заключили мир (война #{war_id})."
            + terms), color=SUCCESS_COLOR)
        if guild:
            await self._broadcast(guild, e)
        await self._npc_check_dissolve(w)

    async def _core_peace(self, author, guild, war_id: int, action: str = "toggle", reparations: int = 0):
        """Мир с согласием второй стороны. Доминатор (захватил ≥90% областей врага) может
        потребовать репарации; иначе — только белый мир (статус-кво)."""
        me = get_object_by_user(author.id)
        w = self.war.get_war(war_id)
        if not me or not w or w["status"] != "active" or me.name not in (w["attacker"], w["defender"]):
            return False, "Вы не в этой войне или её нет."
        opp = w["defender"] if me.name == w["attacker"] else w["attacker"]
        offer, off_rep = self.war.get_peace_offer(war_id)

        if action == "decline":
            if offer and offer == me.name:
                # отзываем СВОЁ предложение
                self.war.clear_peace_offer(war_id)
                return True, f"{_ic('war')} Ты отозвал своё предложение мира."
            if offer and offer != me.name:
                self.war.clear_peace_offer(war_id)
                await self._dm_country(opp, f"{_ic('war')} **{me.name}** отклонил предложение мира — "
                                             f"война #{war_id} продолжается.")
                return True, f"{_ic('war')} Предложение мира от **{opp}** отклонено. Война продолжается."
            return False, "Нет предложения мира."

        if offer == opp:
            await self._conclude_peace(w, me.name, opp, off_rep, guild)
            return True, f"{_ic('peace')} Вы приняли мир. Война #{war_id} окончена."
        if offer == me.name:
            return False, f"Вы уже предложили мир — ждём ответа **{opp}**."

        # новое предложение
        if reparations > 0:
            dom = self._domination(war_id, me.name)
            if dom < self.DOMINATION:
                return False, (f"{_ic('war')} Жёсткие условия (репарации) доступны только при доминировании "
                               f"≥90% областей врага. У тебя захвачено **{int(dom*100)}%** — пока только белый мир "
                               f"(`!war peace {war_id}` без суммы).")
        self.war.set_peace_offer(war_id, me.name, reparations)
        if self.is_npc(opp):
            if self._npc_peace_reply(war_id, me.name, reparations):
                await self._conclude_peace(w, opp, me.name, reparations, guild)
                return True, (f"{_ic('peace')} ИИ-государство **{opp}** "
                              + ("капитулирует." if reparations > 0 else "согласилось на мир.")
                              + f" Война #{war_id} окончена.")
            self.war.clear_peace_offer(war_id)
            return False, (f"{_ic('war')} ИИ-государство **{opp}** отклонило мир — у него ещё есть силы воевать. "
                           f"Нанеси больше потерь или продержись дольше: после {NPC.WHITE_PEACE_ROUNDS} раундов "
                           f"ИИ соглашается на белый мир, а разбитый сам просит пощады.")
        if reparations > 0:
            await self._dm_country(opp, f"{_ic('war_declare')} **{me.name}** ДИКТУЕТ условия мира (война #{war_id}): "
                                        f"репарации **{int_format(reparations)}** {CURRENCY}. "
                                        f"Прими (`!war peace {war_id}`) или отклони (`!war peace {war_id} decline`) и воюй дальше.")
            return True, (f"{_ic('war_declare')} Ультиматум мира отправлен **{opp}**: репарации "
                          f"**{int_format(reparations)}**. Война кончится, когда они примут.")
        await self._dm_country(opp, f"{_ic('peace')} **{me.name}** предлагает мир (война #{war_id}). "
                                     f"Прими через `!war` → «Мои войны» или `!war peace {war_id}`.")
        return True, (f"{_ic('peace')} Предложение мира отправлено **{opp}**. "
                      "Война закончится, когда они согласятся.")

    async def _force_resolve(self, ctx, rest):
        try:
            wid = int(rest.split()[0])
        except (ValueError, IndexError):
            await ctx.send(embed=disnake.Embed(description="Укажите id: `!war resolve <id>`.", color=ERROR_COLOR))
            return
        w = self.war.get_war(wid)
        if not w or w["status"] != "active":
            await ctx.send(embed=disnake.Embed(description="Активная война не найдена.", color=ERROR_COLOR))
            return
        await self._resolve(wid, w["round_no"] + 1)

    async def _aitest(self, ctx):
        """Проверка, работает ли ИИ-арбитр: делает реальный запрос к модели."""
        key = bool(getattr(config, "OPENAI_API_KEY", ""))
        model = getattr(config, "OPENAI_MODEL", "gpt-4o-mini")
        msg = await ctx.send(embed=disnake.Embed(
            description=f"⏳ Проверяю ИИ… (ключ: {'есть' if key else 'НЕТ'}, модель: `{model}`)",
            color=COMMAND_COLOR))
        adj = await WE.adjudicate(
            "Концентрируем всю мощь на одном участке, авиацией давим ПВО, танками прорыв, окружаем.",
            "Растягиваем силы тонко, ПВО выключено, танки в чистом поле, стоим насмерть.",
            "Область Тест. Атакующий: атака 15000. Обороняющийся: атака 15000.")
        if adj.get("ai"):
            await msg.edit(embed=disnake.Embed(
                title="🧠 ИИ РАБОТАЕТ",
                description=(f"✅ Модель ответила.\n"
                            f"**Тактический перевес (edge):** {adj['edge']:+.2f} "
                            f"(ожидаемо в пользу атакующего, т.к. его план лучше)\n"
                            f"**Нарратив:** {adj['narrative'] or '—'}\n"
                            f"{('**Событие:** ' + adj['special']) if adj.get('special') else ''}"),
                color=SUCCESS_COLOR))
        else:
            await msg.edit(embed=disnake.Embed(
                title="⚠️ ИИ НЕ ОТВЕЧАЕТ — бой идёт по числам",
                description=(f"Ключ в конфиге: **{'есть' if key else 'НЕТ'}**, модель: `{model}`\n"
                            f"**Причина:** {adj.get('err') or 'неизвестно'}\n\n"
                            "-# Проверь: правильный ли `OPENAI_API_KEY`, есть ли баланс/доступ к модели, "
                            "виден ли интернет с хостинга."),
                color=ERROR_COLOR))

    # ═══════════ дедлайн ═══════════
    @tasks.loop(minutes=30)
    async def deadline_loop(self):
        now = time.time()
        un = self.bot.get_cog("UNCog")
        for w in self.war.all_active():
            if un and un.ceasefire(w["id"]):
                continue   # прекращение огня ООН: дедлайны раунда стоят
            rnd = w["round_no"] + 1
            pa = self.war.plan_for(w["id"], rnd, "att")
            pd = self.war.plan_for(w["id"], rnd, "def")
            if pa and pd:
                await self._resolve(w["id"], rnd)
            elif (pa or pd):
                submitted = (pa or pd)["submitted_at"] or 0
                if now - submitted >= ROUND_DEADLINE:
                    await self._resolve(w["id"], rnd)   # вторая сторона прозевала

    @deadline_loop.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════ утилиты ═══════════
    async def _broadcast(self, guild, embed):
        ch = None
        ch_id = rid("CH_WAR", 0)
        if guild and ch_id:
            ch = guild.get_channel(ch_id)
        if ch is None and guild:
            ch = disnake.utils.get(guild.text_channels, name="войны") or \
                 disnake.utils.get(guild.text_channels, name="война")
        if ch is None and guild:
            ch = guild.get_channel(rid("CH_NEWS", 0))
        if isinstance(ch, disnake.TextChannel):
            try:
                await ch.send(embed=embed)
            except Exception:
                log.exception("Не удалось отправить отчёт войны")

    async def _dm_country(self, country: str, text: str):
        obj = get_object(country)
        if not obj or not getattr(obj, "user", 0):
            return
        try:
            user = self.bot.get_user(obj.user) or await self.bot.fetch_user(obj.user)
            if user:
                await user.send(embed=disnake.Embed(description=text, color=WARNING_COLOR))
        except Exception:
            pass


    # ═══════════ ТЕСТ: выдать боевой комплект ═══════════
    WARGEAR_KIT = ["tank_div", "tank_div", "motor_rifle", "motor_rifle",
                   "arty_regt", "aa_div", "air_wing", "recon_bn"]

    @commands.command(name="wargear", aliases=["военкомплект", "выдать-войска", "warkit"])
    async def wargear_cmd(self, ctx: commands.Context, *, country: str = ""):
        """ТЕСТ: мгновенно выдаёт стране готовую армию для войны (владелец/админ)."""
        is_admin = (ctx.guild and (ctx.author.id == ctx.guild.owner_id
                                   or ctx.author.guild_permissions.manage_guild))
        if not is_admin:
            await ctx.send(embed=disnake.Embed(
                description="Тестовая команда — только для владельца/админа.", color=ERROR_COLOR))
            return
        obj = get_object(country.strip())
        if not obj:
            await ctx.send(embed=disnake.Embed(
                description=f"Страна «{country}» не найдена.", color=ERROR_COLOR))
            return
        name = obj.name
        self.army.add_building(name, "barracks", 12)
        self.army.add_building(name, "academy", 3)
        self.army.add_building(name, "command", 6)
        self.army.add_pool(name, 100_000)
        now = int(time.time())
        built: dict[str, int] = {}
        for t in self.WARGEAR_KIT:
            fid = self.army.add_formation(name, t, ARM.form_personnel(t), now, now)
            for i, (cat, n) in enumerate(ARM.form_required(t).items()):
                self.army.add_formation_equipment(fid, 900_000 + i, n)
            built[t] = built.get(t, 0) + 1
        lines = "\n".join(f"{ARM.form_icon(t)} {ARM.form_label(t)} ×{c}" for t, c in built.items())
        await ctx.send(embed=disnake.Embed(
            title=f"🪖 Боевой комплект выдан — {name}",
            description=(f"{lines}\n\n-# + 100 000 л/с, казармы ×12, академия ×3, штабы ×6. "
                        "Соединения готовы (слаживание пропущено). Можно воевать."),
            color=SUCCESS_COLOR))

    # ═══════════ ПАНЕЛЬ !war (всё через меню) ═══════════
    CASUS_PRESETS = [
        "Спорная пограничная область", "Отказ на ультиматум", "Защита союзника",
        "Историческая претензия", "Ответ на шпионаж", "Принуждение к миру",
    ]

    def _session(self, uid: int) -> dict:
        return self._ps.setdefault(
            uid, {"view": "hub", "target": None, "casus": None, "war_id": None, "cpage": 0})

    @staticmethod
    def _pe(name: str):
        ic = ui_icon(name)
        return ic if (ic and ic.startswith("<")) else None

    def npc_targets(self, me_name: str) -> list[str]:
        """ИИ-страны, на которые можно напасть: сухопутные соседи (с учётом захватов) и соседи
        партнёров по праву прохода. Морской десант на дальнюю цель — командой `!war declare`."""
        a3 = resolve_a3(me_name)
        if not a3:
            return []
        ov = MapState().overrides()
        near = set(WM.neighbor_countries(a3, ov))
        dip = self.bot.get_cog("DiplomacyCog")
        for partner in (dip.transit_partners(me_name) if dip else []):
            p3 = resolve_a3(partner)
            if p3:
                near |= WM.neighbor_countries(p3, ov)
        out = [n for n in config.COUNTRIES_ROSTER
               if resolve_a3(n) in near and self.is_npc(n) and not self.war.active_for(n)]
        return sorted(out)

    def _npc_intel(self, name: str, me_name: str) -> str:
        """Разведсводка по ИИ-стране для панели объявления войны."""
        r = config.COUNTRIES_ROSTER[name]
        pers, cats, q = NPC.base_military(name, r[3], r[4])
        st = Npc().state(name)
        k = st["strength"] if st["strength"] is not None else 1.0
        land = sum(cats.get(c, 0) for c in ("mbt", "ifv", "apc"))
        air = sum(cats.get(c, 0) for c in ("multirole", "bomber", "attack_heli"))
        sea = sum(cats.get(c, 0) for c in ("destroyer", "frigate", "corvette", "sub_diesel", "sub_nuclear", "carrier"))
        their = self.npc_power(name)
        mine = self._army_power(me_name)
        ratio = WE.combat_power(mine["atk"], mine["arm"], mine["hp"]) / max(1.0, WE.combat_power(
            their["atk"], their["arm"], their["hp"]))
        return (f"{_ic('recon')} **Разведка: {name}** · {NPC.doctrine(name)}"
                + ("" if NPC.has_table(name) else " (оценка)") + "\n"
                f"-# Личный состав ~{int_format(int(pers * k))} · бронетехника ~{int_format(int(land * k))} · "
                f"авиация ~{int_format(int(air * k))} · флот ~{int_format(int(sea * k))}"
                + (f" · силы восстановлены на {int(k * 100)}%" if k < 0.99 else "") + "\n"
                f"{_ic('attack')} Соотношение сил (твоя готовая армия к их боеготовой): **×{ratio:.2f}**")

    def _country_options(self, me_name: str, page: int, mode: str = "players"):
        """Опции выбора цели (чужие страны, не в войне с нами) + число страниц."""
        if mode == "npc":
            names = self.npc_targets(me_name)
        else:
            names = [n for n in Countries().get_object_names()
                     if n != me_name and not self.war.active_between(me_name, n)]
        names.sort()
        pages = max(1, (len(names) + 24) // 25)
        page = max(0, min(page, pages - 1))
        chunk = names[page * 25:page * 25 + 25]
        return chunk, pages, page

    def _panel(self, uid: int, note: str | None = None) -> Panel:
        s = self._session(uid)
        me = get_object_by_user(uid)
        me_name = me.name if me else "—"
        items = [disnake.ui.TextDisplay(f"## {_ic('war')} Война · управление")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        B = disnake.ButtonStyle

        if s["view"] == "declare":
            mode = s.get("tmode", "players")
            items.append(disnake.ui.TextDisplay(
                f"**Цели:** {'ИИ-государства (соседи)' if mode == 'npc' else 'страны игроков'}\n"
                f"**Цель:** {('**' + s['target'] + '**') if s['target'] else '— выбери из списка —'}\n"
                f"**Повод:** {s['casus'] or '— выбери пресет или напиши свой —'}"))
            left = self.newbie_left(me_name)
            if left and mode != "npc":
                items.append(disnake.ui.TextDisplay(
                    f"{_ic('lock')} Первые 2 дня — время развития: войну игрокам объявлять нельзя ещё "
                    f"**{left // 3600}ч**. С ИИ-государствами воевать можно."))
            opts, pages, page = self._country_options(me_name, s["cpage"], mode)
            s["cpage"] = page
            if opts:
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("war", "pickcountry"), placeholder="Выбрать страну-цель…",
                    options=[disnake.SelectOption(label=n[:100], value=n[:100], default=(n == s["target"]),
                                                  description=("ИИ-государство" if mode == "npc" else None))
                             for n in opts])))
            else:
                items.append(disnake.ui.TextDisplay(
                    "-# Рядом нет ИИ-государств (нужна общая граница или право прохода; морской десант — "
                    "`!war declare <страна> <повод>`)." if mode == "npc" else
                    "-# Нет доступных целей (все в войне или только ты)."))
            if s["target"] and mode == "npc" and self.is_npc(s["target"]):
                items.append(disnake.ui.TextDisplay(self._npc_intel(s["target"], me_name)))
            casus_opts = [disnake.SelectOption(label=c, value=c, default=(c == s["casus"]))
                          for c in self.CASUS_PRESETS]
            casus_opts.append(disnake.SelectOption(label="Свой повод…", value="__custom__",
                                                   emoji=self._pe("warplan")))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("war", "pickcasus"), placeholder="Повод (casus belli)…", options=casus_opts)))
            row = [disnake.ui.Button(style=B.danger, label="Объявить войну", emoji=self._pe("war_declare"),
                                     disabled=not (s["target"] and s["casus"]),
                                     custom_id=cid("war", "dodeclare"))]
            if pages > 1:
                row.append(disnake.ui.Button(style=B.secondary, label=f"{page+1}/{pages}", emoji=self._pe("prev"),
                                             custom_id=cid("war", "cprev")))
                row.append(disnake.ui.Button(style=B.secondary, emoji=self._pe("next") or None,
                                             label=None if self._pe("next") else ">", custom_id=cid("war", "cnext")))
            row.append(disnake.ui.Button(
                style=B.primary, emoji=self._pe("ai_state" if mode != "npc" else "globe"),
                label="ИИ-государства" if mode != "npc" else "Страны игроков", custom_id=cid("war", "tmode")))
            row.append(disnake.ui.Button(style=B.secondary, label="Назад", custom_id=cid("war", "goto", "hub")))
            items.append(disnake.ui.ActionRow(*row))

        elif s["view"] in ("plan", "status"):
            wars = self.war.active_for(me_name)
            active_ids = {w["id"] for w in wars}
            if s["war_id"] and s["war_id"] not in active_ids:
                s["war_id"] = None  # выбранная война уже закончилась — сбрасываем
            if not wars:
                items.append(disnake.ui.TextDisplay(f"{_ic('peace')} У тебя нет активных войн."))
            else:
                def opp(w):
                    return w["defender"] if w["attacker"] == me_name else w["attacker"]
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("war", "pickwar"), placeholder="Выбрать войну…",
                    options=[disnake.SelectOption(
                        label=f"#{w['id']} против {opp(w)}"[:100], value=str(w["id"]),
                        description=f"раунд {w['round_no']}"[:100],
                        default=(w["id"] == s["war_id"])) for w in wars[:25]])))
                if s["war_id"]:
                    items.append(disnake.ui.TextDisplay(self._war_brief(s["war_id"])))
            if s["view"] == "plan":
                submitted = False
                if s["war_id"]:
                    wsel = self.war.get_war(s["war_id"])
                    if wsel:
                        rnd = wsel["round_no"] + 1
                        side = "att" if wsel["attacker"] == me_name else "def"
                        pl = self.war.plan_for(s["war_id"], rnd, side)
                        submitted = bool(pl and (pl["plan"] or "").strip())
                        if submitted:
                            items.append(disnake.ui.TextDisplay(
                                f"{_ic('check')} **Твой план на раунд {rnd} отправлен.**\n"
                                "Ждём план противника — как оба готовы, бот разберёт раунд.\n"
                                "-# Пока раунд не разобран, план можно отредактировать."))
                        else:
                            items.append(disnake.ui.TextDisplay(
                                f"-# Опиши план на раунд {rnd} словами — куда бьёшь, чем прикрываешь, "
                                "как используешь авиацию/флот/разведку."))
                lbl = "Редактировать план" if submitted else "Написать план"
                items.append(disnake.ui.ActionRow(
                    disnake.ui.Button(style=B.success, label=lbl, emoji=self._pe("warplan"),
                                      disabled=not s["war_id"], custom_id=cid("war", "writeplan")),
                    disnake.ui.Button(style=B.secondary, label="Назад", custom_id=cid("war", "goto", "hub"))))
            else:  # status + переговоры о мире
                peace_row = []
                if s["war_id"]:
                    wsel = self.war.get_war(s["war_id"])
                    opp_name = (wsel["defender"] if wsel and wsel["attacker"] == me_name
                                else (wsel["attacker"] if wsel else None))
                    offer, off_rep = self.war.get_peace_offer(s["war_id"])
                    dom = self._domination(s["war_id"], me_name)
                    items.append(disnake.ui.Separator())
                    if offer and offer == opp_name:
                        terms = (" и уступает занятые тобой области (капитуляция)" if off_rep == CEDE else
                                 f" с репарациями **{int_format(off_rep)}** {CURRENCY}" if off_rep
                                 else " (белый мир — границы как есть)")
                        items.append(disnake.ui.TextDisplay(
                            f"### {_ic('peace')} Переговоры о мире\n**{opp_name}** предлагает мир{terms}.\n"
                            "-# Прими — война закончится; отклони — продолжите воевать."))
                        peace_row.append(disnake.ui.Button(style=B.success, label="Принять мир",
                                                           emoji=self._pe("peace"), custom_id=cid("war", "peace")))
                        peace_row.append(disnake.ui.Button(style=B.danger, label="Отклонить",
                                                           custom_id=cid("war", "peacedecline")))
                    elif offer and offer == me_name:
                        terms = (f" (репарации **{int_format(off_rep)}**)" if off_rep > 0 else "")
                        items.append(disnake.ui.TextDisplay(
                            f"### {_ic('peace')} Переговоры о мире\nТы предложил мир{terms} — "
                            f"ждём ответа **{opp_name}**.\n-# Можешь отозвать предложение."))
                        peace_row.append(disnake.ui.Button(style=B.secondary, label="Отозвать предложение",
                                                           custom_id=cid("war", "peacedecline")))
                    else:
                        hint = ("Ты доминируешь — можешь предложить белый мир ИЛИ продиктовать репарации."
                                if dom >= self.DOMINATION
                                else f"Можешь предложить белый мир (границы как есть). "
                                     f"Жёсткие условия откроются при доминировании ≥90% (сейчас {int(dom*100)}%).")
                        items.append(disnake.ui.TextDisplay(f"### {_ic('peace')} Переговоры о мире\n-# {hint}"))
                        peace_row.append(disnake.ui.Button(style=B.success, label="Предложить мир",
                                                           emoji=self._pe("peace"), custom_id=cid("war", "peace")))
                        if dom >= self.DOMINATION:
                            peace_row.append(disnake.ui.Button(style=B.danger, label="Диктовать условия",
                                                               emoji=self._pe("war_declare"), custom_id=cid("war", "dictate")))
                    items.append(disnake.ui.ActionRow(*peace_row))
                items.append(disnake.ui.ActionRow(
                    disnake.ui.Button(style=B.secondary, label="Назад", custom_id=cid("war", "goto", "hub"))))

        else:  # hub
            my_wars = self.war.active_for(me_name) if me else []
            wline = (f"{_ic('war')} У тебя сейчас **{len(my_wars)}** активных войн — жми «Мои войны»."
                     if my_wars else "-# Сейчас ты ни с кем не воюешь.")
            items.append(disnake.ui.TextDisplay(
                f"**Твоя страна:** {me_name}\n{wline}\n\n"
                "**Как это работает — просто:**\n"
                f"{_ic('war_declare')} **1.** Объяви войну — стране игрока или **ИИ-государству** по соседству "
                f"(у ИИ реальная армия, им командует бот).\n"
                f"{_ic('warplan')} **2.** Опиши план словами (как в жизни: куда бьёшь, чем прикрываешь).\n"
                f"{_ic('victory')} **3.** Бот сам считает бой и двигает фронт по областям — область за областью до столицы.\n"
                "-# Ничего вводить вручную не нужно — всё кнопками и в окнах."))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.danger, label="Объявить войну", emoji=self._pe("war_declare"),
                                  custom_id=cid("war", "goto", "declare")),
                disnake.ui.Button(style=B.success, label="Подать план", emoji=self._pe("warplan"),
                                  custom_id=cid("war", "goto", "plan")),
                disnake.ui.Button(style=B.secondary, label="Мои войны", emoji=self._pe("front"),
                                  custom_id=cid("war", "goto", "status"))))

        p = Panel()
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(0xC0392B)))
        return p

    def _war_brief(self, war_id: int) -> str:
        w = self.war.get_war(war_id)
        if not w:
            return "-# Война не найдена."
        att, deff = w["attacker"], w["defender"]
        aD, tD = self.war.captured_count(war_id, "D"), self.war.fronts_total(war_id, "D")
        aA, tA = self.war.captured_count(war_id, "A"), self.war.fronts_total(war_id, "A")
        txt = (f"{_ic('front')} **#{war_id}** ⚔️ {att} vs 🛡️ {deff} · раунд {w['round_no']}\n"
               f"{att} захватил **{aD}/{tD}** · {deff} захватил **{aA}/{tA}** (контрнаступление)")
        curD = self.war.current_front(war_id, "D")
        if curD:
            txt += (f"\n{_ic('siege')} Рубеж {att}: **{curD['name']}** "
                    f"({'столица' if curD['is_capital'] else 'осада'} {curD['siege'] or 0:.0f}%)")
        return txt

    def _can_panel(self, uid: int) -> bool:
        return get_object_by_user(uid) is not None

    async def _guard(self, inter) -> bool:
        """Доступ + владелец панели (чужой не управляет твоим меню)."""
        if not self._can_panel(inter.author.id):
            await inter.response.send_message("🔒 Сначала зарегистрируйте страну (`!war` после регистрации).",
                                              ephemeral=True)
            return False
        msg = getattr(inter, "message", None)
        owner = self._owner.get(msg.id) if msg else None
        if owner is not None and owner != inter.author.id:
            await inter.response.send_message(
                "🔒 Это не твоя панель войны — открой свою командой `!war`.", ephemeral=True)
            return False
        return True

    @commands.Cog.listener("on_button_click")
    async def _war_btn(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("war:"):
            return
        if not await self._guard(inter):
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        if action == "goto":
            s.update(view=args[0], target=None if args[0] != "declare" else s["target"],
                     casus=None if args[0] != "declare" else s["casus"],
                     war_id=None if args[0] not in ("plan", "status") else s["war_id"])
        elif action == "tmode":
            s["tmode"] = "players" if s.get("tmode", "players") == "npc" else "npc"
            s.update(target=None, cpage=0)
            if s["tmode"] == "npc":          # поиск соседей — в фоне (граф соседства строится ~1.5 с)
                await inter.response.defer()
                await asyncio.to_thread(self.npc_targets, get_object_by_user(inter.author.id).name)
                await inter.edit_original_message(components=self._panel(inter.author.id).components)
                return
        elif action == "cprev":
            s["cpage"] = max(0, s["cpage"] - 1)
        elif action == "cnext":
            s["cpage"] = s["cpage"] + 1
        elif action == "customcasus":
            pass
        elif action == "writeplan":
            if s["war_id"]:
                existing = ""  # предзаполним текущим планом (режим редактирования)
                wsel = self.war.get_war(s["war_id"])
                me = get_object_by_user(inter.author.id)
                if wsel and me:
                    rnd = wsel["round_no"] + 1
                    side = "att" if wsel["attacker"] == me.name else "def"
                    pl = self.war.plan_for(s["war_id"], rnd, side)
                    existing = (pl["plan"] if pl else "") or ""
                await inter.response.send_modal(disnake.ui.Modal(
                    title=f"План — война #{s['war_id']}", custom_id=cid("war", "modalplan", str(s["war_id"])),
                    components=[disnake.ui.TextInput(
                        label="Ваш план действий на раунд", custom_id="plan",
                        style=disnake.TextInputStyle.paragraph, max_length=1500, required=True,
                        value=existing[:1500] or None,
                        placeholder="Напр.: танковым кулаком в обход, авиацией давим ПВО, пехота закрепляет…")]))
                return
        elif action == "dictate":
            if s["war_id"]:
                await inter.response.send_modal(disnake.ui.Modal(
                    title=f"Условия мира — война #{s['war_id']}",
                    custom_id=cid("war", "modaldictate", str(s["war_id"])),
                    components=[disnake.ui.TextInput(
                        label="Репарации (сумма), напр. 5000000 или 5kk", custom_id="rep",
                        style=disnake.TextInputStyle.short, max_length=20, required=True)]))
                return
            await inter.response.edit_message(components=self._panel(inter.author.id).components)
            return
        elif action in ("peace", "peacedecline"):
            if s["war_id"]:
                ok, note = await self._core_peace(
                    inter.author, inter.guild, s["war_id"],
                    "decline" if action == "peacedecline" else "toggle")
                await inter.response.edit_message(components=self._panel(inter.author.id, note).components)
            else:
                await inter.response.edit_message(components=self._panel(inter.author.id).components)
            return
        elif action == "dodeclare":
            await inter.response.defer()   # объявление может грузить карту — отвечаем сразу
            ok, note, _wid = await self._core_declare(inter.author, inter.guild, s["target"], s["casus"])
            s.update(view="hub", target=None, casus=None)
            await inter.edit_original_message(components=self._panel(inter.author.id, note).components)
            return
        await inter.response.edit_message(components=self._panel(inter.author.id).components)

    @commands.Cog.listener("on_dropdown")
    async def _war_drop(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("war:"):
            return
        if not await self._guard(inter):
            return
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        if action == "pickcountry":
            s["target"] = inter.values[0] if inter.values else None
        elif action == "pickcasus":
            v = inter.values[0] if inter.values else None
            if v == "__custom__":
                await inter.response.send_modal(disnake.ui.Modal(
                    title="Свой повод для войны", custom_id=cid("war", "modalcasus"),
                    components=[disnake.ui.TextInput(
                        label="Повод (casus belli)", custom_id="casus",
                        style=disnake.TextInputStyle.short, max_length=200, required=True)]))
                return
            s["casus"] = v
        elif action == "pickwar":
            try:
                s["war_id"] = int(inter.values[0])
            except (ValueError, IndexError):
                s["war_id"] = None
        await inter.response.edit_message(components=self._panel(inter.author.id).components)

    @commands.Cog.listener("on_modal_submit")
    async def _war_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("war:"):
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        note = None
        if action == "modalcasus":
            s["casus"] = (inter.text_values.get("casus") or "").strip() or None
        elif action == "modalplan":
            wid = int(args[0]) if args else (s["war_id"] or 0)
            ok, note = await self._core_plan(inter.author, wid, inter.text_values.get("plan", ""))
        elif action == "modaldictate":
            wid = int(args[0]) if args else (s["war_id"] or 0)
            try:
                from utils.helpers import string_to_number
                rep = int(string_to_number(inter.text_values.get("rep", "0")))
            except Exception:
                rep = 0
            ok, note = await self._core_peace(inter.author, inter.guild, wid, "toggle", rep)
        try:
            if inter.response.is_done():
                await inter.followup.send(note or "Готово.", ephemeral=True)
            else:
                await inter.response.edit_message(components=self._panel(inter.author.id, note).components)
        except Exception:
            log.exception("war modal: не удалось ответить на взаимодействие")


def setup(bot: commands.Bot):
    bot.add_cog(WarCog(bot))
