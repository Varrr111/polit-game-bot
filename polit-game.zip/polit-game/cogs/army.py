"""
Армия: военные здания, призыв личного состава и формирование соединений.

  !army / !армия — хаб армии (л/с, здания, соединения, мощь, содержание)

Цепочка: построить (казармы/академия/штаб) → призвать л/с → сформировать
соединение (нужны техника из арсенала, л/с, академия, слот штаба, стабильность).
Формирование занимает время (слаживание). Мощь зависит от морали (счастье+
стабильность). Содержание армии списывается в авто-доходе (cogs/economy.py).
"""

import time

import disnake
from disnake.ext import commands

from utils import (
    Army, Equipment, get_object, get_object_by_user, update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY,
    ADMINISTRATOR, MAIN_ECO_CURATOR, PROFILE_ROLE,
)
from utils.ui import Panel, cid, parse_cid
from utils.serverconfig import rid
from utils.perms import is_staff
from utils.resources import res_icon, res_label, ui_icon, action_icon
import utils.army as ARM
import utils.equipment as E


def bld_ic(kind: str) -> str:
    """Иконка военного здания — кастом через UI-систему (fallback — юникод)."""
    return ui_icon(kind) if kind in ("barracks", "academy", "command") else ARM.bld_icon(kind)


def _emoji(s: str):
    try:
        return disnake.PartialEmoji.from_str(s)
    except Exception:
        return None


def _dur(sec: int) -> str:
    sec = int(sec)
    if sec < 3600:
        return f"{sec // 60} мин"
    h, m = sec // 3600, (sec % 3600) // 60
    return f"{h} ч {m} мин" if m else f"{h} ч"


class ArmyHub(Panel):
    def __init__(self, obj, blds: dict, pool: int, cap: int, formations: list, academy: int):
        super().__init__(timeout=300)
        oid = obj.user
        now = int(time.time())
        hap = getattr(obj, "happiness", 100.0) or 0.0
        stab = getattr(obj, "stability", 100.0) or 0.0
        slots = blds.get("command", 0) * ARM.SLOTS_PER_COMMAND
        assigned = sum(f["personnel"] for f in formations)

        atk_i, arm_i, hp_i = ui_icon("attack"), ui_icon("armor"), ui_icon("hp")
        sol_i = ui_icon("soldier")
        bl = "  ".join(f"{bld_ic(k)} {ARM.bld_label(k)} `×{blds.get(k, 0)}`" for k in ARM.ARMY_BUILDINGS)
        header = (f"-# {getattr(obj, 'flag', '')} {obj.name}\n"
                  f"## {ui_icon('command')} Вооружённые силы\n"
                  f"-# {sol_i} личный состав **{int_format(pool)}** свободно · **{int_format(assigned)}** в строю / лимит **{int_format(cap)}**\n"
                  f"-# {bl}")
        items: list = [disnake.ui.TextDisplay(header), disnake.ui.Separator()]

        T_a = T_d = T_h = 0
        upkeep = 0
        if formations:
            # группируем по типу — иначе при большой армии список превышает лимит 4000
            from collections import defaultdict
            grp: dict = defaultdict(lambda: {"ready": 0, "forming": 0, "a": 0, "d": 0, "h": 0, "next": None})
            for f in formations:
                t = f["template"]
                upkeep += ARM.formation_upkeep(t)
                g = grp[t]
                if now >= f["ready_at"]:
                    a, d, h = ARM.formation_combat(t, academy, hap, stab)
                    T_a += a; T_d += d; T_h += h
                    g["ready"] += 1; g["a"] += a; g["d"] += d; g["h"] += h
                else:
                    g["forming"] += 1
                    if g["next"] is None or f["ready_at"] < g["next"]:
                        g["next"] = f["ready_at"]
            lines = []
            for t, g in grp.items():
                total = g["ready"] + g["forming"]
                parts = [f"{ARM.form_icon(t)} **{ARM.form_label(t)}** ×{total}"]
                if g["ready"]:
                    parts.append(f"{atk_i}`{int_format(g['a'])}` {arm_i}`{int_format(g['d'])}` {hp_i}`{int_format(g['h'])}`")
                if g["forming"]:
                    parts.append(f"🛠️{g['forming']} <t:{g['next']}:R>")
                lines.append("  ".join(parts))
            body = f"-# СОЕДИНЕНИЯ · слотов {len(formations)}/{slots}\n" + "\n".join(lines)
            items.append(disnake.ui.TextDisplay(body[:3900]))
            items.append(disnake.ui.TextDisplay(
                f"-# БОЕВАЯ МОЩЬ АРМИИ\n{atk_i} атака **{int_format(T_a)}** · {arm_i} броня **{int_format(T_d)}** · "
                f"{hp_i} живучесть **{int_format(T_h)}**\n"
                f"-# мораль ×{ARM.morale_mult(hap, stab):.2f} (счастье+стабильность) · "
                f"содержание **−{int_format(upkeep)} {CURRENCY}/ч**"))
        else:
            items.append(disnake.ui.TextDisplay(f"-# СОЕДИНЕНИЯ · слотов 0/{slots}\nСоединений нет — постройте штаб, призовите л/с, сформируйте."))

        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(label="Построить", emoji=_emoji(action_icon("build")), style=disnake.ButtonStyle.primary,
                              custom_id=cid("army", "build", oid)),
            disnake.ui.Button(label="Призыв", emoji=_emoji(ui_icon("recruit")), style=disnake.ButtonStyle.success,
                              custom_id=cid("army", "recruit", oid)),
            disnake.ui.Button(label="Сформировать", emoji=_emoji(ui_icon("form")), style=disnake.ButtonStyle.success,
                              custom_id=cid("army", "form", oid)),
            disnake.ui.Button(label="Распустить", emoji=_emoji(ui_icon("disband")), style=disnake.ButtonStyle.secondary,
                              custom_id=cid("army", "disband", oid)),
        ))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


class RecruitModal(disnake.ui.Modal):
    def __init__(self, cog):
        self.cog = cog
        super().__init__(title="Призыв личного состава", custom_id=cid("army", "recruitmodal"),
                         components=[disnake.ui.TextInput(label="Сколько призвать", custom_id="n",
                                                          style=disnake.TextInputStyle.short, max_length=9)])

    async def callback(self, inter: disnake.ModalInteraction):
        await self.cog.finish_recruit(inter, inter.text_values["n"])


class ArmyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.army = Army()
        self.equip = Equipment()

    async def cog_check(self, ctx: commands.Context) -> bool:
        if not ctx.guild:
            return False
        if is_staff(ctx.author):
            return True
        if MAIN_ECO_CURATOR and ctx.guild.get_role(MAIN_ECO_CURATOR) in ctx.author.roles:
            return True
        if ctx.author.get_role(rid("PROFILE_ROLE", PROFILE_ROLE)):
            return True
        if get_object_by_user(ctx.author.id):
            return True
        await ctx.send(embed=disnake.Embed(description="Вы не зарегистрированы — откройте панель регистрации.", color=ERROR_COLOR))
        return False

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CheckFailure):
            return
        raise error

    def _cap(self, obj) -> int:
        return ARM.manpower_cap(self.army.building_count(obj.name, "barracks"), getattr(obj, "population", 0))

    def _hub(self, obj) -> ArmyHub:
        return ArmyHub(obj, self.army.get_buildings(obj.name), self.army.get_pool(obj.name),
                       self._cap(obj), self.army.formations_for(obj.name),
                       self.army.building_count(obj.name, "academy"))

    @commands.command(name="army", aliases=["армия", "вс", "войска"])
    async def army_cmd(self, ctx):
        obj = get_object_by_user(ctx.author.id)
        if not obj:
            await ctx.send(embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR))
            return
        await ctx.send(components=self._hub(obj).components)

    # ───── здания ─────
    def _build_panel(self, obj) -> Panel:
        blds = self.army.get_buildings(obj.name)
        items: list = [disnake.ui.TextDisplay(f"## {action_icon('build')} Военные здания")]
        for k in ARM.ARMY_BUILDINGS:
            rec = "  ".join(f"{res_icon(r)} {int_format(q)}" for r, q in ARM.bld_recipe(k).items())
            note = {"barracks": f"+{int_format(ARM.MANPOWER_PER_BARRACKS)} к лимиту л/с",
                    "academy": "качество армии + продвинутые соединения",
                    "command": f"+{ARM.SLOTS_PER_COMMAND} слота соединений"}.get(k, "")
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"{bld_ic(k)} **{ARM.bld_label(k)}** `×{blds.get(k, 0)}`\n"
                f"-# {note}\n-# цена: {rec}  ·  **{int_format(ARM.bld_cost(k))} {CURRENCY}**"))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(*[
            disnake.ui.Button(label=ARM.bld_label(k), emoji=_emoji(bld_ic(k)), style=disnake.ButtonStyle.success,
                              custom_id=cid("army", "bld", obj.user, k)) for k in ARM.ARMY_BUILDINGS]))
        p = Panel(timeout=300)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    async def _do_build(self, inter, obj, kind: str):
        if kind not in ARM.ARMY_BUILDINGS:
            await inter.response.send_message("Нет такого здания.", ephemeral=True)
            return
        cost, recipe = ARM.bld_cost(kind), ARM.bld_recipe(kind)
        from utils import Settings
        have = Settings().get_resources(obj.name)
        fresh = get_object(obj.name)
        missing = [f"{res_icon(r)} {res_label(r)} — нужно {int_format(q)}, есть {int_format(have.get(r, 0))}"
                   for r, q in recipe.items() if have.get(r, 0) < q]
        if (fresh.money if fresh else 0) < cost:
            missing.append(f"💰 деньги — нужно {int_format(cost)} {CURRENCY}")
        if missing:
            await inter.response.send_message(embed=disnake.Embed(
                title="Недостаточно", description="\n".join(missing), color=ERROR_COLOR), ephemeral=True)
            return
        for r, q in recipe.items():
            Settings().add_resource(obj.name, r, -q)
        update_money(obj.name, -cost)
        self.army.add_building(obj.name, kind, 1)
        await inter.response.send_message(embed=disnake.Embed(
            title=f"🏗️ {ARM.bld_label(kind)} построено",
            description=f"**{ARM.bld_label(kind)}** (всего ×{self.army.building_count(obj.name, kind)})\n-# −{int_format(cost)} {CURRENCY}",
            color=SUCCESS_COLOR), ephemeral=True)

    # ───── призыв ─────
    async def finish_recruit(self, inter, n_raw: str):
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        try:
            n = int(str(n_raw).replace(" ", ""))
        except ValueError:
            n = 0
        if n < 1:
            await inter.response.send_message(embed=disnake.Embed(description="Укажите число ≥ 1.", color=ERROR_COLOR), ephemeral=True)
            return
        fresh = get_object(obj.name)
        cap = self._cap(fresh)
        assigned = sum(f["personnel"] for f in self.army.formations_for(obj.name))
        pool = self.army.get_pool(obj.name)
        room = cap - (pool + assigned)
        if room <= 0:
            await inter.response.send_message(embed=disnake.Embed(
                description=f"Лимит личного состава достигнут ({int_format(cap)}). Постройте казармы.", color=WARNING_COLOR), ephemeral=True)
            return
        n = min(n, room)
        cost = n * ARM.RECRUIT_COST
        if fresh.money < cost:
            affordable = fresh.money // ARM.RECRUIT_COST
            if affordable < 1:
                await inter.response.send_message(embed=disnake.Embed(
                    description=f"Нужно {int_format(cost)} {CURRENCY} на {int_format(n)} бойцов.", color=ERROR_COLOR), ephemeral=True)
                return
            n, cost = affordable, affordable * ARM.RECRUIT_COST
        update_money(obj.name, -cost)
        self.army.add_pool(obj.name, n)
        # массовый призыв бьёт по счастью
        hit = round(n * ARM.RECRUIT_HAPPINESS_HIT, 2)
        if hit >= 0.01:
            from utils import Countries
            new_hap = max(0.0, (getattr(fresh, "happiness", 100.0) or 0.0) - hit)
            Countries().update_object(obj.name, happiness=new_hap)
        await inter.response.send_message(embed=disnake.Embed(
            title="🫡 Призыв",
            description=f"Призвано **{int_format(n)}** · −{int_format(cost)} {CURRENCY}"
                        + (f"\n-# счастье −{hit:.2f} (недовольство мобилизацией)" if hit >= 0.01 else ""),
            color=SUCCESS_COLOR), ephemeral=True)

    # ───── формирование ─────
    def _form_panel(self, obj) -> Panel:
        fresh = get_object(obj.name)
        cats = self.equip.category_counts(obj.name)
        blds = self.army.get_buildings(obj.name)
        academy = blds.get("academy", 0)
        free_slots = blds.get("command", 0) * ARM.SLOTS_PER_COMMAND - self.army.count_formations(obj.name)
        pool = self.army.get_pool(obj.name)
        stab = getattr(fresh, "stability", 100.0) or 0.0
        opts = []
        for key in ARM.ARMY_FORMATIONS:
            req = ARM.form_required(key)
            ok = (free_slots > 0 and academy >= ARM.form_min_academy(key) and stab >= ARM.MIN_STABILITY_TO_FORM
                  and pool >= ARM.form_personnel(key) and all(cats.get(c, 0) >= n for c, n in req.items()))
            opts.append(disnake.SelectOption(
                label=f"{'✅' if ok else '🔒'} {ARM.form_label(key)}"[:100], value=key, emoji=_emoji(ARM.form_icon(key)),
                description=ARM.required_text_plain(key)[:100]))
        p = Panel(timeout=300)
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(f"## {ui_icon('form')} Формирование соединения\n"
                                   f"-# свободно слотов **{max(0, free_slots)}** · л/с **{int_format(pool)}** · академия **{academy}**\n"
                                   "-# ✅ всё есть · 🔒 чего-то не хватает · выбор = старт слаживания"),
            disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("army", "formsel", obj.user), placeholder="Что сформировать", options=opts[:25])),
            accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    async def _do_form(self, inter, obj, template: str):
        if template not in ARM.ARMY_FORMATIONS:
            await inter.response.send_message("Нет такого соединения.", ephemeral=True)
            return
        fresh = get_object(obj.name)
        blds = self.army.get_buildings(obj.name)
        slots = blds.get("command", 0) * ARM.SLOTS_PER_COMMAND
        used = self.army.count_formations(obj.name)
        academy = blds.get("academy", 0)
        pool = self.army.get_pool(obj.name)
        req = ARM.form_required(template)
        pers = ARM.form_personnel(template)
        cats = self.equip.category_counts(obj.name)

        problems = []
        if used >= slots:
            problems.append(f"нет свободного слота штаба ({used}/{slots}) — постройте **{ARM.bld_label('command')}**")
        if academy < ARM.form_min_academy(template):
            problems.append(f"нужно академий: {ARM.form_min_academy(template)} (построено {academy})")
        if (getattr(fresh, "stability", 100.0) or 0.0) < ARM.MIN_STABILITY_TO_FORM:
            problems.append(f"стабильность ниже {ARM.MIN_STABILITY_TO_FORM} — мобилизация невозможна")
        if pool < pers:
            problems.append(f"не хватает личного состава: нужно {int_format(pers)}, есть {int_format(pool)}")
        for c, n in req.items():
            if cats.get(c, 0) < n:
                problems.append(f"техника {E.cat_label(c)}: нужно {n}, есть {cats.get(c, 0)}")
        if problems:
            await inter.response.send_message(embed=disnake.Embed(
                title=f"Нельзя сформировать · {ARM.form_label(template)}", description="\n".join(f"• {p}" for p in problems),
                color=ERROR_COLOR), ephemeral=True)
            return

        # списываем технику (транзакционно) и л/с, создаём соединение в слаживании
        now = int(time.time())
        ready_at = now + ARM.form_seconds(template)
        taken: list[tuple[int, int]] = []
        for c, n in req.items():
            got = self.equip.take_category(obj.name, c, n)
            if got is None:  # кто-то увёл технику между проверкой и списанием — откат
                for eid, cnt in taken:
                    self.equip.add_stock(obj.name, eid, cnt)
                await inter.response.send_message(embed=disnake.Embed(
                    description="Техника изменилась — попробуйте ещё раз.", color=ERROR_COLOR), ephemeral=True)
                return
            taken.extend(got)
        fid = self.army.add_formation(obj.name, template, pers, ready_at, now)
        for eid, cnt in taken:
            self.army.add_formation_equipment(fid, eid, cnt)
        self.army.add_pool(obj.name, -pers)
        a, d, h = ARM.formation_combat(template, academy, getattr(fresh, "happiness", 100), getattr(fresh, "stability", 100))
        await inter.response.send_message(embed=disnake.Embed(
            title=f"{ARM.form_icon(template)} Формирование начато",
            description=(f"**{ARM.form_label(template)}**\n-# списано: {ARM.required_text(template)}\n"
                         f"-# боевая мощь при готовности: ⚔ {int_format(a)} · 🛡 {int_format(d)} · ❤ {int_format(h)}\n"
                         f"-# слаживание {_dur(ARM.form_seconds(template))} · готово <t:{ready_at}:R>"),
            color=SUCCESS_COLOR), ephemeral=True)

    # ───── роспуск ─────
    def _disband_panel(self, obj) -> Panel:
        forms = self.army.formations_for(obj.name)
        p = Panel(timeout=300)
        if not forms:
            p.add_item(disnake.ui.Container(
                disnake.ui.TextDisplay(f"## {ui_icon('disband')} Роспуск\n-# Соединений нет."),
                accent_colour=disnake.Colour(WARNING_COLOR)))
            return p
        opts = [disnake.SelectOption(label=ARM.form_label(f["template"])[:100], value=str(f["id"]),
                                     emoji=_emoji(ARM.form_icon(f["template"])),
                                     description=f"👥 {int_format(f['personnel'])} · техника вернётся в арсенал"[:100]) for f in forms[:25]]
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(f"## {ui_icon('disband')} Роспуск соединения\n-# техника вернётся в арсенал, л/с — в резерв"),
            disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("army", "disbandsel", obj.user), placeholder="Какое распустить", options=opts)),
            accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    async def _do_disband(self, inter, obj, fid: int):
        f = self.army.get_formation(fid)
        if not f or f["country"] != obj.name:
            await inter.response.send_message("Это не ваше соединение.", ephemeral=True)
            return
        for row in self.army.formation_equipment(fid):
            self.equip.add_stock(obj.name, row["equipment_id"], row["count"])
        self.army.add_pool(obj.name, f["personnel"])
        self.army.remove_formation(fid)
        await inter.response.send_message(embed=disnake.Embed(
            title="🏳️ Соединение распущено",
            description=f"**{ARM.form_label(f['template'])}** · техника в арсенале, {int_format(f['personnel'])} л/с в резерве.",
            color=SUCCESS_COLOR), ephemeral=True)

    # ───── роутеры ─────
    def _guard(self, inter, args):
        oid = int(args[0]) if args and args[0].isdigit() else None
        return not (oid and inter.author.id != oid)

    @commands.Cog.listener()
    async def on_button_click(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("army:"):
            return
        _, action, args = parse_cid(c)
        if not self._guard(inter, args):
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны — откройте панель регистрации.", ephemeral=True)
            return
        if action == "build":
            await inter.response.send_message(components=self._build_panel(obj).components, ephemeral=True)
        elif action == "bld" and len(args) >= 2:
            await self._do_build(inter, obj, args[1])
        elif action == "recruit":
            await inter.response.send_modal(RecruitModal(self))
        elif action == "form":
            await inter.response.send_message(components=self._form_panel(obj).components, ephemeral=True)
        elif action == "disband":
            await inter.response.send_message(components=self._disband_panel(obj).components, ephemeral=True)

    @commands.Cog.listener()
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("army:"):
            return
        _, action, args = parse_cid(c)
        if not self._guard(inter, args):
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message("У вас нет страны — откройте панель регистрации.", ephemeral=True)
            return
        if action == "formsel":
            await self._do_form(inter, obj, inter.values[0])
        elif action == "disbandsel":
            v = inter.values[0]
            await self._do_disband(inter, obj, int(v) if v.isdigit() else -1)


def setup(bot: commands.Bot):
    bot.add_cog(ArmyCog(bot))
