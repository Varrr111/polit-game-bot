"""
Авто-карта мира (Nova Order).

Карта = f(состояния): рисуется с нуля из списка зарегистрированных стран
(таблица countries) + оверрайдов владения (map_territories, Этап 2 — война).
Бот держит ОДНО сообщение с картой в заданном канале и редактирует его при
любом изменении (вход/выход игрока, передача территории).

Команды:
  !mapchannel [#канал]  — АДМИН: назначить канал карты (по умолчанию текущий),
                          запостить карту и запомнить сообщение для авто-правок.
  !mapsync              — АДМИН: принудительно перерисовать карту.
  !map                  — разово прислать карту в текущий канал (без привязки).

Перерисовку инициируют другие коги через self.bot.dispatch("map_dirty").
"""

import asyncio
import io
import logging

import disnake
from disnake.ext import commands

from utils import (
    Countries, MapState, ADMINISTRATOR,
    COMMAND_COLOR, ERROR_COLOR, SUCCESS_COLOR, WARNING_COLOR,
)
from utils.ui import Panel, cid, parse_cid
from utils.perms import has_command_access
from utils.resources import ui_icon
import utils.worldmap as WM

log = logging.getLogger("worldmap")

_FILENAME = "nova_map.png"
_PAGE = 25  # лимит опций в select


def _chunk(items: list, page: int) -> tuple[list, int, int]:
    """Возвращает (срез_страницы, нормализованный_номер, всего_страниц)."""
    pages = max(1, (len(items) + _PAGE - 1) // _PAGE)
    page = max(0, min(page, pages - 1))
    return items[page * _PAGE:(page + 1) * _PAGE], page, pages


class WorldMapCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.state = MapState()
        self._lock = asyncio.Lock()  # не рендерим две карты параллельно
        self._sessions: dict[int, dict] = {}  # сессии панели куратора (на юзера)

    def _is_admin(self, ctx: commands.Context) -> bool:
        return has_command_access(ctx.author, ctx.command.name if ctx.command else "warmap")

    # ───── сборка картинки ─────
    def _build_png(self) -> bytes:
        """Синхронный рендер (вызывается в executor'е)."""
        active: dict[str, str] = {}
        for name in self.countries.get_object_names():
            a3 = WM.resolve_a3(name)
            if a3:
                active[a3] = name
            else:
                log.warning("Страна без геометрии на карте: %r", name)
        overrides = self.state.overrides()
        occupied = self.state.occupations()
        lgc = self.bot.get_cog("LegacyCog")
        legends = lgc.legend_map() if lgc else {}
        for a3, title in legends.items():   # «Наследие»: подпись — титул державы
            if a3 in active:
                active[a3] = title
        pmc = self.bot.get_cog("PmcCog")
        bases = pmc.base_markers() if pmc else {}      # метки баз ЧВК
        return WM.render_map(active, overrides, occupied=occupied, legendary=set(legends) & set(active),
                             pmc_bases=bases)

    async def _render(self) -> bytes:
        return await self.bot.loop.run_in_executor(None, self._build_png)

    def _map_v2(self, active_count: int):
        """Красивая публикация карты (Components V2 — кастом-иконки рендерятся)."""
        p = Panel(timeout=None)
        items = [
            disnake.ui.TextDisplay(f"## {ui_icon('globe')} Карта мира · Nova Order"),
            disnake.ui.TextDisplay(
                f"{ui_icon('victory')} В игре держав: **{active_count}** — каждая страна своим цветом.\n"
                f"-# {ui_icon('war')} красные полоски — оккупация на войне · "
                f"{ui_icon('front')} цвет захватчика — аннексия после мира · {ui_icon('pmc_base')} голубой ромб — база ЧВК."),
            disnake.ui.MediaGallery(disnake.MediaGalleryItem("attachment://" + _FILENAME)),
        ]
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    def _file(self, png: bytes) -> disnake.File:
        return disnake.File(io.BytesIO(png), filename=_FILENAME)

    # ───── публичный refresh (из других когов тоже) ─────
    async def refresh(self) -> bool:
        """Перерисовать и обновить закреплённое сообщение карты. True — успех."""
        channel_id = self.state.get_channel_id()
        if not channel_id:
            return False
        channel = self.bot.get_channel(channel_id)
        if channel is None:
            try:
                channel = await self.bot.fetch_channel(channel_id)
            except disnake.HTTPException:
                log.warning("Канал карты %s недоступен", channel_id)
                return False

        async with self._lock:
            png = await self._render()
            active_count = len([1 for n in self.countries.get_object_names() if WM.resolve_a3(n)])
            comp = self._map_v2(active_count).components
            msg_id = self.state.get_message_id()

            if msg_id:
                try:
                    msg = await channel.fetch_message(msg_id)
                    try:
                        await msg.edit(components=comp, file=self._file(png), attachments=[])
                        return True
                    except disnake.HTTPException:
                        await msg.delete()   # старое embed-сообщение → пересоздаём как V2
                except disnake.NotFound:
                    pass  # сообщение удалили — создадим заново

            msg = await channel.send(components=comp, file=self._file(png))
            self.state.set_location(channel_id, msg.id)
            return True

    # ───── слушатель события «карта изменилась» ─────
    @commands.Cog.listener()
    async def on_map_dirty(self):
        try:
            await self.refresh()
        except Exception:
            log.exception("Не удалось обновить карту по событию map_dirty")

    @commands.Cog.listener()
    async def on_ready(self):
        # Прогреваем кэш геометрии один раз: убирает задержку первого рендера
        # и гонку, если !map и авто-обновление стартуют параллельно на холодном кэше.
        if getattr(self, "_warmed", False):
            return
        self._warmed = True
        try:
            await self.bot.loop.run_in_executor(None, WM._ensure_projected)
            log.info("Геометрия карты прогрета")
        except Exception:
            log.exception("Не удалось прогреть геометрию карты")

    # ───── команды ─────
    @commands.command(name="mapchannel", aliases=["карта-канал", "канал-карты"])
    async def mapchannel_cmd(self, ctx: commands.Context, channel: disnake.TextChannel | None = None):
        if not self._is_admin(ctx):
            await ctx.send(embed=disnake.Embed(
                description="Только администратор.", color=ERROR_COLOR))
            return
        target = channel or ctx.channel
        async with ctx.typing():
            png = await self._render()
            active_count = len([1 for n in self.countries.get_object_names() if WM.resolve_a3(n)])
            msg = await target.send(components=self._map_v2(active_count).components, file=self._file(png))
            self.state.set_location(target.id, msg.id)
        await ctx.send(embed=disnake.Embed(
            description=f"Канал карты: {target.mention}. Карта будет обновляться автоматически.",
            color=COMMAND_COLOR))

    @commands.command(name="mapsync", aliases=["карта-обновить", "обновить-карту"])
    async def mapsync_cmd(self, ctx: commands.Context):
        if not self._is_admin(ctx):
            await ctx.send(embed=disnake.Embed(description="Только администратор.", color=ERROR_COLOR))
            return
        async with ctx.typing():
            ok = await self.refresh()
        if ok:
            await ctx.send(embed=disnake.Embed(description="Карта обновлена.", color=SUCCESS_COLOR))
        else:
            await ctx.send(embed=disnake.Embed(
                description="Канал карты не задан. Сначала `!mapchannel`.", color=ERROR_COLOR))

    def _build_bloc_png(self, kind: str) -> tuple[bytes, list]:
        """Карта блоков: каждая страна блока — цветом своего блока."""
        import utils.alliance as AL
        al = self.bot.get_cog("AllianceCog")
        by_name, legend = al.map_palette(kind) if al else ({}, [])
        active, palette = {}, {}
        for name in self.countries.get_object_names():
            a3 = WM.resolve_a3(name)
            if a3:
                active[a3] = name
                if name in by_name:
                    palette[a3] = by_name[name]
        rows = [(f"[{t}] {n} · {c}", col) for t, n, col, c in legend]
        rows.append(("вне блоков", WM.OUTSIDE_BLOC))
        png = WM.render_map(active, self.state.overrides(), subtitle=AL.KINDS[kind]["plural"].upper(),
                            occupied=self.state.occupations(), palette=palette, legend=rows)
        return png, legend

    @commands.command(name="map", aliases=["карта"])
    async def map_cmd(self, ctx: commands.Context, mode: str = ""):
        m = (mode or "").lower()
        kind = ("military" if m in ("блоки", "блок", "альянсы", "военные", "blocs", "military") else
                "economic" if m in ("экономика", "экономические", "союзы", "economic") else None)
        if kind:
            async with ctx.typing():
                png, legend = await self.bot.loop.run_in_executor(None, self._build_bloc_png, kind)
                import utils.alliance as AL
                p = Panel(timeout=None)
                other = "`!карта экономика`" if kind == "military" else "`!карта блоки`"
                p.add_item(disnake.ui.Container(
                    disnake.ui.TextDisplay(f"## {ui_icon(AL.KINDS[kind]['icon'])} Карта блоков · "
                                           f"{AL.KINDS[kind]['plural']}"),
                    disnake.ui.TextDisplay(
                        f"{ui_icon('alliance')} Блоков: **{len(legend)}** — каждый своим цветом, "
                        f"тусклые — вне блоков.\n-# Другой тип: {other} · вступить — `!альянс`."),
                    disnake.ui.MediaGallery(disnake.MediaGalleryItem("attachment://" + _FILENAME)),
                    accent_colour=disnake.Colour(COMMAND_COLOR)))
                await ctx.send(components=p.components, file=self._file(png))
            return
        async with ctx.typing():
            png = await self._render()
            active_count = len([1 for n in self.countries.get_object_names() if WM.resolve_a3(n)])
            await ctx.send(components=self._map_v2(active_count).components, file=self._file(png))

    # ══════════════════════════════════════════════════════════════════════
    #  ПАНЕЛЬ КУРАТОРА ВОЙНЫ  —  ручная передача территорий (!warmap)
    #  Каскад: континент → страна-цель → владелец + мульти-выбор областей.
    #  Состояние держим в памяти на куратора (инструмент живой, не вечный).
    # ══════════════════════════════════════════════════════════════════════
    def _session(self, user_id: int) -> dict:
        s = self._sessions.get(user_id)
        if s is None:
            s = {"continent": None, "victim": None, "owner": None,
                 "selected": set(), "cpage": 0, "rpage": 0}
            self._sessions[user_id] = s
        return s

    def _owner_options(self, current):
        """Опции «новый владелец»: зарегистрированные страны (игроки) + освобождение."""
        opts = [disnake.SelectOption(
            label="♻️ Освободить (вернуть исходным)", value="__free__",
            default=(current == "__free__"))]
        pairs = []
        for nm in self.countries.get_object_names():
            a3 = WM.resolve_a3(nm)
            if a3:
                obj = self.countries.get_object(nm)
                pairs.append((a3, nm, getattr(obj, "flag", "") or ""))
        pairs.sort(key=lambda t: t[1])
        for a3, nm, flag in pairs[:24]:
            opts.append(disnake.SelectOption(
                label=f"{flag} {nm}".strip()[:100], value=a3, default=(current == a3)))
        return opts

    def _wmap_panel(self, s: dict, note: str | None = None) -> Panel:
        cont, victim, owner, sel = s["continent"], s["victim"], s["owner"], s["selected"]
        B = disnake.ButtonStyle
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('globe')} Редактор карты · передача территорий")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        vt = WM.country_name(victim) if victim else "—"
        ot = "♻️ Освобождение" if owner == "__free__" else (WM.country_name(owner) if owner else "—")
        items.append(disnake.ui.TextDisplay(
            f"**Цель:** {vt}\n**Новый владелец:** {ot}\n**Отмечено областей:** `{len(sel)}`"))
        items.append(disnake.ui.Separator())

        if not cont:
            items.append(disnake.ui.TextDisplay("-# ШАГ 1 · КОНТИНЕНТ СТРАНЫ-ЦЕЛИ"))
            opts = [disnake.SelectOption(label=WM.CONTINENT_RU[c], value=c)
                    for c in WM.CONTINENTS_ORDER]
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("wmap", "cont"), placeholder="Континент…", options=opts)))

        elif not victim:
            countries = WM.countries_by_continent(cont)
            page_items, s["cpage"], pages = _chunk(countries, s["cpage"])
            items.append(disnake.ui.TextDisplay(
                f"-# ШАГ 2 · СТРАНА-ЦЕЛЬ · {WM.CONTINENT_RU[cont]} · стр. {s['cpage']+1}/{pages}"))
            opts = [disnake.SelectOption(label=nm[:100], value=a3) for a3, nm in page_items]
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("wmap", "victim"), placeholder="Выберите страну-цель…", options=opts)))
            row = []
            if s["cpage"] > 0:
                row.append(disnake.ui.Button(style=B.secondary, label="◀ Назад",
                                             custom_id=cid("wmap", "cpage", "prev")))
            if s["cpage"] < pages - 1:
                row.append(disnake.ui.Button(style=B.secondary, label="Вперёд ▶",
                                             custom_id=cid("wmap", "cpage", "next")))
            row.append(disnake.ui.Button(style=B.secondary, label="⟵ Континенты",
                                         custom_id=cid("wmap", "backcont")))
            items.append(disnake.ui.ActionRow(*row))

        else:
            items.append(disnake.ui.TextDisplay("-# ШАГ 3 · НОВЫЙ ВЛАДЕЛЕЦ"))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("wmap", "owner"), placeholder="Кому передать…",
                options=self._owner_options(owner))))
            regions = WM.region_list(victim)
            page_items, s["rpage"], pages = _chunk(regions, s["rpage"])
            nav = f" · ⬅️ листайте кнопками ➡️" if pages > 1 else ""
            items.append(disnake.ui.TextDisplay(
                f"**Области · {WM.country_name(victim)}** — страница **{s['rpage']+1} из {pages}** "
                f"· всего областей: {len(regions)} · отмечено: {len(sel)}{nav}"))
            ropts = [disnake.SelectOption(label=nm[:100], value=code, default=(code in sel))
                     for code, nm in page_items]
            if ropts:
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("wmap", "regs"),
                    placeholder=f"Отметьте области (стр. {s['rpage']+1}/{pages})…",
                    options=ropts, min_values=0, max_values=len(ropts))))
            else:
                items.append(disnake.ui.TextDisplay("-# У этой страны нет областей в данных карты."))
            # Один ряд: навигация по страницам (если их >1) + массовый выбор.
            brow = []
            if pages > 1:
                brow.append(disnake.ui.Button(
                    style=B.primary, label="◀ Пред.", disabled=(s["rpage"] == 0),
                    custom_id=cid("wmap", "rpage", "prev")))
                brow.append(disnake.ui.Button(
                    style=B.primary, label="След. ▶", disabled=(s["rpage"] >= pages - 1),
                    custom_id=cid("wmap", "rpage", "next")))
            brow.append(disnake.ui.Button(style=B.secondary, label="✅ Выбрать ВСЮ страну",
                                          custom_id=cid("wmap", "selall")))
            brow.append(disnake.ui.Button(style=B.secondary, label="Снять всё",
                                          custom_id=cid("wmap", "clear")))
            items.append(disnake.ui.ActionRow(*brow))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.success, label="✅ Применить на карте",
                                  custom_id=cid("wmap", "apply")),
                disnake.ui.Button(style=B.secondary, label="⟵ Другая страна",
                                  custom_id=cid("wmap", "backcountry"))))

        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    async def _apply(self, s: dict) -> str:
        """Записывает выбранные области владельцу (или освобождает) и обновляет карту."""
        sel, owner = s["selected"], s["owner"]
        if not owner:
            return "⚠️ Сначала выберите нового владельца."
        if not sel:
            return "⚠️ Не отмечено ни одной области."
        for code in sel:
            if owner == "__free__":
                self.state.reset_region(code)
            else:
                self.state.set_owner(code, owner)
        n = len(sel)
        vt = WM.country_name(s["victim"])
        s["selected"] = set()
        # Обновляем карту отдельной задачей (рендер+загрузка долгие) — чтобы
        # НЕ держать ответ на взаимодействие и не словить таймаут токена (3с).
        self.bot.dispatch("map_dirty")
        if owner == "__free__":
            return f"♻️ Освобождено областей: **{n}** ({vt}). Карта обновляется…"
        return f"✅ Передано областей: **{n}** · {vt} → **{WM.country_name(owner)}**. Карта обновляется…"

    def _guard(self, inter) -> bool:
        return has_command_access(inter.author, "warmap")

    @commands.Cog.listener("on_dropdown")
    async def _wmap_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("wmap:"):
            return
        if not self._guard(inter):
            await inter.response.send_message("Только куратор/админ.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        if action == "cont":
            s.update(continent=inter.values[0], victim=None, selected=set(), cpage=0)
        elif action == "victim":
            s.update(victim=inter.values[0], selected=set(), rpage=0)
        elif action == "owner":
            s["owner"] = inter.values[0]
        elif action == "regs":
            regions = WM.region_list(s["victim"])
            page_items, _, _ = _chunk(regions, s["rpage"])
            page_codes = {code for code, _ in page_items}
            s["selected"] = (s["selected"] - page_codes) | set(inter.values)
        await inter.response.edit_message(components=self._wmap_panel(s).components)

    @commands.Cog.listener("on_button_click")
    async def _wmap_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("wmap:"):
            return
        if not self._guard(inter):
            await inter.response.send_message("Только куратор/админ.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        note = None
        if action == "cpage":
            s["cpage"] += 1 if args and args[0] == "next" else -1
        elif action == "rpage":
            s["rpage"] += 1 if args and args[0] == "next" else -1
        elif action == "backcont":
            s.update(continent=None, victim=None, selected=set())
        elif action == "backcountry":
            s.update(victim=None, selected=set())
        elif action == "selall":
            s["selected"] = {code for code, _ in WM.region_list(s["victim"])}
        elif action == "clear":
            s["selected"] = set()
        elif action == "apply":
            note = await self._apply(s)
        await inter.response.edit_message(components=self._wmap_panel(s, note).components)

    @commands.command(name="warmap", aliases=["карта-война", "редактор-карты", "waredit"])
    async def warmap_cmd(self, ctx: commands.Context):
        if not self._is_admin(ctx):
            await ctx.send(embed=disnake.Embed(description="Только куратор/админ.", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(continent=None, victim=None, owner=None, selected=set(), cpage=0, rpage=0)
        await ctx.send(components=self._wmap_panel(s).components)


def setup(bot: commands.Bot):
    bot.add_cog(WorldMapCog(bot))
