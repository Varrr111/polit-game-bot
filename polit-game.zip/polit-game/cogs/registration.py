"""
Регистрация — ТОЛЬКО через панель !regpanel (континент → страна), маршрут по
custom_id "reg:" в on_dropdown. Отдельной команды !register нет (единый путь).

Профиль создаётся с данными страны из ростера (config.COUNTRIES_ROSTER),
игроку выдаётся роль PROFILE_ROLE. Занятую страну взять нельзя.
Отдельный ког — чтобы проверка роли из экономики не блокировала регистрацию.
"""

import time

import disnake
from disnake.ext import commands

from utils import (
    Countries, Buildings, News, Spy, Politics, Npc, War, MapState, Pmc, COUNTRIES_ROSTER, PROFILE_ROLE, ADMINISTRATOR,
    GUILD_ID, COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY,
    get_object, get_object_by_user, int_format, has_command_access,
)
import utils.politics as P
from utils.resources import ui_icon, res_icon, res_label, country_deposits, has_deposit
from utils.ui import Panel, cid, parse_cid
from utils.serverconfig import rid


def _pe(slug: str):
    try:
        s = ui_icon(slug)
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None

START_MONEY = 100_000_000  # стартовый баланс новой страны

CONTINENT_ORDER = [
    "Европа", "Азия", "Африка",
    "Северная Америка", "Южная Америка", "Австралия и Океания",
]


def _embed(title: str, desc: str, color: int = COMMAND_COLOR) -> disnake.Embed:
    return disnake.Embed(title=title, description=desc, color=color)


def _npc_block(name: str) -> str:
    """Почему свободную страну сейчас нельзя занять (пусто — можно): ИИ-государство воюет
    или полностью аннексировано (исчезло с карты)."""
    if Npc().is_dissolved(name):
        return "государство полностью аннексировано и исчезло с карты"
    if War().active_for(name):
        return "страна сейчас воюет под управлением ИИ — дождитесь конца войны"
    return ""


def _remaining_share(name: str) -> float:
    """Доля областей, которыми страна владеет сейчас (часть могла отойти по итогам войн)."""
    import utils.worldmap as WM
    a3 = WM.resolve_a3(name)
    if not a3:
        return 1.0
    total = len(WM.regions_of(a3))
    if not total:
        return 1.0
    return len(WM.owned_regions(a3, MapState().overrides())) / total


def _available(continent: str) -> list[str]:
    """Свободные (незанятые) страны континента, которые сейчас можно занять."""
    return [n for n, d in COUNTRIES_ROSTER.items()
            if d[1] == continent and not get_object(n) and not _npc_block(n)]


# ВСЕ таблицы, привязанные к стране: (таблица, колонка). Для полного снятия.
_COUNTRY_TABLES = [
    ("countries", "name"), ("resources", "name"), ("buildings", "name"),
    ("building_levels", "name"), ("allocation", "name"), ("country_upgrades", "name"),
    ("bank", "name"), ("collect_cooldown", "name"), ("work_cooldown", "name"),
    ("cooldowns", "name"), ("infrastructure", "name"), ("companies", "country"),
    ("politics", "name"), ("country_effects", "country"),
    ("army_buildings", "country"), ("manpower", "country"), ("formations", "country"),
    ("equipment", "owner"), ("equipment_stock", "country"), ("equipment_plants", "country"),
    ("equipment_licenses", "country"), ("production_queue", "country"),
    ("inventory", "owner"), ("licenses", "owner"), ("war_allies", "country"),
]


def _purge_country(name: str):
    """Полностью стирает ВСЕ данные страны из БД (при снятии регистрации) —
    чтобы ничего не осталось и не перешло следующему владельцу."""
    import sqlite3
    from utils.database import DB_PATH
    conn = sqlite3.connect(str(DB_PATH))
    try:
        # сначала техника соединений (по формированиям страны)
        try:
            conn.execute("DELETE FROM formation_equipment WHERE formation_id IN "
                         "(SELECT id FROM formations WHERE country = ?)", (name,))
        except sqlite3.OperationalError:
            pass
        for tbl, col in _COUNTRY_TABLES:
            try:
                conn.execute(f"DELETE FROM {tbl} WHERE {col} = ?", (name,))
            except sqlite3.OperationalError:
                pass
        # ультиматумы, где страна — инициатор или цель
        try:
            conn.execute("DELETE FROM ultimatums WHERE issuer = ? OR target = ?", (name, name))
        except sqlite3.OperationalError:
            pass
        conn.commit()
    finally:
        conn.close()
    # спец-менеджеры со своей логикой очистки
    try:
        News().clear_country(name)
    except Exception:
        pass
    try:
        Spy().clear_country(name)
    except Exception:
        pass
    try:
        from utils import Sanctions
        Sanctions().clear_country(name)
    except Exception:
        pass
    try:
        from utils import Diplomacy
        Diplomacy().clear_country(name)
    except Exception:
        pass
    try:
        Pmc().clear_country(name)      # заказы, сделки, отношения, санкции и налог страны для ЧВК
    except Exception:
        pass
    try:
        from utils import Legacy
        Legacy().clear_country(name)   # держава «Наследия» снова свободна
    except Exception:
        pass
    try:
        Npc().clear_country(name)   # отметка регистрации (защита новичка)
    except Exception:
        pass
    try:
        from utils import Un
        Un().clear_country(name)
    except Exception:
        pass
    try:
        from utils import Nuclear
        Nuclear().clear_country(name)
    except Exception:
        pass
    try:
        from utils import Alliances
        Alliances().clear_country(name)   # выход из блоков (лидерство/роспуск — на тике альянсов)
    except Exception:
        pass
    # захваченные страной области на карте (оверрайды владения)
    try:
        import utils.worldmap as WM
        from utils import MapState
        a3 = WM.resolve_a3(name)
        if a3:
            ms = MapState()
            for region, owner in ms.overrides().items():
                if owner == a3:
                    ms.reset_region(region)
    except Exception:
        pass


def _wipe_country_data(name: str):
    """Чистый старт при регистрации — полностью стираем любое наследие имени."""
    _purge_country(name)


def _nick_text(flag: str, name: str, ideology: str) -> str:
    """Ник: «флаг Страна · символ_строя». Символ строя — юникод (в никах кастом-иконки
    НЕ рендерятся). Без строя (none) — просто «флаг Страна»."""
    icon = P.ideo(ideology)["icon"] if (ideology and ideology != "none") else ""
    base = f"{flag} {name}"
    if icon:
        base = f"{base} · {icon}"
    return base[:32]


async def _apply_nick(member: disnake.Member, name: str):
    """Ставит ник по текущему состоянию страны (флаг + страна + строй)."""
    o = get_object(name)
    if not o:
        return
    ideology, _ = Politics().get(name)
    from utils import Legacy
    lg = Legacy().of(name)
    shown = lg["title"] if lg and not lg["declined"] else name   # «Наследие»: титул державы вместо страны
    try:
        await member.edit(nick=_nick_text(getattr(o, "flag", ""), shown, ideology),
                          reason="страна / строй")
    except Exception:
        pass


async def update_country_nick(bot, name: str):
    """Обновить ник игрока страны (вызывается при смене строя: реформа/революция/свержение)."""
    o = get_object(name)
    if not o or not getattr(o, "user", 0):
        return
    guild = bot.get_guild(GUILD_ID)
    if not guild:
        return
    member = guild.get_member(o.user)
    if member:
        await _apply_nick(member, name)


async def _clear_country_nick(member: disnake.Member):
    """Сброс ника (возврат к обычному имени) при снятии регистрации."""
    try:
        await member.edit(nick=None, reason="снятие регистрации")
    except Exception:
        pass


def _role(guild: disnake.Guild, key: str, fallback: int = 0):
    """Роль по ключу server_config (или фолбэк config)."""
    rid_ = rid(key, fallback)
    return guild.get_role(rid_) if rid_ else None


async def _apply_join_roles(member: disnake.Member):
    """При входе: «Участник» + «На регистрации» (игровые каналы ещё не видны)."""
    guild = member.guild
    roles = [r for r in (_role(guild, "ROLE_MEMBER"), _role(guild, "ROLE_REGISTERING")) if r]
    if roles:
        try:
            await member.add_roles(*roles, reason="вход на сервер")
        except disnake.HTTPException:
            pass


async def _apply_registered_roles(guild: disnake.Guild, member: disnake.Member):
    """После регистрации: +«Зарегистрирован», −«На регистрации» (+«Участник» на всякий)."""
    add = [r for r in (_role(guild, "PROFILE_ROLE", PROFILE_ROLE), _role(guild, "ROLE_MEMBER"))
           if r and r not in member.roles]
    remove = [r for r in (_role(guild, "ROLE_REGISTERING"),) if r and r in member.roles]
    try:
        if add:
            await member.add_roles(*add, reason="регистрация завершена")
        if remove:
            await member.remove_roles(*remove, reason="регистрация завершена")
    except disnake.HTTPException:
        pass


async def _revert_to_registering(guild: disnake.Guild, member: disnake.Member):
    """При снятии регистрации: −«Зарегистрирован», +«На регистрации»."""
    remove = [r for r in (_role(guild, "PROFILE_ROLE", PROFILE_ROLE),) if r and r in member.roles]
    add = [r for r in (_role(guild, "ROLE_REGISTERING"),) if r and r not in member.roles]
    try:
        if remove:
            await member.remove_roles(*remove, reason="регистрация снята")
        if add:
            await member.add_roles(*add, reason="регистрация снята")
    except disnake.HTTPException:
        pass


# ─────────────── ПОСТОЯННАЯ ПАНЕЛЬ РЕГИСТРАЦИИ (переживает рестарт) ───────────────
# Интерактив маршрутизируется по custom_id с префиксом "reg:" через слушатели
# кога — поэтому панель работает после перезапуска без повторной регистрации View.
def _pe_reg(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s and s.startswith("<") else None
    except Exception:
        return None


def reg_panel(icon_url: str | None = None) -> Panel:
    """Публичная вечная панель: шаг 1 — кем играть (государство или ЧВК).
    Государство → эфемерный выбор континента → страны → досье; ЧВК → окно основания.
    Счётчики свободных стран НЕ показываем здесь — это статичное сообщение, они устарели бы."""
    header = disnake.ui.TextDisplay(
        f"## {ui_icon('globe')} Регистрация\n"
        "Играйте за **государство** — реальную страну мира с её землёй, народом и недрами — или за "
        "**частную военную компанию**, которая живёт контрактами с государствами.\n"
        "-# Один участник — одна страна или одна ЧВК.")
    head = disnake.ui.Section(header, accessory=disnake.ui.Thumbnail(icon_url)) if icon_url else header
    items = [
        head,
        disnake.ui.Separator(),
        disnake.ui.TextDisplay("-# ШАГ 1 · КЕМ ИГРАТЬ"),
        disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("reg", "mode"), placeholder="Государство или ЧВК…", options=[
                disnake.SelectOption(label="Государство", value="country", emoji=_pe_reg("globe"),
                                     description="Реальная страна: экономика, армия, дипломатия, войны"),
                disnake.SelectOption(label="Частная военная компания", value="pmc", emoji=_pe_reg("pmc"),
                                     description="Без территории: бойцы, техника и контракты с государствами"),
            ])),
    ]
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


PAGE_SIZE = 25  # лимит опций в одном select Discord


def continent_panel() -> Panel:
    """Эфемерный шаг 2 для государства: выбор континента."""
    opts = [disnake.SelectOption(label=c, value=c) for c in CONTINENT_ORDER]
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(
        disnake.ui.TextDisplay(f"## {ui_icon('globe')} Регистрация государства\n"
                               "-# ШАГ 2 · Выберите континент, затем свободную страну — покажем её досье."),
        disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("reg", "cont"), placeholder="Выберите континент…", options=opts)),
        accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


def country_panel(continent: str, page: int = 0) -> Panel:
    """Эфемерный шаг 2: выбор свободной страны выбранного континента (постранично)."""
    avail = _available(continent)
    pages = max(1, -(-len(avail) // PAGE_SIZE))
    page = max(0, min(page, pages - 1))
    p = Panel(timeout=None)
    if not avail:
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(f"## {ui_icon('globe')} {continent}\n"
                                   "-# Свободных стран нет — выберите другой регион."),
            accent_colour=disnake.Colour(WARNING_COLOR)))
        return p
    opts = [disnake.SelectOption(label=f"{COUNTRIES_ROSTER[n][0]} {n}"[:100], value=n,
                                 description=f"ВВП {int_format(COUNTRIES_ROSTER[n][4])} {CURRENCY}"[:100])
            for n in avail[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]]
    page_note = f" · стр. **{page + 1}/{pages}**" if pages > 1 else ""
    items = [
        disnake.ui.TextDisplay(f"## {ui_icon('globe')} {continent}\n"
                               f"-# ШАГ 2 · выберите страну — покажем её досье · свободно **{len(avail)}**{page_note}"),
        disnake.ui.Separator(),
        disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("reg", "country", continent, page), placeholder="Выберите страну…", options=opts)),
    ]
    if pages > 1:
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Назад", emoji=_pe("prev"),
                              custom_id=cid("reg", "page", continent, page - 1), disabled=page == 0),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Дальше", emoji=_pe("next"),
                              custom_id=cid("reg", "page", continent, page + 1), disabled=page >= pages - 1)))
    p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


def country_preview_panel(name: str) -> Panel:
    """Шаг 2.5: досье страны + подтверждение «Взять»."""
    flag, continent, territory, population, gdp, atomic = COUNTRIES_ROSTER[name]
    deps = country_deposits(name)
    if deps:
        # сортируем по богатству, показываем иконки ресурсов
        order = sorted(deps.items(), key=lambda kv: -kv[1])
        dep_line = "  ".join(f"{res_icon(r)} {res_label(r)}" for r, _ in order)
    else:
        dep_line = "скудные недра"
    if atomic:
        atom = f"{ui_icon('deterrence')} **Историческая ядерная держава** — ускоренный старт атомной программы"
    elif has_deposit(name, "уран"):
        atom = f"{ui_icon('nuclear')} Уран: **есть месторождения** — своя атомная программа возможна"
    else:
        atom = f"{ui_icon('nuclear')} Урана нет — топливо и сырьё только импортом"
    items = [
        disnake.ui.TextDisplay(
            f"## {flag} {name}\n-# {ui_icon('globe')} {continent} · досье страны"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(
            f"{ui_icon('globe')} Территория: **{int_format(territory)}** км²\n"
            f"{ui_icon('population')} Население: **{int_format(population)}** чел.\n"
            f"{ui_icon('money')} ВВП: **{int_format(gdp)} {CURRENCY}**\n"
            f"{atom}"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(f"{ui_icon('storage')} **Месторождения:** {dep_line}"),
        disnake.ui.Separator(),
        disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, label=f"Взять {name}",
                              emoji=_pe("accept"), custom_id=cid("reg", "take", name)),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Другая страна",
                              emoji=_pe("prev"), custom_id=cid("reg", "list", continent))),
    ]
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
    return p


def _success_panel(obj, population: int, territory: int, continent: str) -> Panel:
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(
        disnake.ui.TextDisplay(
            f"## {ui_icon('check')} Вы — глава государства!\n"
            f"{obj.flag}  **{obj.name}**\n"
            f"-# {ui_icon('globe')} {continent} · {ui_icon('population')} {int_format(population)} · "
            f"{int_format(territory)} км²"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(
            f"{ui_icon('money')} Стартовый капитал: **{int_format(obj.money)} {CURRENCY}**\n"
            f"{ui_icon('plant')} Бесплатный завод уже построен.\n"
            f"-# {ui_icon('guide')} Письмо с инструкциями отправлено вам в личные сообщения."),
        accent_colour=disnake.Colour(SUCCESS_COLOR)))
    return p


def welcome_panel(obj, continent: str) -> Panel:
    """Приветственное письмо в ЛС: поздравление + онбординг (с чего начать)."""
    items = [
        disnake.ui.TextDisplay(
            f"## {ui_icon('check')} Добро пожаловать, {obj.flag} {obj.name}!\n"
            "Поздравляем — под вашим началом целое государство. История вершится здесь."),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(
            f"-# С ЧЕГО НАЧАТЬ\n"
            f"{ui_icon('money')} **1.** `!balance` — ваш профиль и доход (начисляется **каждый час**).\n"
            f"{ui_icon('storage')} **2.** `!resources` — склад; добывайте сырьё и стройте заводы.\n"
            f"{ui_icon('upgrade')} **3.** `!develop` — развивайте экономику (главный рост дохода).\n"
            f"{ui_icon('gov')} **4.** `!state` — держите счастье и стабильность высокими.\n"
            f"{ui_icon('soldier')} **5.** `!army` и `!equip` — армия и техника.\n"
            f"{ui_icon('spy')} **6.** `!spy` — разведка · {ui_icon('diplo')} `!diplo` — дипломатия."),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(
            f"{ui_icon('guide')} Полный гайд — **`!guide`**. Чтобы **побеждать**: развивай экономику, "
            "держи народ довольным, строй армию и умно веди дипломатию. Удачи, глава!"),
    ]
    p = Panel(timeout=None)
    p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(SUCCESS_COLOR)))
    return p


class RegistrationCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        """Вход: выдаём «Участник» + «На регистрации» (ботам — ничего)."""
        if member.bot:
            return
        await _apply_join_roles(member)

    @commands.command(name="regpanel", aliases=["регменю", "панель-регистрации", "рег-панель"])
    async def regpanel_cmd(self, ctx: commands.Context):
        """АДМИН: выставить вечную панель регистрации в текущем канале."""
        if not has_command_access(ctx.author, "regpanel"):
            await ctx.send(embed=_embed("Недоступно", "Нет доступа к этой команде (`!perm`).", ERROR_COLOR))
            return
        icon_url = ctx.guild.icon.url if ctx.guild and ctx.guild.icon else None
        await ctx.send(components=reg_panel(icon_url).components)

    def _info(self, text: str, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(text), accent_colour=disnake.Colour(color)))
        return p

    async def _finish_registration(self, inter: disnake.MessageInteraction, name: str):
        """Создание страны по кнопке «Взять» (редактирует эфемерное превью)."""
        if get_object_by_user(inter.user.id) or Pmc().by_user(inter.user.id):
            await inter.response.edit_message(components=self._info(
                "Вы уже зарегистрированы (страна или ЧВК).", WARNING_COLOR).components)
            return
        if name not in COUNTRIES_ROSTER:
            await inter.response.edit_message(components=self._info("Неизвестная страна.", ERROR_COLOR).components)
            return
        if get_object(name):
            await inter.response.edit_message(components=self._info(f"**{name}** уже заняли — выберите другую.", WARNING_COLOR).components)
            return

        block = _npc_block(name)
        if block:
            await inter.response.edit_message(components=self._info(f"**{name}** занять нельзя: {block}.",
                                                                      WARNING_COLOR).components)
            return
        flag, continent, territory, population, gdp, atomic = COUNTRIES_ROSTER[name]
        _wipe_country_data(name)  # чистый старт (сбрасывает и прежние захваты этой страны)
        share = min(1.0, _remaining_share(name))   # считаем ПОСЛЕ очистки: только свои оставшиеся земли
        if share <= 0:
            await inter.response.edit_message(components=self._info(
                f"**{name}** занять нельзя: у страны не осталось ни одной области.", WARNING_COLOR).components)
            return
        if share < 1:   # часть земель отошла другим по итогам войн — меньше территории и населения
            territory, population = int(territory * share), int(population * share)
        obj = Countries().create_object(
            name=name, flag=flag, user=inter.user.id, money=START_MONEY,
            territory=territory, population=population, continent=continent)
        Buildings().add_building(name, "factory_small", 1)  # бесплатный стартовый завод
        News().touch(name, int(time.time()), log=False)
        Npc().touch_registered(name, int(time.time()), force=True)   # защита новичка: 2 дня без войн с игроками
        if inter.guild and isinstance(inter.user, disnake.Member):
            await _apply_registered_roles(inter.guild, inter.user)
            await _apply_nick(inter.user, name)  # ник → «флаг Страна · строй»
        await inter.response.edit_message(
            components=_success_panel(obj, population, territory, continent).components)
        # приветственное письмо в ЛС
        try:
            await inter.user.send(components=welcome_panel(obj, continent).components)
        except Exception:
            pass
        self.bot.dispatch("map_dirty")  # страна появилась — перерисовать карту
        stats = self.bot.get_cog("ServerStatsCog")  # мгновенно обновить счётчик «Держав»
        if stats:
            try:
                await stats.refresh_stats()
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("reg:"):
            return
        _, action, args = parse_cid(c)
        if action == "mode":
            if get_object_by_user(inter.user.id) or Pmc().by_user(inter.user.id):
                await inter.response.send_message(
                    embed=_embed("Регистрация", "Вы уже зарегистрированы (страна или ЧВК).", WARNING_COLOR),
                    ephemeral=True)
                return
            if inter.values and inter.values[0] == "pmc":
                pmc = self.bot.get_cog("PmcCog")
                if pmc:
                    await inter.response.send_modal(pmc.found_modal(from_reg=True))
                return
            await inter.response.send_message(components=continent_panel().components, ephemeral=True)
            return
        if action == "cont":
            if get_object_by_user(inter.user.id) or Pmc().by_user(inter.user.id):
                await inter.response.send_message(
                    embed=_embed("Регистрация", "Вы уже зарегистрированы.", WARNING_COLOR), ephemeral=True)
                return
            await inter.response.send_message(
                components=country_panel(inter.values[0]).components, ephemeral=True)
        elif action == "country":
            name = inter.values[0]
            if name not in COUNTRIES_ROSTER:
                return
            # шаг 2.5 — показать досье страны с кнопкой «Взять»
            await inter.response.edit_message(components=country_preview_panel(name).components)

    @commands.Cog.listener()
    async def on_button_click(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("reg:"):
            return
        _, action, args = parse_cid(c)
        if action == "take" and args:
            await self._finish_registration(inter, args[0])
        elif action == "list" and args:
            await inter.response.edit_message(components=country_panel(args[0]).components)
        elif action == "page" and len(args) >= 2:
            try:
                page = int(args[1])
            except ValueError:
                page = 0
            await inter.response.edit_message(components=country_panel(args[0], page).components)

    @commands.command(name="unregister",
                      aliases=["разрегистрация", "unreg", "снять", "снятие", "разрег", "дерег"])
    async def unregister_cmd(self, ctx: commands.Context, user: disnake.Member | None = None):
        can_others = has_command_access(ctx.author, "unregister")
        target = user or ctx.author
        if user and not can_others:
            await ctx.send(embed=_embed("Ошибка", "Снимать регистрацию с других может только штаб (`!perm`).", ERROR_COLOR))
            return

        obj = get_object_by_user(target.id)
        if not obj:
            pm = Pmc().by_user(target.id)
            pmc_cog = self.bot.get_cog("PmcCog")
            if pm and pmc_cog:   # ЧВК: роспуск (контракты сорваны с возвратом, роли и ник сброшены)
                note = await pmc_cog._disband(target.id, ctx.guild)
                await ctx.send(embed=_embed(f"{ui_icon('check')} Регистрация снята",
                                            f"ЧВК **«{pm['name']}»** (<@{target.id}>): {note}", SUCCESS_COLOR))
                return
            await ctx.send(embed=_embed("Ошибка", "Профиль не найден (ни страны, ни ЧВК).", ERROR_COLOR))
            return
        name = obj.name

        # ПОЛНАЯ очистка: страна + все привязанные данные (ресурсы, армия, техника,
        # развитие, политика, эффекты, компании, ультиматумы, карта, шпионаж, новости)
        _purge_country(name)

        member = ctx.guild.get_member(target.id) if ctx.guild else None
        if member:
            await _revert_to_registering(ctx.guild, member)   # −Зарегистрирован, +На регистрации
            await _clear_country_nick(member)                 # вернуть обычный ник

        self.bot.dispatch("map_dirty")  # страна освободилась — перерисовать карту
        stats = self.bot.get_cog("ServerStatsCog")
        if stats:
            try:
                await stats.refresh_stats()
            except Exception:
                pass
        await ctx.send(embed=_embed(
            f"{ui_icon('check')} Регистрация снята",
            f"Страна **{name}** полностью освобождена (<@{target.id}>). "
            "Все данные стёрты — её можно взять заново.", SUCCESS_COLOR))


def setup(bot: commands.Bot):
    bot.add_cog(RegistrationCog(bot))
