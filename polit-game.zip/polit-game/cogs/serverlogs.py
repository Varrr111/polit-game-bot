"""
Живые логи сервера → в лог-каналы (ID из server_config, создаёт !setupserver):
  CH_LOG_JOINS    — вход/выход участников
  CH_LOG_MESSAGES — удалённые и изменённые сообщения
  CH_LOG_MOD      — баны/разбаны
  CH_LOG_VOICE    — голосовые перемещения
Если канал не настроен — событие тихо пропускается.
"""

import logging

import disnake
from disnake.ext import commands

import config
from utils import COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR
from utils.serverconfig import rid

log = logging.getLogger("serverlogs")


def _ts(embed: disnake.Embed) -> disnake.Embed:
    embed.timestamp = disnake.utils.utcnow()
    return embed


class ServerLogsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _in_guild(self, guild) -> bool:
        return guild is not None and guild.id == config.GUILD_ID

    async def _send(self, key: str, embed: disnake.Embed):
        ch = self.bot.get_channel(rid(key))
        if ch:
            try:
                await ch.send(embed=_ts(embed))
            except disnake.HTTPException:
                pass

    # ───── вход / выход ─────
    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        if not self._in_guild(member.guild):
            return
        e = disnake.Embed(description=f"📥 **Вошёл** {member.mention}\n-# {member} · ID `{member.id}`",
                          color=SUCCESS_COLOR)
        e.set_thumbnail(url=member.display_avatar.url)
        await self._send("CH_LOG_JOINS", e)

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        if not self._in_guild(member.guild):
            return
        e = disnake.Embed(description=f"📤 **Вышел** {member.mention}\n-# {member} · ID `{member.id}`",
                          color=WARNING_COLOR)
        await self._send("CH_LOG_JOINS", e)

    # ───── сообщения ─────
    @commands.Cog.listener()
    async def on_message_delete(self, message: disnake.Message):
        if not self._in_guild(message.guild) or message.author.bot:
            return
        content = message.content or "*(без текста / вложение)*"
        e = disnake.Embed(
            title="🗑️ Сообщение удалено",
            description=f"**Автор:** {message.author.mention} · **Канал:** {message.channel.mention}\n\n{content[:1800]}",
            color=ERROR_COLOR)
        await self._send("CH_LOG_MESSAGES", e)

    @commands.Cog.listener()
    async def on_message_edit(self, before: disnake.Message, after: disnake.Message):
        if not self._in_guild(before.guild) or before.author.bot:
            return
        if (before.content or "") == (after.content or ""):
            return
        e = disnake.Embed(
            title="✏️ Сообщение изменено",
            description=f"**Автор:** {before.author.mention} · **Канал:** {before.channel.mention} · "
                        f"[перейти]({after.jump_url})",
            color=COMMAND_COLOR)
        e.add_field(name="Было", value=(before.content or "—")[:1000], inline=False)
        e.add_field(name="Стало", value=(after.content or "—")[:1000], inline=False)
        await self._send("CH_LOG_MESSAGES", e)

    # ───── модерация ─────
    @commands.Cog.listener()
    async def on_member_ban(self, guild: disnake.Guild, user: disnake.User):
        if not self._in_guild(guild):
            return
        await self._send("CH_LOG_MOD", disnake.Embed(
            description=f"🔨 **Бан** {user.mention}\n-# {user} · ID `{user.id}`", color=ERROR_COLOR))

    @commands.Cog.listener()
    async def on_member_unban(self, guild: disnake.Guild, user: disnake.User):
        if not self._in_guild(guild):
            return
        await self._send("CH_LOG_MOD", disnake.Embed(
            description=f"♻️ **Разбан** {user.mention}\n-# {user} · ID `{user.id}`", color=SUCCESS_COLOR))

    # ───── голос ─────
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: disnake.Member, before, after):
        if not self._in_guild(member.guild):
            return
        if before.channel == after.channel:
            return
        if before.channel is None:
            txt = f"🔊 **Зашёл в голосовой** {member.mention} → **{after.channel.name}**"
            color = SUCCESS_COLOR
        elif after.channel is None:
            txt = f"🔇 **Вышел из голосового** {member.mention} ← **{before.channel.name}**"
            color = WARNING_COLOR
        else:
            txt = f"🔁 **Переход** {member.mention}: {before.channel.name} → **{after.channel.name}**"
            color = COMMAND_COLOR
        await self._send("CH_LOG_VOICE", disnake.Embed(description=txt, color=color))


def setup(bot: commands.Bot):
    bot.add_cog(ServerLogsCog(bot))
