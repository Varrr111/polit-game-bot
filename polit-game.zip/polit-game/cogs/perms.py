"""
🔐 Права на команды — !perm (удобная панель + текстовые подкоманды)

Поскольку у ролей НЕТ Discord-права «Администратор» (только у владельца), доступ
к админ-командам бота раздаётся здесь.

ПАНЕЛЬ (просто `!perm`): выбери роль ИЛИ участника нативным меню, отметь одну/
несколько команд (или «ВСЕ»), нажми «Выдать» / «Забрать». Внизу — текущие выдачи.

ТЕКСТОМ (для скорости):
  !perm grant  @роль|@юзер <команда|all>
  !perm revoke @роль|@юзер <команда|all>
  !perm list [команда]      · !perm commands

Доступ к !perm: владелец сервера или обладатель доступа `*`.
"""

import logging

import disnake
from disnake.ext import commands

from utils import CommandPerms, COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR
from utils.perms import has_command_access
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon

log = logging.getLogger("perms")


def _pe(slug: str):
    """UI-слаг → PartialEmoji для emoji= кнопок/опций (кастом-иконка бота)."""
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None

# Известные админ-команды (scope). Порядок = порядок в меню.
ADMIN_COMMANDS: dict[str, str] = {
    "console": "супер-консоль админа",
    "eventnow": "прогон событий",
    "collectnow": "прогон авто-дохода",
    "warmap": "редактор карты (война)",
    "mapchannel": "назначить канал карты",
    "mapsync": "пересоздать карту",
    "setyear": "задать игровой год",
    "statsrefresh": "обновить статистику",
    "reloadicons": "переподхватить иконки",
    "autoconfig": "авто-привязка каналов/ролей в БД",
    "setchannel": "назначить игровой канал",
    "setrole": "назначить роль",
    "serverids": "показать сохранённые ID",
    "resetid": "сбросить ID",
    "importconfig": "снять config → БД",
    "regpanel": "панель регистрации",
    "mechanics": "публикация меню механик",
    "rules": "публикация правил сервера",
    "unregister": "снять регистрацию с другого",
    "equip-remove": "удалить образец техники",
    "admin": "панель админ-инструментов",
    "guard": "защита сервера (Sentinel)",
    "reload": "перезагрузить коги",
    "dbreset": "сброс базы (только владелец)",
    "perm": "управление правами",
    "mod-warn": "модерация: варны",
    "mod-timeout": "модерация: тайм-аут",
    "mod-kick": "модерация: кик",
    "mod-ban": "модерация: бан и разбан",
    "purge": "очистка сообщений в канале",
}

_ALL_WORDS = {"all", "*", "все", "всё", "любая"}
_PAGE = 24  # опций команд на страницу (25-й слот — «ВСЕ»)


def _scope_short(scope: str) -> str:
    return "ВСЕ команды (*)" if scope == "*" else scope


class PermsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.perms = CommandPerms()
        self._sessions: dict[int, dict] = {}

    def _can(self, member) -> bool:
        return has_command_access(member, "perm")

    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"kind": None, "tid": None, "tname": None, "scopes": set()}
            self._sessions[uid] = s
        return s

    # ═══════════════ ПАНЕЛЬ ═══════════════
    def _panel(self, guild, uid: int, note: str | None = None) -> Panel:
        s = self._session(uid)
        items = [disnake.ui.TextDisplay(f"## {ui_icon('perm')} Права на команды · !perm")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        # выбранная цель + отмеченные команды
        if s["tid"]:
            tgt = f"{'роль' if s['kind']=='role' else 'участник'} **{s['tname']}**"
        else:
            tgt = "— не выбрана —"
        if s["scopes"]:
            sc = "ВСЕ команды" if "*" in s["scopes"] else ", ".join(sorted(s["scopes"]))
        else:
            sc = "— не выбраны —"
        items.append(disnake.ui.TextDisplay(
            f"Цель: {tgt}\nКоманды: **{sc}**\n"
            f"-# Выбери роль ИЛИ участника, отметь команды, затем «Выдать»/«Забрать»."))
        items.append(disnake.ui.Separator())
        # нативные пикеры
        items.append(disnake.ui.ActionRow(disnake.ui.RoleSelect(
            custom_id=cid("perm", "role"), placeholder="Выбрать роль…", max_values=1)))
        items.append(disnake.ui.ActionRow(disnake.ui.UserSelect(
            custom_id=cid("perm", "user"), placeholder="Выбрать участника…", max_values=1)))
        # выбор команд (мульти) + «ВСЕ»
        opts = [disnake.SelectOption(
            label="ВСЕ команды", value="*", emoji=_pe("perm_all"),
            description="полный доступ к админ-командам", default=("*" in s["scopes"]))]
        for name, desc in list(ADMIN_COMMANDS.items())[:_PAGE]:
            opts.append(disnake.SelectOption(
                label=name, value=name, description=desc[:100], default=(name in s["scopes"])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("perm", "scopes"), placeholder="Отметить команды…",
            min_values=0, max_values=len(opts), options=opts)))
        # кнопки
        B = disnake.ButtonStyle
        ready = bool(s["tid"] and s["scopes"])
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="Выдать", emoji=_pe("perm_grant"),
                              disabled=not ready, custom_id=cid("perm", "apply", "grant")),
            disnake.ui.Button(style=B.danger, label="Забрать", emoji=_pe("perm_revoke"),
                              disabled=not ready, custom_id=cid("perm", "apply", "revoke")),
            disnake.ui.Button(style=B.secondary, label="Сброс выбора", emoji=_pe("perm_clear"),
                              custom_id=cid("perm", "clear"))))
        # текущие выдачи
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(self._grants_text(guild)))
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))
        return p

    def _grants_text(self, guild) -> str:
        rows = self.perms.list_all()
        if not rows:
            return "-# ТЕКУЩИЕ ВЫДАЧИ: пока нет."
        lines = []
        for r in rows[:12]:
            if r["holder_kind"] == "role":
                role = guild.get_role(r["holder_id"]) if guild else None
                who = f"@{role.name}" if role else f"роль {r['holder_id']}"
            else:
                m = guild.get_member(r["holder_id"]) if guild else None
                who = f"@{m.display_name}" if m else f"юзер {r['holder_id']}"
            lines.append(f"• {who} → **{_scope_short(r['scope'])}**")
        extra = f"\n-# …ещё {len(rows) - 12}" if len(rows) > 12 else ""
        return "-# ТЕКУЩИЕ ВЫДАЧИ:\n" + "\n".join(lines) + extra

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _perm_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("perm:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("🔒 Нет доступа к управлению правами.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        if action == "role":
            role = self._first_resolved(inter)
            if role is not None:
                s.update(kind="role", tid=role.id, tname=getattr(role, "name", str(role.id)))
        elif action == "user":
            user = self._first_resolved(inter)
            if user is not None:
                s.update(kind="user", tid=user.id,
                         tname=getattr(user, "display_name", None) or str(user))
        elif action == "scopes":
            s["scopes"] = set(inter.values)
        await inter.response.edit_message(components=self._panel(inter.guild, inter.author.id).components)

    def _first_resolved(self, inter):
        """Возвращает выбранный объект (Role/Member) из Role/User-селекта."""
        rv = getattr(inter, "resolved_values", None)
        if rv:
            return rv[0]
        if inter.values and inter.guild:
            try:
                _id = int(inter.values[0])
            except (TypeError, ValueError):
                return None
            return inter.guild.get_role(_id) or inter.guild.get_member(_id)
        return None

    @commands.Cog.listener("on_button_click")
    async def _perm_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("perm:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("🔒 Нет доступа к управлению правами.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        if action == "clear":
            s.update(kind=None, tid=None, tname=None, scopes=set())
            await inter.response.edit_message(
                components=self._panel(inter.guild, inter.author.id,
                                       f"{ui_icon('perm_clear')} Выбор сброшен.").components)
            return
        if action == "apply":
            note = self._apply(s, args[0])
            await inter.response.edit_message(
                components=self._panel(inter.guild, inter.author.id, note).components)

    def _apply(self, s: dict, mode: str) -> str:
        if not s["tid"] or not s["scopes"]:
            return "⚠️ Выбери цель и хотя бы одну команду."
        scopes = sorted(s["scopes"])
        if mode == "grant":
            for sc in scopes:
                self.perms.grant(sc, s["kind"], s["tid"])
            verb = f"{ui_icon('perm_grant')} Выдан доступ"
        else:
            for sc in scopes:
                self.perms.revoke(sc, s["kind"], s["tid"])
            verb = f"{ui_icon('perm_revoke')} Отозван доступ"
        who = f"{'роли' if s['kind']=='role' else 'участнику'} **{s['tname']}**"
        sc_txt = "ВСЕ команды" if "*" in scopes else ", ".join(scopes)
        return f"{verb} {who}: **{sc_txt}**"

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="perm", aliases=["права", "perms", "доступ"])
    async def perm_cmd(self, ctx: commands.Context, action: str | None = None,
                       target: str | None = None, *, scope: str | None = None):
        if not ctx.guild:
            return
        if not self._can(ctx.author):
            await ctx.send(embed=disnake.Embed(
                description="🔒 Управлять правами может владелец сервера или обладатель доступа `*`.",
                color=ERROR_COLOR))
            return

        act = (action or "").lower()
        # голый !perm → панель
        if act in ("", "menu", "меню", "панель"):
            s = self._session(ctx.author.id)
            s.update(kind=None, tid=None, tname=None, scopes=set())
            await ctx.send(components=self._panel(ctx.guild, ctx.author.id).components)
            return
        if act in ("commands", "команды", "список-команд"):
            await self._send_commands(ctx)
            return
        if act in ("list", "список", "кто"):
            await self._send_list(ctx, target or scope)
            return
        if act in ("help", "справка", "?"):
            await self._send_help(ctx)
            return
        if act not in ("grant", "revoke", "выдать", "забрать", "снять"):
            await ctx.send(embed=disnake.Embed(
                description="`!perm` — меню. Текстом: `grant`/`revoke`/`list`/`commands`.",
                color=WARNING_COLOR))
            return

        kind, holder_id, who = self._resolve_target(ctx, target)
        if not kind:
            await ctx.send(embed=disnake.Embed(
                description="Укажи цель: упомяни роль/участника или дай ID.\n"
                            "Пример: `!perm grant @Куратор console`",
                color=ERROR_COLOR))
            return
        sc = self._resolve_scope(scope or "")
        if not sc:
            await ctx.send(embed=disnake.Embed(
                description="Укажи команду или `all`. Список — `!perm commands`.",
                color=ERROR_COLOR))
            return
        if act in ("grant", "выдать"):
            self.perms.grant(sc, kind, holder_id)
            await ctx.send(embed=disnake.Embed(
                title="✅ Доступ выдан",
                description=f"{who} → **{_scope_short(sc)}**.", color=SUCCESS_COLOR))
        else:
            self.perms.revoke(sc, kind, holder_id)
            await ctx.send(embed=disnake.Embed(
                title="🚫 Доступ забран",
                description=f"У {who} отозван **{_scope_short(sc)}**.", color=COMMAND_COLOR))

    # ── текстовые помощники ──
    def _resolve_target(self, ctx, raw: str):
        if ctx.message.role_mentions:
            r = ctx.message.role_mentions[0]
            return "role", r.id, f"роль **{r.name}**"
        if ctx.message.mentions:
            u = ctx.message.mentions[0]
            return "user", u.id, f"**{u}**"
        raw = (raw or "").strip()
        if raw.isdigit() and ctx.guild:
            rid_ = int(raw)
            role = ctx.guild.get_role(rid_)
            if role:
                return "role", role.id, f"роль **{role.name}**"
            member = ctx.guild.get_member(rid_)
            if member:
                return "user", member.id, f"**{member}**"
        if raw and ctx.guild:
            role = disnake.utils.get(ctx.guild.roles, name=raw)
            if role:
                return "role", role.id, f"роль **{role.name}**"
        return None, None, None

    def _resolve_scope(self, raw: str) -> str | None:
        raw = (raw or "").strip().lower()
        if not raw:
            return None
        if raw in _ALL_WORDS:
            return "*"
        if raw in ADMIN_COMMANDS:
            return raw
        if self.bot.get_command(raw):
            return raw
        return None

    async def _send_commands(self, ctx):
        lines = "\n".join(f"• `{name}` — {desc}" for name, desc in ADMIN_COMMANDS.items())
        await ctx.send(embed=disnake.Embed(
            title="📋 Админ-команды (scope для !perm)",
            description=lines + "\n\n`all` = доступ ко всем сразу.", color=COMMAND_COLOR))

    async def _send_list(self, ctx, scope_raw):
        sc = self._resolve_scope(scope_raw or "") if scope_raw else None
        rows = self.perms.list_scope(sc) if sc else self.perms.list_all()
        if not rows:
            await ctx.send(embed=disnake.Embed(
                description="Выдач нет." if not sc else f"На **{_scope_short(sc)}** выдач нет.",
                color=COMMAND_COLOR))
            return
        await ctx.send(embed=disnake.Embed(
            title="🔐 Выдачи прав" + (f" · {sc}" if sc else ""),
            description="\n".join(self._fmt_row(ctx, r) for r in rows[:30]), color=COMMAND_COLOR))

    async def _send_help(self, ctx):
        await ctx.send(embed=disnake.Embed(
            title="🔐 Права на команды · !perm",
            description=("• `!perm` — удобное меню\n"
                         "• `!perm grant @роль|@юзер <команда|all>`\n"
                         "• `!perm revoke @роль|@юзер <команда|all>`\n"
                         "• `!perm list [команда]` · `!perm commands`\n\n"
                         "`all` = доступ ко всем админ-командам."),
            color=COMMAND_COLOR))

    def _fmt_row(self, ctx, r) -> str:
        if r["holder_kind"] == "role":
            role = ctx.guild.get_role(r["holder_id"])
            who = f"роль {role.mention}" if role else f"роль `{r['holder_id']}`"
        else:
            member = ctx.guild.get_member(r["holder_id"])
            who = member.mention if member else f"юзер `{r['holder_id']}`"
        return f"• {who} → **{_scope_short(r['scope'])}**"


def setup(bot: commands.Bot):
    bot.add_cog(PermsCog(bot))
