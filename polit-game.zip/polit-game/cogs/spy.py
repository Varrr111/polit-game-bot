"""
🕵️ ШПИОНАЖ (Этап 1) — !spy

Скрытые операции одной страны против другой. Решаются АВТОМАТИЧЕСКИ по формуле
(utils/spy.py), исходы: успех / провал / разоблачение. Разоблачение — ТОЛЬКО при
провале: публичный пост в #шпионаж + casus belli. Успех приватен; жертве приходит
уведомление об эффекте, но БЕЗ имени атакующего.

Панель приватная — уходит в ЛС игрока (prefix-команда не может быть эфемерной).
Стиль — Components V2 (как console/events), кастом-иконки шпионажа (ui_icon).

Опоры: Разведка (recon, атака) · Контрразведка (counter, защита) · Агенты
(ранг+специализация, бонус «своей» операции, теряются на разоблачении).

Анти-дыры: предоплата ДО резолюции; кража = min(запрошено, есть); счастье/стаб
clamp(0–100); ресурсы/деньги ≥0; кулдаун + heat + дневной лимит; эффекты через
штатные менеджеры (Countries/Settings/Effects/Equipment). Все числа — в utils/spy.
"""

import asyncio
import datetime
import logging
import random
import time

import disnake
from disnake.ext import commands

import config
from utils import (
    Countries, Settings, Effects, Equipment, Cooldown, Spy, Diplomacy,
    Politics, Army, CountryUpgrades,
    update_money, int_format, string_to_number,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon, res_icon, res_label, RESOURCE_SLUG
from utils.serverconfig import rid
import utils.spy as SPY
import utils.diplomacy as DIP
import utils.politics as POL

log = logging.getLogger("spy")

RESOURCES = list(RESOURCE_SLUG.keys())
_PAGE = 25
_DAY = 86400


def _pe(slug: str):
    """UI-слаг → PartialEmoji для emoji= кнопок/селектов (или None)."""
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _pe_res(name: str):
    try:
        return disnake.PartialEmoji.from_str(res_icon(name))
    except Exception:
        return None


def _num(raw: str):
    raw = (raw or "").strip().replace(" ", "")
    try:
        return int(float(raw))
    except (ValueError, TypeError):
        pass
    try:
        v = string_to_number(raw)
        return int(v) if v is not None else None
    except Exception:
        return None


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def _midnight_ts() -> int:
    now = datetime.datetime.now(config.TZ)
    mid = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return int(mid.timestamp())


def _bar(value: float, cap: float, width: int = 5) -> str:
    filled = int(_clamp(round(value / cap * width), 0, width)) if cap else 0
    return "🔥" * filled + "▫️" * (width - filled)


class SpyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.settings = Settings()
        self.effects = Effects()
        self.equip = Equipment()
        self.cooldown = Cooldown()
        self.spy = Spy()
        self.politics = Politics()
        self.army = Army()
        self.upgrades = CountryUpgrades()
        self._sessions: dict[int, dict] = {}

    # ───── сессия ─────
    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "target": None, "op": None, "agent_id": None,
                 "res": None, "tpage": 0}
            self._sessions[uid] = s
        return s

    def _actor(self, uid: int):
        return self.countries.get_object_by_user(uid)

    async def _defer(self, inter):
        """Мгновенно подтверждаем интеракцию (update), чтобы она не протухла за 3с
        на медленном хосте, пока идёт резолюция и перерисовка панели."""
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    # ───── вспом. расчёты ─────
    def _eff_heat(self, country: str, now: int) -> float:
        raw, upd = self.spy.get_heat_raw(country)
        return SPY.effective_heat(raw, upd, now)

    def _eff_counter(self, country: str, now: int) -> int:
        """Уровень контрразведки + временный бонус зачистки (эффект spy_counter)."""
        _recon, counter = self.spy.get_agency(country)
        bonus = sum(r["value"] for r in self.effects.active(country, now)
                    if r["kind"] == "spy_counter")
        al = self.bot.get_cog("AllianceCog")
        intel = al.counter_bonus(country) if al else 0   # обмен разведданными военного блока
        return int(counter + bonus + intel)

    def _cd_left(self, country: str, now: int) -> int:
        until = self.cooldown.get_cooldown("spy", country)
        return max(0, int(until - now))

    def _ops_left(self, country: str) -> int:
        used = self.spy.ops_today(country, _midnight_ts())
        return max(0, SPY.SPY_MAX_PER_DAY - used)

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('spy')} Разведслужба")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _render(self, uid: int, note=None) -> Panel:
        s = self._session(uid)
        actor = self._actor(uid)
        if not actor:
            return self._container(
                self._head(note) + [disnake.ui.TextDisplay(
                    "-# У вас нет страны. Откройте панель регистрации, чтобы играть.")],
                WARNING_COLOR)
        view = s["view"]
        if view == "target":
            return self._panel_target(uid, actor, note)
        if view == "ops":
            return self._panel_ops(uid, actor, note)
        if view == "hire":
            return self._panel_hire(uid, actor, note)
        return self._panel_hub(uid, actor, note)

    # — хаб службы —
    def _panel_hub(self, uid, actor, note=None):
        now = int(time.time())
        name = actor.name
        recon, counter = self.spy.get_agency(name)
        heat = self._eff_heat(name, now)
        agents = self.spy.count_agents(name)
        cd = self._cd_left(name, now)
        left = self._ops_left(name)
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {actor.flag} {name}\n"
            f"{ui_icon('recon')} Разведка: **ур. {recon}/{SPY.RECON_MAX}** · "
            f"{ui_icon('counterintel')} Контрразведка: **ур. {counter}/{SPY.COUNTER_MAX}**\n"
            f"{ui_icon('agent')} Агенты: **{agents}/{SPY.AGENT_MAX}** · "
            f"{ui_icon('heat')} Накал: {_bar(heat, SPY.HEAT_SOFTCAP)} **{heat:.1f}**\n"
            f"{ui_icon('money')} Казна: **{int_format(actor.money)} {CURRENCY}**\n"
            f"-# Операций сегодня осталось: **{left}/{SPY.SPY_MAX_PER_DAY}**"
            + (f" · перезарядка: **{cd // 60}м {cd % 60}с**" if cd else f" · {ui_icon('check')} готово")))
        items.append(disnake.ui.Separator())
        B = disnake.ButtonStyle
        rc_cost = SPY.level_up_cost(SPY.RECON_BASE_COST, recon)
        cc_cost = SPY.level_up_cost(SPY.COUNTER_BASE_COST, counter)
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(
                style=B.primary, emoji=_pe("recon"),
                label=(f"Разведка +1 · {int_format(rc_cost)}" if recon < SPY.RECON_MAX else "Разведка max"),
                disabled=(recon >= SPY.RECON_MAX), custom_id=cid("spy", "dev", "recon")),
            disnake.ui.Button(
                style=B.primary, emoji=_pe("counterintel"),
                label=(f"Контрразведка +1 · {int_format(cc_cost)}" if counter < SPY.COUNTER_MAX else "Контрразведка max"),
                disabled=(counter >= SPY.COUNTER_MAX), custom_id=cid("spy", "dev", "counter"))))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.secondary, emoji=_pe("agent"), label="Нанять агента",
                              disabled=(agents >= SPY.AGENT_MAX), custom_id=cid("spy", "hire")),
            disnake.ui.Button(style=B.danger, emoji=_pe("spy"), label="Операция",
                              custom_id=cid("spy", "goto", "target")),
            disnake.ui.Button(style=B.success, emoji=_pe("sweep"),
                              label=f"Зачистка · {int_format(SPY.op_cost('sweep'))}",
                              custom_id=cid("spy", "sweep")),
            disnake.ui.Button(style=B.danger, emoji=_pe("pmc"), label="Против ЧВК",   # → панель ЧВК (cogs/pmc.py)
                              custom_id=cid("pmc", "goto", "spy"))))
        # агенты списком
        ags = self.spy.agents(name)
        if ags:
            line = " · ".join(f"{SPY.spec_label(a['spec'])} ур.{a['rank']}" for a in ags[:8])
            items.append(disnake.ui.TextDisplay(f"-# АГЕНТЫ: {line}"))
        return self._container(items)

    # — найм агента —
    def _panel_hire(self, uid, actor, note=None):
        items = self._head(note)
        recon, _c = self.spy.get_agency(actor.name)
        rank = max(1, recon)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('agent')} Найм агента · {actor.flag} {actor.name}\n"
            f"Стоимость: **{int_format(SPY.AGENT_COST)} {CURRENCY}** · ранг нового агента "
            f"**{rank}** (= уровень разведки).\n"
            f"-# Агент даёт бонус операции своей специализации. На разоблачении теряется."))
        B = disnake.ButtonStyle
        spec_icon = {"recon": "recon", "subvert": "destab",
                     "diversion": "sabotage", "counter": "counterintel"}
        buttons = [disnake.ui.Button(
            style=B.secondary, label=label, emoji=_pe(spec_icon[spec]),
            custom_id=cid("spy", "hirespec", spec)) for spec, label in SPY.SPECS.items()]
        items.append(disnake.ui.ActionRow(*buttons))
        items.append(disnake.ui.ActionRow(disnake.ui.Button(
            style=B.secondary, label="⟵ В хаб", custom_id=cid("spy", "goto", "hub"))))
        return self._container(items)

    # — выбор цели —
    def _panel_target(self, uid, actor, note=None):
        s = self._session(uid)
        items = self._head(note)
        names = sorted(n for n in self.countries.get_object_names() if n != actor.name)
        if not names:
            items.append(disnake.ui.TextDisplay("-# Нет других стран для операций."))
            items.append(disnake.ui.ActionRow(disnake.ui.Button(
                style=disnake.ButtonStyle.secondary, label="⟵ В хаб", custom_id=cid("spy", "goto", "hub"))))
            return self._container(items, WARNING_COLOR)
        pages = max(1, (len(names) + _PAGE - 1) // _PAGE)
        s["tpage"] = _clamp(s["tpage"], 0, pages - 1)
        page = names[s["tpage"] * _PAGE:(s["tpage"] + 1) * _PAGE]
        items.append(disnake.ui.TextDisplay(f"### Выбор цели · стр. {s['tpage']+1}/{pages}"))
        opts = []
        for nm in page:
            o = self.countries.get_object(nm)
            opts.append(disnake.SelectOption(label=f"{(o.flag + ' ') if o else ''}{nm}"[:100], value=nm,
                                             default=(nm == s["target"])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("spy", "target"), placeholder="Выберите цель…", options=opts)))
        buttons = [disnake.ui.Button(
            style=disnake.ButtonStyle.secondary, label="⟵ В хаб", custom_id=cid("spy", "goto", "hub"))]
        if pages > 1:
            buttons.append(disnake.ui.Button(
                style=disnake.ButtonStyle.primary, emoji=_pe("prev"), disabled=(s["tpage"] == 0),
                custom_id=cid("spy", "tpage", "prev")))
            buttons.append(disnake.ui.Button(
                style=disnake.ButtonStyle.primary, emoji=_pe("next"), disabled=(s["tpage"] >= pages - 1),
                custom_id=cid("spy", "tpage", "next")))
        items.append(disnake.ui.ActionRow(*buttons))
        return self._container(items)

    # — операция (после выбора цели) —
    def _panel_ops(self, uid, actor, note=None):
        s = self._session(uid)
        now = int(time.time())
        target = s["target"]
        tobj = self.countries.get_object(target) if target else None
        if not tobj:
            s["view"] = "target"
            return self._panel_target(uid, actor, "⚠️ Цель недоступна, выберите снова.")
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(f"### Цель: {tobj.flag} {target}"))
        # выбор операции
        op = s["op"]
        opts = []
        for key in SPY.OFFENSIVE_OPS:
            meta = SPY.SPY_OPS[key]
            opts.append(disnake.SelectOption(
                label=meta["label"], value=key, emoji=_pe(meta["icon"]),
                description=f"{int_format(meta['cost'])} {CURRENCY}"[:100], default=(key == op)))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("spy", "op"), placeholder="Выберите операцию…", options=opts)))

        if op:
            meta = SPY.SPY_OPS[op]
            recon, _c = self.spy.get_agency(actor.name)
            counter = self._eff_counter(target, now)
            heat = self._eff_heat(actor.name, now)
            # агент
            agent = self.spy.get_agent(s["agent_id"]) if s["agent_id"] else None
            agent_match = bool(agent and agent["spec"] == meta["spec"])
            arank = agent["rank"] if agent else 0
            chance = SPY.success_chance(recon, counter, tobj.stability, heat, arank, agent_match)
            risk = SPY.expose_chance(counter, heat)
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon(meta['icon'])} **{meta['label']}** · предоплата **{int_format(meta['cost'])} {CURRENCY}**\n"
                f"-# {meta['desc']}\n"
                f"{ui_icon('check')} Шанс успеха: **~{chance:.0f}%** · "
                f"{ui_icon('exposed')} риск разоблачения при провале: **~{risk:.0f}%**\n"
                f"{ui_icon('agent')} Агент: **{(SPY.spec_label(agent['spec']) + ' ур.' + str(agent['rank'])) if agent else '—'}**"
                + ("" if not agent else (f" {ui_icon('check')} профиль" if agent_match else " — не та специализация"))))
            # выбор агента нужной специализации
            spec = meta["spec"]
            spec_agents = self.spy.agents_by_spec(actor.name, spec)
            aopts = [disnake.SelectOption(label="Без агента", value="none", default=(s["agent_id"] is None))]
            for a in spec_agents[:24]:
                aopts.append(disnake.SelectOption(
                    label=f"{SPY.spec_label(a['spec'])} ур.{a['rank']} (#{a['id']})"[:100],
                    value=str(a["id"]), default=(a["id"] == s["agent_id"])))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("spy", "agent"),
                placeholder=f"Агент ({SPY.spec_label(spec)})…", options=aopts)))
            # ресурс для кражи
            if meta["needs"] == "resource":
                ropts = [disnake.SelectOption(label=res_label(r), value=r, emoji=_pe_res(r),
                                              default=(r == s["res"])) for r in RESOURCES]
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("spy", "res"), placeholder="Что красть…", options=ropts)))
            run_disabled = (meta["needs"] == "resource" and not s["res"])
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Запустить",
                                  emoji=_pe(meta["icon"]), disabled=run_disabled,
                                  custom_id=cid("spy", "run")),
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="⟵ Цель",
                                  custom_id=cid("spy", "goto", "target")),
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="⟵ Хаб",
                                  custom_id=cid("spy", "goto", "hub"))))
        else:
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="⟵ Цель",
                                  custom_id=cid("spy", "goto", "target")),
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="⟵ Хаб",
                                  custom_id=cid("spy", "goto", "hub"))))
        return self._container(items)

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _spy_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("spy:"):
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        v = inter.values[0]
        if action == "target":
            s.update(target=v, view="ops", op=None, agent_id=None, res=None)
        elif action == "op":
            s.update(op=v, agent_id=None, res=None)
        elif action == "agent":
            s["agent_id"] = None if v == "none" else int(v)
        elif action == "res":
            s["res"] = v
        await inter.edit_original_message(components=self._render(inter.author.id).components)

    @commands.Cog.listener("on_button_click")
    async def _spy_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("spy:"):
            return
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        # run может открыть модалку (её НЕЛЬЗЯ слать после defer) — обрабатываем отдельно
        if action == "run":
            await self._run_op(inter)
            return
        if action == "sweep":
            await self._run_sweep(inter)
            return
        await self._defer(inter)
        note = None
        if action == "goto":
            s["view"] = args[0]
            if args[0] == "hub":
                s.update(target=None, op=None, agent_id=None, res=None)
        elif action == "tpage":
            s["tpage"] += 1 if args and args[0] == "next" else -1
        elif action == "hire":
            s["view"] = "hire"
        elif action == "dev":
            note = self._develop(inter.author.id, args[0])
        elif action == "hirespec":
            note = self._hire(inter.author.id, args[0])
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    # ───── развитие службы ─────
    def _develop(self, uid: int, kind: str) -> str:
        actor = self._actor(uid)
        if not actor:
            return "⚠️ Нет страны."
        recon, counter = self.spy.get_agency(actor.name)
        if kind == "recon":
            if recon >= SPY.RECON_MAX:
                return "⚠️ Разведка уже на максимуме."
            cost = SPY.level_up_cost(SPY.RECON_BASE_COST, recon)
            if actor.money < cost:
                return f"⚠️ Недостаточно средств: нужно {int_format(cost)} {CURRENCY}."
            update_money(actor.name, -cost)
            self.spy.set_recon(actor.name, recon + 1)
            return f"{ui_icon('recon')} Разведка → ур. {recon + 1}"
        else:
            if counter >= SPY.COUNTER_MAX:
                return "⚠️ Контрразведка уже на максимуме."
            cost = SPY.level_up_cost(SPY.COUNTER_BASE_COST, counter)
            if actor.money < cost:
                return f"⚠️ Недостаточно средств: нужно {int_format(cost)} {CURRENCY}."
            update_money(actor.name, -cost)
            self.spy.set_counter(actor.name, counter + 1)
            return f"{ui_icon('counterintel')} Контрразведка → ур. {counter + 1}"

    def _hire(self, uid: int, spec: str) -> str:
        actor = self._actor(uid)
        if not actor:
            return "⚠️ Нет страны."
        if spec not in SPY.SPECS:
            return "⚠️ Неизвестная специализация."
        if self.spy.count_agents(actor.name) >= SPY.AGENT_MAX:
            return "⚠️ Достигнут лимит агентов."
        if actor.money < SPY.AGENT_COST:
            return f"⚠️ Недостаточно средств: нужно {int_format(SPY.AGENT_COST)} {CURRENCY}."
        recon, _c = self.spy.get_agency(actor.name)
        rank = max(1, recon)
        update_money(actor.name, -SPY.AGENT_COST)
        self.spy.add_agent(actor.name, spec, rank, int(time.time()))
        return f"{ui_icon('agent')} Нанят агент: {SPY.spec_label(spec)} (ранг {rank})"

    # ───── запуск операции ─────
    async def _precheck(self, inter, actor, op: str, count_limit: bool) -> str | None:
        """Возвращает текст-ошибку или None если можно запускать."""
        now = int(time.time())
        if self._cd_left(actor.name, now) > 0:
            left = self._cd_left(actor.name, now)
            return f"{ui_icon('heat')} Служба перезаряжается: ещё {left // 60}м {left % 60}с."
        if count_limit and self._ops_left(actor.name) <= 0:
            return f"⚠️ Лимит операций на сутки исчерпан ({SPY.SPY_MAX_PER_DAY})."
        cost = SPY.op_cost(op)
        if actor.money < cost:
            return f"⚠️ Недостаточно средств на операцию: нужно {int_format(cost)} {CURRENCY}."
        return None

    async def _run_op(self, inter: disnake.MessageInteraction):
        uid = inter.author.id
        s = self._session(uid)
        actor = self._actor(uid)
        op = s["op"]
        target = s["target"]
        if not actor or not op or op not in SPY.SPY_OPS or SPY.SPY_OPS[op]["scope"] != "enemy":
            await self._defer(inter)
            await inter.edit_original_message(components=self._render(uid, "Операция недоступна.").components)
            return
        tobj = self.countries.get_object(target)
        if not tobj or target == actor.name:
            await self._defer(inter)
            await inter.edit_original_message(components=self._render(uid, "Цель недоступна.").components)
            return
        meta = SPY.SPY_OPS[op]
        err = await self._precheck(inter, actor, op, count_limit=True)
        if err:
            await self._defer(inter)
            await inter.edit_original_message(components=self._render(uid, err).components)
            return
        # операции с вводом количества → модалка (её НЕЛЬЗЯ слать после defer!)
        if meta["needs"] in ("amount", "resource"):
            await inter.response.send_modal(self._amount_modal(op, s.get("res")))
            return
        await self._resolve_offensive(inter, actor, tobj, op, amount=None, resource=None)

    def _amount_modal(self, op: str, res: str | None = None) -> disnake.ui.Modal:
        meta = SPY.SPY_OPS[op]
        if op == "sabotage":
            label, default = "Сколько техники вывести", str(SPY.SABOTAGE_DEFAULT)
        else:  # theft
            label = f"Сколько украсть ({res_label(res)})" if res else "Сколько ресурса украсть"
            default = str(SPY.THEFT_DEFAULT)
        return disnake.ui.Modal(
            title=meta["label"][:45], custom_id=cid("spy", "amodal", op),
            components=[disnake.ui.TextInput(
                label=label[:45], custom_id="val", style=disnake.TextInputStyle.short,
                placeholder="например 20 или 2000", required=True, value=default)])

    @commands.Cog.listener("on_modal_submit")
    async def _spy_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("spy:amodal:"):
            return
        await self._defer(inter)
        uid = inter.author.id
        s = self._session(uid)
        actor = self._actor(uid)
        _, _, args = parse_cid(c)
        op = args[0]
        tobj = self.countries.get_object(s["target"]) if s["target"] else None
        if not actor or not tobj or op not in SPY.SPY_OPS:
            await inter.edit_original_message(components=self._render(uid, "Операция недоступна.").components)
            return
        amount = _num(inter.text_values.get("val", ""))
        if amount is None or amount <= 0:
            await inter.edit_original_message(components=self._render(uid, "Неверное число.").components)
            return
        # повторная проверка на всякий случай (деньги могли измениться)
        err = await self._precheck(inter, actor, op, count_limit=True)
        if err:
            await inter.edit_original_message(components=self._render(uid, err).components)
            return
        await self._resolve_offensive(inter, actor, tobj, op, amount=amount, resource=s["res"])

    async def _resolve_offensive(self, inter, actor, tobj, op, amount, resource):
        """Общая резолюция наступательной операции: предоплата → бросок → эффект/разоблачение."""
        await self._defer(inter)  # мгновенный ack — чтобы интеракция не протухла за 3с
        uid = inter.author.id
        s = self._session(uid)
        meta = SPY.SPY_OPS[op]
        now = int(time.time())
        name, target = actor.name, tobj.name

        # предоплата ДО резолюции (сгорает при любом исходе)
        cost = SPY.op_cost(op)
        update_money(name, -cost)
        self.cooldown.set_cooldown("spy", now + SPY.SPY_COOLDOWN, name)

        # параметры
        recon, _c = self.spy.get_agency(name)
        counter = self._eff_counter(target, now)
        heat = self._eff_heat(name, now)
        agent = self.spy.get_agent(s["agent_id"]) if s["agent_id"] else None
        agent_match = bool(agent and agent["spec"] == meta["spec"])
        arank = agent["rank"] if agent else 0
        chance = SPY.success_chance(recon, counter, tobj.stability, heat, arank, agent_match)

        # накал растёт за операцию
        self.spy.set_heat(name, heat + SPY.HEAT_PER_OP, now)

        success = random.uniform(0, 100) <= chance
        exposed = False
        actor_lines: list[str] = []
        target_lines: list[str] = []
        dossier = None

        if success:
            actor_lines, target_lines, dossier = self._apply_success(op, actor, tobj, amount, resource, now)
        else:
            risk = SPY.expose_chance(counter, heat)
            exposed = random.uniform(0, 100) <= risk
            if exposed:
                self.spy.set_heat(name, heat + SPY.HEAT_PER_OP + SPY.HEAT_ON_EXPOSE, now)
                if agent:  # агент потерян на разоблачении
                    self.spy.remove_agent(agent["id"])
                    s["agent_id"] = None  # сбрасываем мёртвый выбор в сессии
                    actor_lines.append(f"{ui_icon('agent')} Агент потерян при провале.")

        inc_id = self.spy.log_incident(name, target, op, now, success, exposed)

        # — отчёт атакующему (приватно, в ЛС) —
        if success:
            head = f"{ui_icon(meta['icon'])} Операция «{meta['label']}» удалась"
            color = SUCCESS_COLOR
        elif exposed:
            head = f"{ui_icon('exposed')} ПРОВАЛ С РАЗОБЛАЧЕНИЕМ — «{meta['label']}»"
            color = ERROR_COLOR
        else:
            head = f"{ui_icon('heat')} Операция «{meta['label']}» сорвалась"
            color = WARNING_COLOR
        body = (f"Цель: **{tobj.flag} {target}**\n"
                f"Предоплата: **−{int_format(cost)} {CURRENCY}**"
                + (f"\nШанс был ~{chance:.0f}%" if not success else "")
                + ("\n" + "\n".join(actor_lines) if actor_lines else ""))
        if exposed:
            body += "\n\n-# Ваше участие вскрыто публично — это casus belli против вас."
        note = f"{head}\n{body}"

        await inter.edit_original_message(components=self._render(uid, note).components)

        # — досье атакующему (разведка), отдельным сообщением в ЛС —
        if dossier is not None:
            try:
                await inter.followup.send(embed=dossier)
            except Exception:
                try:
                    await inter.author.send(embed=dossier)
                except Exception:
                    pass
        # — уведомление жертве (эффект без имени атакующего), только при успехе с эффектом —
        if success and target_lines:
            await self._notify_target(tobj, meta, target_lines)
        # — публичное разоблачение + casus belli —
        if exposed:
            await self._post_exposure(actor, tobj, meta)
            al = self.bot.get_cog("AllianceCog")
            if al:
                await al.on_spy_exposed(name, target)

    def _apply_success(self, op, actor, tobj, amount, resource, now):
        """Применяет эффект успешной операции через штатные менеджеры.
        Возвращает (строки_для_атакующего, строки_для_жертвы, досье|None)."""
        name, target = actor.name, tobj.name
        a: list[str] = []
        t: list[str] = []
        dossier = None
        if op == "recon":
            a.append(f"{ui_icon('recon')} Досье собрано — см. отдельным сообщением.")
            dossier = self._build_dossier(tobj, now)
        elif op == "destab":
            hit = random.randint(*SPY.DESTAB_HIT)
            new_stab = _clamp(tobj.stability - hit, 0, 100)
            self.countries.update_object(target, stability=round(new_stab, 2))
            a.append(f"{ui_icon('destab')} Стабильность цели −{hit} → {new_stab:.0f}")
            t.append(f"{ui_icon('destab')} Вспышка нестабильности: **−{hit}** стабильности. Источник неизвестен.")
        elif op == "eco_sab":
            mult = round(random.uniform(*SPY.ECO_SAB_MULT), 2)
            hours = random.randint(*SPY.ECO_SAB_HOURS)
            self.effects.add(target, "income_mult", mult, now + hours * 3600)
            a.append(f"{ui_icon('eco_sab')} Доход цели ×{mult:.2f} на {hours}ч")
            t.append(f"{ui_icon('eco_sab')} Саботаж экономики: доход **×{mult:.2f}** на **{hours}ч**.")
        elif op == "sabotage":
            counts = self.equip.category_counts(target)
            req = _clamp(int(amount or 0), 1, SPY.SABOTAGE_MAX)
            if not counts:
                a.append(f"{ui_icon('sabotage')} У цели нет техники на складе — ущерба нет.")
            else:
                cat = max(counts, key=counts.get)
                destroy = min(req, counts[cat])          # min(запрошено, есть)
                if destroy > 0:
                    self.equip.take_category(target, cat, destroy)
                    a.append(f"{ui_icon('sabotage')} Уничтожено **{destroy}** ед. техники (кат. {cat})")
                    t.append(f"{ui_icon('sabotage')} Диверсия на складе: уничтожено **{destroy}** ед. техники.")
                else:
                    a.append(f"{ui_icon('sabotage')} Техники не нашлось — ущерба нет.")
        elif op == "nuke_sab":
            nuc = self.bot.get_cog("NuclearCog")
            res_line = nuc.sabotage(target) if nuc else "Модуль атома недоступен."
            a.append(f"{ui_icon('nuke_sab')} {res_line}")
            t.append(f"{ui_icon('accident')} Сбой на ядерных объектах: {res_line}")
        elif op == "nuke_probe":
            nuc = self.bot.get_cog("NuclearCog")
            st = nuc.nuc.get(target) if nuc else None
            if st and st["status"] == "covert":
                asyncio.get_event_loop().create_task(nuc.expose(target, by=name))
                a.append(f"{ui_icon('violator')} Найдены каскады и чертежи: тайная военная программа "
                         f"**{target}** раскрыта, доказательства переданы МАГАТЭ.")
            else:
                a.append(f"{ui_icon('inspect')} Военного трека не найдено. "
                         f"{nuc.dossier_line(target) if nuc else ''}")
        elif op == "theft":
            res = resource if resource in RESOURCES else None
            if not res:
                a.append(f"{ui_icon('theft')} Ресурс не выбран — кража сорвана.")
            else:
                have = self.settings.get_resources(target).get(res, 0)
                req = _clamp(int(amount or 0), 1, SPY.THEFT_MAX)
                stolen = min(req, have)                   # min(запрошено, есть)
                if stolen > 0:
                    self.settings.add_resource(target, res, -stolen)
                    self.settings.add_resource(name, res, stolen)
                    a.append(f"{ui_icon('theft')} Похищено **{int_format(stolen)}** {res_label(res)} → себе")
                    t.append(f"{ui_icon('theft')} Кража со склада: **−{int_format(stolen)}** {res_label(res)}.")
                else:
                    a.append(f"{ui_icon('theft')} На складе цели нет **{res_label(res)}** — добыча пуста.")
        return a, t, dossier

    def _build_dossier(self, tobj, now) -> disnake.Embed:
        """Разведснимок цели (протухающий срез состояния на момент операции)."""
        name = tobj.name
        ideo, rel = self.politics.get(name)
        recon, counter = self.spy.get_agency(name)
        agents = self.spy.count_agents(name)
        pool = self.army.get_pool(name)
        forms = self.army.formations_for(name)
        arsenal = sum(self.equip.category_counts(name).values())
        res = self.settings.get_resources(name)
        res_line = "  ".join(f"{res_icon(r)} {int_format(res.get(r, 0))}"
                             for r in RESOURCES if res.get(r, 0) > 0) or "—"
        levels = self.upgrades.get_levels(name)
        dev_line = ", ".join(f"{b}:{lvl}" for b, lvl in levels.items()) or "—"
        e = disnake.Embed(
            title=f"🔭 Досье: {tobj.flag} {name}",
            description="-# Разведснимок на момент операции (данные «протухают»).",
            color=COMMAND_COLOR)
        e.add_field(
            name="Состояние",
            value=(f"{ui_icon('money')} Казна: **{int_format(tobj.money)} {CURRENCY}**\n"
                   f"{ui_icon('happy')} Счастье: **{tobj.happiness:.0f}** · "
                   f"{ui_icon('stability')} Стабильность: **{tobj.stability:.0f}**\n"
                   f"{ui_icon('globe')} Население: **{int_format(tobj.population)}** · "
                   f"Территория: **{int_format(tobj.territory)}** км²\n"
                   f"{ui_icon('gov')} {POL.ideo_label(ideo)} · {POL.rel_label(rel)}"),
            inline=False)
        e.add_field(
            name="Вооружённые силы",
            value=(f"{ui_icon('recruit')} Резерв л/с: **{int_format(pool)}**\n"
                   f"{ui_icon('soldier')} Соединений: **{len(forms)}** · "
                   f"техники на складе: **{int_format(arsenal)}**"),
            inline=False)
        e.add_field(
            name="Разведслужба",
            value=(f"{ui_icon('recon')} Разведка: **ур. {recon}** · "
                   f"{ui_icon('counterintel')} Контрразведка: **ур. {counter}** · "
                   f"{ui_icon('agent')} агентов: **{agents}**"),
            inline=False)
        nuc = self.bot.get_cog("NuclearCog")
        if nuc:
            e.add_field(name="Атомная программа", value=nuc.dossier_line(name)[:1024], inline=False)
        e.add_field(name="Ресурсы", value=res_line[:1024], inline=False)
        e.add_field(name="Развитие", value=dev_line[:1024], inline=False)
        return e

    async def _notify_target(self, tobj, meta, lines):
        """ЛС владельцу страны-жертвы: эффект без имени атакующего."""
        try:
            user = self.bot.get_user(tobj.user) or await self.bot.fetch_user(tobj.user)
        except Exception:
            user = None
        if not user:
            return
        e = disnake.Embed(
            title="Скрытая операция против вашей страны",
            description=(f"{tobj.flag} **{tobj.name}** подверглась враждебной спецоперации.\n\n"
                        + "\n".join(lines)
                        + "\n\n-# Исполнитель не установлен. Усильте контрразведку (`!spy` → Зачистка)."),
            color=WARNING_COLOR)
        try:
            await user.send(embed=e)
        except Exception:
            pass

    async def _post_exposure(self, actor, tobj, meta):
        """Публичный пост в #шпионаж: разоблачение + casus belli."""
        ch_id = rid("CH_SPY", 0)
        channel = None
        if ch_id:
            guild = self.bot.get_guild(GUILD_ID)
            channel = (guild.get_channel(ch_id) if guild else None) or self.bot.get_channel(ch_id)
        if not channel:
            return
        e = disnake.Embed(
            title="РАЗОБЛАЧЕНИЕ",
            description=(f"{tobj.flag} **{tobj.name}** поймал(а) агентов "
                        f"{actor.flag} **{actor.name}** при попытке операции "
                        f"«{meta['label']}».\n\n"
                        f"⚔️ Это **casus belli** — законный повод к войне. "
                        f"Разрешение конфликта — через куратора."),
            color=ERROR_COLOR)
        try:
            await channel.send(embed=e)
        except Exception:
            pass

    # ───── зачистка (контрразведка) ─────
    async def _run_sweep(self, inter: disnake.MessageInteraction):
        await self._defer(inter)
        uid = inter.author.id
        actor = self._actor(uid)
        if not actor:
            await inter.edit_original_message(components=self._render(uid, "Нет страны.").components)
            return
        now = int(time.time())
        err = await self._precheck(inter, actor, "sweep", count_limit=False)
        if err:
            await inter.edit_original_message(components=self._render(uid, err).components)
            return
        cost = SPY.op_cost("sweep")
        update_money(actor.name, -cost)
        self.cooldown.set_cooldown("spy", now + SPY.SPY_COOLDOWN, actor.name)
        # временное усиление защиты
        self.effects.add(actor.name, "spy_counter", SPY.SWEEP_COUNTER_BONUS,
                         now + SPY.SWEEP_BONUS_HOURS * 3600)
        lines = [f"{ui_icon('counterintel')} Контрразведка усилена: +{SPY.SWEEP_COUNTER_BONUS} "
                 f"на {SPY.SWEEP_BONUS_HOURS}ч."]
        # поиск свежих следов
        _recon, counter = self.spy.get_agency(actor.name)
        caught = None
        incidents = self.spy.incidents_against(actor.name, now - SPY.SWEEP_WINDOW_D * _DAY, unrevealed_only=True)
        if incidents:
            catch_chance = _clamp(30 + counter * 12, 5, 90)
            if random.uniform(0, 100) <= catch_chance:
                caught = incidents[0]
                self.spy.reveal_incident(caught["id"])
        if caught:
            attacker = self.countries.get_object(caught["actor"])
            flag = attacker.flag if attacker else "🏴"
            lines.append(f"{ui_icon('exposed')} Пойман шпион: {flag} **{caught['actor']}** "
                         f"(операция «{SPY.op_label(caught['op'])}»). Casus belli ваш.")
            await self._post_sweep_catch(actor, caught)
        else:
            lines.append("-# Свежих следов чужой агентуры не обнаружено.")
        note = f"{ui_icon('sweep')} Зачистка проведена\n" + "\n".join(lines)
        await inter.edit_original_message(components=self._render(uid, note).components)

    async def _post_sweep_catch(self, actor, incident):
        ch_id = rid("CH_SPY", 0)
        channel = None
        if ch_id:
            guild = self.bot.get_guild(GUILD_ID)
            channel = (guild.get_channel(ch_id) if guild else None) or self.bot.get_channel(ch_id)
        if not channel:
            return
        attacker = self.countries.get_object(incident["actor"])
        aflag = attacker.flag if attacker else "🏴"
        e = disnake.Embed(
            title="🧹 КОНТРРАЗВЕДКА СРАБОТАЛА",
            description=(f"{actor.flag} **{actor.name}** вычислил(а) агентуру "
                        f"{aflag} **{incident['actor']}** (операция «{SPY.op_label(incident['op'])}»).\n\n"
                        f"⚔️ **Casus belli** в пользу {actor.flag} {actor.name}."),
            color=COMMAND_COLOR)
        try:
            await channel.send(embed=e)
        except Exception:
            pass

    # ═══════════════ КОМАНДЫ ═══════════════
    @commands.command(name="spy", aliases=["шпионаж", "разведка", "spionage"])
    async def spy_cmd(self, ctx: commands.Context):
        actor = self._actor(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(
                description="Шпионаж доступен только зарегистрированным странам. "
                            "Откройте панель регистрации.", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(view="hub", target=None, op=None, agent_id=None, res=None, tpage=0)
        try:
            await ctx.author.send(components=self._render(ctx.author.id).components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(
                description="Не могу написать в ЛС. Включите личные сообщения от участников "
                            "сервера и повторите `!spy`.", color=WARNING_COLOR))
            return
        try:
            await ctx.message.add_reaction("🕵️")
        except Exception:
            pass
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('spy')} Панель разведслужбы отправлена вам в **личные сообщения**.",
                color=COMMAND_COLOR), delete_after=12)

    @commands.command(name="casus", aliases=["casusbelli", "поводы", "casus-belli"])
    async def casus_cmd(self, ctx: commands.Context):
        """Список активных casus belli (разоблачённые операции за окно)."""
        now = int(time.time())
        rows = self.spy.revealed_incidents(now - SPY.CASUS_WINDOW_D * _DAY)
        # обострившиеся дипломатические кризисы — casus belli обеим сторонам
        crises = Diplomacy().casus_incidents(now - SPY.CASUS_WINDOW_D * _DAY)
        nuc_lines = self.bot.get_cog("NuclearCog").casus_lines() if self.bot.get_cog("NuclearCog") else []
        if not rows and not crises and not nuc_lines:
            await ctx.send(embed=disnake.Embed(
                title="Casus belli",
                description="Активных поводов к войне нет.", color=COMMAND_COLOR))
            return
        lines = []
        nuc = self.bot.get_cog("NuclearCog")
        if nuc:
            lines += nuc.casus_lines()
        for r in crises[:10]:
            a, b = self.countries.get_object(r["a"]), self.countries.get_object(r["b"])
            days = max(0, (now - r["created_at"]) // _DAY)
            title = DIP.INCIDENT_BY_KEY.get(r["kind"], ("Кризис", ""))[0]
            lines.append(f"{a.flag if a else '🏴'} **{r['a']}** ⇄ {b.flag if b else '🏴'} **{r['b']}** · "
                         f"кризис «{title}» · {days} дн. назад")
        for r in rows[:20]:
            atk = self.countries.get_object(r["actor"])
            tgt = self.countries.get_object(r["target"])
            af = atk.flag if atk else "🏴"
            tf = tgt.flag if tgt else "🏴"
            days = max(0, (now - r["ts"]) // _DAY)
            lines.append(f"{af} **{r['actor']}** → {tf} **{r['target']}** · "
                         f"«{SPY.op_label(r['op'])}» · {days} дн. назад")
        await ctx.send(embed=disnake.Embed(
            title=f"Активные casus belli ({len(rows) + len(crises) + len(nuc_lines)})",
            description="\n".join(lines), color=WARNING_COLOR))


def setup(bot: commands.Bot):
    bot.add_cog(SpyCog(bot))
