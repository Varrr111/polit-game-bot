"""
Мировые новости (отыгровка игроков + ИИ-последствия).

Канал config.WORLD_NEWS_CHANNEL. Правила к сообщению-новости:
  • автор — зарегистрированная страна;
  • минимум NEWS_MIN_CHARS символов текста;
  • обязательно картинка (вложение-изображение);
  • не больше NEWS_MAX_PER_DAY новостей в сутки на страну.
Невалидное сообщение удаляется с коротким пояснением.

На валидную новость бот создаёт ВЕТКУ и постит туда разбор ИИ (gpt-4o-mini):
реалистичные последствия, применённые к стране. Значения жёстко клампятся
ботом (см. utils/newsai.py) — «-100 счастья» невозможно.

Простой: если страна не публикует новости NEWS_INACTIVITY_DAYS дней — её
регистрация снимается автоматически. ЧВК тоже пишут новости (разбор ИИ по досье
компании: казна, репутация, отношения со странами) и по тому же правилу простоя
распускаются.
"""

import logging
import re
import time
from datetime import datetime

import disnake
from disnake.ext import commands, tasks

import config
from utils import (
    Countries, Settings, Politics, Effects, News, Diplomacy, get_object_by_user,
    Army, Equipment, Buildings, CountryUpgrades, War, Sanctions, Cooldown, Pmc,
    int_format, CURRENCY, COMMAND_COLOR, ERROR_COLOR, WARNING_COLOR, SUCCESS_COLOR,
    WORLD_NEWS_CHANNEL, NEWS_MIN_CHARS, NEWS_MAX_PER_DAY, NEWS_INACTIVITY_DAYS,
    PROFILE_ROLE, GUILD_ID,
)
from utils.resources import ui_icon, res_icon, res_label, building_label
from utils.ui import Panel
import utils.equipment as E
from utils.serverconfig import rid
import utils.politics as POL
import utils.upgrades as UP
import utils.newsai as AI

log = logging.getLogger("news")

WARN_EVERY = 12 * 3600   # напоминание о новостях каждые 12 часов молчания

_IMAGE_EXT = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def _cat_emoji(cat: str) -> str:
    return {
        "economy": UP.cat_icon("economy"),
        "trade": UP.cat_icon("economy"),
        "military": UP.cat_icon("military"),
        "science": ui_icon("ev_science"),
        "diplomacy": ui_icon("ev_diplomacy"),
        "social": ui_icon("ev_social"),
        "nature": ui_icon("ev_nature"),
    }.get(cat, ui_icon("ev_social")) or ui_icon("news")


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s and s.startswith("<") else None
    except Exception:
        return None


class NewsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.settings = Settings()
        self.politics = Politics()
        self.effects = Effects()
        self.news = News()
        self.inactivity_tick.start()

    def cog_unload(self):
        self.inactivity_tick.cancel()

    # ───── валидация входящих новостей ─────
    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot or not message.guild:
            return
        if message.channel.id != rid("CH_NEWS", WORLD_NEWS_CHANNEL):
            return
        if (message.content or "").startswith(config.PREFIX):
            return  # команды в канале новостей не трогаем

        obj = get_object_by_user(message.author.id)
        pm = None if obj else Pmc().by_user(message.author.id)
        if not obj and not pm:
            await self._reject(message, "публиковать новости могут только зарегистрированные страны и ЧВК — "
                                        "откройте панель регистрации.")
            return
        author = obj.name if obj else pm["name"]

        content = (message.content or "").strip()
        has_image = any(
            (a.content_type or "").startswith("image") or a.filename.lower().endswith(_IMAGE_EXT)
            for a in message.attachments)

        if len(content) < NEWS_MIN_CHARS:
            await self._reject(message, f"новость должна быть не короче **{NEWS_MIN_CHARS}** символов "
                                        f"(сейчас {len(content)}).")
            return
        if not has_image:
            await self._reject(message, "к новости **обязательно** приложите картинку.")
            return

        now = int(time.time())
        if self.news.count_since(author, self._day_start(now)) >= NEWS_MAX_PER_DAY:
            await self._reject(message, f"лимит новостей на сегодня исчерпан (**{NEWS_MAX_PER_DAY}/день**).")
            return

        # принято
        self.news.touch(author, now, message.id)
        try:
            await message.add_reaction(_pe("check") or "✅")   # кастомная иконка, юникод — только если её нет
        except disnake.HTTPException:
            pass
        try:
            thread = await message.create_thread(
                name=f"Последствия · {author}"[:100], auto_archive_duration=1440)
        except disnake.HTTPException:
            log.exception("Не удалось создать ветку под новостью")
            return
        if pm:
            await self._process_pmc(thread, pm["name"], content)
        else:
            await self._process(thread, obj, content)

    async def _reject(self, message: disnake.Message, reason: str):
        try:
            await message.delete()
        except disnake.HTTPException:
            pass
        try:
            await message.channel.send(
                embed=disnake.Embed(description=f"{message.author.mention}, {reason}", color=ERROR_COLOR),
                delete_after=12)
        except disnake.HTTPException:
            pass

    def _day_start(self, now: int) -> int:
        dt = datetime.fromtimestamp(now, config.TZ).replace(hour=0, minute=0, second=0, microsecond=0)
        return int(dt.timestamp())

    # ───── ИИ-разбор и применение последствий ─────
    # ───── досье для ИИ (вся база игры по стране) ─────
    def _dossier(self, name: str) -> str:
        """Полный срез страны из БД: экономика, ресурсы, заводы, развитие, армия, техника, власть,
        войны, санкции, дипломатия/альянсы/атом. Компактно — экономим токены."""
        o = self.countries.get_object(name)
        if not o:
            return ""
        now = int(time.time())
        ps = self.politics.get_state(name)
        lines = [
            f"Страна: {name}. Казна {int_format(o.money)} {CURRENCY}, доход развития ~{int_format(UP.country_income(name))}/ч, "
            f"множитель дохода от эффектов ×{self.effects.income_mult(name, now)}.",
            f"Население {int_format(o.population)}, территория {int_format(o.territory)} км². "
            f"Счастье {o.happiness:.0f}, стабильность {o.stability:.0f}.",
            f"Строй: {POL.ideo_label(ps['ideology'])}, религия {POL.rel_label(ps['religion'])}, "
            f"легитимность {ps['legitimacy']:.0f}, оппозиция {ps['opposition']:.0f}.",
        ]
        res = {r: v for r, v in self.settings.get_resources(name).items() if v > 0}
        top = sorted(res.items(), key=lambda kv: -kv[1])[:8]
        lines.append("Склад: " + (", ".join(f"{res_label(r)} {int_format(v)}" for r, v in top) or "пусто") + ".")
        blds = Buildings().get_buildings(name)
        if blds:
            lines.append("Здания: " + ", ".join(f"{building_label(k)}×{c}" for k, c in blds.items() if c) + ".")
        lv = {k: v for k, v in CountryUpgrades().get_levels(name).items() if v}
        if lv:
            lines.append("Развитие: " + ", ".join(f"{UP.BRANCHES[k]['label']} {v}" for k, v in lv.items()
                                                  if k in UP.BRANCHES) + ".")
        army = Army()
        forms = army.formations_for(name)
        ready = sum(1 for f in forms if now >= f["ready_at"])
        dom: dict[str, int] = {}
        for cat, c in Equipment().category_counts(name).items():
            d = E.cat_domain(cat)
            dom[d] = dom.get(d, 0) + c
        lines.append(f"Армия: соединений {len(forms)} (готовы {ready}), резерв л/с {int_format(army.get_pool(name))}; "
                     "техника: " + (", ".join(f"{E.domain_of_label(d)} {c}" for d, c in dom.items()) or "нет") + ".")
        wars = [w["defender"] if w["attacker"] == name else w["attacker"] for w in War().active_for(name)]
        if wars:
            lines.append("Воюет с: " + ", ".join(wars) + ".")
        sc = Sanctions()
        on = [r["sanctioner"] for r in sc.active_against(name)]
        by = [r["target"] for r in sc.active_by(name)]
        if on or by:
            lines.append(f"Санкции против страны: {', '.join(on) or 'нет'}; страна санкционирует: {', '.join(by) or 'нет'}.")
        dip = self.bot.get_cog("DiplomacyCog")
        if dip:
            try:
                lines.append("Дипломатия: " + dip.diplo_context(name).replace("\n", " "))
            except Exception:
                pass
        return "\n".join(lines)

    def _brief(self, name: str, author: str) -> str:
        """Короткое досье упомянутой страны (для оценки угроз/сделок)."""
        o = self.countries.get_object(name)
        if not o:
            return ""
        forms = len(Army().formations_for(name))
        tech = sum(Equipment().category_counts(name).values())
        rel = Diplomacy().get_relation(author, name)
        al = self.bot.get_cog("AllianceCog")
        nuc = self.bot.get_cog("NuclearCog")
        blocs = al.context(name).replace("\n", " ") if al else ""
        atom = nuc.context(name) if nuc else ""
        return (f"{name}: казна {int_format(o.money)}, стабильность {o.stability:.0f}, соединений {forms}, "
                f"техники {tech}; отношения с {author} {rel:+.0f}. {blocs} {atom}").strip()

    @staticmethod
    def _name_re(name: str) -> re.Pattern:
        """Название страны в любом падеже: «Германия» ловит «Германии/Германию», «Южная Корея» — «Южной Корее»."""
        parts = []
        for w in name.lower().split():
            stem = w[:-1] if len(w) > 3 and w[-1] in "аяоеиыйьую" else w
            if len(w) >= 5 and w.endswith(("ая", "ий", "ой", "ые")):
                stem = w[:-2]
            parts.append(re.escape(stem) + r"\w*")
        return re.compile(r"(?<!\w)" + r"[\s-]+".join(parts), re.IGNORECASE)

    def _mentioned(self, content: str, author: str) -> list[str]:
        hits = []
        for n in self.countries.get_object_names():
            if n == author:
                continue
            m = self._name_re(n).search(content)
            if m:
                hits.append((m.start(), n))
        return [n for _pos, n in sorted(hits)][:3]

    # ───── ИИ-разбор и применение последствий ─────
    def _panel(self, text: str, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(text), accent_colour=disnake.Colour(color)))
        return p

    async def _process(self, thread: disnake.Thread, obj, content: str):
        placeholder = await thread.send(components=self._panel(
            f"{ui_icon('news')} Аналитики изучают новость и досье страны…").components)

        if not AI.available():
            await placeholder.edit(components=self._panel(
                f"### {ui_icon('news')} Новость принята\n-# ИИ-анализ последствий отключён: не задан "
                f"`OPENAI_API_KEY` в `.env`.", WARNING_COLOR).components)
            return

        others = self._mentioned(content, obj.name)
        brief = "\n".join(b for b in (self._brief(n, obj.name) for n in others) if b)
        result = await AI.analyze(content, self._dossier(obj.name), brief)
        if not result:
            await placeholder.edit(components=self._panel(
                f"### {ui_icon('news')} Новость принята\n-# Не удалось получить разбор ИИ (ошибка модели или сети). "
                f"Последствия не применены.", WARNING_COLOR).components)
            return

        cred = result["credibility"]
        clamped = AI.clamp_effects(result["effects"])
        if cred < AI.LOW_CREDIBILITY:
            clamped = AI.strip_gains(clamped)      # заявления не подкреплены — выгоды нет
        relations = AI.clamp_relations(result["relations"], others)
        if cred < AI.LOW_CREDIBILITY:   # выдуманное сближение не засчитывается, ухудшение — да
            relations = {k: v for k, v in relations.items() if v < 0}
        lines = self._apply(obj.name, clamped)
        dip = Diplomacy()
        for other, d in relations.items():
            v = dip.add_relation(obj.name, other, d)
            o2 = self.countries.get_object(other)
            lines.append(f"{ui_icon('rel_up' if d > 0 else 'rel_down')} Отношения с {o2.flag if o2 else ''} {other} "
                         f"{'+' if d > 0 else ''}{d} → {v:+.0f}")
        bar = "▰" * round(cred / 10) + "▱" * (10 - round(cred / 10))
        word = "подкреплена" if cred >= 70 else ("преувеличена" if cred >= AI.LOW_CREDIBILITY else "не подкреплена")
        effects_text = "\n".join(lines) if lines else "-# Заметных последствий нет."
        text = (f"## {_cat_emoji(result['category'])} {result['headline']}\n{result['analysis'] or '—'}")
        reality = (f"{ui_icon('inspect')} Достоверность {bar} **{cred}** · {word}"
                   + (f"\n-# {result['reality']}" if result["reality"] else ""))
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(text),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(reality),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(f"**Последствия для {obj.flag} {obj.name}:**\n{effects_text}"),
            disnake.ui.TextDisplay("-# Разбор ИИ по досье страны из базы игры"),
            accent_colour=disnake.Colour(COMMAND_COLOR if cred >= AI.LOW_CREDIBILITY else WARNING_COLOR)))
        await placeholder.edit(components=p.components)

    async def _process_pmc(self, thread: disnake.Thread, name: str, content: str):
        """Новость ЧВК: ИИ судит по досье компании. Действуют только казна (%), репутация ЧВК
        и отношения с упомянутыми странами — у ЧВК нет населения, счастья и ресурсов."""
        pmc_cog = self.bot.get_cog("PmcCog")
        placeholder = await thread.send(components=self._panel(
            f"{ui_icon('news')} Аналитики изучают новость и досье ЧВК…").components)
        if not AI.available() or not pmc_cog:
            await placeholder.edit(components=self._panel(
                f"### {ui_icon('news')} Новость принята\n-# ИИ-анализ последствий отключён.", WARNING_COLOR).components)
            return
        others = self._mentioned(content, name)
        brief = "\n".join(b for b in (self._brief(n, name) for n in others) if b)
        result = await AI.analyze(content, pmc_cog.dossier(name), brief)
        pm = Pmc().get(name)
        if not result or not pm:
            await placeholder.edit(components=self._panel(
                f"### {ui_icon('news')} Новость принята\n-# Не удалось получить разбор ИИ. Последствия не применены.",
                WARNING_COLOR).components)
            return
        cred = result["credibility"]
        eff = AI.clamp_effects(result["effects"])
        if cred < AI.LOW_CREDIBILITY:
            eff = AI.strip_gains(eff)
        relations = AI.clamp_relations(result["relations"], others)
        if cred < AI.LOW_CREDIBILITY:
            relations = {k: v for k, v in relations.items() if v < 0}
        up, down = ui_icon("up"), ui_icon("down")
        lines = []
        if "money_pct" in eff:
            d = int((pm["money"] or 0) * eff["money_pct"] / 100)
            if d:
                Pmc().add_money(name, d)
                lines.append(f"{ui_icon('money')} Казна ЧВК {up if d >= 0 else down} {'+' if d >= 0 else ''}"
                             f"{int_format(d)} {CURRENCY}")
        if "reputation" in eff:
            d = eff["reputation"]
            Pmc().add_rep(name, d)
            lines.append(f"{ui_icon('reputation')} Репутация ЧВК {up if d >= 0 else down} {'+' if d >= 0 else ''}{d}")
        for other, d in relations.items():
            v = Pmc().add_rel(name, other, d)
            o2 = self.countries.get_object(other)
            lines.append(f"{ui_icon('rel_up' if d > 0 else 'rel_down')} Отношения с {o2.flag if o2 else ''} {other} "
                         f"{'+' if d > 0 else ''}{d} → {v:+.0f}")
        bar = "▰" * round(cred / 10) + "▱" * (10 - round(cred / 10))
        word = "подкреплена" if cred >= 70 else ("преувеличена" if cred >= AI.LOW_CREDIBILITY else "не подкреплена")
        reality = (f"{ui_icon('inspect')} Достоверность {bar} **{cred}** · {word}"
                   + (f"\n-# {result['reality']}" if result["reality"] else ""))
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(f"## {_cat_emoji(result['category'])} {result['headline']}\n{result['analysis'] or '—'}"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(reality),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(f"**Последствия для ЧВК [{pm['tag']}] {name}:**\n"
                                   + ("\n".join(lines) if lines else "-# Заметных последствий нет.")),
            disnake.ui.TextDisplay("-# Разбор ИИ по досье ЧВК из базы игры"),
            accent_colour=disnake.Colour(COMMAND_COLOR if cred >= AI.LOW_CREDIBILITY else WARNING_COLOR)))
        await placeholder.edit(components=p.components)

    def _apply(self, name: str, eff: dict) -> list[str]:
        o = self.countries.get_object(name)
        up, down = ui_icon("up"), ui_icon("down")
        lines: list[str] = []

        if "money_pct" in eff:
            d = int(o.money * eff["money_pct"] / 100)
            if d:
                self.countries.update_object(name, money=d)
            lines.append(f"{ui_icon('money')} Казна {up if d >= 0 else down} "
                         f"{'+' if d >= 0 else ''}{int_format(d)} {CURRENCY}")
        if "happiness" in eff:
            d = eff["happiness"]
            new = _clamp(o.happiness + d, 0, 100)
            self.countries.update_object(name, happiness=float(new))
            lines.append(f"{ui_icon('happy')} Счастье {up if d >= 0 else down} "
                         f"{'+' if d >= 0 else ''}{d} → {new:.0f}")
        if "stability" in eff:
            d = eff["stability"]
            new = _clamp(o.stability + d, 0, 100)
            self.countries.update_object(name, stability=float(new))
            lines.append(f"{ui_icon('stability')} Стабильность {up if d >= 0 else down} "
                         f"{'+' if d >= 0 else ''}{d} → {new:.0f}")
        if "population_pct" in eff:
            d = int(o.population * eff["population_pct"] / 100)
            if d:
                self.countries.update_object(name, population=max(0, o.population + d))
            lines.append(f"{ui_icon('globe')} Население {up if d >= 0 else down} "
                         f"{'+' if d >= 0 else ''}{int_format(d)}")
        if "resources" in eff:
            for res, amt in eff["resources"].items():
                self.settings.add_resource(name, res, amt)
                lines.append(f"{res_icon(res)} {res_label(res)} {'+' if amt >= 0 else ''}{int_format(amt)}")
        if "income_mult" in eff:
            im = eff["income_mult"]
            self.effects.add(name, "income_mult", im["value"], int(time.time()) + im["hours"] * 3600)
            pct = round((im["value"] - 1) * 100)
            lines.append(f"{ui_icon('money')} Доход ×{im['value']} на {im['hours']}ч "
                         f"({'+' if pct >= 0 else ''}{pct}%)")
        if "reputation" in eff:
            d = eff["reputation"]
            Diplomacy().add_reputation(name, d)
            lines.append(f"{ui_icon('reputation')} Репутация {up if d >= 0 else down} {'+' if d >= 0 else ''}{d}")
        return lines

    # ───── предупреждения и авто-снятие по простою ─────
    @tasks.loop(hours=1)
    async def inactivity_tick(self):
        now = int(time.time())
        limit = NEWS_INACTIVITY_DAYS * 86400
        guild = self.bot.get_guild(GUILD_ID)
        cd = Cooldown()
        for name in list(self.countries.get_object_names()):
            last = self.news.last_ts(name)
            if last is None:
                self.news.touch(name, now, log=False)  # базовая отметка (отсчёт пошёл)
                continue
            idle = now - last
            if idle > limit:
                await self._auto_remove(name, guild)
            elif idle >= WARN_EVERY and cd.get_cooldown("news_warn", name) <= now:
                # каждые 12 часов молчания — напоминание, сколько осталось до снятия
                cd.set_cooldown("news_warn", now + WARN_EVERY, name)
                await self._warn(name, idle, limit - idle, guild)
        # ЧВК — то же правило простоя
        pmc_cog = self.bot.get_cog("PmcCog")
        for pm in (Pmc().all() if pmc_cog else []):
            name = pm["name"]
            last = self.news.last_ts(name)
            if last is None:
                self.news.touch(name, now, log=False)
                continue
            idle = now - last
            if idle > limit:
                await pmc_cog._disband(pm["user"], guild, reason="нет новостей")
                self.news.clear_country(name)
                ch = self.bot.get_channel(rid("CH_NEWS", WORLD_NEWS_CHANNEL))
                if ch:
                    try:
                        await ch.send(embed=disnake.Embed(
                            title="ЧВК распущена",
                            description=f"ЧВК **[{pm['tag']}] {name}** не публиковала новости {NEWS_INACTIVITY_DAYS} "
                                        f"дня — компания распущена автоматически. <@{pm['user']}>",
                            color=WARNING_COLOR))
                    except disnake.HTTPException:
                        pass
            elif idle >= WARN_EVERY and cd.get_cooldown("news_warn", name) <= now:
                cd.set_cooldown("news_warn", now + WARN_EVERY, name)
                await pmc_cog._dm_user(pm["user"], (
                    f"{ui_icon('exposed')} **ЧВК [{pm['tag']}] {name}: нет мировых новостей {idle // 3600} ч.**\n"
                    f"Если не опубликовать новость, ЧВК будет **распущена через ~{max(1, (limit - idle) // 3600)} ч**.\n"
                    f"-# Новость: от {NEWS_MIN_CHARS} символов и картинка, в канале мировых новостей."))

    async def _warn(self, name: str, idle: int, left: int, guild):
        o = self.countries.get_object(name)
        if not o or not o.user:
            return
        hours_idle, hours_left = idle // 3600, max(1, left // 3600)
        text = (f"{ui_icon('exposed')} **{o.flag} {name}: нет мировых новостей {hours_idle} ч.**\n"
                f"Если не опубликовать новость, страна будет **снята с игры через ~{hours_left} ч** — "
                f"со всеми данными.\n-# Новость: от {NEWS_MIN_CHARS} символов и картинка, в канале мировых новостей.")
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(text), accent_colour=disnake.Colour(WARNING_COLOR)))
        user = self.bot.get_user(o.user)
        try:
            user = user or await self.bot.fetch_user(o.user)
            await user.send(components=p.components)
            return
        except Exception:
            pass
        ch = self.bot.get_channel(rid("CH_NEWS", WORLD_NEWS_CHANNEL))   # ЛС закрыты — напомним в канале
        if ch:
            try:
                await ch.send(content=f"<@{o.user}>", components=p.components, delete_after=12 * 3600)
            except Exception:
                pass

    @inactivity_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    async def _auto_remove(self, name: str, guild):
        o = self.countries.get_object(name)
        if not o:
            self.news.clear_country(name)
            return
        uid = o.user
        # ПОЛНАЯ очистка — как у !unregister: страна, армия, ресурсы, развитие, политика, договоры, блоки,
        # атом, ООН, наследие, захваченные области на карте (иначе данные «висели» бы в базе)
        from cogs.registration import _purge_country, _clear_country_nick
        _purge_country(name)
        self.news.clear_country(name)
        pr = rid("PROFILE_ROLE", PROFILE_ROLE)
        if guild and uid:
            m = guild.get_member(uid)
            role = guild.get_role(pr) if pr else None
            reg_role = guild.get_role(rid("ROLE_REGISTERING", 0)) if rid("ROLE_REGISTERING", 0) else None
            if m:
                try:
                    if role and role in m.roles:
                        await m.remove_roles(role)
                    if reg_role and reg_role not in m.roles:
                        await m.add_roles(reg_role)  # вернуть на регистрацию
                except disnake.HTTPException:
                    pass
                await _clear_country_nick(m)        # ник «флаг Страна · строй» больше не актуален
        self.bot.dispatch("map_dirty")
        ch = self.bot.get_channel(rid("CH_NEWS", WORLD_NEWS_CHANNEL))
        if ch:
            try:
                await ch.send(embed=disnake.Embed(
                    title="Страна снята с игры",
                    description=(f"{o.flag} **{o.name}** не публиковала новости "
                                 f"{NEWS_INACTIVITY_DAYS} дня — регистрация снята автоматически."
                                 + (f" <@{uid}>" if uid else "")),
                    color=WARNING_COLOR))
            except disnake.HTTPException:
                pass
        log.info("Авто-снятие по простою: %s", name)


def setup(bot: commands.Bot):
    bot.add_cog(NewsCog(bot))
