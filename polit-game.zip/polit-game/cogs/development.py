"""
Ког развития (прокачка веток) — панель «Развитие».

  !develop / !развитие — хаб: доход + категории (кнопки)
  категория → список веток с уровнями/ценой → выбор ветки → улучшение

Уровни хранятся в БД (CountryUpgrades), без ролей. Улучшение стоит деньги +
ресурсы, учитывает синергии/требования/скидку образования (utils/upgrades).
"""

import disnake
from disnake.ext import commands

from utils import (
    CountryUpgrades, Settings, get_object_by_user, update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY,
    ADMINISTRATOR, MAIN_ECO_CURATOR, PROFILE_ROLE,
)
from utils.ui import Panel, cid, parse_cid
from utils.serverconfig import rid
from utils.perms import is_staff
from utils.resources import res_icon, res_label, ui_icon
import utils.upgrades as U


def _emoji(s: str):
    try:
        return disnake.PartialEmoji.from_str(s)
    except Exception:
        return None


def _bar(lvl: int, total: int = U.MAX_LEVEL) -> str:
    lvl = max(0, min(total, lvl))
    return "▰" * lvl + "▱" * (total - lvl)


def _cost_text(money: int, res: dict) -> str:
    parts = [f"{int_format(money)} {CURRENCY}"]
    parts += [f"{int_format(q)} {res_icon(r)}" for r, q in res.items()]
    return " + ".join(parts)


def _cost_text_plain(money: int, res: dict) -> str:
    """Без кастом-иконок — для описаний пунктов селекта (там эмодзи не рендерятся)."""
    parts = [f"{int_format(money)} {CURRENCY}"]
    parts += [f"{int_format(q)} {res_label(r)}" for r, q in res.items()]
    return " + ".join(parts)


class DevelopHub(Panel):
    def __init__(self, obj, levels: dict, avatar_url: str | None = None):
        super().__init__(timeout=300)
        total = U.total_income(levels)
        header = (f"-# {getattr(obj, 'flag', '')} {obj.name}\n"
                  f"## {ui_icon('upgrade')} Развитие\n"
                  f"-# доход **~{int_format(total)} {CURRENCY}/ч** · "
                  f"ВВП **~{int_format(U.country_gdp(obj.name))} {CURRENCY}** (растёт с ветками)")
        if avatar_url:
            items: list = [disnake.ui.Section(disnake.ui.TextDisplay(header),
                                              accessory=disnake.ui.Thumbnail(avatar_url))]
        else:
            items = [disnake.ui.TextDisplay(header)]

        lines = []
        for ckey, (clabel, _cemoji) in U.CATEGORIES.items():
            br = U.branches_in(ckey)
            dev = sum(1 for b in br if levels.get(b, 0) > 0)
            lines.append(f"{U.cat_icon(ckey)} **{clabel}** · {dev}/{len(br)} веток")
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay("-# КАТЕГОРИИ\n" + "\n".join(lines)))

        oid = obj.user
        row = [disnake.ui.Button(label=clabel, emoji=_emoji(U.cat_icon(ckey)), style=disnake.ButtonStyle.primary,
                                 custom_id=cid("dev", "cat", ckey, oid))
               for ckey, (clabel, _cemoji) in U.CATEGORIES.items()]
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(*row))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


class CategoryPanel(Panel):
    def __init__(self, obj, category: str, levels: dict):
        super().__init__(timeout=300)
        clabel, _cemoji = U.CATEGORIES[category]
        items = [disnake.ui.TextDisplay(f"-# {obj.name}\n## {U.cat_icon(category)} {clabel}")]
        items.append(disnake.ui.Separator())

        options = []
        lines = []
        for key in U.branches_in(category):
            b = U.BRANCHES[key]
            lvl = levels.get(key, 0)
            inc = U.branch_income(levels, key)
            ok, missing = U.requirements_met(levels, key)
            cost = U.next_cost(levels, key)
            tail = ""
            if lvl >= U.MAX_LEVEL:
                tail = "· **MAX**"
            elif not ok:
                tail = f"· 🔒 нужно: {', '.join(missing)}"
            elif cost:
                tail = f"· след. {_cost_text(cost[0], cost[1])}"
            lines.append(f"{_bar(lvl)} **{b['label']}** `{lvl}/{U.MAX_LEVEL}`  `+{int_format(inc)}/ч`\n-# {tail}")
            if lvl < U.MAX_LEVEL and ok:
                options.append(disnake.SelectOption(
                    label=f"{b['label']} → ур.{lvl + 1}"[:100], value=key,
                    description=(_cost_text_plain(cost[0], cost[1]) if cost else "")[:100]))
        items.append(disnake.ui.TextDisplay("\n\n".join(lines)))
        if options:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("dev", "up", obj.user), placeholder="Улучшить ветку", options=options[:25])))
        self.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(COMMAND_COLOR)))


class DevelopmentCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.upg = CountryUpgrades()
        self.settings = Settings()

    async def cog_check(self, ctx: commands.Context) -> bool:
        if not ctx.guild:
            return False
        if is_staff(ctx.author):
            return True
        if MAIN_ECO_CURATOR and ctx.guild.get_role(MAIN_ECO_CURATOR) in ctx.author.roles:
            return True
        if ctx.author.get_role(rid("PROFILE_ROLE", PROFILE_ROLE)):
            return True
        if get_object_by_user(ctx.author.id):
            return True
        await ctx.send(embed=disnake.Embed(description="Вы не зарегистрированы.", color=ERROR_COLOR))
        return False

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CheckFailure):
            return
        raise error

    def _do_upgrade(self, obj, key: str) -> disnake.Embed:
        levels = self.upg.get_levels(obj.name)
        if key not in U.BRANCHES:
            return disnake.Embed(description="Нет такой ветки.", color=ERROR_COLOR)
        lvl = levels.get(key, 0)
        if lvl >= U.MAX_LEVEL:
            return disnake.Embed(description=f"**{U.BRANCHES[key]['label']}** уже максимального уровня.", color=WARNING_COLOR)
        ok, missing = U.requirements_met(levels, key)
        if not ok:
            return disnake.Embed(description=f"Требуется: {', '.join(missing)}", color=ERROR_COLOR)
        cost = U.next_cost(levels, key)
        money, res = cost
        fresh = get_object_by_user(obj.user)
        have = self.settings.get_resources(obj.name)
        if not fresh or fresh.money < money:
            return disnake.Embed(description=f"Недостаточно денег. Нужно {int_format(money)} {CURRENCY}.", color=ERROR_COLOR)
        lack = [f"{res_icon(r)} {res_label(r)} — нужно {int_format(q)}, есть {int_format(have.get(r, 0))}"
                for r, q in res.items() if have.get(r, 0) < q]
        if lack:
            return disnake.Embed(title="Недостаточно ресурсов", description="\n".join(lack), color=ERROR_COLOR)

        update_money(obj.name, -money)
        for r, q in res.items():
            self.settings.add_resource(obj.name, r, -q)
        self.upg.set_level(obj.name, key, lvl + 1)

        b = U.BRANCHES[key]
        new_inc = b["levels"][lvl]["income"]
        return disnake.Embed(
            title=f"⬆️ {b['label']} → ур.{lvl + 1}",
            description=f"Доход ветки: **+{int_format(new_inc)} {CURRENCY}/ч**\n-# потрачено: {_cost_text(money, res)}",
            color=SUCCESS_COLOR)

    @commands.command(name="develop", aliases=["развитие", "dev", "разв"])
    async def develop_cmd(self, ctx):
        obj = get_object_by_user(ctx.author.id)
        if not obj:
            await ctx.send(embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR))
            return
        hub = DevelopHub(obj, self.upg.get_levels(obj.name), ctx.author.display_avatar.url)
        await ctx.send(components=hub.components)

    @commands.Cog.listener()
    async def on_button_click(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("dev:"):
            return
        _, action, args = parse_cid(c)
        owner = int(args[-1]) if args and args[-1].isdigit() else None
        if owner and inter.author.id != owner:
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            await inter.response.send_message(embed=disnake.Embed(description="У вас нет страны — откройте панель регистрации.", color=ERROR_COLOR), ephemeral=True)
            return
        if action == "cat":
            await inter.response.send_message(
                components=CategoryPanel(obj, args[0], self.upg.get_levels(obj.name)).components, ephemeral=True)

    @commands.Cog.listener()
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("dev:"):
            return
        _, action, args = parse_cid(c)
        owner = int(args[-1]) if args and args[-1].isdigit() else None
        if owner and inter.author.id != owner:
            await inter.response.send_message("Это не ваша панель.", ephemeral=True)
            return
        obj = get_object_by_user(inter.author.id)
        if not obj:
            return
        if action == "up":
            await inter.response.send_message(embed=self._do_upgrade(obj, inter.values[0]), ephemeral=True)


def setup(bot: commands.Bot):
    bot.add_cog(DevelopmentCog(bot))
