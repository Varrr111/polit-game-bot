"""
🕊️ ООН НА ИИ — !оон / !un

КАНАЛЫ (категория «🕊️ ООН» в !setupserver):
  • CH_UN_NEWS — новости ООН: принятые/отклонённые резолюции, заявления Генсека,
    вердикты по ядерным испытаниям (пишет только бот).
  • CH_UN_RES  — резолюции на голосовании: карточка с кнопками За/Против/Воздержаться.
  • CH_UN_SC   — чат Совбеза: доступ бот выдаёт поштучно текущим членам СБ (без ролей).
  • CH_UN_GA   — чат Генассамблеи для всех стран.

ПРОЦЕСС: страна вносит проект (!оон, ЛС) → ИИ-секретариат проверяет допустимость по
мировому журналу, пишет официальный текст, ставит тяжесть и позицию мирового
сообщества/незанятых постоянных членов СБ → голосование 24ч (ГА — необязательные,
СБ с вето P5 — обязательные) → бот применяет эффект в жёстких потолках.
ИИ-НАБЛЮДАТЕЛЬ раз в 6ч читает журнал и сам выносит вопросы (вызов ИИ — только при
серьёзных событиях). ИИ-СУДЬЯ ядерных испытаний: вердикт вступает через час, штаб
может наложить вето. Без ключа ИИ всё работает по правилам, испытания решает штаб.
Только кастом-иконки; текст ИИ очищается от эмодзи (utils.un.clean).
"""

import asyncio
import json
import logging
import random
import time

import disnake
from disnake.ext import commands, tasks

from utils import (
    Countries, Diplomacy, War, Effects, Un, Nuclear, Cooldown, Pmc,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
from utils.perms import is_staff
import utils.un as U

log = logging.getLogger("un")

_DAY = 86400
_PAGE = 25
VOTE_WORD = {"yes": "за", "no": "против", "abstain": "воздержался"}
VOTE_ICON = {"yes": "accept", "no": "reject", "abstain": "abstain"}


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


class _Dummy:
    flag = "🏳️"
    user = 0
    stability = 50.0
    happiness = 50.0


class UNCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.dip = Diplomacy()
        self.war = War()
        self.effects = Effects()
        self.un = Un()
        self.nuc = Nuclear()
        self.cooldown = Cooldown()
        self._sessions: dict[int, dict] = {}
        self._last_watch = 0
        self.un_tick.start()

    def cog_unload(self):
        self.un_tick.cancel()

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "kind": None, "target": None, "page": 0}
            self._sessions[uid] = s
        return s

    def _actor(self, uid: int):
        return self.countries.get_object_by_user(uid)

    def _obj(self, name: str):
        return self.countries.get_object(name) or _Dummy()

    # ═══════════════ ЖУРНАЛ (вызывают другие механики) ═══════════════
    def log(self, kind: str, actor: str, target: str, text: str, war_id: int = 0):
        try:
            self.un.log(kind, actor, target, text, int(time.time()), war_id)
        except Exception:
            log.exception("журнал ООН")

    # ═══════════════ ОРГАНЫ ═══════════════
    def _power(self, name: str) -> float:
        ult = self.bot.get_cog("UltimatumCog")
        try:
            return ult._power(name) if ult else 0.0
        except Exception:
            return 0.0

    def security_council(self) -> list[str]:
        """Члены СБ-игроки: зарегистрированные P5 + до 10 сильнейших остальных."""
        names = self.countries.get_object_names()
        p5 = [c for c in U.P5 if c in names]
        rest = sorted((n for n in names if n not in U.P5), key=lambda n: -self._power(n))[:U.SC_ELECTED]
        return p5 + rest

    def npc_p5(self) -> list[str]:
        names = set(self.countries.get_object_names())
        return [c for c in U.P5 if c not in names]

    # ═══════════════ КАНАЛЫ ═══════════════
    def _ch(self, key: str):
        ch_id = rid(key, 0)
        if not ch_id:
            return None
        g = self.bot.get_guild(GUILD_ID)
        return (g.get_channel(ch_id) if g else None) or self.bot.get_channel(ch_id)

    async def news(self, text: str, color=COMMAND_COLOR):
        """Новости ООН (только бот)."""
        ch = self._ch("CH_UN_NEWS") or self._ch("CH_DIPLO")
        if not ch:
            return
        try:
            p = Panel(timeout=None)
            p.add_item(disnake.ui.Container(disnake.ui.TextDisplay(text), accent_colour=disnake.Colour(color)))
            await ch.send(components=p.components)
        except Exception:
            log.exception("новости ООН")

    async def _dm(self, country: str, text: str = None, components=None):
        o = self.countries.get_object(country)
        if not o or not getattr(o, "user", 0):
            return
        user = self.bot.get_user(o.user)
        if user is None:
            try:
                user = await self.bot.fetch_user(o.user)
            except Exception:
                return
        try:
            await user.send(components=components) if components is not None else await user.send(text)
        except Exception:
            pass

    async def sync_sc_channel(self):
        """Чат Совбеза: доступ ровно у членов СБ (поштучные права участникам, без ролей)."""
        ch = self._ch("CH_UN_SC")
        if not ch:
            return
        want = set()
        for c in self.security_council():
            o = self.countries.get_object(c)
            if o and o.user:
                want.add(o.user)
        try:
            for target, ow in list(ch.overwrites.items()):
                if isinstance(target, disnake.Member) and target.id not in want and not is_staff(target):
                    await ch.set_permissions(target, overwrite=None, reason="ООН: состав Совбеза")
            for uid in want:
                m = ch.guild.get_member(uid)
                if m and not ch.permissions_for(m).send_messages:
                    await ch.set_permissions(m, view_channel=True, send_messages=True, read_message_history=True,
                                             reason="ООН: член Совбеза")
        except Exception:
            log.exception("права чата Совбеза")

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('un')} Организация Объединённых Наций")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _back(self):
        return disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="⟵ В хаб", custom_id=cid("un", "goto", "hub"))

    def _render(self, uid: int, note=None) -> Panel:
        s = self._session(uid)
        actor = self._actor(uid)
        if not actor:
            return self._container(self._head(note) + [disnake.ui.TextDisplay(
                "-# У вас нет страны. Откройте панель регистрации, чтобы играть.")], WARNING_COLOR)
        if s["view"] == "propose":
            return self._panel_propose(uid, actor, note)
        return self._panel_hub(uid, actor, note)

    def _panel_hub(self, uid, actor, note=None):
        me = actor.name
        sc = self.security_council()
        items = self._head(note)
        seat = ("постоянный член Совбеза (право вето)" if me in U.P5 else
                "избранный член Совбеза" if me in sc else "член Генассамблеи")
        items.append(disnake.ui.TextDisplay(
            f"### {actor.flag} {me}\n{ui_icon('un_sc' if me in sc else 'ga')} Ваш статус: **{seat}**\n"
            f"-# Совбез: {', '.join(f'{self._obj(c).flag} {c}' for c in sc) or 'нет игроков'}"
            + (f" · за незанятых постоянных членов ({', '.join(self.npc_p5())}) голосует ИИ" if self.npc_p5() else "")))
        lines = []
        for r in self.un.voting()[:8]:
            mine = self.un.votes(r["id"]).get(me)
            mark = f"{ui_icon(VOTE_ICON[mine])} вы: {VOTE_WORD[mine]}" if mine else "ждёт вашего голоса"
            body = "СБ" if r["body"] == "sc" else "ГА"
            lines.append(f"{ui_icon(U.TYPES[r['kind']]['icon'])} **№{r['id']} {r['title']}** · {body} · "
                         f"до <t:{r['deadline']}:R> · {mark}")
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"{ui_icon('resolution')} **На голосовании**\n"
                                            + ("\n".join(lines) if lines else "-# Повестка пуста.")))
        hist = [f"{ui_icon('accept' if r['status'] == 'adopted' else 'reject')} №{r['id']} {r['title']}"
                for r in self.un.recent(5)]
        if hist:
            items.append(disnake.ui.TextDisplay("-# НЕДАВНИЕ РЕШЕНИЯ\n" + "\n".join(hist)))
        cd = int(self.cooldown.get_cooldown("un_propose", me) - time.time())
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, emoji=_pe("resolution"),
                              label=(f"Внести проект · {U.PROPOSE_COST_INF} дипкапитала" if cd <= 0
                                     else f"Новый проект через {cd // 3600}ч {cd % 3600 // 60}м"),
                              disabled=cd > 0, custom_id=cid("un", "goto", "propose")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Обновить", emoji=_pe("reload"),
                              custom_id=cid("un", "goto", "hub"))))
        items.append(disnake.ui.TextDisplay("-# Голосуйте кнопками на карточках в канале резолюций ООН."))
        return self._container(items)

    def _targets(self, kind: str) -> list[tuple[str, str, str]]:
        if U.TYPES[kind]["needs"] == "war":
            return [(str(w["id"]), f"Война №{w['id']}: {w['attacker']} — {w['defender']}", w["casus"] or "")
                    for w in self.war.all_active()]
        if U.TYPES[kind]["needs"] == "pmc":
            return [(p["name"], f"ЧВК [{p['tag']}] {p['name']}", f"база {p['base']}") for p in Pmc().all()]
        return [(n, f"{self._obj(n).flag} {n}", "") for n in sorted(self.countries.get_object_names())]

    def _panel_propose(self, uid, actor, note=None):
        s = self._session(uid)
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('resolution')} Проект резолюции\n-# Секретариат (ИИ) проверит проект по фактам мирового "
            f"журнала: голословный проект будет признан недопустимым (вернётся {int(U.REJECT_REFUND * 100)}% дипкапитала)."))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("un", "kind"), placeholder="Тип резолюции…",
            options=[disnake.SelectOption(
                label=f"{m['label']} · {'Совбез' if m['body'] == 'sc' else 'Генассамблея'}", value=k,
                emoji=_pe(m["icon"]), description=m["desc"][:100], default=(k == s["kind"]))
                for k, m in U.TYPES.items()])))
        if s["kind"]:
            opts = self._targets(s["kind"])
            pages = max(1, (len(opts) + _PAGE - 1) // _PAGE)
            s["page"] = max(0, min(s["page"], pages - 1))
            page = opts[s["page"] * _PAGE:(s["page"] + 1) * _PAGE]
            if page:
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("un", "target"), placeholder="Цель…",
                    options=[disnake.SelectOption(label=l[:100], value=v, description=(d or None) and d[:100],
                                                  default=(v == s["target"])) for v, l, d in page])))
            else:
                items.append(disnake.ui.TextDisplay("-# Подходящих целей нет."))
            row = [disnake.ui.Button(style=disnake.ButtonStyle.success, emoji=_pe("resolution"),
                                     label="Обосновать и внести", disabled=not s["target"],
                                     custom_id=cid("un", "write"))]
            if pages > 1:
                row.append(disnake.ui.Button(style=disnake.ButtonStyle.primary, emoji=_pe("prev"),
                                             disabled=s["page"] == 0, custom_id=cid("un", "page", "prev")))
                row.append(disnake.ui.Button(style=disnake.ButtonStyle.primary, emoji=_pe("next"),
                                             disabled=s["page"] >= pages - 1, custom_id=cid("un", "page", "next")))
            row.append(self._back())
            items.append(disnake.ui.ActionRow(*row))
        else:
            items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # — карточка резолюции (канал резолюций) —
    def _tally(self, r) -> tuple[str, dict]:
        votes = self.un.votes(r["id"])
        if r["body"] == "sc":
            members = json.loads(r["sc"] or "[]")
            allv = dict(json.loads(r["p5"] or "{}"))
            allv.update({c: v for c, v in votes.items() if c in members})
            seats = members + [c for c in allv if c not in members]
            parts = []
            for c in seats:
                v = allv.get(c)
                tag = " (ИИ)" if c not in members else ""
                mark = f"{ui_icon(VOTE_ICON[v])} {VOTE_WORD[v]}" if v else "—"
                parts.append(f"{'**' if c in U.P5 else ''}{c}{'**' if c in U.P5 else ''}{tag}: {mark}")
            return "\n".join(parts), {"votes": allv, "members": seats}
        yes = sum(1 for v in votes.values() if v == "yes")
        no = sum(1 for v in votes.values() if v == "no")
        ab = sum(1 for v in votes.values() if v == "abstain")
        players = len(self.countries.get_object_names())
        _ok, y, n = U.ga_outcome(yes, no, r["npc_support"], players)
        return (f"{ui_icon('accept')} За: **{yes}** · {ui_icon('reject')} Против: **{no}** · "
                f"{ui_icon('abstain')} Возд.: **{ab}**\n-# С учётом мирового сообщества (ИИ): за {y} · против {n}",
                {"yes": yes, "no": no})

    def _card(self, r, closed_note: str | None = None) -> Panel:
        meta = U.TYPES[r["kind"]]
        body = "Совет Безопасности (обязательная, вето P5)" if r["body"] == "sc" else "Генеральная Ассамблея"
        tally, _ = self._tally(r)
        who = (f"{ui_icon('secgen')} Внесено Генеральным секретарём" if r["proposer"] == U.SG else
               f"Внесла: {self._obj(r['proposer']).flag} **{r['proposer']}**")
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon(meta['icon'])} Резолюция №{r['id']} · {r['title']}\n"
            f"-# {meta['label']} · {body} · тяжесть {r['severity']}/3\n{r['text']}\n{who}")]
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(tally))
        if closed_note:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(closed_note))
        elif r["status"] == "voting":
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="За", emoji=_pe("accept"),
                                  custom_id=cid("un", "vote", r["id"], "yes")),
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Против", emoji=_pe("reject"),
                                  custom_id=cid("un", "vote", r["id"], "no")),
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Воздержаться", emoji=_pe("abstain"),
                                  custom_id=cid("un", "vote", r["id"], "abstain"))))
            items.append(disnake.ui.TextDisplay(
                f"-# Голосование до <t:{r['deadline']}:R>. "
                + ("Голосуют только члены Совбеза." if r["body"] == "sc" else "Голосуют все страны.")))
        color = (SUCCESS_COLOR if r["status"] == "adopted" else ERROR_COLOR if r["status"] == "rejected"
                 else COMMAND_COLOR)
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    async def _refresh_card(self, r, closed_note: str | None = None):
        if not r["channel_id"] or not r["msg_id"]:
            return
        ch = self.bot.get_channel(r["channel_id"])
        if not ch:
            return
        try:
            msg = await ch.fetch_message(r["msg_id"])
            await msg.edit(components=self._card(r, closed_note).components)
        except Exception:
            pass

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _un_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("un:"):
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        v = inter.values[0] if inter.values else None
        if action == "kind":
            s.update(kind=v, target=None, page=0)
        elif action == "target":
            s["target"] = v
        await inter.edit_original_message(components=self._render(inter.author.id).components)

    @commands.Cog.listener("on_button_click")
    async def _un_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("un:"):
            return
        _, action, args = parse_cid(c)
        if action == "vote":
            await self._on_vote(inter, args)
            return
        if action == "tveto":
            await self._on_test_veto(inter, args)
            return
        if action == "write":
            s = self._session(inter.author.id)
            if not s["kind"] or not s["target"]:
                await inter.response.send_message("Выберите тип и цель.", ephemeral=True)
                return
            await inter.response.send_modal(disnake.ui.Modal(
                title=f"Проект: {U.type_label(s['kind'])}"[:45], custom_id=cid("un", "mjust"),
                components=[disnake.ui.TextInput(
                    label="Обоснование (факты)", custom_id="text", style=disnake.TextInputStyle.paragraph,
                    min_length=U.MIN_JUSTIFY, max_length=800,
                    placeholder="Что произошло, почему ООН должна вмешаться")]))
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        if action == "goto":
            s.update(view=args[0] if args else "hub")
            if s["view"] == "hub":
                s.update(kind=None, target=None, page=0)
        elif action == "page":
            s["page"] += 1 if args and args[0] == "next" else -1
        await inter.edit_original_message(components=self._render(inter.author.id).components)

    @commands.Cog.listener("on_modal_submit")
    async def _un_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("un:mjust"):
            return
        actor = self._actor(inter.author.id)
        s = self._session(inter.author.id)
        if not actor:
            await inter.response.send_message("У вас нет страны.", ephemeral=True)
            return
        await inter.response.defer()
        note = await self.propose(actor.name, s["kind"], s["target"], inter.text_values.get("text", ""))
        s.update(view="hub", kind=None, target=None, page=0)
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    async def _on_vote(self, inter, args):
        actor = self._actor(inter.author.id)
        if not actor or len(args) < 2 or not args[0].isdigit() or args[1] not in VOTE_WORD:
            await inter.response.send_message("Голосуют только страны.", ephemeral=True)
            return
        r = self.un.get(int(args[0]))
        if not r or r["status"] != "voting":
            await inter.response.send_message("Голосование закрыто.", ephemeral=True)
            return
        if r["body"] == "sc" and actor.name not in json.loads(r["sc"] or "[]"):
            await inter.response.send_message("Эту резолюцию решает Совет Безопасности — вы не его член.",
                                              ephemeral=True)
            return
        self.un.cast(r["id"], actor.name, args[1])
        await inter.response.send_message(
            f"{ui_icon(VOTE_ICON[args[1]])} Ваш голос по резолюции №{r['id']}: **{VOTE_WORD[args[1]]}**.",
            ephemeral=True)
        await self._refresh_card(self.un.get(r["id"]))
        if self._all_voted(r):
            await self.finish(r["id"])

    def _all_voted(self, r) -> bool:
        votes = self.un.votes(r["id"])
        if r["body"] == "sc":
            return all(c in votes for c in json.loads(r["sc"] or "[]"))
        return all(n in votes for n in self.countries.get_object_names())

    # ═══════════════ ВНЕСЕНИЕ ═══════════════
    def _facts(self, *countries: str) -> str:
        since = int(time.time()) - 14 * _DAY
        rows, seen = [], set()
        for c in countries:
            for r in self.un.facts_about(c, since):
                if r["id"] not in seen:
                    seen.add(r["id"])
                    rows.append(r)
        rows.sort(key=lambda r: r["ts"])
        return "\n".join(f"- {r['text']}" for r in rows[-15:])

    def _ctx(self, *countries: str) -> str:
        dip = self.bot.get_cog("DiplomacyCog")
        out = []
        for c in countries:
            if not c or not self.countries.get_object(c):
                continue
            try:
                out.append(f"[{c}] " + (dip.diplo_context(c) if dip else "").replace("\n", " ")[:500])
            except Exception:
                out.append(f"[{c}]")
        return "\n".join(out)

    async def propose(self, proposer: str, kind: str, target_val: str, justification: str) -> str:
        """Внесение проекта (игрок или Генсек). → строка итога."""
        now = int(time.time())
        if kind not in U.TYPES or not target_val:
            return f"{ui_icon('reject')} Выберите тип и цель."
        meta = U.TYPES[kind]
        war_id, target = 0, target_val
        if meta["needs"] == "war":
            w = self.war.get_war(int(target_val)) if str(target_val).isdigit() else None
            if not w or w["status"] != "active":
                return f"{ui_icon('reject')} Война уже окончена."
            war_id, target = w["id"], w["attacker"]
        elif meta["needs"] == "pmc":
            if not Pmc().get(target):
                return f"{ui_icon('reject')} ЧВК не найдена."
        elif not self.countries.get_object(target):
            return f"{ui_icon('reject')} Страна не найдена."
        if self.un.open_like(kind, target):
            return f"{ui_icon('reject')} Такая резолюция уже на голосовании."
        is_sg = proposer == U.SG
        if not is_sg:
            if len((justification or "").strip()) < U.MIN_JUSTIFY:
                return f"{ui_icon('reject')} Обоснование слишком короткое."
            if self.cooldown.get_cooldown("un_propose", proposer) > now:
                return f"{ui_icon('reject')} Вы недавно вносили проект."
            inf, _rep = self.dip.get_state(proposer)
            if inf < U.PROPOSE_COST_INF:
                return f"{ui_icon('reject')} Нужно {U.PROPOSE_COST_INF} дипкапитала."
            self.dip.add_influence(proposer, -U.PROPOSE_COST_INF)
            self.cooldown.set_cooldown("un_propose", now + U.PROPOSE_CD, proposer)
        parties = [target] + ([] if is_sg else [proposer])
        if meta["needs"] == "pmc":   # досье ЧВК для секретариата (у ЧВК нет дипломатии страны)
            pc = self.bot.get_cog("PmcCog")
            justification = (justification or "") + (f"\n[Досье ЧВК] {pc.dossier(target)}" if pc else "")
        if war_id:
            w = self.war.get_war(war_id)
            parties = [w["attacker"], w["defender"]]
        sec = await U.secretariat(kind, proposer, target, justification, self._facts(*parties),
                                  self._ctx(*parties), self.npc_p5() if meta["body"] == "sc" else [])
        if not sec["admissible"]:
            if not is_sg:
                self.dip.add_influence(proposer, U.PROPOSE_COST_INF * U.REJECT_REFUND)
            rid_ = self.un.create(kind=kind, proposer=proposer, target=target, war_id=war_id, title=sec["title"],
                                  text=sec["text"], body=meta["body"], status="inadmissible", reason=sec["reason"],
                                  created_at=now, deadline=now)
            return (f"{ui_icon('reject')} Секретариат признал проект недопустимым: {sec['reason'] or 'нет оснований в фактах'}. "
                    f"Возвращено {int(U.REJECT_REFUND * 100)}% дипкапитала.")
        sc = self.security_council() if meta["body"] == "sc" else []
        rid_ = self.un.create(kind=kind, proposer=proposer, target=target, war_id=war_id, title=sec["title"],
                              text=sec["text"], severity=sec["severity"], npc_support=sec["npc_support"],
                              p5=json.dumps(sec["p5"], ensure_ascii=False), body=meta["body"], status="voting",
                              created_at=now, deadline=now + U.VOTE_TTL, sc=json.dumps(sc, ensure_ascii=False))
        r = self.un.get(rid_)
        ch = self._ch("CH_UN_RES") or self._ch("CH_DIPLO")
        if ch:
            try:
                msg = await ch.send(components=self._card(r).components)
                self.un.update(rid_, channel_id=ch.id, msg_id=msg.id)
            except Exception:
                log.exception("карточка резолюции")
        await self.news(f"{ui_icon('resolution')} **На голосование вынесена резолюция №{rid_}:** {sec['title']}\n"
                        f"-# {meta['label']} · {'Совет Безопасности' if meta['body'] == 'sc' else 'Генассамблея'} · "
                        f"голосование 24ч в канале резолюций.")
        if meta["body"] == "sc":
            await self.sync_sc_channel()
            for c in sc:
                if c != proposer:
                    await self._dm(c, text=f"{ui_icon('un_sc')} Совбез ООН: резолюция №{rid_} «{sec['title']}» ждёт "
                                           f"вашего голоса (канал резолюций ООН).")
        return f"{ui_icon('resolution')} Резолюция №{rid_} «{sec['title']}» вынесена на голосование."

    # ═══════════════ ИТОГ ═══════════════
    async def finish(self, rid_: int):
        r = self.un.get(rid_)
        if not r or r["status"] != "voting":
            return
        votes = self.un.votes(rid_)
        if r["body"] == "sc":
            _t, data = self._tally(r)
            ok, why = U.sc_outcome(data["votes"], data["members"])
        else:
            yes = sum(1 for v in votes.values() if v == "yes")
            no = sum(1 for v in votes.values() if v == "no")
            ok, y, n = U.ga_outcome(yes, no, r["npc_support"], len(self.countries.get_object_names()))
            why = f"за {y} · против {n}"
        self.un.update(rid_, status="adopted" if ok else "rejected", reason=why)
        r = self.un.get(rid_)
        effect = ""
        if ok and r["kind"] == "pmc_sanctions":
            pc = self.bot.get_cog("PmcCog")
            effect = await pc.un_sanction(r["target"], U.sev_pick("pmc_sanctions", "hours", r["severity"])) if pc else ""
        elif ok:
            effect = self._apply(r, votes)
        head = (f"{ui_icon('accept')} **Резолюция №{rid_} ПРИНЯТА** ({why})." if ok else
                f"{ui_icon('veto' if 'вето' in why else 'reject')} **Резолюция №{rid_} отклонена** ({why}).")
        await self._refresh_card(r, head + (f"\n{effect}" if effect else ""))
        await self.news(f"{head}\n**{r['title']}**" + (f"\n{effect}" if effect else ""),
                        SUCCESS_COLOR if ok else WARNING_COLOR)
        if r["target"] and r["kind"] != "pmc_sanctions":   # ЧВК уведомляет PmcCog.un_sanction
            await self._dm(r["target"], text=f"{ui_icon('un')} ООН: {head}\n{r['title']}" + (f"\n{effect}" if effect else ""))
        if ok and r["kind"] == "inspect":
            await self._inspect(r)

    def _apply(self, r, votes: dict) -> str:
        kind, t, sev = r["kind"], r["target"], r["severity"]
        now = int(time.time())
        o = self.countries.get_object(t)
        if not o:
            return ""
        if kind == "condemn":
            rep, rel = U.sev_pick(kind, "rep", sev), U.sev_pick(kind, "rel", sev)
            self.dip.add_reputation(t, rep)
            for c, v in votes.items():
                if v == "yes" and c != t:
                    self.dip.add_relation(c, t, rel)
            return f"{ui_icon('un_condemn')} {o.flag} {t}: репутация {rep}, отношения с голосовавшими «за» {rel}."
        if kind == "aid":
            hap, stab = U.sev_pick(kind, "happy", sev), U.sev_pick(kind, "stab", sev)
            mult, hours = U.sev_pick(kind, "income", sev), U.EFFECTS["aid"]["hours"]
            self.countries.update_object(t, happiness=min(100.0, (o.happiness or 0) + hap),
                                         stability=min(100.0, (o.stability or 0) + stab))
            self.effects.add(t, "income_mult", mult, now + hours * U.H)
            return f"{ui_icon('un_aid')} {o.flag} {t}: счастье +{hap}, стабильность +{stab}, доход ×{mult} на {hours}ч."
        if kind == "sanctions":
            mult, hours = U.sev_pick(kind, "income", sev), U.sev_pick(kind, "hours", sev)
            self.effects.add(t, "income_mult", mult, now + hours * U.H)
            return f"{ui_icon('sanctions')} {o.flag} {t}: доход ×{mult} на {hours}ч (санкции ООН)."
        if kind == "embargo":
            hours = U.sev_pick(kind, "hours", sev)
            self.cooldown.set_cooldown("un_embargo", now + hours * U.H, t)
            return f"{ui_icon('un_embargo')} {o.flag} {t}: оружейное эмбарго на {hours}ч — без производства техники, лицензий и боеголовок."
        if kind == "ceasefire":
            hours = U.sev_pick(kind, "hours", sev)
            self.cooldown.set_cooldown("un_ceasefire", now + hours * U.H, str(r["war_id"]))
            return f"{ui_icon('peace')} Война №{r['war_id']}: прекращение огня на {hours}ч — раунды и удары запрещены."
        if kind == "inspect":
            return f"{ui_icon('inspect')} Инспекторы МАГАТЭ направлены в {o.flag} {t}."
        return ""

    async def _inspect(self, r):
        t = r["target"]
        nuc = self.bot.get_cog("NuclearCog")
        st = self.nuc.get(t)
        if nuc and st and st["status"] == "covert" and random.random() < U.sev_pick("inspect", "expose", r["severity"]):
            await nuc.expose(t, by=None)
            await self.news(f"{ui_icon('violator')} Инспекция МАГАТЭ в {self._obj(t).flag} **{t}** нашла следы военной "
                            f"ядерной программы.", ERROR_COLOR)
        else:
            self.dip.add_reputation(t, U.EFFECTS["inspect"]["clean_rep"])
            await self.news(f"{ui_icon('inspect')} Инспекция МАГАТЭ в {self._obj(t).flag} **{t}** нарушений не выявила. "
                            f"Репутация +{U.EFFECTS['inspect']['clean_rep']}.", SUCCESS_COLOR)

    # ═══════════════ API ДЛЯ ДРУГИХ МЕХАНИК ═══════════════
    def embargoed(self, country: str) -> int:
        """Секунд до конца оружейного эмбарго (0 — нет)."""
        return max(0, int(self.cooldown.get_cooldown("un_embargo", country) - time.time()))

    def ceasefire(self, war_id: int) -> int:
        """Секунд до конца прекращения огня в войне (0 — нет)."""
        return max(0, int(self.cooldown.get_cooldown("un_ceasefire", str(war_id)) - time.time()))

    # ── ядерные испытания: ИИ-судья + вето штаба ──
    async def judge_test(self, tid: int) -> bool:
        """Вызывается из NuclearCog._submit_to_arbiter. False — ИИ недоступен (решит штаб)."""
        nucc = self.bot.get_cog("NuclearCog")
        t = self.nuc.test(tid)
        if not nucc or not t or not U.available():
            return False
        c = t["country"]
        o = self._obj(c)
        st = self.nuc.get(c)
        rep = self.dip.get_state(c)[1]
        wars = [w["defender"] if w["attacker"] == c else w["attacker"] for w in self.war.active_for(c)]
        aggressor = [w["defender"] for w in self.war.active_for(c) if w["attacker"] == c]
        dossier = (f"Страна: {c}. Стабильность {o.stability:.0f}, счастье {o.happiness:.0f}, репутация {rep:.0f}/100. "
                   f"Статус по ДНЯО: {st['status']} ({'историческая держава' if st['historic'] else 'нет'}). "
                   f"Войны: {', '.join(wars) or 'нет'}; нападала на: {', '.join(aggressor) or 'никого'}.\n"
                   f"События 14 дней:\n{self._facts(c) or 'нет'}")
        verdict = await U.judge_test(dossier)
        if not verdict:
            return False
        apply_at = int(time.time()) + U.TEST_VETO_S
        self.un.set_test(tid, verdict["approve"], verdict["statement"], apply_at)
        ch = self._ch("CH_LOG") or self._ch("CH_UN_NEWS")
        word = "ОДОБРИТЬ" if verdict["approve"] else "ОТКЛОНИТЬ"
        if ch:
            p = Panel(timeout=None)
            p.add_item(disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"## {ui_icon('nuke_test')} ИИ-ООН: испытание {o.flag} {c}\n"
                    f"Вердикт: **{word}**\n{verdict['statement']}\n"
                    f"-# Вступит в силу <t:{apply_at}:R>. Штаб может наложить вето."),
                disnake.ui.ActionRow(
                    disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Утвердить сейчас", emoji=_pe("accept"),
                                      custom_id=cid("un", "tveto", tid, "now")),
                    disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Вето (обратить)", emoji=_pe("veto"),
                                      custom_id=cid("un", "tveto", tid, "flip"))),
                accent_colour=disnake.Colour(WARNING_COLOR)))
            try:
                await ch.send(components=p.components)
            except Exception:
                pass
        await self._dm(c, text=f"{ui_icon('un')} Заявка на испытание у ООН. Решение будет объявлено <t:{apply_at}:R>.")
        return True

    async def _apply_test(self, test_id: int, approve: bool, statement: str, by: str):
        nucc = self.bot.get_cog("NuclearCog")
        if not nucc:
            return
        self.un.set_test_status(test_id, "applied")
        t = self.nuc.test(test_id)
        o = self._obj(t["country"]) if t else _Dummy()
        await self.news(f"{ui_icon('nuke_test')} **ООН по заявке {o.flag} {t['country'] if t else ''} на ядерное "
                        f"испытание:** {'одобрено' if approve else 'отклонено'}.\n{statement}",
                        WARNING_COLOR if approve else COMMAND_COLOR)
        await nucc._decide_test(test_id, approve, by)

    async def _on_test_veto(self, inter, args):
        if not is_staff(inter.author):
            await inter.response.send_message("Только штаб.", ephemeral=True)
            return
        await self._defer(inter)
        if len(args) < 2 or not args[0].isdigit():
            return
        tid = int(args[0])
        row = self.un.test(tid)
        if not row or row["status"] != "pending":
            await inter.followup.send("Решение уже вступило в силу.", ephemeral=True)
            return
        approve = bool(row["approve"])
        if args[1] == "flip":
            approve = not approve
            self.un.set_test_status(tid, "vetoed")
            stmt = "Решение пересмотрено по вето штаба."
        else:
            stmt = row["statement"]
        await self._apply_test(tid, approve, stmt, f"ООН ({inter.author})")
        await inter.followup.send(f"Готово: испытание {'одобрено' if approve else 'отклонено'}.", ephemeral=True)

    # ═══════════════ НАБЛЮДАТЕЛЬ ═══════════════
    async def _watch(self, now: int):
        rows = self.un.unseen()
        if not rows:
            return
        self.un.mark_seen(rows[-1]["id"])
        serious = [r for r in rows if r["kind"] in U.SERIOUS]
        if not serious:
            return   # мелочь — ИИ не зовём вовсе (экономия)
        names = self.countries.get_object_names()
        if U.available():
            items = await U.watcher("\n".join(f"[{r['kind']}] {r['text']} (war_id={r['war_id']})" for r in serious[-20:]),
                                    names)
        else:   # правила без ИИ
            items = [{"type": "sanctions", "target": r["actor"], "war_id": 0,
                      "justification": r["text"]} for r in serious if r["kind"] == "nuke_strike"][:1]
        for it in items:
            tv = str(it["war_id"]) if it["type"] == "ceasefire" else it["target"]
            if it["type"] == "ceasefire" and not it["war_id"]:
                continue
            note = await self.propose(U.SG, it["type"], tv, it["justification"])
            if "вынесена" in note:
                await self.news(f"{ui_icon('secgen')} **Генеральный секретарь** выносит вопрос на повестку: "
                                f"{U.type_label(it['type'])} — {it['target']}.\n-# {it['justification']}")

    # ═══════════════ ЦИКЛ ═══════════════
    @tasks.loop(minutes=10)
    async def un_tick(self):
        now = int(time.time())
        try:
            for r in self.un.voting():
                if r["deadline"] <= now:
                    await self.finish(r["id"])
            for t in self.un.tests_due(now):
                await self._apply_test(t["test_id"], bool(t["approve"]), t["statement"], "ООН (ИИ)")
            if now - self._last_watch >= U.WATCH_EVERY_H * U.H:
                self._last_watch = now
                await self._watch(now)
                await self.sync_sc_channel()
                self.un.prune(now - 30 * _DAY)
        except Exception:
            log.exception("сбой цикла ООН")

    @un_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()
        self._last_watch = int(time.time()) - U.WATCH_EVERY_H * U.H + 600   # первый обход через 10 мин

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="un", aliases=["оон", "unitednations", "резолюция"])
    async def un_cmd(self, ctx: commands.Context):
        actor = self._actor(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(description="ООН доступна только странам.", color=ERROR_COLOR))
            return
        self._session(ctx.author.id).update(view="hub", kind=None, target=None, page=0)
        try:
            await ctx.author.send(components=self._render(ctx.author.id).components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(description="Включите ЛС и повторите `!оон`.", color=WARNING_COLOR))
            return
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('un')} Панель ООН отправлена вам в **личные сообщения**.",
                color=COMMAND_COLOR), delete_after=12)


def setup(bot: commands.Bot):
    bot.add_cog(UNCog(bot))
