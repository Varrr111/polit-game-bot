"""
🤝 ДИПЛОМАТИЯ — !diplo

ЖИВАЯ СЕТЬ, которая работает на фоне и с которой можно взаимодействовать.

ФОН (часовой цикл, без участия игроков):
  • Отношения каждой пары стран дрейфуют к «равновесию» из состояния мира:
    строй/религия, посольства, договоры, торговля на рынке (+); санкции, война,
    разоблачённый шпионаж, ультиматумы (−); общий враг (+); репутация сторон.
  • Дипкапитал копится сам (стабильность, посольства, репутация); репутация
    медленно возвращается к норме.
  • Между враждующими странами бот сам заводит КРИЗИСЫ: обеим в ЛС приходит
    выбор «Деэскалация» / «Жёсткий ответ», исход по матрице (вплоть до casus belli).
  • Просроченные предложения договоров и неотвеченные зовы союзников закрываются.

ИГРОК (панель !diplo в ЛС):
  • Договоры: ненападение, торговое соглашение (+% дохода), право прохода
    (наступление через земли партнёра). Военные союзы — это БЛОКИ (cogs/alliance.py):
    зов в войну идёт членам военного блока жертвы, блоки влияют на равновесие.
  • Дипмиссия (+отношения), нота протеста (публичное осуждение), посольства.
  • Предательство (война против партнёра по пакту/союзу) — удар по репутации
    у всего мира. Верность союзу — рост репутации.

Публичный канал #дипломатия (CH_DIPLO). Все числа — в utils/diplomacy.
Только кастом-иконки (ui_icon в тексте, emoji= в кнопках/опциях).
"""

import asyncio
import itertools
import logging
import random
import time

import disnake
from disnake.ext import commands, tasks

from utils import (
    Countries, Politics, Diplomacy, Sanctions, Spy, War, Cooldown,
    update_money, int_format,
    COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
import utils.diplomacy as D
import utils.politics as POL

log = logging.getLogger("diplomacy")

_PAGE = 25
_LIST_PAGE = 15   # строк в текстовом списке отношений
_DAY = 86400


def _pe(slug: str):
    """UI-слаг → PartialEmoji для emoji= кнопок/селектов (или None)."""
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def _sign(v: float) -> str:
    return f"+{v:.0f}" if v > 0 else f"{v:.0f}"


class _Dummy:
    flag = "🏳️"
    user = 0
    stability = 0.0


class DiplomacyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.politics = Politics()
        self.dip = Diplomacy()
        self.sanc = Sanctions()
        self.spy = Spy()
        self.war = War()
        self.cooldown = Cooldown()
        self._sessions: dict[int, dict] = {}
        self.diplo_tick.start()

    def cog_unload(self):
        self.diplo_tick.cancel()

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    # ───── сессия ─────
    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "target": None, "page": 0, "treaty": None, "prop": None}
            self._sessions[uid] = s
        return s

    def _actor(self, uid: int):
        return self.countries.get_object_by_user(uid)

    def _obj(self, name: str):
        return self.countries.get_object(name) or _Dummy()

    # ═══════════════ РАВНОВЕСИЕ ОТНОШЕНИЙ ═══════════════
    def _world(self, now: int) -> dict:
        """Снимок мира для расчёта равновесия (один раз на тик/панель)."""
        names = self.countries.get_object_names()
        politics = {n: self.politics.get(n) for n in names}
        sanctions: dict[tuple, int] = {}
        enemies: dict[str, set] = {n: set() for n in names}
        for s in self.sanc.all_active():
            k = D.pair(s["sanctioner"], s["target"])
            sanctions[k] = sanctions.get(k, 0) + 1
            enemies.setdefault(s["sanctioner"], set()).add(s["target"])
        wars = set()
        for w in self.war.all_active():
            wars.add(D.pair(w["attacker"], w["defender"]))
            enemies.setdefault(w["attacker"], set()).add(w["defender"])
            enemies.setdefault(w["defender"], set()).add(w["attacker"])
        for r in self.war.ally_wars():   # союзник в чужой войне воюет с противной стороной
            foe = r["attacker"] if r["side"] == "def" else r["defender"]
            wars.add(D.pair(r["country"], foe))
            enemies.setdefault(r["country"], set()).add(foe)
            enemies.setdefault(foe, set()).add(r["country"])
        spy: dict[tuple, int] = {}
        for r in self.spy.revealed_incidents(now - D.MEMORY_WINDOW_D * _DAY):
            k = D.pair(r["actor"], r["target"])
            spy[k] = spy.get(k, 0) + 1
        ults: dict[tuple, int] = {}
        for r in self.dip.ultimatums_since(now - D.MEMORY_WINDOW_D * _DAY):
            k = D.pair(r["issuer"], r["target"])
            ults[k] = ults.get(k, 0) + 1
        treaties: dict[tuple, list] = {}
        embassies: dict[tuple, int] = {}
        reps: dict[str, float] = {}
        for n in names:
            for t in self.dip.treaties_of(n):
                treaties.setdefault((t["a"], t["b"]), [])
                if t["kind"] not in treaties[(t["a"], t["b"])]:
                    treaties[(t["a"], t["b"])].append(t["kind"])
            for host in self.dip.embassies_of(n):
                k = D.pair(n, host)
                embassies[k] = embassies.get(k, 0) + 1
            reps[n] = self.dip.get_state(n)[1]
        return {
            "names": names, "politics": politics, "sanctions": sanctions, "wars": wars,
            "enemies": enemies, "spy": spy, "ults": ults, "treaties": treaties,
            "embassies": embassies, "reps": reps,
            "trade": self.dip.trade_volumes(now - D.TRADE_WINDOW_D * _DAY),
            "blocs": self._alliance().snapshot() if self._alliance() else None,
            "nuclear": self.bot.get_cog("NuclearCog").snapshot() if self.bot.get_cog("NuclearCog") else None,
        }

    def _alliance(self):
        return self.bot.get_cog("AllianceCog")

    def _equilibrium(self, a: str, b: str, w: dict) -> tuple[float, list]:
        """→ (равновесие, [(подпись, вклад)]) — куда тянутся отношения пары и почему."""
        k = D.pair(a, b)
        f: list[tuple[str, float]] = []
        ia, ra = w["politics"].get(a, ("none", ""))
        ib, rb = w["politics"].get(b, ("none", ""))
        if ia and ia != "none" and ia == ib:
            f.append((f"Схожий строй ({POL.ideo(ia)['label']})", D.EQ_SAME_IDEOLOGY))
        if ra and ra not in ("secular", "atheism") and ra == rb:
            f.append((f"Общая религия ({POL.rel(ra)['label']})", D.EQ_SAME_RELIGION))
        emb = w["embassies"].get(k, 0)
        if emb:
            f.append((f"Посольства ({emb})", D.EQ_EMBASSY * emb))
        for kind in w["treaties"].get(k, []):
            if kind in D.TREATIES:
                f.append((D.treaty_label(kind), D.TREATIES[kind]["eq"]))
        al, blocs = self._alliance(), w.get("blocs")
        vol = w["trade"].get(k, 0)
        if vol:
            tk = al.trade_k(a, b, blocs) if al and blocs else 1.0
            f.append(("Торговля в таможенном союзе" if tk > 1 else "Торговля на рынке",
                      round(D.EQ_TRADE_MAX * tk * min(1.0, vol / D.TRADE_VALUE_FOR_MAX), 1)))
        if al and blocs:
            f += al.relation_factors(a, b, blocs)
        nuc = self.bot.get_cog("NuclearCog")
        if nuc and w.get("nuclear"):
            f += nuc.relation_factors(a, b, w["nuclear"])
        sc = w["sanctions"].get(k, 0)
        if sc:
            f.append((f"Санкции ({sc})", D.EQ_SANCTIONS * sc))
        if k in w["wars"]:
            f.append(("Война", D.EQ_WAR))
        sp = w["spy"].get(k, 0)
        if sp:
            f.append(("Разоблачённый шпионаж", max(D.EQ_SPY_CAP, D.EQ_SPY_EXPOSED * sp)))
        ut = w["ults"].get(k, 0)
        if ut:
            f.append(("Ультиматумы", max(D.EQ_ULT_CAP, D.EQ_ULTIMATUM * ut)))
        common = (w["enemies"].get(a, set()) & w["enemies"].get(b, set())) - {a, b}
        if common:
            f.append(("Общий враг", D.EQ_COMMON_ENEMY))
        rep = ((w["reps"].get(a, D.REP_BASE) - D.REP_BASE) + (w["reps"].get(b, D.REP_BASE) - D.REP_BASE)) * D.EQ_REP_K
        if abs(rep) >= 1:
            f.append(("Репутация сторон", round(rep, 1)))
        target = _clamp(sum(v for _, v in f), D.REL_MIN, D.REL_MAX)
        return target, f

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('diplo')} Дипломатия")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _back(self, label="⟵ В хаб", to="hub"):
        return disnake.ui.Button(style=disnake.ButtonStyle.secondary, label=label,
                                 custom_id=cid("dip", "goto", to))

    def _render(self, uid: int, note=None) -> Panel:
        s = self._session(uid)
        actor = self._actor(uid)
        if not actor:
            return self._container(self._head(note) + [disnake.ui.TextDisplay(
                "-# У вас нет страны. Откройте панель регистрации, чтобы играть.")], WARNING_COLOR)
        view = s["view"]
        if view == "list":
            return self._panel_list(uid, actor, note)
        if view == "country" and s["target"]:
            return self._panel_country(uid, actor, note)
        if view == "propose" and s["target"]:
            return self._panel_propose(uid, actor, note)
        if view == "treaties":
            return self._panel_treaties(uid, actor, note)
        return self._panel_hub(uid, actor, note)

    # — хаб —
    def _panel_hub(self, uid, actor, note=None):
        name = actor.name
        inf, rep = self.dip.get_state(name)
        emb = self.dip.embassies_of(name)
        rate = D.influence_rate(getattr(actor, "stability", 0) or 0, len(emb), rep)
        treaties = self.dip.treaties_of(name)
        incoming = self.dip.incoming_proposals(name)
        rels = {n: v for n, v in self.dip.relations_of(name).items() if self.countries.get_object(n)}
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {actor.flag} {name}\n"
            f"{ui_icon('influence')} Дипкапитал: **{inf:.0f}/{D.INF_MAX:.0f}** (+{rate:.1f}/ч)\n"
            f"{ui_icon('reputation')} Репутация: **{rep:.0f}/100** · {D.rep_word(rep)}\n"
            f"{ui_icon('treaty')} Договоры: **{len(treaties)}** · "
            f"{ui_icon('embassy')} Посольства: **{len(emb)}/{D.EMBASSY_MAX}**"
            + (f"\n{ui_icon('envelope')} Входящие предложения: **{len(incoming)}**" if incoming else "")))
        if rels:
            ordered = sorted(rels.items(), key=lambda kv: -kv[1])
            best = " · ".join(f"{self._obj(n).flag} {n} **{_sign(v)}**" for n, v in ordered[:3] if v > 0)
            worst = " · ".join(f"{self._obj(n).flag} {n} **{_sign(v)}**"
                               for n, v in reversed(ordered[-3:]) if v < 0)
            lines = []
            if best:
                lines.append(f"{ui_icon('rel_up')} Ближе всех: {best}")
            if worst:
                lines.append(f"{ui_icon('rel_down')} Хуже всех: {worst}")
            if lines:
                items.append(disnake.ui.Separator())
                items.append(disnake.ui.TextDisplay("\n".join(lines)))
        items.append(disnake.ui.Separator())
        B = disnake.ButtonStyle
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.primary, label="Страны и отношения", emoji=_pe("relations"),
                              custom_id=cid("dip", "goto", "list")),
            disnake.ui.Button(style=B.success if incoming else B.secondary,
                              label=f"Договоры{f' · {len(incoming)} новых' if incoming else ''}",
                              emoji=_pe("treaty"), custom_id=cid("dip", "goto", "treaties")),
            disnake.ui.Button(style=B.secondary, label="Обновить", emoji=_pe("reload"),
                              custom_id=cid("dip", "goto", "hub"))))
        items.append(disnake.ui.TextDisplay(
            "-# Отношения меняются сами каждый час — от строя, торговли, санкций, войн и шпионажа."))
        return self._container(items)

    # — список стран —
    def _panel_list(self, uid, actor, note=None):
        s = self._session(uid)
        items = self._head(note)
        names = sorted(n for n in self.countries.get_object_names() if n != actor.name)
        if not names:
            items.append(disnake.ui.TextDisplay("-# Других стран пока нет."))
            items.append(disnake.ui.ActionRow(self._back()))
            return self._container(items, WARNING_COLOR)
        rels = self.dip.relations_of(actor.name)
        names.sort(key=lambda n: -rels.get(n, 0.0))
        pages = max(1, (len(names) + _PAGE - 1) // _PAGE)
        s["page"] = _clamp(s["page"], 0, pages - 1)
        page = names[s["page"] * _PAGE:(s["page"] + 1) * _PAGE]
        lines = []
        for n in page[:_LIST_PAGE]:
            v = rels.get(n, 0.0)
            _k, label, icon = D.tier(v)
            lines.append(f"{ui_icon(icon)} {self._obj(n).flag} **{n}** · {_sign(v)} · {label}")
        more = len(page) - _LIST_PAGE
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('relations')} Отношения · стр. {s['page'] + 1}/{pages}\n" + "\n".join(lines)
            + (f"\n-# …и ещё {more} — в меню ниже" if more > 0 else "")))
        opts = []
        for n in page:
            v = rels.get(n, 0.0)
            _k, label, icon = D.tier(v)
            opts.append(disnake.SelectOption(label=f"{self._obj(n).flag} {n}"[:100], value=n,
                                             emoji=_pe(icon), description=f"{_sign(v)} · {label}"[:100]))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("dip", "pick"), placeholder="Открыть страну…", options=opts)))
        buttons = [self._back()]
        if pages > 1:
            buttons.append(disnake.ui.Button(style=disnake.ButtonStyle.primary, emoji=_pe("prev"),
                                             disabled=s["page"] == 0, custom_id=cid("dip", "page", "prev")))
            buttons.append(disnake.ui.Button(style=disnake.ButtonStyle.primary, emoji=_pe("next"),
                                             disabled=s["page"] >= pages - 1, custom_id=cid("dip", "page", "next")))
        items.append(disnake.ui.ActionRow(*buttons))
        return self._container(items)

    # — страна —
    def _panel_country(self, uid, actor, note=None):
        s = self._session(uid)
        target = s["target"]
        tobj = self.countries.get_object(target)
        if not tobj:
            s["view"] = "list"
            return self._panel_list(uid, actor, f"{ui_icon('reject')} Страна недоступна.")
        now = int(time.time())
        me = actor.name
        rel = self.dip.get_relation(me, target)
        eq, factors = self._equilibrium(me, target, self._world(now))
        _k, label, icon = D.tier(rel)
        trend = ("держатся" if abs(eq - rel) < 1 else ("растут" if eq > rel else "падают"))
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {tobj.flag} {target} · {ui_icon(icon)} {label}\n"
            f"{ui_icon('relations')} Отношения: {D.rel_bar(rel)} **{_sign(rel)}**\n"
            f"-# Равновесие **{_sign(eq)}** — отношения {trend} на {D.DRIFT_PER_H:.0f}/ч"))
        if factors:
            fl = "\n".join(f"{ui_icon('rel_up' if v > 0 else 'rel_down')} {lbl} **{_sign(v)}**"
                           for lbl, v in factors)
            items.append(disnake.ui.TextDisplay(f"-# ЧТО ВЛИЯЕТ\n{fl}"))
        active = self.dip.treaties_between(me, target)
        pending = self.dip.treaties_between(me, target, "pending")
        tl = [f"{ui_icon(D.TREATIES[t['kind']]['icon'])} {D.treaty_label(t['kind'])}" for t in active]
        tl += [f"{ui_icon('envelope')} {D.treaty_label(t['kind'])} — ждёт ответа" for t in pending]
        mine, theirs = self.dip.has_embassy(me, target), self.dip.has_embassy(target, me)
        emb = ("взаимные" if mine and theirs else "ваше там" if mine else "их у вас" if theirs else "нет")
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(
            (f"{ui_icon('treaty')} Договоры: " + (" · ".join(tl) if tl else "нет") + "\n")
            + f"{ui_icon('embassy')} Посольства: **{emb}**"))
        inf, _rep = self.dip.get_state(me)
        B = disnake.ButtonStyle
        mcd = self._cd(f"{D.pair(me, target)}", "dipmission", now)
        pcd = self._cd(f"{me}>{target}", "dipprotest", now)
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.success, label="Предложить договор", emoji=_pe("treaty"),
                              custom_id=cid("dip", "goto", "propose")),
            disnake.ui.Button(style=B.primary, emoji=_pe("rel_up"),
                              label=(f"Дипмиссия · {D.MISSION_COST}" if not mcd else f"Миссия · {mcd // 60}м"),
                              disabled=bool(mcd) or inf < D.MISSION_COST, custom_id=cid("dip", "mission")),
            disnake.ui.Button(style=B.danger, emoji=_pe("rel_down"),
                              label=(f"Нота протеста · {D.PROTEST_COST}" if not pcd else f"Нота · {pcd // 60}м"),
                              disabled=bool(pcd) or inf < D.PROTEST_COST, custom_id=cid("dip", "protest"))))
        row2 = [disnake.ui.Button(
            style=B.secondary, emoji=_pe("embassy"),
            label=("Закрыть посольство" if mine
                   else f"Посольство · {int_format(D.EMBASSY_COST_MONEY)} + {D.EMBASSY_COST_INF}"),
            custom_id=cid("dip", "embassy"))]
        row2.append(self._back("⟵ К списку", "list"))
        items.append(disnake.ui.ActionRow(*row2))
        if active:
            opts = [disnake.SelectOption(label=D.treaty_label(t["kind"]), value=str(t["id"]),
                                         emoji=_pe(D.TREATIES[t["kind"]]["icon"]),
                                         description=f"Разорвать: отношения {D.CANCEL_REL_HIT}"[:100])
                    for t in active]
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("dip", "cancel"), placeholder="Разорвать договор…", options=opts)))
        return self._container(items)

    # — предложить договор —
    def _panel_propose(self, uid, actor, note=None):
        s = self._session(uid)
        target = s["target"]
        tobj = self.countries.get_object(target)
        if not tobj:
            s["view"] = "list"
            return self._panel_list(uid, actor)
        me = actor.name
        rel = self.dip.get_relation(me, target)
        inf, _rep = self.dip.get_state(me)
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('treaty')} Договор с {tobj.flag} {target}\n"
            f"-# Отношения **{_sign(rel)}** · ваш дипкапитал **{inf:.0f}**. "
            f"При отказе возвращается {int(D.REJECT_REFUND * 100)}% цены."))
        opts = []
        for key in D.TREATY_KEYS:
            meta = D.TREATIES[key]
            reason = self._propose_block(me, target, key, rel, inf)
            opts.append(disnake.SelectOption(
                label=f"{meta['label']} · {meta['cost']}"[:100], value=key, emoji=_pe(meta["icon"]),
                description=(f"Недоступно: {reason}" if reason else meta["desc"])[:100],
                default=(key == s["treaty"])))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("dip", "treaty"), placeholder="Тип договора…", options=opts)))
        sel = s["treaty"]
        block = self._propose_block(me, target, sel, rel, inf) if sel else "не выбран договор"
        if sel:
            meta = D.TREATIES[sel]
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon(meta['icon'])} **{meta['label']}** — {meta['desc']}\n"
                f"-# Нужно отношений от **{_sign(meta['min_rel'])}** · цена **{meta['cost']}** дипкапитала"
                + (f"\n{ui_icon('reject')} {block}" if block else "")))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.success, label="Отправить предложение",
                              emoji=_pe("envelope"), disabled=bool(block), custom_id=cid("dip", "send")),
            self._back("⟵ К стране", "country")))
        return self._container(items)

    def _propose_block(self, me: str, target: str, key: str, rel: float, inf: float) -> str:
        """Почему нельзя предложить договор (пустая строка — можно)."""
        meta = D.TREATIES[key]
        if self.dip.treaty_between(me, target, key):
            return "уже действует"
        if self.dip.treaty_between(me, target, key, ("pending",)):
            return "уже ждёт ответа"
        if self.war.active_between(me, target):
            return "между вами война"
        if rel < meta["min_rel"]:
            return f"отношения ниже {_sign(meta['min_rel'])}"
        if inf < meta["cost"]:
            return "мало дипкапитала"
        return ""

    # — договоры и входящие —
    def _panel_treaties(self, uid, actor, note=None):
        s = self._session(uid)
        me = actor.name
        items = self._head(note)
        active = self.dip.treaties_of(me)
        incoming = self.dip.incoming_proposals(me)
        outgoing = [t for t in self.dip.treaties_of(me, "pending") if t["proposer"] == me]
        lines = []
        for t in active:
            other = t["b"] if t["a"] == me else t["a"]
            lines.append(f"{ui_icon(D.TREATIES[t['kind']]['icon'])} {D.treaty_label(t['kind'])} · "
                         f"{self._obj(other).flag} {other}")
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('treaty')} Договоры · {actor.flag} {me}\n"
            + ("\n".join(lines) if lines else "-# Действующих договоров нет.")))
        if outgoing:
            ol = " · ".join(f"{D.treaty_label(t['kind'])} → {t['b'] if t['a'] == me else t['a']}"
                            for t in outgoing[:6])
            items.append(disnake.ui.TextDisplay(f"-# ОТПРАВЛЕНО, ЖДЁТ ОТВЕТА: {ol}"))
        items.append(disnake.ui.Separator())
        if incoming:
            opts = []
            for t in incoming[:_PAGE]:
                other = t["proposer"]
                opts.append(disnake.SelectOption(
                    label=f"{self._obj(other).flag} {other}"[:100], value=str(t["id"]),
                    emoji=_pe(D.TREATIES[t["kind"]]["icon"]), description=D.treaty_label(t["kind"])[:100],
                    default=(str(t["id"]) == str(s["prop"]))))
            items.append(disnake.ui.TextDisplay(f"{ui_icon('envelope')} **Входящие предложения: {len(incoming)}**"))
            items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                custom_id=cid("dip", "prop"), placeholder="Выберите предложение…", options=opts)))
            chosen = s["prop"] is not None and any(str(t["id"]) == str(s["prop"]) for t in incoming)
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Принять", emoji=_pe("accept"),
                                  disabled=not chosen, custom_id=cid("dip", "tacc", s["prop"] or 0)),
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Отклонить", emoji=_pe("reject"),
                                  disabled=not chosen, custom_id=cid("dip", "trej", s["prop"] or 0)),
                self._back()))
        else:
            items.append(disnake.ui.TextDisplay("-# Входящих предложений нет."))
            items.append(disnake.ui.ActionRow(self._back()))
        return self._container(items)

    # ═══════════════ ПОМОЩНИКИ ═══════════════
    def _cd(self, name: str, key: str, now: int) -> int:
        return max(0, int(self.cooldown.get_cooldown(key, name) - now))

    def _channel(self):
        ch_id = rid("CH_DIPLO", 0)
        if not ch_id:
            return None
        g = self.bot.get_guild(GUILD_ID)
        return (g.get_channel(ch_id) if g else None) or self.bot.get_channel(ch_id)

    async def _post(self, desc: str, color=COMMAND_COLOR):
        channel = self._channel()
        if not channel:
            return
        try:
            await channel.send(embed=disnake.Embed(description=desc, color=color))
        except Exception:
            pass

    async def _dm(self, country: str, components=None, text: str | None = None):
        o = self.countries.get_object(country)
        if not o or not getattr(o, "user", 0):
            return
        user = self.bot.get_user(o.user)
        if user is None:
            try:
                user = await self.bot.fetch_user(o.user)
            except Exception:
                return
        try:
            if components is not None:
                await user.send(components=components)
            else:
                await user.send(text)
        except Exception:
            pass

    def _note_panel(self, text: str, color=COMMAND_COLOR) -> Panel:
        return self._container([disnake.ui.TextDisplay(text)], color)

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _dip_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("dip:"):
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        actor = self._actor(inter.author.id)
        _, action, _ = parse_cid(c)
        v = inter.values[0] if inter.values else None
        note = None
        if not actor or v is None:
            pass
        elif action == "pick":
            s.update(view="country", target=v, treaty=None)
        elif action == "treaty":
            s["treaty"] = v
        elif action == "prop":
            s["prop"] = int(v)
        elif action == "cancel":
            note = await self._cancel_treaty(actor, int(v))
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    @commands.Cog.listener("on_button_click")
    async def _dip_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("dip:"):
            return
        _, action, args = parse_cid(c)
        # персистентные сообщения (предложение / кризис / зов) — свои обработчики
        if action == "offer":
            await self._on_offer_message(inter, args)
            return
        if action == "inc":
            await self._on_incident_choice(inter, args)
            return
        if action == "call":
            await self._on_call_answer(inter, args)
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        actor = self._actor(inter.author.id)
        note = None
        if not actor:
            pass
        elif action == "goto":
            s["view"] = args[0]
            if args[0] == "hub":
                s.update(target=None, treaty=None, prop=None)
            elif args[0] == "list":
                s["treaty"] = None
        elif action == "page":
            s["page"] += 1 if args and args[0] == "next" else -1
        elif action == "send":
            note = await self._send_proposal(actor, s)
        elif action == "mission":
            note = self._mission(actor, s["target"])
        elif action == "protest":
            note = await self._protest(actor, s["target"])
        elif action == "embassy":
            note = await self._toggle_embassy(actor, s["target"])
        elif action in ("tacc", "trej") and args and args[0].isdigit():
            note = await self._answer_proposal(actor, int(args[0]), accept=(action == "tacc"))
            s["prop"] = None
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    # ───── договоры ─────
    async def _send_proposal(self, actor, s) -> str:
        me, target, key = actor.name, s["target"], s["treaty"]
        if not target or key not in D.TREATIES or not self.countries.get_object(target):
            return f"{ui_icon('reject')} Выберите страну и договор."
        inf, _rep = self.dip.get_state(me)
        block = self._propose_block(me, target, key, self.dip.get_relation(me, target), inf)
        if block:
            return f"{ui_icon('reject')} Нельзя: {block}."
        cost = D.TREATIES[key]["cost"]
        self.dip.add_influence(me, -cost)
        tid = self.dip.propose(key, me, target, cost, int(time.time()))
        await self._dm(target, components=self._offer_panel(tid).components)
        s.update(view="country", treaty=None)
        return (f"{ui_icon('envelope')} Предложение «{D.treaty_label(key)}» отправлено "
                f"{self._obj(target).flag} {target} (−{cost} дипкапитала).")

    def _offer_panel(self, tid: int, result: str | None = None) -> Panel:
        """Сообщение в ЛС адресату: предложение договора с кнопками (живёт после рестарта)."""
        t = self.dip.get_treaty(tid)
        if not t:
            return self._note_panel(f"{ui_icon('reject')} Предложение не найдено.", WARNING_COLOR)
        meta = D.TREATIES.get(t["kind"], {"label": t["kind"], "icon": "treaty", "desc": ""})
        prop = t["proposer"]
        other = t["b"] if t["a"] == prop else t["a"]
        rel = self.dip.get_relation(prop, other)
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('envelope')} Дипломатическое предложение\n"
            f"{self._obj(prop).flag} **{prop}** предлагает вам "
            f"{ui_icon(meta['icon'])} **{meta['label']}**\n-# {meta['desc']}\n"
            f"{ui_icon('relations')} Ваши отношения: **{_sign(rel)}** ({D.tier(rel)[1]})")]
        if result:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(result))
        elif t["status"] == "pending":
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Подписать", emoji=_pe("accept"),
                                  custom_id=cid("dip", "offer", tid, "yes")),
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Отклонить", emoji=_pe("reject"),
                                  custom_id=cid("dip", "offer", tid, "no"))))
            items.append(disnake.ui.TextDisplay("-# Предложение действует 24 часа. Все договоры — в `!diplo`."))
        else:
            items.append(disnake.ui.TextDisplay(f"-# Предложение уже закрыто ({t['status']})."))
        return self._container(items, COMMAND_COLOR)

    async def _on_offer_message(self, inter, args):
        await self._defer(inter)
        actor = self._actor(inter.author.id)
        if not actor or len(args) < 2 or not args[0].isdigit():
            return
        tid = int(args[0])
        note = await self._answer_proposal(actor, tid, accept=(args[1] == "yes"))
        await inter.edit_original_message(components=self._offer_panel(tid, note).components)

    async def _answer_proposal(self, actor, tid: int, accept: bool) -> str:
        t = self.dip.get_treaty(tid)
        me = actor.name
        if not t or t["status"] != "pending" or me not in (t["a"], t["b"]) or t["proposer"] == me:
            return f"{ui_icon('reject')} Предложение уже недействительно."
        prop = t["proposer"]
        now = int(time.time())
        label = D.treaty_label(t["kind"])
        if not accept:
            self.dip.set_treaty_status(tid, "rejected", now)
            self.dip.add_influence(prop, (t["cost"] or 0) * D.REJECT_REFUND)
            await self._dm(prop, text=f"{ui_icon('reject')} {actor.flag} **{me}** отклонила ваше предложение "
                                      f"«{label}». Возвращено {int(D.REJECT_REFUND * 100)}% дипкапитала.")
            return f"{ui_icon('reject')} Вы отклонили «{label}»."
        if self.war.active_between(prop, me):
            return f"{ui_icon('reject')} Между вами идёт война — договор невозможен."
        if self.dip.treaty_between(prop, me, t["kind"]):
            self.dip.set_treaty_status(tid, "rejected", now)
            return f"{ui_icon('check')} Такой договор уже действует."
        self.dip.set_treaty_status(tid, "active", now)
        self.dip.add_relation(prop, me, D.SIGN_REL_BOOST)
        pobj = self._obj(prop)
        await self._dm(prop, text=f"{ui_icon('treaty')} {actor.flag} **{me}** подписала «{label}»!")
        await self._post(
            f"{ui_icon(D.TREATIES[t['kind']]['icon'])} {pobj.flag} **{prop}** и {actor.flag} **{me}** "
            f"подписали договор: **{label}**.", SUCCESS_COLOR)
        return f"{ui_icon('check')} Договор «{label}» с {pobj.flag} {prop} подписан."

    async def _cancel_treaty(self, actor, tid: int) -> str:
        t = self.dip.get_treaty(tid)
        me = actor.name
        if not t or t["status"] != "active" or me not in (t["a"], t["b"]):
            return f"{ui_icon('reject')} Договор не найден."
        other = t["b"] if t["a"] == me else t["a"]
        label = D.treaty_label(t["kind"])
        self.dip.set_treaty_status(tid, "ended", int(time.time()))
        self.dip.add_relation(me, other, D.CANCEL_REL_HIT)
        await self._dm(other, text=f"{ui_icon('rel_down')} {actor.flag} **{me}** разорвала договор «{label}» с вами.")
        await self._post(f"{ui_icon('rel_down')} {actor.flag} **{me}** разрывает договор «{label}» "
                         f"с {self._obj(other).flag} **{other}**.", WARNING_COLOR)
        return f"{ui_icon('rel_down')} Договор «{label}» разорван (отношения {D.CANCEL_REL_HIT})."

    # ───── действия со страной ─────
    def _mission(self, actor, target) -> str:
        me = actor.name
        now = int(time.time())
        if not target or not self.countries.get_object(target):
            return f"{ui_icon('reject')} Страна недоступна."
        key = D.pair(me, target)
        if self._cd(f"{key}", "dipmission", now):
            return f"{ui_icon('reject')} Миссия в эту страну недавно была."
        inf, _ = self.dip.get_state(me)
        if inf < D.MISSION_COST:
            return f"{ui_icon('reject')} Нужно {D.MISSION_COST} дипкапитала."
        self.dip.add_influence(me, -D.MISSION_COST)
        v = self.dip.add_relation(me, target, D.MISSION_BOOST)
        self.cooldown.set_cooldown("dipmission", now + D.MISSION_CD, f"{key}")
        return (f"{ui_icon('rel_up')} Дипмиссия в {self._obj(target).flag} {target}: отношения "
                f"**{_sign(D.MISSION_BOOST)}** → **{_sign(v)}**. Без причин эффект постепенно угаснет.")

    async def _protest(self, actor, target) -> str:
        me = actor.name
        now = int(time.time())
        if not target or not self.countries.get_object(target):
            return f"{ui_icon('reject')} Страна недоступна."
        if self._cd(f"{me}>{target}", "dipprotest", now):
            return f"{ui_icon('reject')} Нота этой стране уже была недавно."
        inf, _ = self.dip.get_state(me)
        if inf < D.PROTEST_COST:
            return f"{ui_icon('reject')} Нужно {D.PROTEST_COST} дипкапитала."
        self.dip.add_influence(me, -D.PROTEST_COST)
        self.dip.add_relation(me, target, D.PROTEST_REL)
        self.dip.add_reputation(target, D.PROTEST_REP)
        self.cooldown.set_cooldown("dipprotest", now + D.PROTEST_CD, f"{me}>{target}")
        tobj = self._obj(target)
        await self._post(f"{ui_icon('rel_down')} {actor.flag} **{me}** вручает ноту протеста "
                         f"{tobj.flag} **{target}** и публично осуждает её действия.", WARNING_COLOR)
        await self._dm(target, text=f"{ui_icon('rel_down')} {actor.flag} **{me}** вручила вам ноту протеста "
                                    f"(отношения {D.PROTEST_REL}, репутация {D.PROTEST_REP}).")
        return (f"{ui_icon('rel_down')} Нота вручена: отношения {D.PROTEST_REL}, "
                f"репутация {tobj.flag} {target} {D.PROTEST_REP}.")

    async def _toggle_embassy(self, actor, target) -> str:
        me = actor.name
        if not target or not self.countries.get_object(target):
            return f"{ui_icon('reject')} Страна недоступна."
        tobj = self._obj(target)
        if self.dip.has_embassy(me, target):
            self.dip.close_embassy(me, target)
            await self._dm(target, text=f"{ui_icon('embassy')} {actor.flag} **{me}** закрыла посольство у вас.")
            return f"{ui_icon('embassy')} Посольство в {tobj.flag} {target} закрыто."
        if len(self.dip.embassies_of(me)) >= D.EMBASSY_MAX:
            return f"{ui_icon('reject')} Лимит посольств: {D.EMBASSY_MAX}."
        if self.war.active_between(me, target):
            return f"{ui_icon('reject')} Во время войны посольство не открыть."
        inf, _ = self.dip.get_state(me)
        fresh = self.countries.get_object(me)
        if inf < D.EMBASSY_COST_INF:
            return f"{ui_icon('reject')} Нужно {D.EMBASSY_COST_INF} дипкапитала."
        if (fresh.money or 0) < D.EMBASSY_COST_MONEY:
            return f"{ui_icon('reject')} Нужно {int_format(D.EMBASSY_COST_MONEY)} {CURRENCY}."
        update_money(me, -D.EMBASSY_COST_MONEY)
        self.dip.add_influence(me, -D.EMBASSY_COST_INF)
        self.dip.open_embassy(me, target, int(time.time()))
        await self._dm(target, text=f"{ui_icon('embassy')} {actor.flag} **{me}** открыла посольство в вашей стране.")
        return (f"{ui_icon('embassy')} Посольство в {tobj.flag} {target} открыто: "
                f"отношения тянутся вверх (+{D.EQ_EMBASSY}), дипкапитал капает быстрее.")

    # ═══════════════ ВОЙНА: ПРЕДАТЕЛЬСТВО И ЗОВ СОЮЗНИКА ═══════════════
    def transit_partners(self, country: str) -> list[str]:
        """Страны, через чьи земли можно наступать (право прохода или базы военного блока)."""
        al = self._alliance()
        return sorted(set(self.dip.partners(country, "transit")) | set(al.base_partners(country) if al else []))

    async def on_war_declared(self, aggressor: str, defender: str, war_id: int, casus: str = "") -> str:
        """Хук из cogs/war.py после объявления войны. → строка-пометка для итога."""
        notes = []
        now = int(time.time())
        dobj = self._obj(defender)
        betrayal = await self._betray_check(aggressor, defender, now)
        if betrayal:
            notes.append(betrayal)
        al = self._alliance()
        if al:
            split = await al.on_war_declared(aggressor, defender)   # нападение на члена своего блока
            if split:
                notes.append(split)
        # союзник, вступивший в чужую войну, сам не созывает своих союзников (без цепной реакции)
        if (casus or "").startswith(D.CALL_CASUS):
            return "\n".join(notes)
        allies = [a for a, _b in (al.defense_allies(defender, aggressor) if al else [])
                  if not self.war.is_participant(war_id, a)]
        for ally in allies:
            call_id = self.dip.create_call(war_id, ally, aggressor, defender, now, now + D.CALL_TTL)
            await self._dm(ally, components=self._call_panel(call_id).components)
        if allies:
            bloc = al.bloc_of(defender, "military")
            names = ", ".join(f"{self._obj(a).flag} {a}" for a in allies)
            await self._post(f"{ui_icon('call_arms')} {dobj.flag} **{defender}** задействует коллективную оборону "
                             f"блока **[{bloc['tag']}] {bloc['name']}**: {names}. У них 24 часа на ответ.",
                             WARNING_COLOR)
            notes.append(f"{ui_icon('call_arms')} Члены блока {defender} получили зов: {names}.")
        return "\n".join(notes)

    async def _betray_check(self, aggressor: str, victim: str, now: int) -> str:
        """Война против партнёра: ненападение/союз → предательство; прочие договоры просто гаснут."""
        treaties = self.dip.treaties_between(aggressor, victim)
        broken = [t for t in treaties if t["kind"] == "nonaggr"]
        for t in treaties:
            self.dip.set_treaty_status(t["id"], "broken" if broken else "ended", now)
        if not broken:
            return ""
        self.dip.add_reputation(aggressor, D.BETRAYAL_REP)
        self.dip.add_relation(aggressor, victim, D.BETRAYAL_REL)
        labels = ", ".join(D.treaty_label(t["kind"]) for t in broken)
        aobj, vobj = self._obj(aggressor), self._obj(victim)
        await self._post(
            f"{ui_icon('betrayal')} **ПРЕДАТЕЛЬСТВО.** {aobj.flag} **{aggressor}** пошла войной на "
            f"{vobj.flag} **{victim}**, нарушив: {labels}.\n"
            f"-# Репутация {aggressor} {D.BETRAYAL_REP} — это заметит весь мир.", ERROR_COLOR)
        await self._dm(victim, text=f"{ui_icon('betrayal')} {aobj.flag} **{aggressor}** предала вас: {labels}.")
        return f"{ui_icon('betrayal')} Нарушено: {labels} — репутация {D.BETRAYAL_REP}."

    async def on_sanctions_imposed(self, sanctioner: str, target: str) -> str:
        """Хук из cogs/sanctions.py: санкции против партнёра рвут торговлю, союз и проход."""
        now = int(time.time())
        broken = [t for t in self.dip.treaties_between(sanctioner, target) if t["kind"] in D.SANCTION_BREAKS]
        if not broken:
            return ""
        for t in broken:
            self.dip.set_treaty_status(t["id"], "ended", now)
        labels = ", ".join(D.treaty_label(t["kind"]) for t in broken)
        sobj, tobj = self._obj(sanctioner), self._obj(target)
        await self._post(f"{ui_icon('rel_down')} Санкции {sobj.flag} **{sanctioner}** против {tobj.flag} "
                         f"**{target}** разрушили договоры: {labels}.", WARNING_COLOR)
        await self._dm(target, text=f"{ui_icon('rel_down')} Из-за санкций {sobj.flag} **{sanctioner}** "
                                    f"расторгнуты договоры с вами: {labels}.")
        return f"{ui_icon('rel_down')} Расторгнуты договоры: {labels}."

    def _call_panel(self, call_id: int, result: str | None = None) -> Panel:
        c = self.dip.get_call(call_id)
        if not c:
            return self._note_panel(f"{ui_icon('reject')} Зов не найден.", WARNING_COLOR)
        ally, agg, dfd = c["ally"], c["aggressor"], c["defender"]
        warn = ""
        pact = [t for t in self.dip.treaties_between(ally, agg) if t["kind"] == "nonaggr"]
        if pact:
            warn = (f"\n{ui_icon('betrayal')} У вас договор с {agg} "
                    f"({', '.join(D.treaty_label(t['kind']) for t in pact)}): вступление — предательство.")
        al = self._alliance()
        bloc = al.bloc_of(dfd, "military") if al else None
        btxt = f" по блоку **[{bloc['tag']}] {bloc['name']}**" if bloc else ""
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('call_arms')} Коллективная оборона\n"
            f"На вашего союзника{btxt} {self._obj(dfd).flag} **{dfd}** напала "
            f"{self._obj(agg).flag} **{agg}** (война #{c['war_id']}).\n"
            f"{ui_icon('alliance')} Вступить — ваши готовые соединения воюют в этой войне вместе с {dfd} "
            f"(общий бой, общие потери), репутация **+{D.CALL_JOIN_REP}**.\n"
            f"{ui_icon('reject')} Отказ или молчание 24ч — репутация **{D.CALL_REFUSE_REP}**, "
            f"отношения с {dfd} **{D.CALL_REFUSE_REL}**, сплочённость блока падает." + warn)]
        if result:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(result))
        elif c["status"] == "pending":
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Вступить в войну",
                                  emoji=_pe("call_arms"), custom_id=cid("dip", "call", call_id, "join")),
                disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Отказаться",
                                  emoji=_pe("reject"), custom_id=cid("dip", "call", call_id, "refuse"))))
        else:
            items.append(disnake.ui.TextDisplay(f"-# Зов уже закрыт ({c['status']})."))
        return self._container(items, ERROR_COLOR)

    async def _on_call_answer(self, inter, args):
        await self._defer(inter)
        actor = self._actor(inter.author.id)
        if not actor or len(args) < 2 or not args[0].isdigit():
            return
        call_id = int(args[0])
        c = self.dip.get_call(call_id)
        if not c or c["status"] != "pending" or c["ally"] != actor.name:
            await inter.edit_original_message(components=self._call_panel(call_id).components)
            return
        if args[1] == "join":
            note = await self._join_war(inter.author, c)
        else:
            note = await self._refuse_call(c)
        await inter.edit_original_message(components=self._call_panel(call_id, note).components)

    async def _join_war(self, author, c) -> str:
        war_cog = self.bot.get_cog("WarCog")
        if not war_cog:
            return f"{ui_icon('reject')} Модуль войны недоступен."
        ok, note = war_cog.join_as_ally(c["war_id"], c["ally"])
        if not ok:
            self.dip.set_call_status(c["id"], "void")
            return f"{ui_icon('reject')} {note}"
        self.dip.set_call_status(c["id"], "joined")
        if self._alliance():
            self._alliance().on_call_result(c["ally"], c["defender"], True)
        self.dip.add_reputation(c["ally"], D.CALL_JOIN_REP)
        self.dip.add_relation(c["ally"], c["defender"], D.CALL_JOIN_REL)
        aobj = self._obj(c["ally"])
        await self._post(f"{ui_icon('alliance')} {aobj.flag} **{c['ally']}** верна союзу и вступает в войну "
                         f"на стороне {self._obj(c['defender']).flag} **{c['defender']}**!", SUCCESS_COLOR)
        await self._dm(c["defender"], text=f"{ui_icon('alliance')} {aobj.flag} **{c['ally']}** вступила "
                                           f"в войну на вашей стороне!")
        # договоры с агрессором теряют силу; ненападение/союз с ним — предательство
        await self._betray_check(c["ally"], c["aggressor"], int(time.time()))
        return f"{ui_icon('alliance')} Вы вступили в войну. {note}"

    async def _refuse_call(self, c, silent: bool = False) -> str:
        self.dip.set_call_status(c["id"], "expired" if silent else "refused")
        if self._alliance():
            self._alliance().on_call_result(c["ally"], c["defender"], False)
        self.dip.add_reputation(c["ally"], D.CALL_REFUSE_REP)
        self.dip.add_relation(c["ally"], c["defender"], D.CALL_REFUSE_REL)
        aobj = self._obj(c["ally"])
        how = "промолчала на зов" if silent else "отказалась помочь"
        await self._post(f"{ui_icon('rel_down')} {aobj.flag} **{c['ally']}** {how} союзнику "
                         f"{self._obj(c['defender']).flag} **{c['defender']}**.", WARNING_COLOR)
        await self._dm(c["defender"], text=f"{ui_icon('rel_down')} {aobj.flag} **{c['ally']}** {how} вам.")
        return (f"{ui_icon('reject')} Вы отказались. Репутация {D.CALL_REFUSE_REP}, "
                f"отношения с {c['defender']} {D.CALL_REFUSE_REL}.")

    def diplo_context(self, country: str) -> str:
        """Короткая дипломатическая сводка страны для ИИ (новости и т.п.)."""
        inf, rep = self.dip.get_state(country)
        lines = [f"Репутация {rep:.0f}/100 ({D.rep_word(rep)})."]
        by_kind: dict[str, list] = {}
        for t in self.dip.treaties_of(country):
            by_kind.setdefault(D.treaty_label(t["kind"]), []).append(t["b"] if t["a"] == country else t["a"])
        lines += [f"{k}: {', '.join(v)}." for k, v in by_kind.items()] or ["Договоров нет."]
        if self._alliance():
            lines.append("Блоки: " + self._alliance().context(country))
        if self.bot.get_cog("NuclearCog"):
            lines.append("Атом: " + self.bot.get_cog("NuclearCog").context(country))
        lgc = self.bot.get_cog("LegacyCog")
        if lgc and lgc.context(country):
            lines.append(lgc.context(country))
        rels = sorted(((n, v) for n, v in self.dip.relations_of(country).items() if abs(v) >= 20),
                      key=lambda kv: -abs(kv[1]))[:6]
        if rels:
            lines.append("Заметные отношения: " + ", ".join(f"{n} {_sign(v)} ({D.tier(v)[1]})" for n, v in rels) + ".")
        wars = [w["defender"] if w["attacker"] == country else w["attacker"] for w in self.war.active_for(country)]
        if wars:
            lines.append("В войне с: " + ", ".join(wars) + ".")
        return "\n".join(lines)

    def trade_pact_mult(self, country: str) -> float:
        """Множитель дохода от торговых соглашений (читает economy)."""
        return D.trade_pact_mult(len(self.dip.partners(country, "trade")))

    # ═══════════════ КРИЗИСЫ ═══════════════
    def _incident_panel(self, iid: int, viewer: str, result: str | None = None) -> Panel:
        inc = self.dip.get_incident(iid)
        if not inc:
            return self._note_panel(f"{ui_icon('reject')} Кризис не найден.", WARNING_COLOR)
        title, desc = D.INCIDENT_BY_KEY.get(inc["kind"], ("Кризис", "{a} и {b} на грани конфликта."))
        a, b = inc["a"], inc["b"]
        text = desc.format(a=f"{self._obj(a).flag} {a}", b=f"{self._obj(b).flag} {b}")
        side = "a" if viewer == a else "b"
        mine = inc["a_choice"] if side == "a" else inc["b_choice"]
        items = [disnake.ui.TextDisplay(
            f"## {ui_icon('incident')} Кризис · {title}\n{text}\n"
            f"-# Ответьте в течение {D.INCIDENT_TTL // 3600} ч. Исход зависит от ответа обеих сторон.")]
        items.append(disnake.ui.TextDisplay(
            f"{ui_icon('deescalate')} **Деэскалация** ({D.DEESCALATE_COST} дипкапитала): если обе стороны "
            f"уступят — отношения растут.\n"
            f"{ui_icon('escalate')} **Жёсткий ответ**: народ сплачивается (+стабильность), но если обе "
            f"стороны пойдут на обострение — casus belli и обвал отношений."))
        if result:
            items.append(disnake.ui.Separator())
            items.append(disnake.ui.TextDisplay(result))
        elif inc["status"] == "open" and not mine:
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=disnake.ButtonStyle.success, label="Деэскалация",
                                  emoji=_pe("deescalate"), custom_id=cid("dip", "inc", iid, "soft")),
                disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Жёсткий ответ",
                                  emoji=_pe("escalate"), custom_id=cid("dip", "inc", iid, "hard"))))
        elif inc["status"] == "open":
            items.append(disnake.ui.TextDisplay(
                f"-# Ваш ответ: **{'деэскалация' if mine == 'soft' else 'жёсткий ответ'}**. Ждём другую сторону."))
        else:
            items.append(disnake.ui.TextDisplay("-# Кризис завершён."))
        return self._container(items, WARNING_COLOR)

    async def _on_incident_choice(self, inter, args):
        await self._defer(inter)
        actor = self._actor(inter.author.id)
        if not actor or len(args) < 2 or not args[0].isdigit():
            return
        iid = int(args[0])
        choice = args[1] if args[1] in ("soft", "hard") else None
        inc = self.dip.get_incident(iid)
        me = actor.name
        if not inc or inc["status"] != "open" or me not in (inc["a"], inc["b"]) or not choice:
            await inter.edit_original_message(components=self._incident_panel(iid, me).components)
            return
        side = "a" if me == inc["a"] else "b"
        if (inc["a_choice"] if side == "a" else inc["b_choice"]):
            await inter.edit_original_message(components=self._incident_panel(iid, me).components)
            return
        if choice == "soft":
            inf, _ = self.dip.get_state(me)
            if inf < D.DEESCALATE_COST:
                await inter.edit_original_message(components=self._incident_panel(
                    iid, me, f"{ui_icon('reject')} Для деэскалации нужно {D.DEESCALATE_COST} дипкапитала "
                             f"(у вас {inf:.0f}). Можно ответить жёстко.").components)
                return
            self.dip.add_influence(me, -D.DEESCALATE_COST)
        self.dip.set_choice(iid, side, choice)
        inc = self.dip.get_incident(iid)
        if inc["a_choice"] and inc["b_choice"]:
            result = await self._resolve_incident(inc)
            await inter.edit_original_message(components=self._incident_panel(iid, me, result).components)
        else:
            await inter.edit_original_message(components=self._incident_panel(iid, me).components)

    async def _resolve_incident(self, inc) -> str:
        a, b = inc["a"], inc["b"]
        ca, cb = inc["a_choice"] or "none", inc["b_choice"] or "none"
        delta, casus = D.INCIDENT_OUTCOMES.get((ca, cb), (0, False))
        self.dip.close_incident(inc["id"], casus)
        if delta:
            self.dip.add_relation(a, b, delta)
        for side, choice, other_choice in ((a, ca, cb), (b, cb, ca)):
            o = self.countries.get_object(side)
            if choice == "hard" and o:
                stab = _clamp((getattr(o, "stability", 50.0) or 0.0) + D.HARD_STAB_BONUS, 0, 100)
                self.countries.update_object(side, stability=round(stab, 2))
            if choice == "soft" and other_choice == "hard":
                self.dip.add_reputation(side, D.SOFT_REP_BONUS)
        title, _desc = D.INCIDENT_BY_KEY.get(inc["kind"], ("Кризис", ""))
        fa, fb = self._obj(a).flag, self._obj(b).flag
        word = {"soft": "уступила", "hard": "ответила жёстко", "none": "промолчала"}
        summary = (f"{fa} **{a}** {word[ca]} · {fb} **{b}** {word[cb]}\n"
                   f"{ui_icon('relations')} Отношения **{_sign(delta)}**"
                   + (f"\n{ui_icon('war')} Обе стороны получили **casus belli** друг против друга." if casus else ""))
        if casus:
            head, color = f"{ui_icon('escalate')} **Кризис обострился: {title}**", ERROR_COLOR
        elif delta > 0:
            head, color = f"{ui_icon('deescalate')} **Кризис урегулирован: {title}**", SUCCESS_COLOR
        else:
            head, color = f"{ui_icon('incident')} **Кризис завершён: {title}**", WARNING_COLOR
        await self._post(f"{head}\n{summary}", color)
        for side in (a, b):
            await self._dm(side, text=f"{head}\n{summary}")
        return summary

    async def _spawn_incidents(self, now: int, names: list[str]):
        busy = set()
        spawned = 0
        for x, y in itertools.combinations(sorted(names), 2):
            if spawned >= 3:
                break
            if x in busy or y in busy:
                continue
            rel = self.dip.get_relation(x, y)
            chance = D.incident_chance(rel)
            if chance <= 0 or random.random() >= chance:
                continue
            if self.war.active_between(x, y) or self.dip.open_incident_between(x, y):
                continue
            if any(now - self.dip.last_incident_ts(c) < D.INCIDENT_COUNTRY_CD for c in (x, y)):
                continue
            a, b = random.sample([x, y], 2)
            kind = random.choice(D.INCIDENTS)[0]
            iid = self.dip.create_incident(kind, a, b, now, now + D.INCIDENT_TTL)
            busy.update((x, y))
            spawned += 1
            title, desc = D.INCIDENT_BY_KEY[kind]
            await self._post(
                f"{ui_icon('incident')} **Кризис: {title}**\n"
                + desc.format(a=f"{self._obj(a).flag} **{a}**", b=f"{self._obj(b).flag} **{b}**")
                + "\n-# Стороны решают: уступить или ответить жёстко.", WARNING_COLOR)
            for side in (a, b):
                await self._dm(side, components=self._incident_panel(iid, side).components)

    # ═══════════════ ЧАСОВОЙ ЦИКЛ ═══════════════
    def _tick_relations(self, now: int) -> list[str]:
        """Синхронная часть тика (в отдельном потоке): капитал, репутация, дрейф отношений."""
        objs = self.countries.all_objects()
        names = [o.name for o in objs]
        for o in objs:
            inf, rep = self.dip.get_state(o.name)
            rate = D.influence_rate(getattr(o, "stability", 0) or 0, len(self.dip.embassies_of(o.name)), rep)
            self.dip.set_influence(o.name, min(D.INF_MAX, inf + rate))
            if abs(rep - D.REP_BASE) > 0.01:
                self.dip.set_reputation(o.name, D.drift(rep, D.REP_BASE, D.REP_RECOVER_PER_H))
        w = self._world(now)
        for a, b in itertools.combinations(sorted(names), 2):
            cur = self.dip.get_relation(a, b)
            eq, _f = self._equilibrium(a, b, w)
            new = D.drift(cur, eq)
            if new != cur:
                self.dip.set_relation(a, b, new)
        self.dip.prune_trade(now - D.TRADE_WINDOW_D * _DAY)
        return names

    @tasks.loop(hours=1)
    async def diplo_tick(self):
        try:
            now = int(time.time())
            names = await asyncio.to_thread(self._tick_relations, now)
            # просроченные предложения → возврат части капитала
            for t in self.dip.pending_expired(now - D.PROPOSAL_TTL):
                self.dip.set_treaty_status(t["id"], "expired", now)
                self.dip.add_influence(t["proposer"], (t["cost"] or 0) * D.REJECT_REFUND)
            # кризисы без ответа одной/обеих сторон
            for inc in self.dip.open_incidents_due(now):
                try:
                    await self._resolve_incident(inc)
                except Exception:
                    log.exception("разбор кризиса #%s", inc["id"])
            # молчание на зов союзника = отказ
            for c in self.dip.calls_due(now):
                try:
                    await self._refuse_call(c, silent=True)
                except Exception:
                    log.exception("зов #%s", c["id"])
            await self._spawn_incidents(now, names)
        except Exception:
            log.exception("сбой цикла дипломатии")

    @diplo_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="diplo", aliases=["дипломатия", "diplomacy", "дипло", "отношения"])
    async def diplo_cmd(self, ctx: commands.Context):
        actor = self._actor(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(
                description="Дипломатия доступна только зарегистрированным странам. "
                            "Откройте панель регистрации.", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(view="hub", target=None, page=0, treaty=None, prop=None)
        try:
            await ctx.author.send(components=self._render(ctx.author.id).components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(
                description="Не могу написать в ЛС. Включите личные сообщения от участников "
                            "сервера и повторите `!diplo`.", color=WARNING_COLOR))
            return
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('diplo')} Дипломатическая панель отправлена вам в **личные сообщения**.",
                color=COMMAND_COLOR), delete_after=12)


def setup(bot: commands.Bot):
    bot.add_cog(DiplomacyCog(bot))
