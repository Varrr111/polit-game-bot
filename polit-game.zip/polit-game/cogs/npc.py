"""
🤖 ИИ-ГОСУДАРСТВА — незанятые страны с реальной армией (utils/npc.py), которыми командует бот.

Сама война идёт в cogs/war.py (ИИ-сторона: npc_power / npc_damage / автоплан / мир / капитуляция).
Здесь — фон и справка:
  • часовой цикл: восстановление сил ИИ вне войны, мораль к норме;
  • АГРЕССИЯ (в меру): ИИ изредка нападает на соседа-игрока, только если тот заметно слабее,
    в игре дольше недели (защита новичков), не воюет и давно не был жертвой ИИ;
    на сервере одновременно не больше одной такой войны и не чаще раза в 3 дня;
  • `!ии [страна]` — разведсводка по ИИ-государству (без аргумента — твои соседи-ИИ).
Только кастом-иконки.
"""

import asyncio
import logging
import random
import time

import disnake
from disnake.ext import commands, tasks

import config
from utils import Countries, War, Npc, COMMAND_COLOR, ERROR_COLOR
from utils.helpers import get_object_by_user
from utils.ui import Panel
from utils.resources import ui_icon
import utils.npc as NPC
import utils.war as WE
import utils.worldmap as WM
from utils import MapState

log = logging.getLogger("npc")


class NpcCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.npc = Npc()
        self.war = War()
        self.countries = Countries()
        self.npc_tick.start()

    def cog_unload(self):
        self.npc_tick.cancel()

    def _wc(self):
        return self.bot.get_cog("WarCog")

    # ═══════════════ ЧАСОВОЙ ЦИКЛ ═══════════════
    def _regen(self, now: int):
        at_war = {w["attacker"] for w in self.war.all_active()} | {w["defender"] for w in self.war.all_active()}
        for st in self.npc.all():
            name = st["country"]
            if name in at_war or st["dissolved"]:
                continue
            strength = min(1.0, (st["strength"] or 0) + NPC.REGEN_PER_DAY / 24)
            morale = st["morale"] or 70
            morale = min(70.0, morale + 1.0) if morale < 70 else max(70.0, morale - 1.0)
            if strength != st["strength"] or morale != st["morale"]:
                self.npc.set(name, strength=round(strength, 4), morale=round(morale, 2), updated_at=now)

    async def _aggression(self, now: int):
        wc = self._wc()
        if not wc:
            return
        active = {w["id"] for w in self.war.all_active()}
        if len(set(self.npc.aggr_war_ids()) & active) >= NPC.AGGR_MAX_ACTIVE:
            return
        if now - self.npc.last_aggr() < NPC.AGGR_GAP_S:
            return
        ov = MapState().overrides()
        candidates = []
        for o in self.countries.all_objects():
            name = o.name
            reg = self.npc.registered_at(name)
            if reg and now - reg < NPC.NEWBIE_PROTECT_S:            # новичок — не трогаем
                continue
            if self.war.active_for(name):                           # уже воюет
                continue
            if now - self.npc.last_aggr(name) < NPC.AGGR_PLAYER_CD_S:  # недавно был жертвой ИИ
                continue
            a3 = WM.resolve_a3(name)
            if not a3:
                continue
            mine = wc._army_power(name)
            my_pw = WE.combat_power(mine["atk"], mine["arm"], mine["hp"])
            if name in config.COUNTRIES_ROSTER:   # потенциал страны сдерживает: на Индию без армии Бутан не полезет
                pot = wc.npc_power(name, baseline=True)
                my_pw = max(my_pw, NPC.AGGR_POTENTIAL * WE.combat_power(pot["atk"], pot["arm"], pot["hp"]))
            for n3 in WM.neighbor_countries(a3, ov):
                npc = next((n for n in config.COUNTRIES_ROSTER if WM.resolve_a3(n) == n3), None)
                if not npc or not wc.is_npc(npc) or self.war.active_for(npc):
                    continue
                their = wc.npc_power(npc)
                th_pw = WE.combat_power(their["atk"], their["arm"], their["hp"])
                if th_pw >= NPC.AGGR_POWER_RATIO * max(1.0, my_pw):
                    candidates.append((npc, name))
        random.shuffle(candidates)
        for npc, target in candidates:
            if random.random() >= NPC.AGGR_CHANCE:
                continue
            wid = await wc.npc_declare(npc, target, random.choice(NPC.AGGR_CASUS))
            if wid:
                self.npc.log_aggr(npc, target, wid, now)
                log.info("ИИ %s напало на %s (война #%s)", npc, target, wid)
                return   # не больше одной войны за тик

    @tasks.loop(hours=1)
    async def npc_tick(self):
        now = int(time.time())
        try:
            await asyncio.to_thread(self._regen, now)
            await self._aggression(now)
        except Exception:
            log.exception("сбой цикла ИИ-государств")

    @npc_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="npc", aliases=["ии", "ии-страна", "ии-страны", "разведка-ии"])
    async def npc_cmd(self, ctx: commands.Context, *, country: str = ""):
        wc = self._wc()
        me = get_object_by_user(ctx.author.id)
        if not wc:
            return
        name = wc.npc_name(country) if country else None
        if country and not name:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('reject')} «{country}» — не ИИ-государство (занята игроком, исчезла или нет такой).",
                color=ERROR_COLOR))
            return
        p = Panel(timeout=None)
        if name:
            st = self.npc.state(name)
            w = self.war.active_for(name)
            text = (wc._npc_intel(name, me.name) if me else f"## {name}") + (
                f"\n{ui_icon('war')} Сейчас воюет: война #{w[0]['id']} ({w[0]['attacker']} — {w[0]['defender']})"
                if w else f"\n{ui_icon('peace')} Сейчас не воюет · мораль **{st['morale']:.0f}**")
            body = [disnake.ui.TextDisplay(f"## {ui_icon('ai_state')} ИИ-государство · {name}"),
                    disnake.ui.TextDisplay(text),
                    disnake.ui.TextDisplay("-# Армия — оценка реальных вооружённых сил страны. В бой идёт около "
                                           f"{int(NPC.READINESS * 100)}% (остальное — гарнизоны и резерв).")]
        else:
            if not me:
                await ctx.send(embed=disnake.Embed(description="Сначала зарегистрируйте страну.", color=ERROR_COLOR))
                return
            names = await asyncio.to_thread(wc.npc_targets, me.name)
            lines = "\n".join(f"{ui_icon('ai_state')} **{n}** · {NPC.doctrine(n)}" for n in names) \
                or "-# Рядом нет ИИ-государств (нужна общая граница или право прохода)."
            body = [disnake.ui.TextDisplay(f"## {ui_icon('ai_state')} ИИ-государства рядом с {me.flag} {me.name}"),
                    disnake.ui.TextDisplay(lines),
                    disnake.ui.TextDisplay("-# Подробнее: `!ии <страна>`. Объявить войну — `!war` → «ИИ-государства».")]
        p.add_item(disnake.ui.Container(*body, accent_colour=disnake.Colour(COMMAND_COLOR)))
        await ctx.send(components=p.components)


def setup(bot: commands.Bot):
    bot.add_cog(NpcCog(bot))
