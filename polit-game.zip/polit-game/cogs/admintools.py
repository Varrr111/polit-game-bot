"""
🛠️ Админ-инструменты — одна панель !admin (перезагрузка когов + сброс базы).

  !admin  — красивое меню: выбери ког из списка (без ввода названий) и перезагрузи,
            либо сбрось нужный раздел базы данных с подтверждением кнопкой.

Текстом по-прежнему можно: !reload [ког] · !dbreset <раздел> confirm.

Доступ к панели/reload — по !perm (scope "reload"). Сброс базы — ТОЛЬКО владелец.
"""

import logging
import sqlite3

import disnake
from disnake.ext import commands

from utils import COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR
from utils.perms import has_command_access
from utils.resources import ui_icon
from utils.database import DB_PATH
from utils.ui import Panel, cid, parse_cid

log = logging.getLogger("admintools")

# Человеческие названия когов для меню (чтобы не помнить "cogs.x").
COG_LABELS: dict[str, str] = {
    "cogs.items": "Предметы", "cogs.registration": "Регистрация",
    "cogs.resources": "Ресурсы", "cogs.development": "Развитие",
    "cogs.equipment": "Техника", "cogs.state": "Политика",
    "cogs.army": "Армия", "cogs.events": "События", "cogs.economy": "Экономика",
    "cogs.worldmap": "Карта мира", "cogs.spy": "Шпионаж", "cogs.console": "Консоль",
    "cogs.perms": "Права", "cogs.news": "Новости", "cogs.serversetup": "Построение сервера",
    "cogs.serverstats": "Статистика", "cogs.serverlogs": "Логи",
    "cogs.idconfig": "Настройка ID", "cogs.admintools": "Админ-инструменты",
    "cogs.help": "Помощь", "cogs.ultimatum": "Ультиматумы", "cogs.sanctions": "Санкции",
    "cogs.war": "Война", "cogs.trade": "Торговля", "cogs.guard": "Защита",
    "cogs.cleanup": "Чистка твинков", "cogs.masstools": "Масс-инструменты",
    "cogs.guide": "Гайд",
}

# Разделы БД → таблицы (для точечного сброса).
DB_SCOPES: dict[str, list[str]] = {
    "spy":            ["spy_agency", "spy_agents", "spy_heat", "spy_incidents"],
    "countries":      ["countries"],
    "army":           ["army_buildings", "manpower", "formations", "formation_equipment"],
    "equipment":      ["equipment", "equipment_licenses", "equipment_stock",
                       "license_offers", "equipment_plants", "production_queue"],
    "resources":      ["resources", "buildings", "building_levels", "allocation"],
    "politics":       ["politics"],
    "effects":        ["country_effects"],
    "upgrades":       ["country_upgrades"],
    "map":            ["map_territories"],
    "news":           ["news_activity", "news_log"],
    "sanctions":      ["sanctions", "sanction_effect"],
    "ultimatums":     ["ultimatums"],
    "perms":          ["command_perms"],
    "cooldowns":      ["cooldowns", "collect_cooldown", "work_cooldown"],
    "companies":      ["companies"],
    "infrastructure": ["infrastructure"],
    "items":          ["inventory", "licenses"],
    "market":         ["market"],
    "war":            ["war_conflicts", "war_fronts", "war_plans", "war_log"],
    "trade":          ["trade_offers"],
    "guard":          ["guard_settings", "guard_wl", "guard_raiders", "guard_stats"],
}
_SCOPE_DESC = {
    "all": "все игровые данные (ID/каналы сохранятся)",
    "full": "ВСЁ, включая настройки сервера",
}
_KEEP_FOR_ALL = {"server_config", "map_config"}


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s else None
    except Exception:
        return None


def _all_tables() -> list[str]:
    conn = sqlite3.connect(str(DB_PATH))
    try:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()
    finally:
        conn.close()
    return [r[0] for r in rows]


class AdminToolsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._sessions: dict[int, dict] = {}

    # ───── доступ/сессия ─────
    def _can(self, member) -> bool:
        return has_command_access(member, "reload")

    def _is_owner(self, inter_or_ctx) -> bool:
        g = getattr(inter_or_ctx, "guild", None)
        a = getattr(inter_or_ctx, "author", None)
        return bool(g and a and a.id == g.owner_id)

    def _session(self, uid: int) -> dict:
        s = self._sessions.get(uid)
        if s is None:
            s = {"view": "hub", "db_scope": None, "page": 0}
            self._sessions[uid] = s
        return s

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    # ───── логика ─────
    def _do_reload(self, targets: list[str]):
        ok, fail = [], []
        for e in targets:
            try:
                self.bot.reload_extension(e)
                ok.append(e)
            except commands.ExtensionNotLoaded:
                try:
                    self.bot.load_extension(e)
                    ok.append(e + " (загружен)")
                except Exception as ex:
                    fail.append((e, ex))
            except Exception as ex:
                fail.append((e, ex))
        return ok, fail

    def _resolve_tables(self, scope: str) -> list[str] | None:
        scope = scope.lower()
        if scope == "full":
            return _all_tables()
        if scope == "all":
            return [t for t in _all_tables() if t not in _KEEP_FOR_ALL]
        if scope in DB_SCOPES:
            return DB_SCOPES[scope]
        return None

    def _do_reset(self, tables: list[str]):
        conn = sqlite3.connect(str(DB_PATH))
        cleared = total = 0
        errors = []
        try:
            for t in tables:
                try:
                    cur = conn.execute(f"DELETE FROM {t}")
                    total += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
                    cleared += 1
                except sqlite3.OperationalError as ex:
                    errors.append(f"{t}: {ex}")
            conn.commit()
        finally:
            conn.close()
        return cleared, total, errors

    # ═══════════════ ПАНЕЛЬ ═══════════════
    def _container(self, items, color=COMMAND_COLOR) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _render(self, uid: int, note: str | None = None) -> Panel:
        s = self._session(uid)
        if s["view"] == "reload":
            return self._panel_reload(uid, note)
        if s["view"] == "db":
            return self._panel_db(uid, note)
        if s["view"] == "status":
            return self._panel_status(uid, note)
        return self._panel_hub(uid, note)

    def _head(self, note):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('tools')} Админ-инструменты")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _panel_hub(self, uid, note=None):
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            "-# Инструменты владельца: перезагрузка когов без рестарта, иконки, статус, сброс базы."))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.primary, label="Перезагрузка когов",
                              emoji=_pe("reload"), custom_id=cid("adm", "goto", "reload")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Перезагрузить иконки",
                              emoji=_pe("tools"), custom_id=cid("adm", "reloadicons")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Статус бота",
                              emoji=_pe("guide"), custom_id=cid("adm", "goto", "status"))))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Сброс базы",
                              emoji=_pe("dbreset"), custom_id=cid("adm", "goto", "db"))))
        return self._container(items)

    def _panel_reload(self, uid, note=None):
        import main
        s = self._session(uid)
        exts = list(main.INITIAL_EXTENSIONS)           # ВСЕ коги
        pages = max(1, (len(exts) + 24) // 25)
        page = max(0, min(s.get("page", 0), pages - 1))
        s["page"] = page
        chunk = exts[page * 25:page * 25 + 25]
        items = self._head(note)
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('reload')} Перезагрузка когов · стр. {page + 1}/{pages}\n"
            "-# Выбери ког — перезагрузится сразу. «Перезагрузить все» — одним нажатием."))
        opts = []
        for ext in chunk:
            loaded = ext in self.bot.extensions
            opts.append(disnake.SelectOption(
                label=COG_LABELS.get(ext, ext.replace("cogs.", "")), value=ext,
                description=(ext.replace("cogs.", "") + ("" if loaded else " · НЕ загружен"))[:100]))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("adm", "reloadsel"), placeholder="Выберите ког…", options=opts)))
        row = [disnake.ui.Button(style=disnake.ButtonStyle.success, label="Перезагрузить все",
                                 emoji=_pe("reload"), custom_id=cid("adm", "reloadall"))]
        if pages > 1:
            row.append(disnake.ui.Button(style=disnake.ButtonStyle.secondary, label=f"◀ {page + 1}/{pages}",
                                         custom_id=cid("adm", "rpage", "prev")))
            row.append(disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="▶",
                                         custom_id=cid("adm", "rpage", "next")))
        row.append(disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Назад",
                                     emoji=_pe("prev"), custom_id=cid("adm", "goto", "hub")))
        items.append(disnake.ui.ActionRow(*row))
        return self._container(items)

    def _panel_status(self, uid, note=None):
        import main, time as _t
        items = self._head(note)
        loaded = len(self.bot.extensions)
        total = len(main.INITIAL_EXTENSIONS)
        import math
        lat = round(self.bot.latency * 1000) if not math.isnan(self.bot.latency or float("nan")) else 0
        guilds = len(self.bot.guilds)
        try:
            import os
            size = os.path.getsize(DB_PATH) / 1024
            dbinfo = f"{DB_PATH} · {size:.0f} КБ"
        except Exception:
            dbinfo = str(DB_PATH)
        try:
            from utils import War, Trade
            wars = len(War().all_active())
            offers = len(Trade().all_offers())
        except Exception:
            wars = offers = "?"
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('guide')} Статус бота\n"
            f"{ui_icon('reload')} Коги: **{loaded}/{total}** загружено\n"
            f"🌐 Серверов: **{guilds}** · пинг: **{lat} мс**\n"
            f"{ui_icon('war')} Активных войн: **{wars}** · {ui_icon('trade')} заявок на рынке: **{offers}**\n"
            f"-# База: `{dbinfo}`"))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Назад",
                              emoji=_pe("prev"), custom_id=cid("adm", "goto", "hub"))))
        return self._container(items)

    def _panel_db(self, uid, note=None):
        s = self._session(uid)
        scope = s["db_scope"]
        items = self._head(note)
        tables = self._resolve_tables(scope) if scope else None
        info = ""
        if scope:
            desc = _SCOPE_DESC.get(scope, f"таблиц: {len(tables) if tables else 0}")
            info = (f"\nВыбрано: **{scope}** — {desc}\n"
                    f"-# Будет очищено таблиц: **{len(tables) if tables else 0}**")
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('dbreset')} Сброс базы данных\n"
            "-# Выберите раздел. Сброс **необратим** и доступен только владельцу сервера." + info))
        # опции разделов
        opts = [
            disnake.SelectOption(label="Все игровые данные (all)", value="all",
                                 description=_SCOPE_DESC["all"][:100], default=(scope == "all")),
            disnake.SelectOption(label="ВСЁ, включая настройки (full)", value="full",
                                 description=_SCOPE_DESC["full"][:100], default=(scope == "full")),
        ]
        for k in DB_SCOPES:
            opts.append(disnake.SelectOption(
                label=k, value=k, description=f"таблиц: {len(DB_SCOPES[k])}"[:100],
                default=(scope == k)))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("adm", "dbscope"), placeholder="Выберите раздел для сброса…",
            options=opts[:25])))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=disnake.ButtonStyle.danger, label="Подтвердить сброс",
                              emoji=_pe("dbreset"), disabled=(scope is None),
                              custom_id=cid("adm", "dbconfirm")),
            disnake.ui.Button(style=disnake.ButtonStyle.secondary, label="Назад",
                              emoji=_pe("prev"), custom_id=cid("adm", "goto", "hub"))))
        return self._container(items, WARNING_COLOR if scope else COMMAND_COLOR)

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _adm_dropdown(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("adm:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("Нет доступа (`!perm`).", ephemeral=True)
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        _, action, _ = parse_cid(c)
        note = None
        if action == "reloadsel":
            ext = inter.values[0]
            ok, fail = self._do_reload([ext])
            note = (f"{ui_icon('reload')} Перезагружен: **{COG_LABELS.get(ext, ext)}**"
                    if ok else f"Ошибка: {fail[0][1]}")
        elif action == "dbscope":
            s["db_scope"] = inter.values[0]
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    @commands.Cog.listener("on_button_click")
    async def _adm_button(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("adm:"):
            return
        if not self._can(inter.author):
            await inter.response.send_message("Нет доступа (`!perm`).", ephemeral=True)
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        note = None
        if action == "goto":
            s["view"] = args[0]
            if args[0] != "db":
                s["db_scope"] = None
        elif action == "reloadall":
            import main
            ok, fail = self._do_reload(list(main.INITIAL_EXTENSIONS))
            note = f"{ui_icon('reload')} Перезагружено: **{len(ok)}/{len(ok) + len(fail)}**"
            if fail:
                note += " · ошибки: " + ", ".join(e for e, _ in fail[:5])
        elif action == "rpage":
            s["page"] = s.get("page", 0) + (1 if args and args[0] == "next" else -1)
        elif action == "reloadicons":
            try:
                from utils.resources import apply_custom_emojis
                emojis = await self.bot.fetch_application_emojis()
                n = apply_custom_emojis({e.name: f"<:{e.name}:{e.id}>" for e in emojis})
                note = f"{ui_icon('tools')} Иконки обновлены: подхвачено **{n}**."
            except Exception as ex:
                note = f"Не удалось обновить иконки: {ex}"
        elif action == "dbconfirm":
            if not self._is_owner(inter):
                await inter.edit_original_message(
                    components=self._render(inter.author.id,
                                            "Сброс базы — только владелец сервера.").components)
                return
            scope = s["db_scope"]
            tables = self._resolve_tables(scope) if scope else None
            if not tables:
                note = "Раздел не выбран."
            else:
                cleared, total, errors = self._do_reset(tables)
                note = (f"{ui_icon('dbreset')} Раздел `{scope}` сброшен · "
                        f"таблиц: **{cleared}/{len(tables)}**, строк: **{total}**")
                if scope in ("all", "full", "map"):
                    self.bot.dispatch("map_dirty")
                if scope == "full":
                    note += "\n-# Настройки сброшены — выполните `!autoconfig`/`!setupserver`."
                s["db_scope"] = None
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    # ═══════════════ КОМАНДЫ ═══════════════
    @commands.command(name="admin", aliases=["tools", "инструменты", "утилиты"])
    async def admin_cmd(self, ctx: commands.Context):
        if not self._can(ctx.author):
            await ctx.send(embed=disnake.Embed(
                description="Нет доступа к админ-инструментам (`!perm`).", color=ERROR_COLOR))
            return
        s = self._session(ctx.author.id)
        s.update(view="hub", db_scope=None)
        await ctx.send(components=self._render(ctx.author.id).components)

    @commands.command(name="reload", aliases=["перезагрузка", "релоад", "reloadcogs"])
    async def reload_cmd(self, ctx: commands.Context, ext: str | None = None):
        if not has_command_access(ctx.author, "reload"):
            await ctx.send(embed=disnake.Embed(
                description="Нет доступа (`!perm`). Удобнее — через `!admin`.", color=ERROR_COLOR))
            return
        import main
        targets = ([ext if ext.startswith("cogs.") else f"cogs.{ext}"] if ext
                   else list(main.INITIAL_EXTENSIONS))
        ok, fail = self._do_reload(targets)
        desc = f"{ui_icon('reload')} Перезагружено когов: **{len(ok)}/{len(targets)}**"
        if fail:
            desc += "\n\n**Ошибки:**\n" + "\n".join(f"• `{e}` — {type(ex).__name__}: {ex}"
                                                     for e, ex in fail[:10])
        await ctx.send(embed=disnake.Embed(title="Перезагрузка когов", description=desc,
                                           color=SUCCESS_COLOR if not fail else WARNING_COLOR))

    @commands.command(name="dbreset", aliases=["сброс-бд", "wipedb", "resetdb", "сбросить-бд"])
    async def dbreset_cmd(self, ctx: commands.Context, scope: str = "", confirm: str = ""):
        if not ctx.guild or ctx.author.id != ctx.guild.owner_id:
            await ctx.send(embed=disnake.Embed(
                description="Сброс базы может делать **только владелец сервера**. "
                            "Удобнее — через `!admin`.", color=ERROR_COLOR))
            return
        tables = self._resolve_tables(scope) if scope else None
        if not scope or tables is None:
            scopes_line = "`all`, `full`, " + ", ".join(f"`{k}`" for k in DB_SCOPES)
            await ctx.send(embed=disnake.Embed(
                title="Сброс базы данных",
                description="Проще через `!admin`. Либо: `!dbreset <раздел> confirm`.\n\n" + scopes_line,
                color=WARNING_COLOR))
            return
        if confirm.lower() not in ("confirm", "да", "yes", "подтвердить"):
            await ctx.send(embed=disnake.Embed(
                title="Подтвердите сброс",
                description=(f"Очистится таблиц: **{len(tables)}** (`{scope}`):\n`{', '.join(tables)}`\n\n"
                            f"Необратимо. Подтвердите: **`!dbreset {scope} confirm`**"),
                color=ERROR_COLOR))
            return
        cleared, total, errors = self._do_reset(tables)
        if scope in ("all", "full", "map"):
            self.bot.dispatch("map_dirty")
        desc = (f"{ui_icon('dbreset')} Раздел `{scope}` сброшен · "
                f"таблиц **{cleared}/{len(tables)}**, строк **{total}**")
        if scope == "full":
            desc += "\n-# Настройки сброшены — выполните `!autoconfig`/`!setupserver`."
        await ctx.send(embed=disnake.Embed(title="База сброшена", description=desc, color=SUCCESS_COLOR))


    @commands.command(name="dbinfo", aliases=["бд", "дб", "dbstatus", "гдебаза"])
    async def dbinfo_cmd(self, ctx: commands.Context):
        """Показывает, ГДЕ физически лежит база и что в ней — для диагностики."""
        if not self._can(ctx.author):
            await ctx.send(embed=disnake.Embed(
                description="Нет доступа (`!perm`).", color=ERROR_COLOR))
            return
        import os
        exists = os.path.exists(DB_PATH)
        size_kb = (os.path.getsize(DB_PATH) / 1024) if exists else 0
        env = os.getenv("GAME_DB_PATH") or os.getenv("DB_PATH")

        counts: dict[str, int] = {}
        cfg_keys = 0
        try:
            con = sqlite3.connect(DB_PATH)
            cur = con.cursor()
            for label, table in (("Страны", "countries"), ("Политика", "politics"),
                                 ("Санкции", "sanctions"), ("Права команд", "command_perms")):
                try:
                    cur.execute(f"SELECT COUNT(*) FROM {table}")
                    counts[label] = cur.fetchone()[0]
                except sqlite3.Error:
                    counts[label] = -1
            try:
                cur.execute("SELECT COUNT(*) FROM server_config")
                cfg_keys = cur.fetchone()[0]
            except sqlite3.Error:
                cfg_keys = -1
            con.close()
        except sqlite3.Error as e:
            await ctx.send(embed=disnake.Embed(
                title="Ошибка доступа к базе",
                description=f"Не удалось открыть `{DB_PATH}`:\n`{e}`", color=ERROR_COLOR))
            return

        src = f"переменная `GAME_DB_PATH`" if env else "по умолчанию (`data/game.db`)"
        lines = [
            f"**Путь:** `{DB_PATH}`",
            f"**Источник пути:** {src}",
            f"**Файл существует:** {'да' if exists else 'НЕТ (пустая будет создана)'}",
            f"**Размер:** {size_kb:.0f} КБ",
            "",
            f"**Стран зарегистрировано:** {counts.get('Страны', '?')}",
            f"**Привязок каналов/ролей (server_config):** {cfg_keys}",
            f"**Записей политики:** {counts.get('Политика', '?')}",
            f"**Санкций:** {counts.get('Санкции', '?')}",
            f"**Выданных прав (!perm):** {counts.get('Права команд', '?')}",
        ]
        color = SUCCESS_COLOR if (exists and counts.get("Страны", 0) > 0) else WARNING_COLOR
        await ctx.send(embed=disnake.Embed(
            title=f"{ui_icon('reload')} Состояние базы данных",
            description="\n".join(lines), color=color))


def setup(bot: commands.Bot):
    bot.add_cog(AdminToolsCog(bot))
