"""
Построение сервера с нуля — !setupserver (владелец/админ, с подтверждением).

Создаёт роли (с цветами и правами), категории и каналы с эмодзи, расставляет
доступ (гость / держава / штаб / админ), пишет все ID в server_config, чтобы бот
сразу использовал новую структуру без правки config.py. Привязывает карту мира
к созданному каналу и инициализирует игровой год.

Идемпотентно: существующие роли/каналы (по имени) переиспользуются, дубликаты
не плодятся. Запуск: !setupserver → показывает план → !setupserver confirm.
"""

import logging

import disnake
from disnake.ext import commands

import config
from utils import MapState, ADMINISTRATOR, COMMAND_COLOR, ERROR_COLOR, SUCCESS_COLOR, WARNING_COLOR
from utils.serverconfig import rid, sset, sget

log = logging.getLogger("serversetup")

PO = disnake.PermissionOverwrite

# ── Роли: (ключ, имя, цвет, пресет прав, hoist) — сверху вниз по иерархии ─────
# ВАЖНО: НИ У ОДНОЙ роли нет Discord-права «Администратор» — всевластен только
# владелец сервера. Штабные роли получают все права КРОМЕ administrator (пресет
# "full") и доступ к админ-командам бота через систему !perm (авто-grant ниже).
ROLES = [
    ("ROLE_FOUNDER",      "👑 Основатель",               0xE6B45A, "full",    True),
    ("ROLE_COOWNER",      "🜲 Соправитель",               0xF0D29C, "full",    True),
    ("ROLE_HEAD_ADMIN",   "⚙️ Верховный администратор",   0x7FB8EC, "full",    True),
    ("ROLE_ADMIN",        "⚙️ Администратор",             0x4D9DE0, "full",    True),
    ("ROLE_JR_ADMIN",     "⚙️ Младший администратор",     0x3570A8, "jradmin", True),
    ("ROLE_HEAD_CURATOR", "🛡️ Главный куратор",           0x2E6FB0, "curator", True),
    ("ROLE_CURATOR",      "🛡️ Куратор",                   0x43708F, "curator", True),
    ("ROLE_MOD",          "🔨 Модератор",                 0x4E7FA0, "mod",     True),
    ("ROLE_HELPER",       "🔨 Хелпер",                    0x6E9ABC, "helper",  True),
    ("ROLE_REGISTERED",   "✅ Зарегистрирован",           0x6CC2E8, "member",  True),
    ("ROLE_MEMBER",       "👤 Участник",                  0x9AA7B4, "member",  False),
    ("ROLE_REGISTERING",  "📝 На регистрации",            0x8A94A0, "none",    False),
]

STAFF_KEYS = ["ROLE_FOUNDER", "ROLE_COOWNER", "ROLE_HEAD_ADMIN", "ROLE_ADMIN", "ROLE_JR_ADMIN",
              "ROLE_HEAD_CURATOR", "ROLE_CURATOR", "ROLE_MOD", "ROLE_HELPER"]
ADMIN_KEYS = ["ROLE_FOUNDER", "ROLE_COOWNER", "ROLE_HEAD_ADMIN", "ROLE_ADMIN", "ROLE_JR_ADMIN"]
# Кому авто-выдать доступ ко ВСЕМ админ-командам (!perm scope '*'): админы + кураторы.
STAR_GRANT_KEYS = ADMIN_KEYS + ["ROLE_HEAD_CURATOR", "ROLE_CURATOR"]
# Игровые каналы видят зарегистрированные + штаб.
PLAYER_KEYS = ["ROLE_REGISTERED"] + STAFF_KEYS

# ── Структура: (имя категории, видимость, [(тип, имя, ключ|None, readonly?)]) ─
# видимость: all · all_voice · stats · player · staff · admin
STRUCTURE = [
    ("📊 СТАТИСТИКА", "stats", [
        ("voice", "👥・Участников: 0", "STAT_MEMBERS", False),
        ("voice", "🤖・Ботов: 0", "STAT_BOTS", False),
        ("voice", "🌍・Держав: 0", "STAT_PLAYERS", False),
        ("voice", "📅・Год: —", "STAT_YEAR", False),
    ]),
    ("📜 ИНФОРМАЦИЯ", "all", [
        ("text", "📜・правила", "CH_RULES", True),
        ("text", "📖・гайд", None, True),
        ("text", "📣・анонсы", None, True),
        ("text", "📝・регистрация", "CH_REGISTER", False),
        ("text", "🗺️・карта-мира", "CH_MAP", False),
    ]),
    ("🌍 МИРОВАЯ АРЕНА", "player", [
        ("text", "📰・мировые-новости", "CH_NEWS", False),
        ("text", "🎲・события", "CH_EVENTS", False),
        ("text", "💰・доходы", "CH_INCOME", False),
        ("text", "🏭・экономика-и-ресурсы", None, False),
        ("text", "🔬・развитие-и-техника", None, False),
        ("text", "⚔️・армия-и-война", None, False),
    ]),
    ("⚔️ КОНФЛИКТ И ДИПЛОМАТИЯ", "player", [
        ("text", "🤝・дипломатия", "CH_DIPLO", False),
        ("text", "🛡️・альянсы", "CH_ALLIANCE", False),
        ("text", "☢️・ядерная-программа", "CH_NUCLEAR", False),
        ("text", "🪖・чвк", "CH_PMC", False),
        ("text", "🚫・санкции", "CH_SANCTIONS", False),
        ("text", "⏳・ультиматумы", "CH_ULTIMATUM", False),
        ("text", "📢・объявления-войны", None, False),
        ("text", "🕵️・шпионаж", "CH_SPY", False),
    ]),
    # ООН: новости и резолюции пишет только бот (игроки читают и голосуют кнопками);
    # чат Совбеза — доступ выдаёт бот поштучно членам СБ (cogs/un.py), без ролей.
    ("🕊️ ООН", "player", [
        ("text", "📰・новости-оон", "CH_UN_NEWS", "player_ro"),
        ("text", "📜・резолюции-оон", "CH_UN_RES", "player_ro"),
        ("text", "🛡️・совбез-оон", "CH_UN_SC", "sc_only"),
        ("text", "💬・генассамблея-оон", "CH_UN_GA", False),
    ]),
    ("💬 ОБЩЕНИЕ", "all", [
        ("text", "💬・общий-чат", None, False),
        ("text", "🖼️・медиа", None, False),
        ("text", "☕・оффтоп", None, False),
        ("text", "🤖・команды-бота", None, False),
    ]),
    ("🔊 ГОЛОСОВЫЕ", "all_voice", [
        ("voice", "🎙️・Трибуна", None, False),
        ("voice", "🗣️・Переговоры I", None, False),
        ("voice", "🗣️・Переговоры II", None, False),
        ("voice", "💤・AFK", None, False),
    ]),
    ("🛠️ ШТАБ", "staff", [
        ("text", "🛠️・админ-чат", None, False),
        ("text", "🖥️・консоль", None, False),
        ("text", "📥・заявки", None, False),
        ("voice", "🎧・Админ-войс", None, False),
    ]),
    ("📂 ЛОГИ", "admin", [
        ("text", "🚪・вход-выход", "CH_LOG_JOINS", False),
        ("text", "✉️・сообщения", "CH_LOG_MESSAGES", False),
        ("text", "🛡️・модерация", "CH_LOG_MOD", False),
        ("text", "📁・игровые-события", "CH_LOG", False),
        ("text", "🧾・логи-бота", "CH_LOG_BOT", False),
        ("text", "🔈・голос-логи", "CH_LOG_VOICE", False),
    ]),
]


def _perms(preset: str) -> disnake.Permissions:
    if preset == "full":
        # все права КРОМЕ administrator (единственный с админкой — владелец сервера)
        p = disnake.Permissions.all()
        p.administrator = False
        return p
    if preset == "member":
        return disnake.Permissions(
            view_channel=True, read_message_history=True, send_messages=True,
            send_messages_in_threads=True, create_public_threads=True, add_reactions=True,
            embed_links=True, attach_files=True, use_external_emojis=True,
            connect=True, speak=True, stream=True, use_voice_activation=True,
            change_nickname=True)
    if preset == "jradmin":
        return disnake.Permissions(
            manage_channels=True, manage_roles=True, kick_members=True, ban_members=True,
            manage_messages=True, moderate_members=True, manage_nicknames=True, view_audit_log=True,
            mute_members=True, move_members=True, manage_threads=True)
    if preset == "curator":
        return disnake.Permissions(
            manage_messages=True, moderate_members=True, mute_members=True, move_members=True,
            manage_nicknames=True, manage_threads=True)
    if preset == "mod":
        return disnake.Permissions(manage_messages=True, moderate_members=True, kick_members=True,
                                   manage_nicknames=True)
    if preset == "helper":
        return disnake.Permissions(manage_messages=True, moderate_members=True)
    return disnake.Permissions.none()


def _stored(guild, key: str, kind: str):
    """Объект по ID, сохранённому в БД (переживает переименование). kind: role | category | channel."""
    cur = sget(key)
    if not cur:
        return None
    try:
        obj = guild.get_role(int(cur)) if kind == "role" else guild.get_channel(int(cur))
    except (TypeError, ValueError):
        return None
    if kind == "category" and not isinstance(obj, disnake.CategoryChannel):
        return None
    if kind == "channel" and isinstance(obj, disnake.CategoryChannel):
        return None
    return obj


def _unbound_channel(guild, key: str) -> bool:
    """Ключ канала ещё не привязан или привязан к удалённому каналу."""
    cur = sget(key)
    return not cur or guild.get_channel(int(cur)) is None


def _unbound_role(guild, key: str) -> bool:
    cur = sget(key)
    return not cur or guild.get_role(int(cur)) is None


class ServerSetupCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="setupserver", aliases=["построить-сервер", "setup-server", "собрать-сервер"])
    async def setupserver_cmd(self, ctx: commands.Context, mode: str = "", confirm: str = ""):
        # Команда создаёт И удаляет роли/каналы — доступна ТОЛЬКО владельцу сервера.
        if not ctx.guild or ctx.author.id != ctx.guild.owner_id:
            await ctx.send(embed=disnake.Embed(
                description="🔒 Эту команду может выполнять **только владелец сервера**.", color=ERROR_COLOR))
            return

        mode = mode.lower()
        ok_words = ("confirm", "да", "yes")
        if mode == "wipe":
            if confirm.lower() not in ok_words:
                await ctx.send(embed=disnake.Embed(
                    title="⚠️ Полная пересборка (wipe)",
                    description=("Создам новую структуру, затем **УДАЛЮ все старые каналы** и **все роли ниже "
                                 "роли бота** (кроме @everyone и ботовых). Это **необратимо**.\n\n"
                                 "Подтвердите: **`!setupserver wipe confirm`**"),
                    color=ERROR_COLOR))
                return
            wipe = True
        elif mode in ok_words:
            wipe = False
        else:
            cats = len(STRUCTURE)
            chans = sum(len(c[2]) for c in STRUCTURE)
            e = disnake.Embed(
                title="🏗️ Построение сервера",
                description=(f"Будет создано: **{len(ROLES)} ролей**, **{cats} категорий**, **{chans} каналов** "
                            "с правами (гость / держава / штаб / админ).\n\n"
                            "• **`!setupserver confirm`** — добавить только НОВЫЕ роли, категории и каналы и настроить "
                            "права только у них. Существующие каналы, роли, их права и сообщения не трогаются\n"
                            "• **`!setupserver wipe confirm`** — пересобрать с нуля (удалить старые каналы и роли)"),
                color=WARNING_COLOR)
            e.set_footer(text="Роли создаются ниже роли бота — при желании поднимите выше вручную.")
            await ctx.send(embed=e)
            return

        guild = ctx.guild
        # Пока бот сам перестраивает сервер — анти-нюк (guard) должен молчать,
        # иначе он откатывает удаляемые каналы/роли и дерётся с пересборкой.
        import utils.guard as GU
        GU.suppress(guild.id)
        # failsafe: даже при ошибке снимем подавление через 3 минуты.
        self.bot.loop.call_later(180, GU.unsuppress, guild.id)
        progress = await ctx.send(embed=disnake.Embed(description="⏳ Создаю роли…", color=COMMAND_COLOR))
        roles_map: dict[str, disnake.Role] = {}
        created_role_ids: set[int] = set()

        # ── роли ──
        created_roles = 0
        for key, name, color, preset, hoist in ROLES:
            # сначала по сохранённому ID (роль могли переименовать), потом по имени
            role = _stored(guild, key, "role") or disnake.utils.get(guild.roles, name=name)
            if role is None:
                try:
                    role = await guild.create_role(
                        name=name, colour=disnake.Colour(color), permissions=_perms(preset),
                        hoist=hoist, mentionable=False, reason="setupserver")
                    created_roles += 1
                except disnake.HTTPException:
                    log.exception("Не удалось создать роль %s", name)
                    continue
            elif wipe:
                # пересборка: приводим права существующей роли к пресету (напр. снимаем старую админку);
                # в обычном режиме существующие роли НЕ трогаем
                try:
                    await role.edit(permissions=_perms(preset), reason="setupserver sync perms")
                except disnake.HTTPException:
                    pass
            roles_map[key] = role
            created_role_ids.add(role.id)
            if wipe or _unbound_role(guild, key):   # свою привязку (!setrole) не перезаписываем
                sset(key, role.id)
        if wipe or _unbound_role(guild, "PROFILE_ROLE"):
            sset("PROFILE_ROLE", roles_map["ROLE_REGISTERED"].id)  # регистрация выдаёт эту роль

        # ── авто-выдача доступа ко ВСЕМ админ-командам штабу (!perm scope '*') ──
        from utils import CommandPerms
        cp = CommandPerms()
        for k in STAR_GRANT_KEYS:
            r = roles_map.get(k)
            if r:
                cp.grant("*", "role", r.id)

        await progress.edit(embed=disnake.Embed(description="⏳ Создаю категории и каналы…", color=COMMAND_COLOR))

        # ── категории и каналы ──
        created_cats = created_chans = 0
        new_ch_ids: set[int] = set()   # каналы, созданные ИМЕННО сейчас
        created_ch_ids: set[int] = set()
        created_cat_ids: set[int] = set()
        tagged: dict[str, int] = {}
        report_target = None
        for cat_name, vis, channels in STRUCTURE:
            ow = self._overwrites(guild, vis, roles_map)
            cat_key = f"SETUP_CAT:{cat_name}"   # ID категории в БД — переименование не плодит дубли
            category = _stored(guild, cat_key, "category") or disnake.utils.get(guild.categories, name=cat_name)
            if category is None:
                category = await guild.create_category(cat_name, overwrites=ow, reason="setupserver")
                created_cats += 1
            elif wipe:
                # пересборка: права категории к стандарту; в обычном режиме существующие НЕ трогаем
                try:
                    await category.edit(overwrites=ow)
                except disnake.HTTPException:
                    pass
            created_cat_ids.add(category.id)
            sset(cat_key, category.id)

            for ctype, cname, ckey, readonly in channels:
                ch_key = f"SETUP_CH:{cname}"     # ID канала в БД — переименование не плодит дубли
                ch = None
                if ckey and not wipe and not _unbound_channel(guild, ckey):
                    ch = guild.get_channel(int(sget(ckey)))   # у ключа уже есть свой живой канал — дубль не создаём
                if ch is None:
                    ch = _stored(guild, ch_key, "channel")
                if ch is None:
                    ch = disnake.utils.get(guild.channels, name=cname.lower() if ctype == "text" else cname,
                                           category_id=category.id)
                if ch is None:
                    try:
                        if ctype == "voice":
                            cow = dict(ow)
                            if vis == "stats":  # стат-каналы заблокированы на вход
                                cow[guild.default_role] = PO(view_channel=True, connect=False)
                            ch = await guild.create_voice_channel(cname, category=category, overwrites=cow,
                                                                  reason="setupserver")
                        else:
                            cow = dict(ow)  # disnake требует dict, не None
                            if readonly == "player_ro":   # видят игроки, пишет только бот
                                reg = roles_map.get("ROLE_REGISTERED")
                                if reg:
                                    cow[reg] = PO(view_channel=True, send_messages=False, add_reactions=True)
                            elif readonly == "sc_only":   # закрыт для всех, кроме штаба (членов СБ добавит бот)
                                reg = roles_map.get("ROLE_REGISTERED")
                                if reg:
                                    cow[reg] = PO(view_channel=False)
                            elif readonly:
                                cow[guild.default_role] = PO(view_channel=True, send_messages=False,
                                                             add_reactions=True)
                            ch = await guild.create_text_channel(cname, category=category, overwrites=cow,
                                                                 reason="setupserver")
                        created_chans += 1
                        new_ch_ids.add(ch.id)
                    except disnake.HTTPException:
                        log.exception("Не удалось создать канал %s", cname)
                        continue
                if ch:
                    created_ch_ids.add(ch.id)
                    sset(ch_key, ch.id)
                    if ctype == "text" and readonly is False and report_target is None:
                        report_target = ch
                if ckey and ch:
                    # привязку пишем для нового канала или если ключ пуст/его канал удалён;
                    # свою привязку (!setchannel) не перезаписываем
                    if wipe or ch.id in new_ch_ids or _unbound_channel(guild, ckey):
                        sset(ckey, ch.id)
                    tagged[ckey] = sget(ckey) or ch.id

        # ── привязки: карта, год, игровые каналы ──
        # карту перепривязываем только если её канал создан сейчас или карта ещё не настроена
        # (иначе бот потерял бы своё сообщение с картой и выложил новое)
        if "CH_MAP" in tagged and (tagged["CH_MAP"] in new_ch_ids or not MapState().get_channel_id()):
            MapState().set_location(tagged["CH_MAP"], None)
            self.bot.dispatch("map_dirty")
        if sget("GAME_YEAR") is None:
            import datetime
            sset("GAME_YEAR", datetime.datetime.now(config.TZ).year)
            sset("GAME_HALF", 1)
        stats = self.bot.get_cog("ServerStatsCog")
        if stats:
            try:
                await stats.refresh_stats()
                await stats.refresh_year_channel()
            except Exception:
                log.exception("Не удалось обновить статистику после сборки")

        # ── wipe: удалить старую структуру (после создания новой) ──
        deleted_ch = deleted_roles = 0
        if wipe:
            try:
                await progress.edit(embed=disnake.Embed(
                    description="🧹 Удаляю старые каналы и роли…", color=WARNING_COLOR))
            except disnake.HTTPException:
                pass
            for ch in list(guild.channels):
                if ch.id in created_ch_ids or ch.id in created_cat_ids:
                    continue
                try:
                    await ch.delete(reason="setupserver wipe")
                    deleted_ch += 1
                except disnake.HTTPException:
                    pass
            me = guild.me
            for role in list(guild.roles):
                if role.is_default() or role.managed or role.id in created_role_ids:
                    continue
                if me and role >= me.top_role:  # роли выше/равные роли бота не трогаем
                    continue
                try:
                    await role.delete(reason="setupserver wipe")
                    deleted_roles += 1
                except disnake.HTTPException:
                    pass

        # ── перестройка завершена: возвращаем guard и даём ему свежий снапшот
        #    НОВОЙ структуры (чтобы анти-нюк защищал уже новые каналы/роли) ──
        GU.unsuppress(guild.id)
        gcog = self.bot.get_cog("GuardCog")
        if gcog:
            try:
                gcog._snap(guild)
            except Exception:
                log.exception("Не удалось обновить снапшот guard после сборки")

        # ── отчёт ──
        desc = f"Создано: **{created_roles}** ролей, **{created_cats}** категорий, **{created_chans}** каналов.\n"
        if wipe:
            desc += f"Удалено старого: **{deleted_ch}** каналов, **{deleted_roles}** ролей.\n"
        desc += ("\nВсе ID записаны — бот уже использует новую структуру (карта, новости, события, доходы, "
                 "логи, статистика, роль «Зарегистрирован»).\n-# При входе выдаются «Участник» + "
                 "«На регистрации»; после регистрации — «Зарегистрирован».\n"
                 "-# Проверьте: `!mapsync`, `!setyear <год>`. Права на админ-команды — `!perm`.")
        done = disnake.Embed(title="✅ Сервер построен", description=desc, color=SUCCESS_COLOR)
        done.add_field(name="Ключевые каналы",
                       value="\n".join(f"`{k}` → <#{v}>" for k, v in tagged.items()
                                       if k in ("CH_MAP", "CH_NEWS", "CH_EVENTS", "CH_INCOME",
                                                "CH_REGISTER", "CH_LOG")) or "—",
                       inline=False)
        # в режиме wipe канал ctx мог быть удалён — отчёт в новый канал / в ЛС
        try:
            if wipe:
                await (report_target or ctx.author).send(embed=done)
            else:
                await progress.edit(embed=done)
        except disnake.HTTPException:
            try:
                await ctx.author.send(embed=done)
            except disnake.HTTPException:
                pass

    def _overwrites(self, guild, vis, roles_map) -> dict:
        everyone = guild.default_role
        ow = {}
        if vis in ("all", "all_voice", "stats"):
            ow[everyone] = PO(view_channel=True)
            return ow
        ow[everyone] = PO(view_channel=False)
        keys = PLAYER_KEYS if vis == "player" else (STAFF_KEYS if vis == "staff" else ADMIN_KEYS)
        for k in keys:
            r = roles_map.get(k)
            if r:
                ow[r] = PO(view_channel=True)
        return ow


def setup(bot: commands.Bot):
    bot.add_cog(ServerSetupCog(bot))
