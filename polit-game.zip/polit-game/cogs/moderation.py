"""
🛡️ МОДЕРАЦИЯ — !мод / !mod, текстовые команды и !очистить

ПАНЕЛЬ: `!мод [@участник]` → кнопка «Открыть панель» → ПРИВАТНАЯ панель (видна только модератору):
выбор участника, сведения (аккаунт, вход, тайм-аут, варны), кнопки Варн · Тайм-аут · Снять тайм-аут ·
Кик · Бан · Разбан по ID · Снять варны. Причина — в окне.

ПРАВА — через систему !perm, ОТДЕЛЬНО на каждое действие: mod-warn, mod-timeout, mod-kick, mod-ban, purge.
Панель у всех одна; кнопка без права неактивна (верховному админу — всё или «*», обычному — например,
только mod-timeout). Владелец сервера и обладатели «*» могут всё.

ЗАЩИТА: нельзя наказать себя, владельца, бота и того, чья высшая роль не ниже твоей (кроме владельца);
бот тоже должен стоять выше цели. Авто-эскалация варнов: 3 → тайм-аут на сутки, 5 → на неделю.
Журнал — канал логов модерации (CH_LOG_MOD), нарушитель получает ЛС с причиной.

ТЕКСТОМ: !warn @u причина · !timeout @u 1ч причина · !untimeout @u · !kick @u причина ·
!ban @u причина · !unban id · !warns @u · !clearwarns @u · !очистить N [@u] (до 500).
Только кастом-иконки.
"""

import datetime
import logging
import re
import time

import disnake
from disnake.ext import commands

from utils import ModWarns, COMMAND_COLOR, SUCCESS_COLOR, ERROR_COLOR, WARNING_COLOR
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
from utils.perms import has_command_access

log = logging.getLogger("moderation")

SCOPES = ("mod-warn", "mod-timeout", "mod-kick", "mod-ban", "purge")
DURATIONS = [("10 минут", 600), ("30 минут", 1800), ("1 час", 3600), ("6 часов", 6 * 3600),
             ("12 часов", 12 * 3600), ("1 день", 86400), ("3 дня", 3 * 86400), ("7 дней", 7 * 86400)]
ESCALATION = {3: 86400, 5: 7 * 86400}      # число варнов → авто-тайм-аут (сек)
PURGE_MAX = 500
MOD_COLOR = 0x6F8FAF


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s and s.startswith("<") else None
    except Exception:
        return None


def _dur_text(sec: int) -> str:
    for label, v in DURATIONS:
        if v == sec:
            return label
    if sec % 86400 == 0:
        return f"{sec // 86400} д"
    if sec % 3600 == 0:
        return f"{sec // 3600} ч"
    return f"{sec // 60} мин"


def parse_duration(text: str) -> int | None:
    """«10м», «1ч», «2д», «30min», «1h», «7d» → секунды (макс. 28 дней — лимит Discord)."""
    m = re.fullmatch(r"\s*(\d+)\s*([a-zа-яё]*)\s*", (text or "").lower())
    if not m:
        return None
    n, unit = int(m.group(1)), m.group(2)
    if unit in ("", "м", "мин", "m", "min"):
        sec = n * 60
    elif unit in ("ч", "час", "h", "hour"):
        sec = n * 3600
    elif unit in ("д", "дн", "день", "дня", "дней", "d", "day"):
        sec = n * 86400
    else:
        return None
    return min(sec, 28 * 86400) if sec > 0 else None


class ModerationCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.warns = ModWarns()
        self._sessions: dict[int, dict] = {}

    # ═══════════════ ПРАВА И ПРОВЕРКИ ═══════════════
    @staticmethod
    def can(member, scope: str) -> bool:
        return bool(member) and has_command_access(member, scope)

    def any_scope(self, member) -> bool:
        return any(self.can(member, s) for s in SCOPES)

    @staticmethod
    def _block(mod: disnake.Member, target: disnake.Member | None) -> str:
        """Почему модератор не может наказать цель (пусто — может)."""
        if target is None:
            return "участник не на сервере"
        g = mod.guild
        if target.id == mod.id:
            return "нельзя наказать себя"
        if target.id == g.owner_id:
            return "нельзя наказать владельца сервера"
        if target.bot:
            return "ботов наказывать нельзя"
        if mod.id != g.owner_id and target.top_role >= mod.top_role:
            return "роль участника не ниже вашей"
        if g.me and target.top_role >= g.me.top_role:
            return "роль участника выше роли бота — бот не сможет"
        return ""

    # ═══════════════ ЖУРНАЛ / ЛС ═══════════════
    async def _log(self, guild, text: str, color=MOD_COLOR):
        ch_id = rid("CH_LOG_MOD", 0) or rid("CH_LOG", 0)
        ch = guild.get_channel(ch_id) if (guild and ch_id) else None
        if not ch:
            return
        try:
            await ch.send(embed=disnake.Embed(description=text, color=color,
                                              timestamp=datetime.datetime.now(datetime.timezone.utc)))
        except Exception:
            pass

    async def _dm(self, user, text: str):
        try:
            await user.send(embed=disnake.Embed(description=text, color=WARNING_COLOR))
        except Exception:
            pass

    # ═══════════════ ДЕЙСТВИЯ (общие для панели и текста) ═══════════════
    async def do_warn(self, mod, target, reason: str) -> str:
        if not self.can(mod, "mod-warn"):
            return f"{ui_icon('lock')} Нет права выдавать варны (`mod-warn`)."
        b = self._block(mod, target)
        if b:
            return f"{ui_icon('reject')} {b}."
        n = self.warns.add(target.id, mod.id, reason, int(time.time()))
        g = mod.guild
        await self._dm(target, f"{ui_icon('mod_warn')} Вы получили **предупреждение** на сервере **{g.name}** "
                               f"(всего {n}).\nПричина: {reason}")
        await self._log(g, f"{ui_icon('mod_warn')} **Варн №{n}** · {target.mention} · модератор {mod.mention}\n"
                           f"Причина: {reason}", WARNING_COLOR)
        note = f"{ui_icon('mod_warn')} {target.mention} получил варн №{n}. Причина: {reason}"
        if n in ESCALATION:
            sec = ESCALATION[n]
            try:
                await target.timeout(duration=sec, reason=f"Авто: {n} варнов")
                note += f"\n{ui_icon('mod_timeout')} Авто-эскалация: тайм-аут на **{_dur_text(sec)}** ({n} варнов)."
                await self._log(g, f"{ui_icon('mod_timeout')} **Авто-тайм-аут** {target.mention} на "
                                   f"{_dur_text(sec)} — {n} варнов.", WARNING_COLOR)
            except disnake.HTTPException:
                note += "\n-# Авто-тайм-аут не удался (нет прав у бота)."
        return note

    async def do_timeout(self, mod, target, sec: int, reason: str) -> str:
        if not self.can(mod, "mod-timeout"):
            return f"{ui_icon('lock')} Нет права на тайм-аут (`mod-timeout`)."
        b = self._block(mod, target)
        if b:
            return f"{ui_icon('reject')} {b}."
        try:
            await target.timeout(duration=sec, reason=f"{mod}: {reason}")
        except disnake.HTTPException as e:
            return f"{ui_icon('reject')} Discord не дал выдать тайм-аут: {e.text or e}"
        await self._dm(target, f"{ui_icon('mod_timeout')} Вам выдан **тайм-аут** на {_dur_text(sec)} на сервере "
                               f"**{mod.guild.name}**.\nПричина: {reason}")
        await self._log(mod.guild, f"{ui_icon('mod_timeout')} **Тайм-аут {_dur_text(sec)}** · {target.mention} · "
                                   f"модератор {mod.mention}\nПричина: {reason}", WARNING_COLOR)
        return f"{ui_icon('mod_timeout')} {target.mention} — тайм-аут на **{_dur_text(sec)}**. Причина: {reason}"

    async def do_untimeout(self, mod, target) -> str:
        if not self.can(mod, "mod-timeout"):
            return f"{ui_icon('lock')} Нет права на тайм-аут (`mod-timeout`)."
        if target is None:
            return f"{ui_icon('reject')} Участник не на сервере."
        try:
            await target.timeout(duration=None, reason=f"{mod}: снят тайм-аут")
        except disnake.HTTPException as e:
            return f"{ui_icon('reject')} Не удалось: {e.text or e}"
        await self._log(mod.guild, f"{ui_icon('check')} **Тайм-аут снят** · {target.mention} · модератор {mod.mention}",
                        SUCCESS_COLOR)
        return f"{ui_icon('check')} Тайм-аут {target.mention} снят."

    async def do_kick(self, mod, target, reason: str) -> str:
        if not self.can(mod, "mod-kick"):
            return f"{ui_icon('lock')} Нет права кикать (`mod-kick`)."
        b = self._block(mod, target)
        if b:
            return f"{ui_icon('reject')} {b}."
        await self._dm(target, f"{ui_icon('expel')} Вы исключены с сервера **{mod.guild.name}**.\nПричина: {reason}")
        try:
            await target.kick(reason=f"{mod}: {reason}")
        except disnake.HTTPException as e:
            return f"{ui_icon('reject')} Discord не дал кикнуть: {e.text or e}"
        await self._log(mod.guild, f"{ui_icon('expel')} **Кик** · {target} ({target.id}) · модератор {mod.mention}\n"
                                   f"Причина: {reason}", ERROR_COLOR)
        return f"{ui_icon('expel')} **{target}** исключён. Причина: {reason}"

    async def do_ban(self, mod, target, reason: str) -> str:
        if not self.can(mod, "mod-ban"):
            return f"{ui_icon('lock')} Нет права банить (`mod-ban`)."
        b = self._block(mod, target)
        if b:
            return f"{ui_icon('reject')} {b}."
        await self._dm(target, f"{ui_icon('mod_ban')} Вы забанены на сервере **{mod.guild.name}**.\nПричина: {reason}")
        try:
            await mod.guild.ban(target, reason=f"{mod}: {reason}", clean_history_duration=0)
        except disnake.HTTPException as e:
            return f"{ui_icon('reject')} Discord не дал забанить: {e.text or e}"
        await self._log(mod.guild, f"{ui_icon('mod_ban')} **Бан** · {target} ({target.id}) · модератор {mod.mention}\n"
                                   f"Причина: {reason}", ERROR_COLOR)
        return f"{ui_icon('mod_ban')} **{target}** забанен. Причина: {reason}"

    async def do_unban(self, mod, user_id: int) -> str:
        if not self.can(mod, "mod-ban"):
            return f"{ui_icon('lock')} Нет права разбанивать (`mod-ban`)."
        try:
            user = await self.bot.fetch_user(user_id)
            await mod.guild.unban(user, reason=f"{mod}: разбан")
        except disnake.NotFound:
            return f"{ui_icon('reject')} Такого бана нет (или неверный ID)."
        except disnake.HTTPException as e:
            return f"{ui_icon('reject')} Не удалось: {e.text or e}"
        await self._log(mod.guild, f"{ui_icon('mod_unban')} **Разбан** · {user} ({user.id}) · модератор {mod.mention}",
                        SUCCESS_COLOR)
        return f"{ui_icon('mod_unban')} **{user}** разбанен."

    async def do_clearwarns(self, mod, target) -> str:
        if not self.can(mod, "mod-warn"):
            return f"{ui_icon('lock')} Нет права на варны (`mod-warn`)."
        if target is None:
            return f"{ui_icon('reject')} Участник не найден."
        n = self.warns.clear(target.id)
        await self._log(mod.guild, f"{ui_icon('check')} **Варны сняты ({n})** · {target.mention} · модератор {mod.mention}",
                        SUCCESS_COLOR)
        return f"{ui_icon('check')} С {target.mention} снято варнов: **{n}**."

    # ═══════════════ ПАНЕЛЬ ═══════════════
    def _session(self, uid: int) -> dict:
        return self._sessions.setdefault(uid, {"target": None, "dur": 3600})

    def _target_info(self, guild, uid: int | None) -> str:
        if not uid:
            return "-# Выберите участника в меню ниже."
        m = guild.get_member(uid)
        if not m:
            return f"-# Участник <@{uid}> не на сервере (можно только разбанить по ID)."
        created = int(m.created_at.timestamp())
        joined = int(m.joined_at.timestamp()) if m.joined_at else 0
        to = m.current_timeout
        warns = self.warns.of(uid)
        lines = [f"### {ui_icon('soldier')} {m.mention} · `{m}`",
                 f"Аккаунт создан <t:{created}:R> · на сервере с <t:{joined}:D>" if joined else
                 f"Аккаунт создан <t:{created}:R>",
                 f"Высшая роль: {m.top_role.mention if not m.top_role.is_default() else 'нет'}"]
        if to:
            lines.append(f"{ui_icon('mod_timeout')} В тайм-ауте до <t:{int(to.timestamp())}:f>")
        lines.append(f"{ui_icon('mod_warn')} Варнов: **{len(warns)}**")
        for w in warns[:3]:
            lines.append(f"-# <t:{w['ts']}:d> · {w['reason'][:80]} · <@{w['moderator']}>")
        return "\n".join(lines)

    def panel(self, mod: disnake.Member, note: str | None = None) -> Panel:
        s = self._session(mod.id)
        g = mod.guild
        target = g.get_member(s["target"]) if s["target"] else None
        items = [disnake.ui.TextDisplay(f"## {ui_icon('mod')} Модерация")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        items.append(disnake.ui.TextDisplay(self._target_info(g, s["target"])))
        items.append(disnake.ui.ActionRow(disnake.ui.UserSelect(
            custom_id=cid("mod", "pick"), placeholder="Выбрать участника…", min_values=1, max_values=1)))
        items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
            custom_id=cid("mod", "dur"), placeholder="Срок тайм-аута…",
            options=[disnake.SelectOption(label=label, value=str(v), emoji=_pe("mod_timeout"),
                                          default=(v == s["dur"])) for label, v in DURATIONS])))
        B = disnake.ButtonStyle
        has = target is not None
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.secondary, label="Варн", emoji=_pe("mod_warn"),
                              disabled=not (has and self.can(mod, "mod-warn")), custom_id=cid("mod", "warn")),
            disnake.ui.Button(style=B.primary, label=f"Тайм-аут · {_dur_text(s['dur'])}", emoji=_pe("mod_timeout"),
                              disabled=not (has and self.can(mod, "mod-timeout")), custom_id=cid("mod", "timeout")),
            disnake.ui.Button(style=B.success, label="Снять тайм-аут", emoji=_pe("check"),
                              disabled=not (has and self.can(mod, "mod-timeout")), custom_id=cid("mod", "untimeout"))))
        items.append(disnake.ui.ActionRow(
            disnake.ui.Button(style=B.danger, label="Кик", emoji=_pe("expel"),
                              disabled=not (has and self.can(mod, "mod-kick")), custom_id=cid("mod", "kick")),
            disnake.ui.Button(style=B.danger, label="Бан", emoji=_pe("mod_ban"),
                              disabled=not (has and self.can(mod, "mod-ban")), custom_id=cid("mod", "ban")),
            disnake.ui.Button(style=B.secondary, label="Разбан по ID", emoji=_pe("mod_unban"),
                              disabled=not self.can(mod, "mod-ban"), custom_id=cid("mod", "unban")),
            disnake.ui.Button(style=B.secondary, label="Снять варны", emoji=_pe("check"),
                              disabled=not (has and self.can(mod, "mod-warn")), custom_id=cid("mod", "clearwarns"))))
        mine = ", ".join(sc for sc in SCOPES if self.can(mod, sc)) or "нет"
        items.append(disnake.ui.TextDisplay(f"-# Ваши права: {mine}. Права выдаются через `!perm`."))
        p = Panel(timeout=900)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(MOD_COLOR)))
        return p

    def _reason_modal(self, action: str, title: str):
        return disnake.ui.Modal(title=title[:45], custom_id=cid("mod", "m" + action), components=[
            disnake.ui.TextInput(label="Причина", custom_id="reason", style=disnake.TextInputStyle.paragraph,
                                 max_length=300, required=True, placeholder="Например: оскорбления (п. 2.1)")])

    @commands.Cog.listener("on_button_click")
    async def _mod_btn(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("mod:") or not inter.guild:
            return
        _, action, _args = parse_cid(c)
        mod = inter.author
        if not self.any_scope(mod):
            await inter.response.send_message(f"{ui_icon('lock')} У вас нет прав модерации.", ephemeral=True)
            return
        if action == "open":
            await inter.response.send_message(components=self.panel(mod).components, ephemeral=True)
            return
        titles = {"warn": "Варн", "timeout": "Тайм-аут", "kick": "Кик", "ban": "Бан"}
        if action in titles:
            await inter.response.send_modal(self._reason_modal(action, f"{titles[action]}: причина"))
            return
        if action == "unban":
            await inter.response.send_modal(disnake.ui.Modal(
                title="Разбан по ID", custom_id=cid("mod", "munban"), components=[disnake.ui.TextInput(
                    label="ID пользователя", custom_id="uid", style=disnake.TextInputStyle.short, max_length=22)]))
            return
        s = self._session(mod.id)
        target = inter.guild.get_member(s["target"]) if s["target"] else None
        await inter.response.defer()
        if action == "untimeout":
            note = await self.do_untimeout(mod, target)
        elif action == "clearwarns":
            note = await self.do_clearwarns(mod, target)
        else:
            note = None
        await inter.edit_original_message(components=self.panel(mod, note).components)

    @commands.Cog.listener("on_dropdown")
    async def _mod_drop(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("mod:") or not inter.guild:
            return
        _, action, _ = parse_cid(c)
        if not self.any_scope(inter.author):
            await inter.response.send_message(f"{ui_icon('lock')} У вас нет прав модерации.", ephemeral=True)
            return
        s = self._session(inter.author.id)
        if action == "pick" and inter.values:
            s["target"] = int(inter.values[0])
        elif action == "dur" and inter.values:
            s["dur"] = int(inter.values[0])
        await inter.response.edit_message(components=self.panel(inter.author).components)

    @commands.Cog.listener("on_modal_submit")
    async def _mod_modal(self, inter: disnake.ModalInteraction):
        c = inter.custom_id or ""
        if not c.startswith("mod:m") or not inter.guild:
            return
        _, action, _ = parse_cid(c)
        mod = inter.author
        s = self._session(mod.id)
        target = inter.guild.get_member(s["target"]) if s["target"] else None
        await inter.response.defer()
        reason = (inter.text_values.get("reason") or "").strip() or "без причины"
        if action == "mwarn":
            note = await self.do_warn(mod, target, reason)
        elif action == "mtimeout":
            note = await self.do_timeout(mod, target, s["dur"], reason)
        elif action == "mkick":
            note = await self.do_kick(mod, target, reason)
            s["target"] = None if note.startswith(ui_icon("expel")) else s["target"]
        elif action == "mban":
            note = await self.do_ban(mod, target, reason)
            s["target"] = None if note.startswith(ui_icon("mod_ban")) else s["target"]
        elif action == "munban":
            raw = re.sub(r"\D", "", inter.text_values.get("uid", "") or "")
            note = await self.do_unban(mod, int(raw)) if raw else f"{ui_icon('reject')} Неверный ID."
        else:
            return
        await inter.edit_original_message(components=self.panel(mod, note).components)

    # ═══════════════ КОМАНДЫ ═══════════════
    async def _reply(self, ctx, text: str, ok: bool = True):
        await ctx.send(embed=disnake.Embed(description=text, color=SUCCESS_COLOR if ok else ERROR_COLOR))

    @commands.command(name="mod", aliases=["мод", "модерация", "moderation"])
    async def mod_cmd(self, ctx: commands.Context, member: disnake.Member | None = None):
        if not ctx.guild or not self.any_scope(ctx.author):
            await self._reply(ctx, f"{ui_icon('lock')} У вас нет прав модерации (`!perm`).", False)
            return
        if member:
            self._session(ctx.author.id)["target"] = member.id
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(
            disnake.ui.TextDisplay(f"{ui_icon('mod')} **Панель модерации** для {ctx.author.mention}"
                                   + (f" · цель: {member.mention}" if member else "")
                                   + "\n-# Панель откроется приватно — её видите только вы."),
            disnake.ui.ActionRow(disnake.ui.Button(style=disnake.ButtonStyle.primary, label="Открыть панель",
                                                   emoji=_pe("mod"), custom_id=cid("mod", "open"))),
            accent_colour=disnake.Colour(MOD_COLOR)))
        await ctx.send(components=p.components, delete_after=90)
        try:
            await ctx.message.delete()
        except Exception:
            pass

    @commands.command(name="warn", aliases=["варн", "пред", "предупреждение"])
    async def warn_cmd(self, ctx, member: disnake.Member, *, reason: str = "без причины"):
        note = await self.do_warn(ctx.author, member, reason)
        await self._reply(ctx, note, not note.startswith((ui_icon("lock"), ui_icon("reject"))))

    @commands.command(name="timeout", aliases=["таймаут", "тайм-аут", "мут", "mute"])
    async def timeout_cmd(self, ctx, member: disnake.Member, duration: str = "1ч", *, reason: str = "без причины"):
        sec = parse_duration(duration)
        if not sec:
            await self._reply(ctx, f"{ui_icon('reject')} Срок: например `10м`, `1ч`, `2д`.", False)
            return
        note = await self.do_timeout(ctx.author, member, sec, reason)
        await self._reply(ctx, note, not note.startswith((ui_icon("lock"), ui_icon("reject"))))

    @commands.command(name="untimeout", aliases=["снять-таймаут", "размут", "unmute"])
    async def untimeout_cmd(self, ctx, member: disnake.Member):
        note = await self.do_untimeout(ctx.author, member)
        await self._reply(ctx, note, not note.startswith((ui_icon("lock"), ui_icon("reject"))))

    @commands.command(name="kick", aliases=["кик"])
    async def kick_cmd(self, ctx, member: disnake.Member, *, reason: str = "без причины"):
        note = await self.do_kick(ctx.author, member, reason)
        await self._reply(ctx, note, not note.startswith((ui_icon("lock"), ui_icon("reject"))))

    @commands.command(name="ban", aliases=["бан"])
    async def ban_cmd(self, ctx, member: disnake.Member, *, reason: str = "без причины"):
        note = await self.do_ban(ctx.author, member, reason)
        await self._reply(ctx, note, not note.startswith((ui_icon("lock"), ui_icon("reject"))))

    @commands.command(name="unban", aliases=["разбан"])
    async def unban_cmd(self, ctx, user_id: str):
        raw = re.sub(r"\D", "", user_id or "")
        note = await self.do_unban(ctx.author, int(raw)) if raw else f"{ui_icon('reject')} Укажите ID."
        await self._reply(ctx, note, not note.startswith((ui_icon("lock"), ui_icon("reject"))))

    @commands.command(name="warns", aliases=["варны", "преды"])
    async def warns_cmd(self, ctx, member: disnake.Member | None = None):
        member = member or ctx.author
        if member != ctx.author and not self.any_scope(ctx.author):
            await self._reply(ctx, f"{ui_icon('lock')} Чужие варны видит только модерация.", False)
            return
        rows = self.warns.of(member.id)
        text = (f"{ui_icon('mod_warn')} **Варны {member.mention}: {len(rows)}**\n"
                + ("\n".join(f"-# <t:{w['ts']}:d> · {w['reason'][:120]} · <@{w['moderator']}>" for w in rows[:15])
                   or "-# Чисто."))
        await ctx.send(embed=disnake.Embed(description=text, color=MOD_COLOR))

    @commands.command(name="clearwarns", aliases=["снять-варны", "очистить-варны"])
    async def clearwarns_cmd(self, ctx, member: disnake.Member):
        note = await self.do_clearwarns(ctx.author, member)
        await self._reply(ctx, note, not note.startswith((ui_icon("lock"), ui_icon("reject"))))

    @commands.command(name="purge", aliases=["очистить", "clear", "чистка", "удалить"])
    async def purge_cmd(self, ctx, amount: int = 0, member: disnake.Member | None = None):
        if not ctx.guild or not self.can(ctx.author, "purge"):
            await self._reply(ctx, f"{ui_icon('lock')} Нет права на очистку (`purge`).", False)
            return
        if not 1 <= amount <= PURGE_MAX:
            await self._reply(ctx, f"{ui_icon('reject')} Укажите число от 1 до {PURGE_MAX}: `!очистить 100` "
                                   f"или `!очистить 100 @участник`.", False)
            return
        try:
            await ctx.message.delete()
        except Exception:
            pass
        check = (lambda m: m.author.id == member.id) if member else None
        try:
            deleted = await ctx.channel.purge(limit=amount, check=check, bulk=True)
        except disnake.HTTPException as e:
            await self._reply(ctx, f"{ui_icon('reject')} Не удалось: {e.text or e}", False)
            return
        await ctx.send(embed=disnake.Embed(
            description=f"{ui_icon('purge')} Удалено сообщений: **{len(deleted)}**"
                        + (f" от {member.mention}" if member else "") + ".",
            color=SUCCESS_COLOR), delete_after=6)
        await self._log(ctx.guild, f"{ui_icon('purge')} **Очистка** {ctx.channel.mention}: {len(deleted)} сообщений"
                                   + (f" от {member.mention}" if member else "") + f" · модератор {ctx.author.mention}")

    @warn_cmd.error
    @timeout_cmd.error
    @kick_cmd.error
    @ban_cmd.error
    @untimeout_cmd.error
    @clearwarns_cmd.error
    async def _arg_error(self, ctx, error):
        if isinstance(error, (commands.MissingRequiredArgument, commands.MemberNotFound, commands.BadArgument)):
            await self._reply(ctx, f"{ui_icon('reject')} Укажите участника: `!{ctx.command.name} @участник …`", False)
        else:
            raise error


def setup(bot: commands.Bot):
    bot.add_cog(ModerationCog(bot))
