"""
⚜️ НАСЛЕДИЕ — !наследие / !legacy

Формируемые исторические державы (utils/legacy.FORMABLES): страна-основатель удерживает
нужные области (свои + отвоёванные у игроков и ИИ-государств) и выполняет условия —
провозглашает державу.

ПУЛЬТ (ЛС): доступные державы с прогрессом, подробные требования полосками
(«Венгрия 14/20 областей», стабильность, легитимность, развитие, мир, казна, дипкапитал),
кнопка «Провозгласить» (два шага) и список легендарных держав мира.

ПРОВОЗГЛАШЕНИЕ: титул поверх страны (ник, карта, профиль, новости), исторический строй,
престиж (+репутация, +легитимность), соседи настороже (−отношения), торжественный пост
с баннером державы, ЗОЛОТО на карте. Бонусы — utils/legacy.BONUSES.

УПАДОК (часовой цикл): удержано меньше половины требуемых земель — бонусы и золото
пропадают, ник возвращается к стране; вернёшь земли — величие возвращается.
Только кастом-иконки.
"""

import asyncio
import logging
import time
from pathlib import Path

import disnake
from disnake.ext import commands, tasks

from utils import (
    Countries, Politics, Diplomacy, CountryUpgrades, War, MapState, Legacy, update_money, int_format,
    COMMAND_COLOR, ERROR_COLOR, WARNING_COLOR, CURRENCY, GUILD_ID,
)
from utils.ui import Panel, cid, parse_cid
from utils.resources import ui_icon
from utils.serverconfig import rid
import utils.legacy as LG
import utils.worldmap as WM
import utils.politics as POL

log = logging.getLogger("legacy")

BANNERS = Path(__file__).resolve().parent.parent / "assets" / "brand" / "legacy"
GOLD_INT = (LG.GOLD[0] << 16) | (LG.GOLD[1] << 8) | LG.GOLD[2]


def _pe(slug: str):
    s = ui_icon(slug)
    try:
        return disnake.PartialEmoji.from_str(s) if s and s.startswith("<") else None
    except Exception:
        return None


def _bar(frac: float, width: int = 10) -> str:
    filled = round(max(0.0, min(1.0, frac)) * width)
    return "▰" * filled + "▱" * (width - filled)


class LegacyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.countries = Countries()
        self.politics = Politics()
        self.dip = Diplomacy()
        self.upg = CountryUpgrades()
        self.war = War()
        self.lg = Legacy()
        self._sessions: dict[int, dict] = {}
        self.legacy_tick.start()

    def cog_unload(self):
        self.legacy_tick.cancel()

    async def _defer(self, inter):
        try:
            if not inter.response.is_done():
                await inter.response.defer()
        except Exception:
            pass

    def _session(self, uid: int) -> dict:
        return self._sessions.setdefault(uid, {"view": "hub", "key": None, "confirm": False})

    # ═══════════════ ТРЕБОВАНИЯ ═══════════════
    @staticmethod
    def _territory(me_a3: str, cores: dict, owners: dict, by_a0: dict) -> list[dict]:
        rows = []
        for a3, need in cores.items():
            total = len(by_a0.get(a3, ()))
            have = sum(1 for rid in by_a0.get(a3, ()) if owners.get(rid) == me_a3)
            need_n = max(1, -(-int(round(need * total * 100)) // 100)) if total else 0   # ceil(need × total)
            need_n = min(total, need_n)
            rows.append({"a3": a3, "label": WM.country_name(a3), "have": have, "need": need_n, "total": total,
                         "ok": have >= need_n})
        return rows

    def progress(self, country: str, key: str, owners: dict | None = None, by_a0: dict | None = None) -> dict:
        """Полный разбор требований державы для страны. → {land, checks, ok, land_share}."""
        f = LG.FORMABLES[key]
        me_a3 = WM.resolve_a3(country)
        if owners is None:
            owners = WM._owners(MapState().overrides())
        if by_a0 is None:
            by_a0 = self._by_a0()
        land = self._territory(me_a3, f["cores"], owners, by_a0)
        o = self.countries.get_object(country)
        ps = self.politics.get_state(country)
        dev = sum(self.upg.get_levels(country).values())
        inf, _rep = self.dip.get_state(country)
        taken = self.lg.by_key(key)
        mine = self.lg.of(country)
        checks = [
            ("stability", f"Стабильность ≥ {f['stab']}", f"{o.stability:.0f}", o.stability >= f["stab"]),
            ("legitimacy", f"Легитимность ≥ {f['legit']}", f"{ps['legitimacy']:.0f}", ps["legitimacy"] >= f["legit"]),
            ("upgrade", f"Развитие (сумма уровней веток) ≥ {f['dev']}", str(dev), dev >= f["dev"]),
            ("peace", "Не воевать", "воюет" if self.war.active_for(country) else "мир", not self.war.active_for(country)),
            ("money", f"Казна ≥ {int_format(f['money'])} {CURRENCY}", int_format(o.money), o.money >= f["money"]),
            ("influence", f"Дипкапитал ≥ {f['influence']}", f"{inf:.0f}", inf >= f["influence"]),
        ]
        if taken and taken["country"] != country:
            checks.append(("lock", "Держава свободна", f"уже основана: {taken['country']}", False))
        if mine and mine["key"] != key:
            checks.append(("lock", "Страна ещё не основала другую державу", mine["title"], False))
        need_sum = sum(r["need"] for r in land) or 1
        land_share = sum(min(r["have"], r["need"]) for r in land) / need_sum
        ok = all(r["ok"] for r in land) and all(c[3] for c in checks)
        return {"land": land, "checks": checks, "ok": ok, "land_share": land_share}

    @staticmethod
    def _by_a0() -> dict:
        WM._load()
        out: dict[str, list] = {}
        for r in WM._REGIONS:  # type: ignore[union-attr]
            out.setdefault(r.a0, []).append(r.region_id)
        return out

    # ═══════════════ API ДЛЯ ДРУГИХ МЕХАНИК ═══════════════
    def title_of(self, country: str) -> str | None:
        r = self.lg.of(country)
        return r["title"] if r and not r["declined"] else None

    def bonus(self, country: str, kind: str) -> float:
        r = self.lg.of(country)
        if not r or r["declined"] or r["key"] not in LG.FORMABLES:
            return 0.0
        return float(LG.FORMABLES[r["key"]]["bonuses"].get(kind, 0))

    def income_lines(self, country: str, total_income: int) -> list[tuple[str, int]]:
        pct = self.bonus(country, "income")
        if pct and total_income > 0:
            return [(f"Наследие: {self.title_of(country)}", round(total_income * pct / 100))]
        return []

    def army_mult(self, country: str) -> float:
        return 1.0 + self.bonus(country, "army") / 100

    def legend_map(self) -> dict[str, str]:
        """{a3: титул} действующих легендарных держав — для золота на карте."""
        out = {}
        for r in self.lg.all():
            if not r["declined"]:
                a3 = WM.resolve_a3(r["country"])
                if a3:
                    out[a3] = r["title"]
        return out

    def context(self, country: str) -> str:
        r = self.lg.of(country)
        if not r:
            return ""
        return (f"Легендарная держава «{r['title']}»" + (" (в упадке)" if r["declined"] else "") + ".")

    # ═══════════════ ПАНЕЛИ ═══════════════
    def _container(self, items, color=GOLD_INT) -> Panel:
        p = Panel(timeout=600)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(color)))
        return p

    def _head(self, note=None):
        items = [disnake.ui.TextDisplay(f"## {ui_icon('legacy')} Наследие")]
        if note:
            items.append(disnake.ui.TextDisplay(note))
        return items

    def _render(self, uid: int, note=None) -> Panel:
        s = self._session(uid)
        actor = self.countries.get_object_by_user(uid)
        if not actor:
            return self._container(self._head(note) + [disnake.ui.TextDisplay(
                "-# У вас нет страны. Откройте панель регистрации.")], WARNING_COLOR)
        if s["view"] == "detail" and s["key"] in LG.FORMABLES:
            return self._panel_detail(uid, actor, note)
        return self._panel_hub(uid, actor, note)

    def _legends_text(self) -> str:
        rows = self.lg.all()
        if not rows:
            return "-# Легендарных держав в мире пока нет."
        out = []
        for r in rows:
            o = self.countries.get_object(r["country"])
            mark = ui_icon("legacy_decline") if r["declined"] else ui_icon("legacy")
            out.append(f"{mark} **{r['title']}** · {o.flag if o else ''} {r['country']}"
                       + (" · в упадке" if r["declined"] else f" · с <t:{r['formed_at']}:D>"))
        return "\n".join(out)

    def _panel_hub(self, uid, actor, note=None):
        me = actor.name
        items = self._head(note)
        mine = self.lg.of(me)
        if mine and mine["key"] in LG.FORMABLES:
            f = LG.FORMABLES[mine["key"]]
            pr = self.progress(me, mine["key"])
            items.append(disnake.ui.TextDisplay(
                f"### {ui_icon('legacy_crown')} {mine['title']}\n-# «{f['motto']}» · провозглашена <t:{mine['formed_at']}:D>\n"
                f"{ui_icon('up')} Бонусы: **{LG.bonus_text(f['bonuses'])}**"
                + (" — **не действуют (упадок)**" if mine["declined"] else "") + "\n"
                f"{ui_icon('globe')} Удержано требуемых земель: {_bar(pr['land_share'])} **{int(pr['land_share'] * 100)}%**"
                f" (упадок ниже {int(LG.DECLINE_SHARE * 100)}%)"))
        else:
            keys = LG.available_for(me)
            if not keys:
                items.append(disnake.ui.TextDisplay(
                    f"-# Для {actor.flag} {me} нет исторических держав в каталоге. Но легендой можно стать "
                    f"иначе — через войну и альянсы."))
            else:
                owners, by_a0 = WM._owners(MapState().overrides()), self._by_a0()
                lines, opts = [], []
                for k in keys:
                    f = LG.FORMABLES[k]
                    pr = self.progress(me, k, owners, by_a0)
                    taken = self.lg.by_key(k)
                    state = (f"основана: {taken['country']}" if taken else
                             ("всё готово!" if pr["ok"] else f"земли {int(pr['land_share'] * 100)}%"))
                    lines.append(f"{ui_icon('legacy')} **{f['title']}** · {_bar(pr['land_share'], 8)} · {state}")
                    opts.append(disnake.SelectOption(label=f["title"][:100], value=k, emoji=_pe("legacy"),
                                                     description=f"{f['motto']} · {state}"[:100]))
                items.append(disnake.ui.TextDisplay(
                    f"### {actor.flag} {me} может основать\n" + "\n".join(lines)))
                items.append(disnake.ui.ActionRow(disnake.ui.StringSelect(
                    custom_id=cid("leg", "pick"), placeholder="Открыть державу…", options=opts[:25])))
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"{ui_icon('nuke_club')} **Легендарные державы мира**\n" + self._legends_text()))
        items.append(disnake.ui.ActionRow(disnake.ui.Button(
            style=disnake.ButtonStyle.secondary, label="Обновить", emoji=_pe("reload"), custom_id=cid("leg", "hub"))))
        return self._container(items)

    def _panel_detail(self, uid, actor, note=None):
        s = self._session(uid)
        key = s["key"]
        f = LG.FORMABLES[key]
        me = actor.name
        pr = self.progress(me, key)
        items = self._head(note)
        ideo = f" · строй: **{POL.ideo_label(f['ideology'])}**" if f["ideology"] else ""
        items.append(disnake.ui.TextDisplay(
            f"### {ui_icon('legacy_crown')} {f['title']}\n-# «{f['motto']}»\n"
            f"{ui_icon('up')} Бонусы: **{LG.bonus_text(f['bonuses'])}**{ideo}\n"
            f"-# Престиж: репутация +{LG.FORM_REP}, легитимность +{LG.FORM_LEGIT}; соседи насторожатся "
            f"({LG.NEIGHBOR_REL} к отношениям). Золото на карте."))
        land = "\n".join(
            f"{ui_icon('check') if r['ok'] else ui_icon('lock')} {r['label']}: **{r['have']}/{r['need']}** "
            f"областей {_bar(r['have'] / r['need'] if r['need'] else 1, 8)}" for r in pr["land"])
        items.append(disnake.ui.Separator())
        items.append(disnake.ui.TextDisplay(f"{ui_icon('globe')} **Земли** (свои и отвоёванные области)\n{land}"))
        conds = "\n".join(f"{ui_icon('check') if ok else ui_icon('lock')} {label}: **{val}**"
                          for _slug, label, val, ok in pr["checks"])
        items.append(disnake.ui.TextDisplay(f"{ui_icon('charter')} **Условия**\n{conds}"))
        B = disnake.ButtonStyle
        if s["confirm"] and pr["ok"]:
            items.append(disnake.ui.TextDisplay(
                f"{ui_icon('legacy_crown')} **Провозгласить {f['title']}?** Будет списано "
                f"{int_format(f['money'])} {CURRENCY} и {f['influence']} дипкапитала"
                + (f", строй сменится на «{POL.ideo_label(f['ideology'])}»" if f["ideology"] else "") + "."))
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.success, label="Да, провозгласить", emoji=_pe("legacy_crown"),
                                  custom_id=cid("leg", "form", key)),
                disnake.ui.Button(style=B.secondary, label="Отмена", custom_id=cid("leg", "open", key))))
        else:
            items.append(disnake.ui.ActionRow(
                disnake.ui.Button(style=B.success, label="Провозгласить", emoji=_pe("legacy_crown"),
                                  disabled=not pr["ok"], custom_id=cid("leg", "ask", key)),
                disnake.ui.Button(style=B.secondary, label="Обновить", emoji=_pe("reload"), custom_id=cid("leg", "open", key)),
                disnake.ui.Button(style=B.secondary, label="⟵ Назад", custom_id=cid("leg", "hub"))))
        if not pr["ok"]:
            items.append(disnake.ui.TextDisplay("-# Земли берутся войной с игроками и ИИ-государствами (`!war`) "
                                                "или по ультиматуму."))
        return self._container(items)

    # ═══════════════ ОБРАБОТЧИКИ ═══════════════
    @commands.Cog.listener("on_dropdown")
    async def _leg_drop(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("leg:"):
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        if inter.values and inter.values[0] in LG.FORMABLES:
            s.update(view="detail", key=inter.values[0], confirm=False)
        await inter.edit_original_message(components=self._render(inter.author.id).components)

    @commands.Cog.listener("on_button_click")
    async def _leg_btn(self, inter: disnake.MessageInteraction):
        c = inter.component.custom_id or ""
        if not c.startswith("leg:"):
            return
        await self._defer(inter)
        s = self._session(inter.author.id)
        _, action, args = parse_cid(c)
        note = None
        actor = self.countries.get_object_by_user(inter.author.id)
        if action == "hub":
            s.update(view="hub", key=None, confirm=False)
        elif action in ("open", "ask") and args and args[0] in LG.FORMABLES:
            s.update(view="detail", key=args[0], confirm=(action == "ask"))
        elif action == "form" and args and actor:
            note = await self.proclaim(actor.name, args[0])
            s.update(view="hub" if note.startswith(ui_icon("legacy_crown")) else "detail", confirm=False)
        await inter.edit_original_message(components=self._render(inter.author.id, note).components)

    # ═══════════════ ПРОВОЗГЛАШЕНИЕ ═══════════════
    async def proclaim(self, country: str, key: str) -> str:
        if key not in LG.FORMABLES or country not in LG.FORMABLES[key]["founders"]:
            return f"{ui_icon('reject')} Эту державу ваша страна основать не может."
        taken = self.lg.by_key(key)
        if taken:
            return f"{ui_icon('reject')} «{LG.FORMABLES[key]['title']}» уже основана: {taken['country']}."
        mine = self.lg.of(country)
        if mine:
            return f"{ui_icon('reject')} Ваша страна уже основала державу «{mine['title']}»."
        pr = self.progress(country, key)
        if not pr["ok"]:
            return f"{ui_icon('reject')} Условия ещё не выполнены."
        f = LG.FORMABLES[key]
        now = int(time.time())
        try:
            self.lg.form(country, key, f["title"], now)
        except Exception:
            return f"{ui_icon('reject')} Держава уже основана."
        update_money(country, -f["money"])
        self.dip.add_influence(country, -f["influence"])
        self.dip.add_reputation(country, LG.FORM_REP)
        ps = self.politics.get_state(country)
        self.politics.set_legitimacy(country, min(100.0, ps["legitimacy"] + LG.FORM_LEGIT))
        if f["ideology"]:
            self.politics.clear_transition(country)
            self.politics.set_ideology(country, f["ideology"])
        a3 = WM.resolve_a3(country)
        ov = MapState().overrides()
        for n3 in WM.neighbor_countries(a3, ov) if a3 else ():
            name = next((n for n in self.countries.get_object_names() if WM.resolve_a3(n) == n3), None)
            if name:
                self.dip.add_relation(country, name, LG.NEIGHBOR_REL)
        un = self.bot.get_cog("UNCog")
        if un:
            un.log("legacy", country, "", f"{country} провозгласила державу «{f['title']}»")
        try:
            from cogs.registration import update_country_nick
            await update_country_nick(self.bot, country)
        except Exception:
            log.exception("ник после провозглашения")
        self.bot.dispatch("map_dirty")
        await self._announce(country, key)
        return f"{ui_icon('legacy_crown')} **{f['title']}** провозглашена! Страна горит золотом на карте мира."

    async def _announce(self, country: str, key: str):
        f = LG.FORMABLES[key]
        o = self.countries.get_object(country)
        ch_id = rid("CH_EVENTS", 0) or rid("CH_NEWS", 0)
        g = self.bot.get_guild(GUILD_ID)
        ch = (g.get_channel(ch_id) if g and ch_id else None) or (self.bot.get_channel(ch_id) if ch_id else None)
        if not ch:
            return
        banner = BANNERS / f"{key}.jpg"
        items = []
        if banner.exists():
            items.append(disnake.ui.MediaGallery(disnake.MediaGalleryItem(media=f"attachment://{key}.jpg")))
        items.append(disnake.ui.TextDisplay(
            f"## {ui_icon('legacy_crown')} Рождение легендарной державы\n"
            f"{o.flag if o else ''} **{country}** провозглашает **{f['title']}**.\n-# «{f['motto']}»\n"
            f"{ui_icon('up')} {LG.bonus_text(f['bonuses'])}"
            + (f" · строй: {POL.ideo_label(f['ideology'])}" if f["ideology"] else "")
            + f"\n{ui_icon('rel_down')} Соседи встревожены: отношения {LG.NEIGHBOR_REL}."))
        p = Panel(timeout=None)
        p.add_item(disnake.ui.Container(*items, accent_colour=disnake.Colour(GOLD_INT)))
        try:
            if banner.exists():
                await ch.send(components=p.components, file=disnake.File(str(banner), filename=f"{key}.jpg"))
            else:
                await ch.send(components=p.components)
        except Exception:
            log.exception("объявление «Наследия»")

    # ═══════════════ ЧАСОВОЙ ЦИКЛ ═══════════════
    async def _tick(self):
        rows = self.lg.all()
        if not rows:
            return
        owners, by_a0 = WM._owners(MapState().overrides()), self._by_a0()
        changed = False
        for r in rows:
            country, key = r["country"], r["key"]
            o = self.countries.get_object(country)
            if not o or key not in LG.FORMABLES:
                continue
            pr = self.progress(country, key, owners, by_a0)
            declined = pr["land_share"] < LG.DECLINE_SHARE
            if declined != bool(r["declined"]):
                self.lg.set_declined(country, declined)
                changed = True
                try:
                    from cogs.registration import update_country_nick
                    await update_country_nick(self.bot, country)
                except Exception:
                    pass
                await self._post_status(country, r["title"], declined)
            if declined:
                continue
            b = LG.FORMABLES[key]["bonuses"]
            if b.get("stability"):
                self.countries.update_object(country, stability=round(min(100.0, (o.stability or 0) + b["stability"]), 2))
            if b.get("legitimacy"):
                ps = self.politics.get_state(country)
                self.politics.set_legitimacy(country, min(100.0, ps["legitimacy"] + b["legitimacy"]))
            if b.get("influence"):
                self.dip.add_influence(country, b["influence"])
        if changed:
            self.bot.dispatch("map_dirty")

    async def _post_status(self, country: str, title: str, declined: bool):
        ch_id = rid("CH_EVENTS", 0) or rid("CH_NEWS", 0)
        ch = self.bot.get_channel(ch_id) if ch_id else None
        if not ch:
            return
        text = (f"{ui_icon('legacy_decline')} **{title}** приходит в упадок: {country} утратила больше половины "
                f"исторических земель. Бонусы и золото на карте утрачены." if declined else
                f"{ui_icon('legacy_crown')} **{title}** возрождается: {country} вернула исторические земли.")
        try:
            await ch.send(embed=disnake.Embed(description=text, color=WARNING_COLOR if declined else GOLD_INT))
        except Exception:
            pass

    @tasks.loop(hours=1)
    async def legacy_tick(self):
        try:
            await self._tick()
        except Exception:
            log.exception("сбой цикла «Наследия»")

    @legacy_tick.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ═══════════════ КОМАНДА ═══════════════
    @commands.command(name="legacy", aliases=["наследие", "держава", "империя"])
    async def legacy_cmd(self, ctx: commands.Context):
        actor = self.countries.get_object_by_user(ctx.author.id)
        if not actor:
            await ctx.send(embed=disnake.Embed(description="«Наследие» доступно только странам.", color=ERROR_COLOR))
            return
        self._session(ctx.author.id).update(view="hub", key=None, confirm=False)
        panel = await asyncio.to_thread(self._render, ctx.author.id)   # граф областей может строиться ~1.5 с
        try:
            await ctx.author.send(components=panel.components)
        except disnake.Forbidden:
            await ctx.send(embed=disnake.Embed(description="Включите ЛС и повторите `!наследие`.", color=WARNING_COLOR))
            return
        if ctx.guild:
            await ctx.send(embed=disnake.Embed(
                description=f"{ui_icon('legacy')} Пульт «Наследия» отправлен вам в **личные сообщения**.",
                color=COMMAND_COLOR), delete_after=12)


def setup(bot: commands.Bot):
    bot.add_cog(LegacyCog(bot))
