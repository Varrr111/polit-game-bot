"""
Система развития страны (прокачка веток) — БЕЗ ролей, уровни в БД.

Оригинальная механика (не копия референса):
  • 22 ветки в 5 категориях, у каждой 5 уровней.
  • Уровень стоит ДЕНЬГИ + РЕСУРСЫ (связь с экономикой ресурсов).
  • СИНЕРГИИ (фишка): «множительные» ветки усиливают другие —
      Финансы  → +3%/ур. ко ВСЕМУ доходу;
      Наука    → +5%/ур. к доходу науки и военки;
      Энергетика → +4%/ур. к доходу промышленности и добычи;
      Логистика → +4%/ур. к доходу добычи (и +склад — применяется в ресурсах);
      Образование → −3%/ур. к стоимости улучшений (скидка).
  • ТРЕБОВАНИЯ (мини-дерево): продвинутые ветки открываются после базовых
      (Космос требует Науку/IT, Ядерный щит — Атомпром/ВПК, и т.д.).
  • Эффекты добывающих веток ускоряют пассивную добычу ресурсов.
"""

# категория -> (название, иконка-эмодзи для заголовков)
CATEGORIES: dict[str, tuple[str, str]] = {
    "economy":  ("Экономика", "💰"),
    "science":  ("Наука и технологии", "🔬"),
    "infra":    ("Инфраструктура", "🏗️"),
    "mining":   ("Добыча", "⛏️"),
    "military": ("Военное", "⚔️"),
}

# Кастомные иконки категорий (слаги для application-эмодзи бота)
CATEGORY_SLUG = {
    "economy": "cat_economy", "science": "cat_science", "infra": "cat_infra",
    "mining": "cat_mining", "military": "cat_military",
}
CATEGORY_ICONS = {k: CATEGORIES[k][1] for k in CATEGORIES}  # фолбэк-эмодзи
CATEGORY_ICONS_CUSTOM: dict[str, str] = {}


def cat_icon(key: str) -> str:
    return CATEGORY_ICONS_CUSTOM.get(key) or CATEGORY_ICONS.get(key, "")


MAX_LEVEL = 5
INC_MULT = [1.0, 2.4, 5.0, 9.0, 16.0]     # доход по уровням (×base)
MONEY_MULT = [1, 3, 7, 16, 35]            # цена по уровням (×money_base)
RES_MULT = [0, 1, 2, 4, 8]                # множитель ресурсов (ур.1 без ресурсов)

# Сигнатура ресурсов по категории: [(ресурс, базовое_кол-во)]
RES_SIG = {
    "economy":  [("сталь", 200), ("медь", 120)],
    "science":  [("электроника", 150), ("никель", 60)],
    "infra":    [("сталь", 300), ("топливо", 150)],
    "mining":   [("сталь", 150), ("топливо", 100)],
    "military": [("сталь", 250), ("электроника", 120), ("вольфрам", 60)],
}

M = 1_000_000  # млн


def _levels(base_income_m: float, money_base_m: float, category: str, res_override=None):
    sig = res_override if res_override is not None else RES_SIG[category]
    out = []
    for i in range(MAX_LEVEL):
        res = {r: int(q * RES_MULT[i]) for r, q in sig} if RES_MULT[i] else {}
        out.append({
            "money": int(money_base_m * M * MONEY_MULT[i]),
            "income": int(base_income_m * M * INC_MULT[i]),
            "res": {r: v for r, v in res.items() if v > 0},
        })
    return out


# ключ: (label, category, base_income_млн, money_base_млн, requires{branch:lvl})
_SPEC = [
    # ── Экономика ──
    ("trade",      "Торговля",             "economy", 0.8, 15, {}),
    ("tourism",    "Туризм",               "economy", 0.7, 14, {}),
    ("industry",   "Промышленность",       "economy", 1.0, 20, {}),
    ("agriculture","Сельское хозяйство",   "economy", 0.6, 12, {}),
    ("finance",    "Финансы",              "economy", 0.9, 25, {}),          # синергия: +% ко всему
    ("energy",     "Энергетика",           "economy", 1.1, 28, {"industry": 1}),  # синергия: пром+добыча
    # ── Наука и технологии ──
    ("science",    "Наука",                "science", 0.9, 25, {}),          # синергия: наука+военка
    ("education",  "Образование",          "science", 0.5, 18, {}),          # синергия: скидка
    ("it",         "IT-сектор",            "science", 1.2, 30, {"science": 1}),
    ("space",      "Космос",               "science", 1.6, 45, {"science": 3, "it": 2}),
    # ── Инфраструктура ──
    ("logistics",  "Логистика",            "infra",   0.8, 22, {}),          # синергия: добыча+склад
    ("urban",      "Урбанизация",          "infra",   0.9, 24, {}),
    ("medicine",   "Медицина",             "infra",   0.6, 20, {}),
    ("grid",       "Энергосети",           "infra",   0.7, 21, {"energy": 1}),
    # ── Добыча ──
    ("oilgas",     "Нефтегаз",             "mining",  1.0, 24, {}),
    ("mining_ore", "Горное дело",          "mining",  0.9, 22, {}),
    ("forestry",   "Лесное хозяйство",     "mining",  0.6, 15, {}),
    ("atomprom",   "Атомпром",             "mining",  1.4, 40, {"science": 2}),
    # ── Военное ──
    ("army",       "Армия",                "military", 0.7, 20, {}),
    ("mic",        "ВПК",                  "military", 1.0, 30, {"industry": 2}),
    ("airforce",   "Авиация",              "military", 1.1, 34, {"army": 2}),
    ("navy",       "Флот",                 "military", 1.1, 34, {"army": 2}),
    ("nuke",       "Ядерный щит",          "military", 2.0, 60, {"atomprom": 3, "mic": 2}),
]

BRANCHES: dict[str, dict] = {}
for key, label, cat, inc, money, req in _SPEC:
    BRANCHES[key] = {
        "label": label, "category": cat, "requires": req,
        "levels": _levels(inc, money, cat),
    }

# Ветки-добытчики ускоряют пассивную добычу этих ресурсов (эффект)
MINING_BOOST = {
    "oilgas":     ["нефть"],
    "mining_ore": ["железо", "уголь", "медь", "марганец", "бокситы", "хром", "никель"],
    "forestry":   ["молибден"],       # «редкие» — медленные ветки-добытчики
    "atomprom":   ["уран", "вольфрам"],
}


def branches_in(category: str) -> list[str]:
    return [k for k, b in BRANCHES.items() if b["category"] == category]


def requirements_met(levels: dict[str, int], key: str) -> tuple[bool, list[str]]:
    """Выполнены ли требования ветки. Возвращает (ок, список_невыполненных_текстом)."""
    missing = []
    for req_key, req_lvl in BRANCHES[key]["requires"].items():
        if levels.get(req_key, 0) < req_lvl:
            missing.append(f"{BRANCHES[req_key]['label']} ур.{req_lvl}")
    return (not missing, missing)


def next_cost(levels: dict[str, int], key: str) -> tuple[int, dict[str, int]] | None:
    """Стоимость (деньги, ресурсы) улучшения до следующего уровня. None если MAX."""
    lvl = levels.get(key, 0)
    if lvl >= MAX_LEVEL:
        return None
    lv = BRANCHES[key]["levels"][lvl]  # cost to reach lvl+1
    money = lv["money"]
    # скидка от образования: −3%/ур., максимум −45%
    edu = levels.get("education", 0)
    money = int(money * max(0.55, 1 - 0.03 * edu))
    return money, dict(lv["res"])


def branch_income(levels: dict[str, int], key: str) -> int:
    """Доход ветки на её текущем уровне (0 если не прокачана)."""
    lvl = levels.get(key, 0)
    if lvl <= 0:
        return 0
    return BRANCHES[key]["levels"][lvl - 1]["income"]


def total_income(levels: dict[str, int]) -> int:
    """Суммарный доход страны с учётом синергий."""
    sci = levels.get("science", 0)
    energy = levels.get("energy", 0)
    log = levels.get("logistics", 0)
    fin = levels.get("finance", 0)
    total = 0.0
    for key, b in BRANCHES.items():
        inc = branch_income(levels, key)
        if inc <= 0:
            continue
        mult = 1.0
        cat = b["category"]
        if cat in ("science", "military"):
            mult += 0.05 * sci
        if key == "industry" or cat == "mining":
            mult += 0.04 * energy
        if cat == "mining":
            mult += 0.04 * log
        total += inc * mult
    total *= (1 + 0.03 * fin)
    return int(total)


def country_income(name: str) -> int:
    """Суммарный доход/ч страны по её прокачке (читает из БД)."""
    from .managers import CountryUpgrades
    return total_income(CountryUpgrades().get_levels(name))


# Вклад развития в ВВП: ВВП = база_ростера + доход/ч_развития × GDP_INCOME_MULT.
# Полное развитие (≈485M/ч) добавляет ~2.4 трлн — заметно, но база тоже важна. Тюнится.
GDP_INCOME_MULT = 5000


def country_gdp(name: str) -> int:
    """ДИНАМИЧЕСКИЙ ВВП: статовая база из ростера + вклад от веток развития.
    Чем сильнее прокачана страна, тем выше её ВВП (а значит и вес в санкциях)."""
    import config
    base = int(config.COUNTIES_GDP.get(name, 0) or 0)
    return base + country_income(name) * GDP_INCOME_MULT


def country_mining_multiplier(name: str, resource: str) -> float:
    from .managers import CountryUpgrades
    return mining_multiplier(CountryUpgrades().get_levels(name), resource)


def mining_multiplier(levels: dict[str, int], resource: str) -> float:
    """Множитель пассивной добычи ресурса от прокачанных веток-добытчиков."""
    mult = 1.0
    for key, resources in MINING_BOOST.items():
        if resource in resources:
            mult += 0.15 * levels.get(key, 0)   # +15%/уровень ветки
    return mult
