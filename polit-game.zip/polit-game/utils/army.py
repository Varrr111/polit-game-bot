"""
Армия: формирование боевых соединений из техники + личного состава.

Цепочка (что нужно сделать):
  1. ПОСТРОИТЬ военные здания:
       • Казарма      — ёмкость личного состава;
       • Военная академия — качество и доступ к продвинутым соединениям;
       • Штаб         — слоты под соединения.
  2. ПРИЗВАТЬ личный состав (ограничен казармами и населением; стоит денег,
     массовый призыв бьёт по счастью).
  3. СФОРМИРОВАТЬ соединение по шаблону — нужны: свободный слот штаба,
     нужная техника в арсенале, личный состав, уровень академии, стабильность.

Мощь соединения растёт от техники и качества (академия), но зависит от МОРАЛИ
(счастье+стабильность) — армия связана с состоянием государства.
Содержание армии списывается из авто-дохода (реализм, без слома экономики).

Все числа — ЗАГЛУШКИ под тюнинг клиента.
"""

import math

from .equipment import EQUIP_CATEGORIES, cat_label as eq_cat_label, cat_icon as eq_cat_icon

# ── Военные здания: (название, иконка, цена $, рецепт ресурсов) ──
ARMY_BUILDINGS: dict[str, tuple[str, str, int, dict[str, int]]] = {
    "barracks": ("Казарма",          "🏕️", 20_000_000, {"сталь": 150, "топливо": 80}),
    "academy":  ("Военная академия", "🎖️", 60_000_000, {"сталь": 200, "электроника": 150}),
    "command":  ("Штаб",             "🗼", 40_000_000, {"сталь": 180, "электроника": 120}),
}

MANPOWER_PER_BARRACKS = 20_000     # +ёмкость л/с за казарму
MANPOWER_BASE = 10_000             # базовая ёмкость без казарм
MAX_MOBILIZATION = 0.05            # не больше 5% населения под ружьё
SLOTS_PER_COMMAND = 2              # слотов соединений за штаб
RECRUIT_COST = 500                 # $ за одного бойца
RECRUIT_HAPPINESS_HIT = 0.000005   # −счастья за бойца при призыве (массовый призыв злит)
MIN_STABILITY_TO_FORM = 20         # нельзя мобилизоваться в хаосе
UPKEEP_PER_SOLDIER = 50            # $/ч за бойца в строю
UPKEEP_EQUIP_FACTOR = 0.002        # доля стоимости техники в час на содержание

# ── Шаблоны соединений: (название, иконка, домен, {категория: кол-во}, л/с, мин.академия) ──
ARMY_FORMATIONS: dict[str, tuple[str, str, str, dict[str, int], int, int]] = {
    "motor_rifle":   ("Мотострелковая бригада",      "🪖", "land", {"ifv": 20, "apc": 10}, 8_000, 0),
    "tank_div":      ("Танковая дивизия",            "🛡️", "land", {"mbt": 40, "ifv": 15}, 12_000, 1),
    "arty_regt":     ("Артиллерийский полк",         "💥", "land", {"spg": 18, "mlrs": 6}, 4_000, 0),
    "aa_div":        ("ПВО-дивизион",                "🎯", "land", {"sam_short": 8, "sam_long": 2}, 3_000, 1),
    "recon_bn":      ("Разведбатальон",              "🔎", "land", {"recon_veh": 12, "mrap": 8}, 2_500, 0),
    "air_wing":      ("Авиакрыло",                   "✈️", "air", {"fighter": 12, "multirole": 6}, 2_000, 1),
    "bomber_wing":   ("Бомбардировочное крыло",      "🛩️", "air", {"bomber": 6, "strike": 6}, 1_500, 2),
    "heli_regt":     ("Вертолётный полк",            "🚁", "air", {"attack_heli": 12, "transp_heli": 6}, 2_500, 0),
    "uav_sqn":       ("БПЛА-эскадрилья",             "🛸", "air", {"uav_combat": 10, "uav_recon": 6}, 800, 1),
    "flotilla":      ("Эскадра",                     "🚢", "naval", {"frigate": 2, "corvette": 3, "missile_boat": 4}, 5_000, 1),
    "carrier_group": ("Авианосная группа",           "⚓", "naval", {"carrier": 1, "destroyer": 3, "frigate": 4}, 12_000, 3),
    "sub_fleet":     ("Подводный флот",              "🌊", "naval", {"sub_diesel": 3, "sub_nuclear": 1}, 3_000, 2),
    "missile_bde":   ("Ракетная бригада",            "🚀", "missile", {"ballistic_msl": 6, "cruise_msl": 12}, 2_000, 1),
}

# Время слаживания соединения (сек) — большие формирования дольше.
FORMATION_TIME: dict[str, int] = {
    "motor_rifle": 3600, "tank_div": 7200, "arty_regt": 2700, "aa_div": 3600, "recon_bn": 1800,
    "air_wing": 5400, "bomber_wing": 7200, "heli_regt": 4500, "uav_sqn": 2700,
    "flotilla": 9000, "carrier_group": 18000, "sub_fleet": 10800, "missile_bde": 6000,
}


def form_seconds(key: str) -> int:
    return max(600, FORMATION_TIME.get(key, 3600))


# ── Здания ──
def bld_label(kind: str) -> str:
    return ARMY_BUILDINGS.get(kind, (kind, "🏚️", 0, {}))[0]


def bld_icon(kind: str) -> str:
    return ARMY_BUILDINGS.get(kind, (kind, "🏚️", 0, {}))[1]


def bld_cost(kind: str) -> int:
    return ARMY_BUILDINGS.get(kind, (kind, "🏚️", 0, {}))[2]


def bld_recipe(kind: str) -> dict[str, int]:
    return dict(ARMY_BUILDINGS.get(kind, (kind, "🏚️", 0, {}))[3])


def manpower_cap(barracks: int, population: int) -> int:
    """Ёмкость личного состава: по казармам, но не больше доли населения."""
    by_barracks = MANPOWER_BASE + barracks * MANPOWER_PER_BARRACKS
    by_pop = int((population or 0) * MAX_MOBILIZATION)
    return min(by_barracks, by_pop) if by_pop else by_barracks


# ── Соединения ──
def _form(key: str):
    return ARMY_FORMATIONS.get(key, (key, "🎖️", "land", {}, 0, 0))


def form_label(key: str) -> str:
    return _form(key)[0]


def form_icon(key: str) -> str:
    from .resources import ui_icon
    return ui_icon("fm_" + key) or _form(key)[1]


def form_domain(key: str) -> str:
    return _form(key)[2]


def form_required(key: str) -> dict[str, int]:
    return dict(_form(key)[3])


def form_personnel(key: str) -> int:
    return _form(key)[4]


def form_min_academy(key: str) -> int:
    return _form(key)[5]


# ── РЕАЛИСТИЧНЫЕ боевые характеристики: категория → (атака, броня, живучесть) ──
# Атака — наносимый урон; Броня — снижение входящего урона; Живучесть (HP) —
# сколько урона держит до вывода из строя. Значения реалистично соотнесены:
# ракеты/артиллерия — «стекло с огромной атакой», корабли — живучие, пехота —
# массовка. Все числа — ЗАГЛУШКИ под тюнинг.
COMBAT: dict[str, tuple[int, int, int]] = {
    # сухопутные
    "mbt": (60, 55, 50), "light_tank": (35, 30, 30), "ifv": (30, 25, 28), "apc": (12, 22, 25),
    "mrap": (10, 18, 20), "spg": (75, 12, 22), "mlrs": (90, 8, 18), "towed_arty": (65, 5, 14),
    "atgm": (55, 4, 8), "aa_gun": (25, 8, 12), "sam_short": (40, 10, 16), "sam_long": (70, 12, 22),
    "recon_veh": (15, 14, 18), "eng_veh": (5, 20, 26),
    # авиация
    "fighter": (70, 15, 20), "multirole": (80, 18, 22), "interceptor": (75, 14, 20),
    "bomber": (120, 20, 30), "strike": (85, 22, 26), "attack_heli": (65, 16, 22),
    "transp_heli": (10, 14, 20), "transp_plane": (5, 18, 30), "awacs": (10, 10, 24),
    "uav_recon": (8, 2, 6), "uav_combat": (45, 3, 8),
    # флот
    "missile_boat": (70, 20, 40), "corvette": (90, 45, 90), "frigate": (140, 80, 180),
    "destroyer": (220, 120, 300), "cruiser": (320, 180, 440), "carrier": (260, 200, 700),
    "lhd": (120, 110, 360), "sub_diesel": (180, 60, 120), "sub_nuclear": (320, 90, 200),
    "minesweeper": (40, 30, 80),
    # ракеты
    "tactical_msl": (90, 1, 2), "cruise_msl": (140, 1, 2), "ballistic_msl": (400, 1, 3),
    "aa_missile": (50, 1, 1), "anti_ship": (160, 1, 2),
}
# Вклад личного состава (на 1000 бойцов): пехота — массовка (атака/броня/живучесть)
INF_ATTACK, INF_ARMOR, INF_HP = 2, 1, 4


def cat_combat(category: str) -> tuple[int, int, int]:
    return COMBAT.get(category, (5, 5, 5))


def quality_mult(academy: int) -> float:
    return 1.0 + academy * 0.10


def morale_mult(happiness: float, stability: float) -> float:
    """Мораль армии: от счастья и стабильности (0.60 … 1.00)."""
    return round(0.60 + (happiness or 0) / 100 * 0.20 + (stability or 0) / 100 * 0.20, 3)


def formation_combat(key: str, academy: int, happiness: float, stability: float) -> tuple[int, int, int]:
    """Боевые параметры соединения → (атака, броня, живучесть) с учётом морали/академии."""
    atk = arm = hp = 0
    for cat, n in form_required(key).items():
        a, d, h = cat_combat(cat)
        atk += a * n; arm += d * n; hp += h * n
    k = form_personnel(key) // 1000
    atk += k * INF_ATTACK; arm += k * INF_ARMOR; hp += k * INF_HP
    q = quality_mult(academy); m = morale_mult(happiness, stability)
    return int(atk * q * m), int(arm * q), int(hp * q * m)


def formation_power(key: str, academy: int, happiness: float, stability: float) -> int:
    """Единый боевой рейтинг (для сумм/сортировки): атака + броня + живучесть."""
    a, d, h = formation_combat(key, academy, happiness, stability)
    return a + d + h


def formation_upkeep(key: str) -> int:
    equip_value = sum(EQUIP_CATEGORIES.get(cat, ("", "", "", {}, 0, 0))[4] * n
                      for cat, n in form_required(key).items())
    return int(equip_value * UPKEEP_EQUIP_FACTOR) + form_personnel(key) * UPKEEP_PER_SOLDIER


def required_text(key: str) -> str:
    parts = [f"{eq_cat_icon(c)} {eq_cat_label(c)} ×{n}" for c, n in form_required(key).items()]
    extra = f" · академия {form_min_academy(key)}" if form_min_academy(key) else ""
    return " · ".join(parts) + f" · 👥 {form_personnel(key):,}".replace(",", " ") + extra


def required_text_plain(key: str) -> str:
    """Без кастом-иконок — для описаний пунктов селекта (там эмодзи не рендерятся)."""
    parts = [f"{eq_cat_label(c)} ×{n}" for c, n in form_required(key).items()]
    pers = f"{form_personnel(key):,}".replace(",", " ")
    extra = f" · акад.{form_min_academy(key)}" if form_min_academy(key) else ""
    return " · ".join(parts) + f" · {pers} л/с" + extra
