"""
Ультиматумы — ядро логики. Без БД и disnake: правила, числа, формулы.

ГЛАВНОЕ — РЕАЛИЗМ СИЛЫ. Слабая страна не может давить сильную: всё упирается в
power ratio = сила(инициатор)/сила(цель). Коэффициент режет требования (клампы)
и «зубастость» угрозы (leverage). Ватикан против США: ratio ≈ 0 → денег/территории
требовать нельзя (потолки ~0), рычаг ~0 → цель отказывает бесплатно, а инициатор
теряет лицо за пустую угрозу.

Решение (принять/отклонить/контр) — за игроком-целью; формулы лишь задают ставки.
Все числа — ЗАГЛУШКИ под клиента, тюнятся здесь.
"""

from __future__ import annotations

# ──────────────────────────────────────────────────────────────────────────
#  Расчёт силы страны (на существующих статах бота)
# ──────────────────────────────────────────────────────────────────────────
W_MIL      = 1.0      # вес военной мощи (доминирует)
W_ECO      = 1.0      # вес экономики
W_DEM      = 0.5      # вес демографии/территории
ARSENAL_W  = 0.002    # вклад единицы техники на складе в военную мощь


def power_score(army_power: float, arsenal: int, income: float,
                population: int, territory: int) -> float:
    """Интегральная «сила» страны. +1 чтобы не делить на ноль."""
    mil = (army_power or 0.0) + (arsenal or 0) * ARSENAL_W
    eco = (income or 0.0) / 1_000_000.0
    dem = (population or 0) / 1_000_000.0 + (territory or 0) / 100_000.0
    return mil * W_MIL + eco * W_ECO + dem * W_DEM + 1.0


def power_ratio(issuer_power: float, target_power: float) -> float:
    return (issuer_power or 0.0) / (target_power or 1.0)


def leverage(ratio: float) -> float:
    """Кредибильность угрозы 0–100. ratio=1 → 50; сильно больше → →100; меньше → →0."""
    r = max(0.0, ratio)
    return round(_clamp(100.0 * r / (r + 1.0), 0, 100), 1)


# ──────────────────────────────────────────────────────────────────────────
#  Серьёзность и потолки требований (ЗАЩИТА от нереалистичного давления)
# ──────────────────────────────────────────────────────────────────────────
SERIOUS_MIN_RATIO = 0.40   # ниже — ультиматум несерьёзен: только «мягкие» требования
MONEY_CAP_PCT     = 0.25   # максимум денег = % казны цели · clamp(ratio)
RES_CAP_PCT       = 0.30   # максимум ресурса = % склада цели · clamp(ratio)
MAX_TERR_REGIONS  = 5      # потолок областей за один ультиматум
TERR_MIN_RATIO    = 1.20   # территорию можно требовать ТОЛЬКО будучи заметно сильнее
TERR_PER_RATIO    = 1.0    # сколько областей добавляет каждая единица превосходства
DEMIL_MIN_RATIO   = 1.30   # демилитаризацию — только будучи сильнее


def is_serious(ratio: float) -> bool:
    return ratio >= SERIOUS_MIN_RATIO


def money_cap(target_money: int, ratio: float) -> int:
    if ratio < SERIOUS_MIN_RATIO:   # несопоставимо слабее — вообще ничего не выжать
        return 0
    return max(0, int((target_money or 0) * MONEY_CAP_PCT * _clamp(ratio, 0, 1)))


def resource_cap(have: int, ratio: float) -> int:
    if ratio < SERIOUS_MIN_RATIO:
        return 0
    return max(0, int((have or 0) * RES_CAP_PCT * _clamp(ratio, 0, 1)))


def territory_cap(ratio: float) -> int:
    if ratio < TERR_MIN_RATIO:
        return 0
    return int(_clamp(1 + (ratio - TERR_MIN_RATIO) * TERR_PER_RATIO, 0, MAX_TERR_REGIONS))


def demil_cap(formations: int, ratio: float) -> int:
    if ratio < DEMIL_MIN_RATIO:
        return 0
    return int(_clamp(int((ratio - 1.0)), 0, formations))


# ──────────────────────────────────────────────────────────────────────────
#  Каталог требований
#    icon  — ui-слаг · material — материальное (режется потолком) · needs —
#    'amount' | 'resource' | 'regions' | None
# ──────────────────────────────────────────────────────────────────────────
DEMANDS: dict[str, dict] = {
    "money":        {"label": "Контрибуция", "icon": "money", "material": True, "needs": "amount"},
    "resource":     {"label": "Ресурсы", "icon": "storage", "material": True, "needs": "resource"},
    "territory":    {"label": "Территория", "icon": "globe", "material": True, "needs": "regions"},
    "demilitarize": {"label": "Демилитаризация", "icon": "disband", "material": True, "needs": "amount"},
    "apology":      {"label": "Публичные извинения", "icon": "gov", "material": False, "needs": None},
}
MATERIAL_DEMANDS = [k for k, v in DEMANDS.items() if v["material"]]

CONSEQUENCES: dict[str, dict] = {
    "war":      {"label": "Война (casus belli)", "icon": "attack"},
    "blockade": {"label": "Экономическая блокада", "icon": "blockade"},
}


def demand_label(key: str) -> str:
    return DEMANDS[key]["label"] if key in DEMANDS else key


# ──────────────────────────────────────────────────────────────────────────
#  Темп / стоимость / сроки
# ──────────────────────────────────────────────────────────────────────────
ISSUE_COST       = 50_000_000     # стоимость выдвижения (анти-спам)
ULT_COOLDOWN     = 2 * 3600       # кулдаун на инициатора между ультиматумами
DEADLINE_MIN_H   = 6
DEADLINE_MAX_H   = 48
DEADLINE_DEF_H   = 24

# ──────────────────────────────────────────────────────────────────────────
#  Эффекты исходов (все — заглушки)
# ──────────────────────────────────────────────────────────────────────────
ACCEPT_HUMILIATION   = (5, 15)     # −счастье цели при принятии (× вес требований)
ACCEPT_ISSUER_HAPPY  = 4           # +счастье инициатору за дип. победу
REJECT_STAB_MAX      = 18          # макс −стабильность цели при отказе (при leverage=100)
BLUFF_LEVERAGE       = 35          # ниже — угроза воспринимается как блеф
BLUFF_HAPPY_HIT      = 8           # −счастье инициатору за блеф, который отвергли
BLOCKADE_MULT        = (0.85, 0.92)
BLOCKADE_HOURS       = (24, 48)
COUNTER_FACTOR       = 0.5         # контрпредложение урезает материальные требования вдвое
CASUS_WINDOW_D       = 30          # сколько дней отказ остаётся casus belli


def reject_stability_hit(lev: float) -> int:
    """−стабильность цели при отказе: масштаб от рычага (слабая угроза → ~0)."""
    return int(round(REJECT_STAB_MAX * (lev / 100.0)))


def is_bluff(lev: float) -> bool:
    return lev < BLUFF_LEVERAGE


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))
