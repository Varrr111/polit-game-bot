"""
«Наследие» — формируемые исторические державы. Без БД и disnake.

Страна-основатель, удержавшая нужные земли (области на карте — свои, отвоёванные у игроков
и у ИИ-государств) и выполнившая условия, провозглашает державу: титул поверх страны
(ник, карта, профиль, новости), исторический строй, уникальные бонусы, золото на карте.

Требования по землям — доля областей каждой страны-ядра, которыми ты владеешь СЕЙЧАС
(с учётом захватов). Если позже потерять больше половины требуемого — «упадок»:
бонусы и золото пропадают, пока земли не вернутся. Каждую державу можно основать
один раз за игру, страна — одну державу.

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from __future__ import annotations

# ── бонусы: ключ → (подпись, единица) ──
BONUSES = {
    "income": ("доход", "%"),          # +% к авто-доходу (строка «Наследие» в экономике)
    "army": ("сила армии", "%"),       # +% к боевой мощи в войне
    "stability": ("стабильность", "/ч"),   # +к стабильности каждый час (до 100)
    "legitimacy": ("легитимность", "/ч"),  # +к легитимности каждый час (до 100)
    "influence": ("дипкапитал", "/ч"),     # +дипкапитал каждый час
}

DECLINE_SHARE = 0.5          # держать ≥ этой доли от требуемого — иначе упадок
FORM_REP = 10                # престиж: репутация
FORM_LEGIT = 15              # легитимность при провозглашении
NEIGHBOR_REL = -10           # соседи насторожены
GOLD = (232, 194, 96)


def _f(title, founders, cores, *, ideology=None, stab=60, legit=55, dev=15, money=20_000_000_000,
       influence=60, bonuses=None, motto=""):
    return {"title": title, "founders": founders, "cores": cores, "ideology": ideology, "stab": stab,
            "legit": legit, "dev": dev, "money": money, "influence": influence,
            "bonuses": bonuses or {}, "motto": motto}


# cores: {adm0_a3: минимальная доля областей страны во владении}
FORMABLES: dict[str, dict] = {
    "greater_armenia": _f("Армянская империя", ["Армения"],
        {"ARM": 0.9, "AZE": 0.35, "GEO": 0.25, "TUR": 0.12, "IRN": 0.08}, ideology="monarchy",
        bonuses={"income": 6, "legitimacy": 0.5}, motto="Наследие Тиграна Великого"),
    "austria_hungary": _f("Австро-Венгрия", ["Австрия", "Венгрия"],
        {"AUT": 0.9, "HUN": 0.9, "CZE": 0.7, "SVK": 0.7, "SVN": 0.7, "HRV": 0.6, "BIH": 0.5},
        ideology="monarchy", bonuses={"stability": 0.6, "income": 5}, motto="Двуединая монархия"),
    "ottoman": _f("Османская империя", ["Турция"],
        {"TUR": 0.9, "GRC": 0.3, "BGR": 0.5, "SYR": 0.7, "IRQ": 0.5, "JOR": 0.5, "EGY": 0.3},
        ideology="monarchy", money=40_000_000_000, bonuses={"army": 8, "income": 5}, motto="Возрождённая Порта"),
    "russian_empire": _f("Российская империя", ["Россия"],
        {"RUS": 0.9, "UKR": 0.7, "BLR": 0.8, "FIN": 0.5, "KAZ": 0.5, "GEO": 0.5, "ARM": 0.5, "AZE": 0.5,
         "EST": 0.7, "LVA": 0.7, "LTU": 0.7, "MDA": 0.5},
        ideology="monarchy", money=60_000_000_000, bonuses={"army": 8, "stability": 0.4}, motto="Самодержавие и держава"),
    "ussr": _f("Советский Союз", ["Россия", "Украина", "Белоруссия", "Казахстан"],
        {"RUS": 0.8, "UKR": 0.8, "BLR": 0.8, "KAZ": 0.7, "UZB": 0.6, "AZE": 0.5, "ARM": 0.5, "GEO": 0.5,
         "MDA": 0.5, "KGZ": 0.5, "TJK": 0.5, "TKM": 0.5, "EST": 0.5, "LVA": 0.5, "LTU": 0.5},
        ideology="communism", money=60_000_000_000, bonuses={"army": 10, "legitimacy": 0.5}, motto="Союз нерушимый"),
    "commonwealth": _f("Речь Посполитая", ["Польша", "Литва"],
        {"POL": 0.9, "LTU": 0.9, "BLR": 0.6, "LVA": 0.4, "UKR": 0.3},
        ideology="monarchy", bonuses={"income": 6, "influence": 0.5}, motto="Республика двух народов"),
    "hre": _f("Священная Римская империя", ["Германия", "Австрия"],
        {"DEU": 0.9, "AUT": 0.9, "CZE": 0.8, "NLD": 0.6, "BEL": 0.5, "CHE": 0.5, "LUX": 1.0},
        ideology="monarchy", money=50_000_000_000, bonuses={"income": 7, "legitimacy": 0.4}, motto="Империя германской нации"),
    "roman_empire": _f("Римская империя", ["Италия"],
        {"ITA": 0.9, "FRA": 0.5, "ESP": 0.5, "GRC": 0.5, "TUR": 0.3, "EGY": 0.3, "TUN": 0.5, "PRT": 0.5},
        ideology="authoritarian", money=80_000_000_000, dev=25, bonuses={"army": 10, "income": 8},
        motto="SPQR — Сенат и народ Рима"),
    "byzantium": _f("Византийская империя", ["Греция", "Турция"],
        {"GRC": 0.9, "TUR": 0.6, "BGR": 0.6, "CYP": 1.0, "ALB": 0.5, "MKD": 0.5},
        ideology="theocracy", bonuses={"stability": 0.5, "income": 5}, motto="Второй Рим"),
    "gran_colombia": _f("Великая Колумбия", ["Колумбия", "Венесуэла", "Эквадор"],
        {"COL": 0.9, "VEN": 0.9, "ECU": 0.9, "PAN": 0.9},
        bonuses={"income": 7, "stability": 0.3}, motto="Мечта Боливара"),
    "kalmar_union": _f("Кальмарская уния", ["Дания", "Швеция", "Норвегия"],
        {"DNK": 0.9, "SWE": 0.9, "NOR": 0.9, "ISL": 0.5, "FIN": 0.5},
        ideology="monarchy", bonuses={"income": 6, "influence": 0.5}, motto="Три короны"),
    "united_korea": _f("Объединённая Корея", ["Южная Корея", "КНДР"],
        {"KOR": 0.9, "PRK": 0.9}, bonuses={"income": 8, "stability": 0.3}, motto="Один народ"),
    "yugoslavia": _f("Югославия", ["Сербия", "Хорватия", "Словения", "Босния и Герцеговина"],
        {"SRB": 0.9, "HRV": 0.9, "BIH": 0.9, "SVN": 0.8, "MKD": 0.8, "MNE": 0.9, "KOS": 0.8},
        ideology="socialism", bonuses={"stability": 0.5, "army": 5}, motto="Братство и единство"),
    "czechoslovakia": _f("Чехословакия", ["Чехия", "Словакия"],
        {"CZE": 0.9, "SVK": 0.9}, money=10_000_000_000, dev=10,
        bonuses={"income": 5, "legitimacy": 0.4}, motto="Правда побеждает"),
    "persian_empire": _f("Персидская империя", ["Иран"],
        {"IRN": 0.9, "IRQ": 0.5, "AFG": 0.4, "AZE": 0.4, "ARM": 0.3, "TKM": 0.3},
        ideology="monarchy", money=40_000_000_000, bonuses={"army": 7, "income": 5}, motto="Шахиншахство"),
    "mongol_empire": _f("Монгольская империя", ["Монголия"],
        {"MNG": 0.9, "CHN": 0.25, "KAZ": 0.4, "RUS": 0.08}, ideology="monarchy",
        bonuses={"army": 12, "stability": 0.3}, motto="Вечное синее небо"),
    "caliphate": _f("Арабский халифат", ["Саудовская Аравия", "Египет"],
        {"SAU": 0.9, "EGY": 0.7, "IRQ": 0.6, "SYR": 0.6, "JOR": 0.9, "YEM": 0.6},
        ideology="theocracy", money=40_000_000_000, bonuses={"income": 7, "legitimacy": 0.5}, motto="Умма едина"),
    "celestial_empire": _f("Поднебесная империя", ["Китай"],
        {"CHN": 0.95, "MNG": 0.7, "TWN": 1.0}, ideology="monarchy", money=60_000_000_000,
        bonuses={"income": 8, "stability": 0.4}, motto="Мандат Неба"),
    "british_empire": _f("Британская империя", ["Великобритания"],
        {"GBR": 0.9, "IRL": 0.9, "CAN": 0.2, "AUS": 0.2, "IND": 0.15, "ZAF": 0.3, "EGY": 0.2},
        ideology="monarchy", money=60_000_000_000, bonuses={"income": 8, "influence": 0.6},
        motto="Империя, над которой не заходит солнце"),
    "french_empire": _f("Французская империя", ["Франция"],
        {"FRA": 0.9, "BEL": 0.9, "LUX": 1.0, "NLD": 0.6, "ITA": 0.3, "ESP": 0.3, "DEU": 0.2},
        ideology="monarchy", money=50_000_000_000, bonuses={"army": 8, "legitimacy": 0.4}, motto="Великая армия"),
    "spanish_empire": _f("Испанская империя", ["Испания"],
        {"ESP": 0.9, "PRT": 0.6, "MEX": 0.3, "COL": 0.2, "PER": 0.3, "ARG": 0.2, "PHL": 0.3},
        ideology="monarchy", money=50_000_000_000, bonuses={"income": 7, "army": 5}, motto="Plus Ultra"),
    "portuguese_empire": _f("Португальская империя", ["Португалия"],
        {"PRT": 0.9, "BRA": 0.3, "AGO": 0.4, "MOZ": 0.4}, ideology="monarchy",
        bonuses={"income": 7, "influence": 0.4}, motto="Морская держава"),
    "ethiopian_empire": _f("Эфиопская империя", ["Эфиопия"],
        {"ETH": 0.9, "ERI": 0.9, "SOM": 0.4, "DJI": 0.9}, ideology="monarchy", money=10_000_000_000, dev=10,
        bonuses={"stability": 0.5, "army": 6}, motto="Лев Иудеи"),
    "inca_empire": _f("Империя инков", ["Перу", "Боливия"],
        {"PER": 0.9, "BOL": 0.7, "ECU": 0.7, "CHL": 0.3}, money=10_000_000_000, dev=10,
        bonuses={"income": 6, "stability": 0.4}, motto="Тауантинсуйу"),
    "mexican_empire": _f("Мексиканская империя", ["Мексика"],
        {"MEX": 0.9, "GTM": 0.9, "HND": 0.6, "SLV": 0.9, "NIC": 0.5, "CRI": 0.5}, ideology="monarchy",
        bonuses={"income": 6, "army": 5}, motto="Наследие Итурбиде"),
    "turan": _f("Великий Туран", ["Казахстан", "Узбекистан", "Туркменистан", "Кыргызстан"],
        {"KAZ": 0.9, "UZB": 0.9, "TKM": 0.7, "KGZ": 0.7}, bonuses={"income": 6, "army": 6},
        motto="Единство степи"),
    "japanese_empire": _f("Японская империя", ["Япония"],
        {"JPN": 0.95, "KOR": 0.5, "TWN": 0.7, "PHL": 0.3}, ideology="monarchy", money=50_000_000_000,
        bonuses={"army": 9, "income": 5}, motto="Восходящее солнце"),
    "mughal_empire": _f("Империя Великих Моголов", ["Индия", "Пакистан", "Бангладеш"],
        {"IND": 0.8, "PAK": 0.8, "BGD": 0.8, "AFG": 0.3}, ideology="monarchy", money=50_000_000_000,
        bonuses={"income": 8, "stability": 0.3}, motto="Сокровищница Индостана"),
    "baltic_union": _f("Балтийская уния", ["Эстония", "Латвия", "Литва"],
        {"EST": 0.9, "LVA": 0.9, "LTU": 0.9}, money=8_000_000_000, dev=8,
        bonuses={"income": 6, "influence": 0.5}, motto="Балтийский путь"),
    "mali_empire": _f("Империя Мали", ["Мали"],
        {"MLI": 0.9, "NER": 0.5, "SEN": 0.4, "GIN": 0.4, "MRT": 0.4}, ideology="monarchy",
        money=6_000_000_000, dev=8, bonuses={"income": 8, "stability": 0.3}, motto="Золото Мансы Мусы"),
    "khmer_empire": _f("Кхмерская империя", ["Камбоджа"],
        {"KHM": 0.9, "LAO": 0.5, "THA": 0.3, "VNM": 0.2}, ideology="monarchy",
        money=8_000_000_000, dev=8, bonuses={"income": 6, "stability": 0.4}, motto="Ангкор"),
}


def bonus_text(bonuses: dict) -> str:
    parts = []
    for k, v in bonuses.items():
        label, unit = BONUSES[k]
        parts.append(f"+{v:g}{unit} {label}")
    return ", ".join(parts)


def available_for(country: str) -> list[str]:
    return [k for k, f in FORMABLES.items() if country in f["founders"]]
