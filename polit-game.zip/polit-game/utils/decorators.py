"""
Декораторы для UI-колбэков.

interaction_error_handler оборачивает async-колбэки кнопок/модалок, чтобы
исключения не роняли взаимодействие молча, а логировались и показывали
пользователю аккуратную ошибку.
"""

import functools
import traceback

import disnake


def interaction_error_handler(func):
    """Ловит исключения в колбэке интеракции и аккуратно сообщает об ошибке."""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except Exception:
            traceback.print_exc()
            # TODO: единый ERROR_COLOR-эмбед + ответ пользователю (этап 5).
            inter = next((a for a in args if isinstance(a, disnake.Interaction)), None)
            if inter is not None and not inter.response.is_done():
                try:
                    await inter.response.send_message("Произошла ошибка.", ephemeral=True)
                except Exception:
                    pass
    return wrapper
