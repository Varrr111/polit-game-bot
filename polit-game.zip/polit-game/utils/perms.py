"""
Централизованный слой прав на команды (система !perm).

По требованию: НИ У ОДНОЙ роли нет Discord-права «Администратор» (кроме владельца
сервера — он всевластен по определению). Доступ к админ-командам раздаётся
через !perm (grant роли/юзеру на конкретную команду или на всё — scope '*').

  • has_command_access(member, scope) — владелец | Discord-админ (= только владелец)
    | config.ADMINISTRATOR | явный grant на scope ИЛИ на '*'.
  • is_staff(member) — владелец | админ | config.ADMINISTRATOR | grant на '*'
    (широкий «штабной» доступ: игровые cog_check-байпасы — действовать за любую страну).

Один источник правды — таблица command_perms (менеджер CommandPerms).
"""

import config
from .managers import CommandPerms

_cp = CommandPerms()


def _role_ids(member) -> list[int]:
    return [r.id for r in getattr(member, "roles", []) if getattr(r, "id", None)]


def _owner_or_admin(member) -> bool:
    if member is None:
        return False
    uid = getattr(member, "id", None)
    if config.ADMINISTRATOR and uid == config.ADMINISTRATOR:
        return True
    guild = getattr(member, "guild", None)
    if guild is not None and getattr(guild, "owner_id", None) == uid:
        return True
    gp = getattr(member, "guild_permissions", None)
    return bool(gp and gp.administrator)


def is_staff(member) -> bool:
    """Широкий админ-доступ: владелец/админ или grant на '*'."""
    if _owner_or_admin(member):
        return True
    return _cp.has("*", getattr(member, "id", 0) or 0, _role_ids(member))


def has_command_access(member, scope: str) -> bool:
    """Доступ к конкретной команде scope: владелец/админ, grant на '*' или на scope."""
    if _owner_or_admin(member):
        return True
    uid = getattr(member, "id", 0) or 0
    rids = _role_ids(member)
    return _cp.has("*", uid, rids) or _cp.has(scope, uid, rids)
