"""
Дипломатия — ядро логики. Без БД и disnake: формулы, числа, справочники.

ЖИВАЯ СЕТЬ: у каждой пары стран есть ОТНОШЕНИЯ (−100..+100). Они не стоят на
месте — каждый час дрейфуют к «равновесию», которое бот вычисляет из состояния
мира: схожий строй/религия, посольства, договоры, торговля на рынке (сближают);
санкции, война, разоблачённый шпионаж, ультиматумы (отталкивают); общий враг
(сближает); репутация каждой стороны. Разовые толчки (миссия, нота, инцидент,
предательство) сдвигают отношения сразу, но со временем «выветриваются» к
равновесию — память о событиях угасает, если причина ушла.

ДИПКАПИТАЛ — валюта влияния (0..100), копится сам (стабильность, посольства,
репутация) и тратится на действия: договоры, миссии, ноты, деэскалацию.

РЕПУТАЦИЯ (0..100) — глобальная: предательство договора бьёт по ней, верность
союзу растёт. Влияет на равновесие отношений со ВСЕМИ странами.

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from __future__ import annotations


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


# ── отношения ──
REL_MIN, REL_MAX = -100.0, 100.0
DRIFT_PER_H = 2.0            # на сколько пунктов в час отношения идут к равновесию

# Ступени отношений: (нижняя граница, ключ, подпись, слаг иконки)
TIERS = [
    (60,   "friend",  "Дружба",        "relations"),
    (20,   "partner", "Партнёрство",   "rel_up"),
    (-20,  "neutral", "Нейтралитет",   "diplo"),
    (-60,  "tension", "Напряжённость", "rel_down"),
    (-101, "hostile", "Вражда",        "escalate"),
]


def tier(value: float) -> tuple[str, str, str]:
    """→ (ключ, подпись, слаг иконки) ступени для значения отношений."""
    for lo, key, label, icon in TIERS:
        if value >= lo:
            return key, label, icon
    return TIERS[-1][1:]


def rel_bar(value: float, width: int = 10) -> str:
    """Шкала −100..+100: ▰▰▰▱▱ (центр — нейтраль)."""
    filled = round((_clamp(value, REL_MIN, REL_MAX) + 100) / 200 * width)
    return "▰" * filled + "▱" * (width - filled)


# ── слагаемые равновесия (вклад в «куда тянутся» отношения) ──
EQ_SAME_IDEOLOGY = 15
EQ_SAME_RELIGION = 8
EQ_EMBASSY = 10              # за каждое посольство в паре (взаимные = 20)
EQ_TRADE_MAX = 15            # торговля на рынке между странами за окно
TRADE_VALUE_FOR_MAX = 500_000_000   # оборот за окно, дающий полный бонус
TRADE_WINDOW_D = 7
EQ_SANCTIONS = -25           # за каждую активную санкцию в паре
EQ_WAR = -80                 # идёт война
EQ_SPY_EXPOSED = -15         # за каждое разоблачение в паре за окно
EQ_SPY_CAP = -30
EQ_ULTIMATUM = -10           # за каждый ультиматум в паре за окно
EQ_ULT_CAP = -20
MEMORY_WINDOW_D = 14         # окно «памяти» для шпионажа/ультиматумов
EQ_COMMON_ENEMY = 10         # оба воюют с одной страной или санкционируют одну цель
REP_BASE = 60.0
EQ_REP_K = 0.3               # (репутация − 60) × k — от каждой стороны пары

# ── договоры ──
# key → подпись, иконка, мин. отношения для предложения, цена в дипкапитале,
# вклад в равновесие, описание
TREATIES: dict[str, dict] = {
    "nonaggr": {"label": "Пакт о ненападении", "icon": "nonaggression", "min_rel": -30,
                "cost": 10, "eq": 10,
                "desc": "Обязательство не нападать. Нарушение — предательство."},
    "trade":   {"label": "Торговое соглашение", "icon": "trade_pact", "min_rel": 0,
                "cost": 15, "eq": 15,
                "desc": "Обоим +3% к авто-доходу (до 4 соглашений)."},
    "transit": {"label": "Право прохода", "icon": "transit", "min_rel": 20,
                "cost": 10, "eq": 5,
                "desc": "Можно наступать через земли партнёра (общая граница)."},
}
# Военный союз больше не парный договор — это военный БЛОК (utils/alliance.py, !альянс).
TREATY_KEYS = list(TREATIES.keys())
PROPOSAL_TTL = 24 * 3600     # сколько висит предложение договора
REJECT_REFUND = 0.5          # доля дипкапитала, возвращаемая при отказе/истечении
TRADE_PACT_BONUS = 0.03      # +3% дохода за торговое соглашение
TRADE_PACT_CAP = 4
CANCEL_REL_HIT = -10         # разрыв договора (честный, не война)
SIGN_REL_BOOST = 10          # подписание договора — разовый толчок


def treaty_label(key: str) -> str:
    return TREATIES[key]["label"] if key in TREATIES else key


def trade_pact_mult(active_trade_pacts: int) -> float:
    return round(1.0 + TRADE_PACT_BONUS * min(active_trade_pacts, TRADE_PACT_CAP), 3)


# ── предательство (война против партнёра по ненападению/союзу) ──
BETRAYAL_REP = -30
BETRAYAL_REL = -60           # разовый удар по отношениям с жертвой

# ── зов союзника ──
CALL_TTL = 24 * 3600
CALL_JOIN_REP = 8
CALL_JOIN_REL = 15
CALL_REFUSE_REP = -10
CALL_REFUSE_REL = -20
CALL_CASUS = "Защита союзника"

# ── связь с другими механиками ──
SANCTION_BREAKS = ("trade", "transit")   # что рвут санкции против партнёра

# ── дипкапитал ──
INF_MAX = 100.0
INF_START = 30.0


def influence_rate(stability: float, embassies: int, reputation: float) -> float:
    """Прирост дипкапитала в час."""
    return round(1.0 + (stability or 0) / 50.0 + embassies * 0.3 + (reputation or 0) / 50.0, 2)


# ── репутация ──
REP_MIN, REP_MAX = 0.0, 100.0
REP_RECOVER_PER_H = 0.5      # дрейф репутации обратно к базе


def rep_word(rep: float) -> str:
    if rep >= 85: return "образцовая"
    if rep >= 70: return "надёжная"
    if rep >= 50: return "обычная"
    if rep >= 30: return "сомнительная"
    return "вероломная"


# ── действия ──
MISSION_COST = 15            # дипмиссия: разовый толчок отношений вверх
MISSION_BOOST = 8
MISSION_CD = 6 * 3600        # на пару
PROTEST_COST = 10            # нота протеста: публичное осуждение
PROTEST_REL = -12
PROTEST_REP = -2             # удар по репутации цели
PROTEST_CD = 12 * 3600
EMBASSY_COST_MONEY = 50_000_000
EMBASSY_COST_INF = 10
EMBASSY_MAX = 8

# ── инциденты (фоновые кризисы) ──
INCIDENT_REL_THRESHOLD = -20     # кризисы возникают при отношениях ниже
INCIDENT_BASE_CHANCE = 0.03      # в час на пару при пороге; растёт к вражде
INCIDENT_COUNTRY_CD = 12 * 3600  # не чаще на страну
INCIDENT_TTL = 12 * 3600         # время на ответ
DEESCALATE_COST = 10

# исходы: (выбор_A, выбор_B) → (изм. отношений, casus belli обеим)
# soft = деэскалация, hard = жёсткий ответ, none = промолчал
INCIDENT_OUTCOMES = {
    ("soft", "soft"): (+10, False),
    ("soft", "hard"): (-10, False),
    ("hard", "soft"): (-10, False),
    ("hard", "hard"): (-25, True),
    ("none", "none"): (-5, False),
    ("soft", "none"): (0, False),
    ("none", "soft"): (0, False),
    ("hard", "none"): (-15, False),
    ("none", "hard"): (-15, False),
}
HARD_STAB_BONUS = 2.0            # «сплочение вокруг флага» тому, кто ответил жёстко
SOFT_REP_BONUS = 3.0             # миротворцу против жёсткой стороны — репутация

INCIDENTS = [
    ("border",   "Пограничный инцидент",
     "На границе {a} и {b} произошла перестрелка патрулей. Обе стороны обвиняют друг друга."),
    ("diplomat", "Высылка дипломата",
     "{a} объявила дипломата {b} персоной нон грата. Посольство требует объяснений."),
    ("vessel",   "Задержание судна",
     "Береговая охрана {a} задержала торговое судно под флагом {b}. Экипаж под арестом."),
    ("airspace", "Нарушение воздушного пространства",
     "Военный самолёт {b} вошёл в воздушное пространство {a}. Подняты перехватчики."),
    ("hackers",  "Кибератака на ведомства",
     "Сайты министерств {a} легли. Следы ведут к хакерам, связанным с {b}."),
    ("arrest",   "Арест журналистов",
     "В {a} задержаны журналисты из {b} по обвинению в шпионаже."),
    ("protest",  "Штурм посольства",
     "Толпа в {a} осадила посольство {b}. Полиция не вмешалась."),
    ("fishing",  "Рыболовный конфликт",
     "Рыбаки {b} зашли в спорные воды {a}. Начались столкновения с пограничниками."),
]
INCIDENT_BY_KEY = {k: (t, d) for k, t, d in INCIDENTS}


def incident_chance(relation: float) -> float:
    """Шанс инцидента за час для пары: 0 выше порога, растёт к −100."""
    if relation >= INCIDENT_REL_THRESHOLD:
        return 0.0
    depth = (INCIDENT_REL_THRESHOLD - relation) / (INCIDENT_REL_THRESHOLD - REL_MIN)
    return round(INCIDENT_BASE_CHANCE * (1.0 + 2.0 * depth), 4)


def drift(value: float, target: float, step: float = DRIFT_PER_H) -> float:
    """Шаг отношений к равновесию."""
    if abs(target - value) <= step:
        return round(target, 2)
    return round(value + step * (1 if target > value else -1), 2)


def pair(a: str, b: str) -> tuple[str, str]:
    """Неупорядоченная пара в каноническом порядке (ключ в БД)."""
    return (a, b) if a < b else (b, a)
