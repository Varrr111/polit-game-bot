"""
Защита сервера (Sentinel) — константы, пороги, метаданные, кэши.

Философия: ЖЁСТКО к атакам, КОМФОРТНО к людям. Анти-нюк (крушение каналов/ролей,
массбаны, вебхуки, боты) — агрессивен: иммунен только владелец, нарушитель
банится, структура откатывается. Анти-спам — мягкий и СТУПЕНЧАТЫЙ: штаб и
доверенные иммунны, нормальный чат не трогаем, первая провинность — удаление +
мягкое предупреждение, тайм-ауты только на повтор и растут. Жёсткость анти-спама
включается рейд-режимом.

Все пороги — тюнятся здесь.
"""

from __future__ import annotations

import re
from collections import defaultdict

# ── Модули (ключ → слаг_иконки, название, описание) ──
MODULE_META: dict[str, tuple[str, str, str]] = {
    "antispam":    ("antispam",    "Анти-спам",   "Флуд, масс-пинг, рейд-скорость (ступенчато, штаб иммунен)"),
    "antichannel": ("antinuke",    "Анти-нюк",    "Откат удаления каналов/категорий + бан крушителя"),
    "antirole":    ("antirole",    "Анти-роль",   "Защита ролей: откат удаления/опасных прав"),
    "antiwebhook": ("antiwebhook", "Анти-вебхук", "Удаление вредоносных вебхуков"),
    "antiban":     ("antiban",     "Анти-бан",    "Откат несанкционированных банов/киков"),
    "antibot":     ("antibot",     "Анти-бот",    "Блок добавления чужих ботов"),
}
# Дефолты: защита структуры — ВКЛ; анти-спам — ВКЛ (мягкий). Владелец всё тюнит.
MODULE_DEFAULTS: dict[str, bool] = {
    "antispam": True, "antichannel": True, "antirole": True,
    "antiwebhook": True, "antiban": True, "antibot": True,
}

# ── Пороги анти-спама (комфортные) ──
SPAM_LIMIT         = 7       # сообщений
SPAM_INTERVAL      = 5.0     # за столько секунд → флуд
REPEAT_LIMIT       = 6       # одинаковых подряд → спам-повтор
MASS_MENTION_LIMIT = 6       # упоминаний в одном сообщении → абуз
RAID_SPEED_LIMIT   = 12      # сообщений
RAID_SPEED_WINDOW  = 3.0     # за столько секунд (только в рейд-режиме)
LINK_SOFT_LIMIT    = 3       # ссылок за окно до первого наказания
LINK_WINDOW        = 25.0

# Ступенчатые тайм-ауты (растут за повторы в течение дня), секунды
TIMEOUT_LADDER = (60, 300, 1800, 3600)   # 1м → 5м → 30м → 1ч
STRIKE_DECAY   = 6 * 3600                 # страйки «сгорают» через 6 ч

# «Доверенный» (мягче анти-спам): аккаунт старше N и на сервере дольше M
TRUSTED_ACCOUNT_AGE_D = 7
TRUSTED_MEMBER_MIN    = 20          # сообщений, после которых участник «прижился» (кэш)

# ── Рейд-режим (включается вручную или паник-автоматом) ──
RAID_NEW_ACCOUNT_D = 7              # в рейд-режиме новые аккаунты (<N дн.) ограничены
# Паник-автомат: если за окно много разрушительных действий → авто-локдаун
PANIC_ACTIONS   = 4
PANIC_WINDOW    = 20.0

# ── Анти-нюк: опасные права, за выдачу которых роль откатывается ──
DANGEROUS_PERMS = ("administrator", "ban_members", "kick_members", "manage_guild",
                   "manage_channels", "manage_roles", "manage_webhooks", "mention_everyone")

# ── Контент ──
URL_REGEX = re.compile(
    r"(https?://[^\s]+|discord\.gg/[^\s]+|discord\.com/invite/[^\s]+|\.gg/[^\s]+)",
    re.IGNORECASE)
# Домены, которым ссылки разрешены всем (гифки/медиа/ютуб и т.п.)
SAFE_DOMAINS = frozenset({
    "tenor.com", "giphy.com", "media.tenor.com", "media.giphy.com",
    "youtube.com", "youtu.be", "twitch.tv", "imgur.com", "wikipedia.org",
})
# Фильтр-слов по умолчанию ПУСТ (не превращаем чат в тюрьму) — наполняется владельцем.

# ── Цвета ──
C_DANGER  = 0xE05260
C_WARNING = 0xE0A54D
C_SUCCESS = 0x2E9BD6
C_INFO    = 0x4D9DE0

# ── Кэши (в памяти) ──
spam_cache:   dict = defaultdict(list)   # user_id -> [ts]
repeat_cache: dict = defaultdict(list)   # user_id -> [text]
raid_cache:   dict = defaultdict(list)   # user_id -> [ts]
link_cache:   dict = defaultdict(list)   # user_id -> [ts]
msg_count:    dict = defaultdict(int)    # user_id -> кол-во сообщений (для «прижился»)
strikes:      dict = defaultdict(list)   # user_id -> [ts] наказаний (лестница)
panic_actions: list = []                 # [ts] разрушительных действий (паник-автомат)

# Снапшоты структуры (для отката)
CHANNEL_SNAPSHOT: dict[int, list] = {}
ROLE_SNAPSHOT:    dict[int, list] = {}
LOCKED_GUILDS:    set[int] = set()

# Гильдии, где СЕЙЧАС структуру перестраивает САМ бот (!setupserver и т.п.).
# Пока id здесь — анти-нюк полностью стоит в стороне: не откатывает и не банит
# за удаление/создание каналов и ролей. Снимается автоматически после операции.
SUPPRESS: set[int] = set()


def suppress(guild_id: int):
    """Включить режим «бот сам перестраивает сервер» — guard не реагирует."""
    SUPPRESS.add(guild_id)


def unsuppress(guild_id: int):
    SUPPRESS.discard(guild_id)


def host_of(url: str) -> str:
    m = re.search(r"https?://([^/\s]+)", url) or re.search(r"([a-z0-9.-]+\.[a-z]{2,})", url, re.I)
    if not m:
        return ""
    return m.group(1).lower().lstrip("www.")


def is_safe_link(text: str) -> bool:
    """True, если ВСЕ ссылки в тексте ведут на безопасные домены."""
    urls = URL_REGEX.findall(text or "")
    if not urls:
        return True
    for u in urls:
        h = host_of(u if u.startswith("http") else "http://" + u)
        if not any(h == d or h.endswith("." + d) for d in SAFE_DOMAINS):
            return False
    return True


def next_timeout(user_id: int, now: float) -> int:
    """Длительность тайм-аута по лестнице (растёт за повторы), сек."""
    hist = strikes[user_id]
    hist[:] = [t for t in hist if now - t <= STRIKE_DECAY]
    idx = min(len(hist), len(TIMEOUT_LADDER) - 1)
    hist.append(now)
    return TIMEOUT_LADDER[idx]
