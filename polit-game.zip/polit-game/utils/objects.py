"""
Игровые объекты (датаклассы).

Каждый объект — это «участник» экономики: страна, ЧВК, регион, террорист,
повстанец, а также вспомогательные сущности (компании, инвентарь,
инфраструктура). Поля выведены из использования в cogs/economy.py.

TODO: финализировать поля и значения по умолчанию при реализации DB-слоя.
"""

from dataclasses import dataclass, field


# ── Базовый участник ───────────────────────────────────────────────────────
@dataclass
class BaseObject:
    name: str
    flag: str
    user: int          # discord user id владельца
    money: int = 0


@dataclass
class CountryObject(BaseObject):
    territory: int = 0
    population: int = 0
    continent: str = ""
    trade_lvl: int = 0
    tourism_lvl: int = 0
    economy_lvl: int = 0
    tax_from_popul: int = 0
    happiness: float = 100.0
    stability: float = 100.0
    is_people_important: bool = True

    def __str__(self) -> str:
        return "countries"


@dataclass
class PMCObject(BaseObject):
    country: str = ""          # страна расположения
    trade_lvl: int = 0

    def __str__(self) -> str:
        return "pmcs"


@dataclass
class RegionObject(BaseObject):
    country: str = ""
    trade_lvl: int = 0
    tourism_lvl: int = 0
    economy_lvl: int = 0

    def __str__(self) -> str:
        return "regions"


@dataclass
class TerroristObject(BaseObject):
    country: str = ""

    def __str__(self) -> str:
        return "terrorists"


@dataclass
class RebelObject(BaseObject):
    country: str = ""

    def __str__(self) -> str:
        return "rebels"


# ── Компании и инфраструктура ─────────────────────────────────────────────
@dataclass
class CompanyObject:
    name: str
    country: str
    specialization: str
    level: int = 1


@dataclass
class InfrastructureObject:
    name: str
    chp: int = 0
    atomic: int = 0
    hps1: int = 0
    hps2: int = 0
    hps3: int = 0
    hps4: int = 0


# ── Инвентарь ─────────────────────────────────────────────────────────────
@dataclass
class InventoryObject:
    name: str
    owner: str
    amount: int = 1
    data: dict = field(default_factory=dict)
