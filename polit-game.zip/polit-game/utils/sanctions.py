"""
Санкции — ядро логики. Без БД и disnake: формулы, числа, пакеты.

РЕАЛИЗМ СИЛЫ (как у ультиматумов): урон цели ∝ сумме рычагов санкционеров
(коалиция складывается), ВЗАИМНАЯ ЦЕНА санкционеру ∝ 1/его рычаг — то есть
бить сильно слабее себя почти бесплатно, а давить гиганта в одиночку — бьёт
по тебе же. Ватикан не задушит США сам; коалиция — может.

  econ_power = доход/1e6 + ВВП/1e9 + развитие·5 + 1
  leverage(s→t) = econ_power(s) / econ_power(t)

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from __future__ import annotations


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


# ── сила экономики / рычаг ──
def econ_power(income: float, gdp: float, dev: int) -> float:
    return (income or 0) / 1_000_000.0 + (gdp or 0) / 1_000_000_000.0 + (dev or 0) * 5.0 + 1.0


def leverage(sanctioner_power: float, target_power: float) -> float:
    return (sanctioner_power or 0.0) / (target_power or 1.0)


# ── пакеты санкций: вес в давлении на доход + стоимость введения ──
PACKAGES: dict[str, dict] = {
    "financial": {"label": "Финансовые", "icon": "financial", "weight": 0.30, "cost": 60_000_000,
                  "desc": "Заморозка финансов — главный удар по доходу цели."},
    "embargo":   {"label": "Торговое эмбарго", "icon": "embargo", "weight": 0.18, "cost": 40_000_000,
                  "desc": "Разрыв торговли — удар по рынку и доходу (бьёт и по вам)."},
    "tech":      {"label": "Технологические", "icon": "techban", "weight": 0.10, "cost": 50_000_000,
                  "desc": "Запрет технологий — развитие и производство цели дороже."},
}
PACKAGE_KEYS = list(PACKAGES.keys())


def packages_weight(pkgs: list[str]) -> float:
    return sum(PACKAGES[p]["weight"] for p in pkgs if p in PACKAGES)


def packages_cost(pkgs: list[str]) -> int:
    return sum(PACKAGES[p]["cost"] for p in pkgs if p in PACKAGES)


def package_label(key: str) -> str:
    return PACKAGES[key]["label"] if key in PACKAGES else key


# ── коэффициенты формул (заглушки) ──
K_TARGET      = 1.00    # сила давления на цель
K_COST        = 0.40    # сила взаимной цены санкционеру
FLOOR_TARGET  = 0.50    # доход цели не ниже ×0.5 (в ноль не задушить)
FLOOR_COST    = 0.70    # санкционер не навредит себе сильнее ×0.7
MIN_LEV       = 0.05    # нижняя граница рычага (чтобы 1/lev не взрывалось)
RESILIENCE_DIV = 150.0  # устойчивость снижает давление: ×(1 − resilience/150)

# ── техпакет: удорожание развития/замедление производства ──
TECH_DEV_COST_MULT = 1.25   # развитие цели ×1.25 стоимости при техсанкциях

# ── внутренний удар (связка с политикой) ──
BITE_THRESHOLD   = 0.85   # если доход цели ×< этого — санкции бьют по политике
BITE_HAP_PER_H   = 2.0    # −счастье/ч (× глубина)
BITE_LEGIT_PER_H = 1.5    # −легитимность/ч (× глубина)
BITE_OPP_PER_H   = 3.0    # +оппозиция/ч (× глубина)

# ── устойчивость (контригра цели) ──
RESILIENCE_MAX        = 100.0
RESILIENCE_DECAY_PER_H = 1.0            # устойчивость медленно спадает
RESILIENCE_COST_PER_PT = 4_000_000     # $ за +1 устойчивости

# ── темп / стоимость ──
IMPOSE_COOLDOWN = 1 * 3600   # пауза между введениями санкций на санкционера
CASUS_WINDOW_D  = 30


def target_pressure(lev: float, weight: float, resilience: float) -> float:
    """Вклад ОДНОГО санкционера в давление на доход цели."""
    return max(0.0, lev) * weight * (1.0 - _clamp(resilience, 0, 100) / RESILIENCE_DIV)


def target_income_mult(total_pressure: float) -> float:
    """Итоговый множитель дохода цели от ВСЕХ санкций (сумма давлений)."""
    return round(_clamp(1.0 - K_TARGET * max(0.0, total_pressure), FLOOR_TARGET, 1.0), 3)


def cost_pressure(lev: float, weight: float) -> float:
    """Взаимная цена ОДНОЙ санкции санкционеру (∝ 1/рычаг)."""
    return K_COST * weight / max(lev, MIN_LEV)


def cost_income_mult(total_cost_pressure: float) -> float:
    """Итоговый множитель дохода САНКЦИОНЕРА (его собственные потери от торговли)."""
    return round(_clamp(1.0 - max(0.0, total_cost_pressure), FLOOR_COST, 1.0), 3)


def bite_depth(target_mult: float) -> float:
    """Насколько глубоко санкции бьют по политике (0..1), 0 если легче порога."""
    if target_mult >= BITE_THRESHOLD:
        return 0.0
    return _clamp((BITE_THRESHOLD - target_mult) / (BITE_THRESHOLD - FLOOR_TARGET), 0.0, 1.0)


def mult_word(m: float) -> str:
    if m >= 0.98: return "нет эффекта"
    if m >= 0.90: return "лёгкое давление"
    if m >= 0.78: return "ощутимое давление"
    if m >= 0.62: return "тяжёлые санкции"
    return "удушающие санкции"
