"""
Атомная программа — ядро логики. Без БД и disnake: ступени, требования, формулы.

ДВА ТРЕКА:
  • МИРНЫЙ АТОМ — ступени I «Ядерная физика» и II «Каскад центрифуг»: открывают
    АЭС и завод ТВЭЛ. Законно по ДНЯО, даёт доход и дипкапитал, но АЭС требуют
    ядерного топлива и содержания и могут взорваться (риск растёт от нестабильности).
  • ВОЕННЫЙ ТРЕК — ступени III «Оружейное обогащение», IV «Конструкция заряда»,
    V «Ядерное испытание». Для участника ДНЯО это СКРЫТОЕ НАРУШЕНИЕ: каждый час
    шанс разоблачения (разведка мира против контрразведки программы). Разоблачение —
    санкции, обвал отношений, casus belli для всех.

ОГРАНИЧЕНИЕ: испытание (стать ядерной державой) проходит через АРБИТРА. Сейчас
арбитр — штаб сервера (кнопки одобрить/отклонить). Шов под замену на ИИ-ООН —
NuclearCog._submit_to_arbiter.

Исторические ядерные державы (флаг в ростере) получают ускоренный старт: ступени
I–II пройдены и программа признана (без риска разоблачения). Бомбу — сами.

ПРИМЕНЕНИЕ: удар в идущей войне. Перехват по ПВО цели. Катастрофа для мира:
репутация агрессора в ноль, обвал отношений со всеми, мировой шок дохода,
возможный ответный удар (ядерная держава-цель или её «ядерный зонтик»).

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from __future__ import annotations

H = 3600


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


# ── ступени исследований ──
# key → подпись, иконка, трек, цена $, уран, часы, требования веток развития {ветка: ур.}
STAGES: list[dict] = [
    {"key": "physics", "label": "Ядерная физика", "icon": "physics", "track": "peace",
     "cost": 2_000_000_000, "uranium": 0, "hours": 12,
     "req": {"atomprom": 1, "science": 2}, "min_stab": 30,
     "desc": "Реакторная физика и кадры. Открывает АЭС и завод ТВЭЛ."},
    {"key": "centrifuge", "label": "Каскад центрифуг", "icon": "centrifuge", "track": "peace",
     "cost": 5_000_000_000, "uranium": 20_000, "hours": 24,
     "req": {"atomprom": 2, "science": 3}, "min_stab": 35,
     "desc": "Своё обогащение до реакторного уровня: АЭС дешевле в топливе, открыт путь дальше."},
    {"key": "weapons", "label": "Оружейное обогащение", "icon": "enrich", "track": "war",
     "cost": 10_000_000_000, "uranium": 60_000, "hours": 48,
     "req": {"atomprom": 3, "science": 3, "mic": 2}, "min_stab": 50,
     "desc": "Каскады до 90% U-235: производство оружейного урана. Для участника ДНЯО — нарушение."},
    {"key": "warhead", "label": "Конструкция заряда", "icon": "warhead", "track": "war",
     "cost": 15_000_000_000, "uranium": 0, "hours": 48,
     "req": {"atomprom": 4, "science": 4, "mic": 3}, "min_stab": 50,
     "desc": "Имплозия, инициатор, миниатюризация: можно зарегистрировать свою боеголовку."},
]
STAGE_KEYS = [s["key"] for s in STAGES]
STAGE_BY_KEY = {s["key"]: s for s in STAGES}
PEACE_STAGES = 2          # stage ≥ 2 — мирный трек пройден
WEAPONS_STAGE = 3         # stage ≥ 3 — есть оружейное обогащение
DESIGN_STAGE = 4          # stage ≥ 4 — можно регистрировать боеголовки и просить испытание
ROMAN = ["I", "II", "III", "IV", "V"]


def stage_meta(idx: int) -> dict | None:
    """idx — номер СЛЕДУЮЩЕЙ ступени (0-based = сколько пройдено)."""
    return STAGES[idx] if 0 <= idx < len(STAGES) else None


# ── статусы по ДНЯО ──
NPT = {
    "member":   ("Участник ДНЯО", "npt"),
    "covert":   ("Участник ДНЯО", "npt"),              # тайно на военном треке (наружу — как member)
    "exposed":  ("Нарушитель ДНЯО", "violator"),
    "frozen":   ("Программа свёрнута (контроль МАГАТЭ)", "inspect"),
    "power":    ("Ядерная держава", "nuke_club"),
    "historic": ("Признанная ядерная программа", "deterrence"),
}


def npt_label(status: str) -> str:
    return NPT.get(status, NPT["member"])[0]


def npt_icon(status: str) -> str:
    return NPT.get(status, NPT["member"])[1]


def public_status(status: str) -> str:
    """Что видит мир: тайный военный трек выглядит как обычный участник ДНЯО."""
    return "member" if status == "covert" else status


# ── АЭС ──
NPP_COST = 4_000_000_000
NPP_BUILD_H = 24
NPP_MAX = 6
NPP_INCOME = 0.03            # +3% авто-дохода за работающую АЭС
NPP_UPKEEP = 25_000_000      # $/ч за станцию
NPP_FUEL = 40                # ядерного топлива в час на станцию (центрифуги своей страны — дешевле)
NPP_FUEL_OWN_ENRICH = 0.75   # ×расход при пройденной ступени «Каскад центрифуг»
NPP_INFLUENCE = 0.3          # дипкапитал/ч за работающую станцию («мирный атом»)
# авария: шанс в час на станцию
ACC_BASE = 0.0006
ACC_PER_STAB = 0.00015       # за каждый пункт стабильности ниже 40
ACC_NO_FUEL = 0.0            # без топлива станция заглушена — безопасна
ACC_SABOTAGE_BONUS = 0.01    # временный бонус после диверсии (эффект nuke_risk)
ACC_MAJOR_SHARE = 0.25       # доля тяжёлых аварий


def accident_chance(stability: float, extra: float = 0.0) -> float:
    return round(ACC_BASE + ACC_PER_STAB * max(0.0, 40 - (stability or 0)) + extra, 5)


# ── обогащение (оружейный уран) ──
CASCADE_COST = 3_000_000_000
CASCADE_MAX = 6
CASCADE_URANIUM_H = 300      # урана в час на каскад
CASCADE_HEU_H = 0.5          # кг оружейного урана в час на каскад

# ── боеголовки ──
DESIGN_MAX = 3
WARHEAD_KINDS = {
    "tactical": {"label": "Тактическая", "min": 1, "max": 50, "heu": 15, "cost": 600_000_000, "hours": 12},
    "strategic": {"label": "Стратегическая", "min": 100, "max": 1000, "heu": 30, "cost": 2_000_000_000, "hours": 24},
}
WARHEAD_UPKEEP = 8_000_000   # $/ч за боеголовку
NAME_MIN, NAME_MAX = 3, 32
TEST_HEU_MULT = 1.0          # испытание расходует HEU одной боеголовки модели

# ── риск разоблачения военного трека ──
EXPOSE_BASE = {3: 0.012, 4: 0.02}   # в час, по номеру ступени, которую страна ведёт/прошла (≥3)
EXPOSE_PER_RECON = 0.004            # × максимальный уровень разведки в мире (0..5)
EXPOSE_PER_COUNTER = 0.003          # − × контрразведка программы
EXPOSE_PER_CASCADE = 0.002          # каскады трудно спрятать
EXPOSE_MIN, EXPOSE_MAX = 0.002, 0.08


def expose_chance(stage_idx: int, world_recon: int, counter: int, cascades: int) -> float:
    base = EXPOSE_BASE.get(min(max(stage_idx, 3), 4), 0.0)
    p = base + EXPOSE_PER_RECON * world_recon - EXPOSE_PER_COUNTER * counter + EXPOSE_PER_CASCADE * cascades
    return round(_clamp(p, EXPOSE_MIN, EXPOSE_MAX), 4)


EXPOSE_REP = -25
EXPOSE_REL_SHOCK = -20       # разовый удар по отношениям со всеми
EXPOSE_INCOME = 0.85         # международные санкции: множитель дохода
EXPOSE_INCOME_H = 72
EQ_VIOLATOR = -10            # постоянный фактор равновесия отношений с нарушителем
FREEZE_REP = 10              # свернул военную программу — мир чуть доверяет
TEST_REL_SHOCK = -15         # испытание пугает мир
TEST_REP = -10

# ── сдерживание (ультиматумы) ──
DETER_BASE = 1.6
DETER_PER_WARHEAD = 0.03
DETER_MAX = 2.5
UMBRELLA_SHARE = 0.6         # доля сдерживания, которую союзник получает от «ядерного зонтика»


def deterrence(warheads: int) -> float:
    if warheads <= 0:
        return 1.0
    return round(min(DETER_MAX, DETER_BASE + DETER_PER_WARHEAD * warheads), 3)


# ── удар ──
CARRIERS = {
    # ключ категории техники → подпись, расходуется ли носитель, база перехвата, какие ПВО цели работают
    "ballistic_msl": {"label": "Баллистическая ракета", "spent": True, "base": 0.08,
                      "aa": {"sam_long": 0.012}, "cap": 0.45, "kinds": ("tactical", "strategic")},
    "cruise_msl":    {"label": "Крылатая ракета", "spent": True, "base": 0.15,
                      "aa": {"sam_short": 0.004, "sam_long": 0.006, "aa_missile": 0.002}, "cap": 0.6,
                      "kinds": ("tactical",)},
    "bomber":        {"label": "Бомбардировщик", "spent": False, "base": 0.25,
                      "aa": {"interceptor": 0.01, "fighter": 0.006, "multirole": 0.006, "sam_long": 0.006},
                      "cap": 0.8, "kinds": ("tactical", "strategic")},
    "sub_nuclear":   {"label": "Атомная подлодка (БРПЛ)", "spent": False, "base": 0.04,
                      "aa": {"sam_long": 0.006}, "cap": 0.3, "kinds": ("strategic",)},
}


def intercept_chance(carrier: str, target_counts: dict[str, int]) -> float:
    c = CARRIERS[carrier]
    p = c["base"] + sum(k * (target_counts.get(cat, 0) or 0) for cat, k in c["aa"].items())
    return round(_clamp(p, 0.0, c["cap"]), 3)


def front_damage(kind: str, yield_kt: int) -> float:
    """Доля потерь армии стороны при ударе по фронту."""
    if kind == "tactical":
        return round(_clamp(0.08 + yield_kt / 250, 0.08, 0.30), 3)
    return round(_clamp(0.25 + yield_kt / 3000, 0.25, 0.55), 3)


def city_damage(kind: str, yield_kt: int) -> dict:
    """Удар по тылу: доля населения, счастье, стабильность, доход."""
    pop = _clamp(yield_kt / 1000 * 0.06, 0.004, 0.08)
    return {"pop": round(pop, 4), "happy": 25 if kind == "strategic" else 12,
            "stab": 20 if kind == "strategic" else 10,
            "income": 0.55 if kind == "strategic" else 0.8, "hours": 96 if kind == "strategic" else 48}


STRIKE_REL_SHOCK = -40       # отношения агрессора со ВСЕМИ
STRIKE_SELF_STAB = -10       # паника у себя
WORLD_SHOCK = 0.97           # мировой шок дохода (каждой стране)
WORLD_SHOCK_BIG = 0.92       # если мощность ≥ порога
WORLD_SHOCK_KT = 300
WORLD_SHOCK_H = 48
RETALIATE_H = 12             # окно ответного удара
STRIKE_COH_HIT = -20         # сплочённость блоков агрессора


def kind_label(kind: str) -> str:
    return WARHEAD_KINDS[kind]["label"] if kind in WARHEAD_KINDS else kind


def kt_word(kt: int) -> str:
    return f"{kt / 1000:g} Мт" if kt >= 1000 else f"{kt} кт"


def fmt_dur(sec: int) -> str:
    sec = max(0, int(sec))
    h, m = sec // 3600, (sec % 3600) // 60
    return f"{h}ч {m:02d}м" if h else f"{m}м"
