"""
Альянсы — ядро логики. Без БД и disnake: типы блоков, статьи устава, формулы.

ДВА ТИПА БЛОКОВ (как в реальном мире — НАТО и ЕС/ЕАЭС живут параллельно):
  • ВОЕННЫЙ БЛОК — коллективная оборона, общее командование, базы, разведка.
  • ЭКОНОМИЧЕСКИЙ СОЮЗ — общий рынок, таможня, единые санкции, валютный щит.
Страна может состоять в ОДНОМ военном и ОДНОМ экономическом блоке одновременно.

УСТАВ = СТАТЬИ. У каждого типа своя «базовая» статья (есть всегда) и набор
дополнительных, которые члены включают голосованием. Каждая доп. статья —
глубже интеграция: сильнее эффект, но выше требования к доверию (−сплочённость).

СПЛОЧЁННОСТЬ (0..100) — живая метрика блока. Каждый час дрейфует к равновесию из
состояния мира (отношения между членами, общий строй, общий враг, глубина устава).
Разовые толчки (верность зову, отказ, шпионаж против своих, предательство)
сдвигают её сразу и со временем выветриваются. Сила ВСЕХ статей × множитель
сплочённости; ниже порога блок парализован — статьи не работают.

УПРАВЛЕНИЕ: лидер (председатель) выносит решения на голосование членов
(простое большинство, 12ч). Любой член может запросить субсидию из фонда
или поставить вотум недоверия лидеру. Не-член может подать заявку.

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from __future__ import annotations

import math


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


# ── типы блоков ──
KINDS: dict[str, dict] = {
    "military": {
        "label": "Военный блок", "plural": "Военные блоки", "short": "военный", "icon": "bloc_mil",
        "core": "defense",
        "articles": ["defense", "command", "bases", "intel", "umbrella", "fund"],
        "found_money": 150_000_000, "found_inf": 30,
        "min_rel": 30,          # отношения кандидата с КАЖДЫМ членом
        "max_members": 8,
        "desc": "Коллективная оборона: нападение на одного — нападение на всех.",
    },
    "economic": {
        "label": "Экономический союз", "plural": "Экономические союзы", "short": "экономический", "icon": "bloc_eco",
        "core": "market",
        "articles": ["market", "customs", "sanctions", "currency", "fund"],
        "found_money": 100_000_000, "found_inf": 25,
        "min_rel": 10,
        "max_members": 10,
        "desc": "Общий рынок и единая экономическая политика.",
    },
}
KIND_KEYS = list(KINDS.keys())

# ── статьи устава ──
ARTICLES: dict[str, dict] = {
    # военный блок
    "defense": {"kind": "military", "label": "Коллективная оборона", "icon": "call_arms",
                "desc": "На члена напали — зов в войну всем членам блока (после ратификации 24ч)."},
    "command": {"kind": "military", "label": "Объединённое командование", "icon": "joint_command",
                "desc": "Члены блока в одной войне: +12% к силе стороны (совместимость, единый штаб)."},
    "bases":   {"kind": "military", "label": "Военные базы", "icon": "transit",
                "desc": "Право прохода по землям всех членов: фронт можно открыть через союзника."},
    "intel":   {"kind": "military", "label": "Обмен разведданными", "icon": "intel_share",
                "desc": "+1–2 к контрразведке каждому члену. Шпионаж против своих бьёт по блоку."},
    "umbrella": {"kind": "military", "label": "Ядерный зонтик", "icon": "umbrella",
                 "desc": "Ядерные державы блока прикрывают членов: сдерживание в ультиматумах и право ответного удара."},
    "fund":    {"kind": "both", "label": "Общий фонд", "icon": "treasury",
                "desc": "Взнос 2% авто-дохода в казну блока; субсидии членам — по голосованию."},
    # экономический союз
    "market":  {"kind": "economic", "label": "Общий рынок", "icon": "market",
                "desc": "+1% к доходу за каждого другого члена (до +6%)."},
    "customs": {"kind": "economic", "label": "Таможенный союз", "icon": "customs",
                "desc": "+2% к доходу; торговля внутри союза сближает вдвое сильнее."},
    "sanctions": {"kind": "economic", "label": "Единая санкционная политика", "icon": "sanctions",
                  "desc": "Член ввёл санкции — остальным приходит предложение присоединиться."},
    "currency": {"kind": "economic", "label": "Валютный союз", "icon": "currency_union",
                 "desc": "Удар чужих санкций по членам смягчён на 30% (общий финансовый щит)."},
}


def article_label(key: str) -> str:
    return ARTICLES[key]["label"] if key in ARTICLES else key


def kind_label(kind: str) -> str:
    return KINDS[kind]["label"] if kind in KINDS else kind


def articles_for(kind: str) -> list[str]:
    return list(KINDS[kind]["articles"]) if kind in KINDS else []


def parse_articles(raw: str | None) -> list[str]:
    return [a for a in (raw or "").split(",") if a in ARTICLES]


def dump_articles(arts) -> str:
    return ",".join(sorted(set(a for a in arts if a in ARTICLES)))


# ── сплочённость ──
COH_MIN, COH_MAX = 0.0, 100.0
COH_START = 55.0
COH_DRIFT_PER_H = 1.5
COH_BASE = 35.0
COH_REL_K = 0.35            # × средние отношения между членами (−100..+100)
COH_IDEO_MAX = 15.0         # доля членов с самым частым строем × это
COH_COMMON_ENEMY = 10.0     # у блока есть общий враг (война/санкции против одной цели)
COH_PER_ARTICLE = -3.0      # каждая доп. статья — глубже интеграция, строже требования
COH_PARALYSIS = 20.0        # ниже — статьи не работают

# толчки
COH_CALL_JOIN = 8.0
COH_CALL_REFUSE = -15.0
COH_SPY_EXPOSED = -10.0     # разоблачённый шпионаж члена против члена
COH_EXPEL = -8.0
COH_SANCTION_JOIN = 3.0


def cohesion_target(avg_rel: float, ideo_share: float, common_enemy: bool, extra_articles: int) -> float:
    t = (COH_BASE + COH_REL_K * avg_rel + COH_IDEO_MAX * ideo_share
         + (COH_COMMON_ENEMY if common_enemy else 0.0) + COH_PER_ARTICLE * extra_articles)
    return round(_clamp(t, COH_MIN, COH_MAX), 2)


def cohesion_mult(cohesion: float) -> float:
    """Сила статей: 0 ниже паралича, 0.5 на пороге → 1.0 при 80+."""
    if cohesion < COH_PARALYSIS:
        return 0.0
    return round(0.5 + 0.5 * _clamp((cohesion - COH_PARALYSIS) / 60.0, 0.0, 1.0), 3)


def coh_word(c: float) -> str:
    if c >= 80: return "монолит"
    if c >= 60: return "крепкий"
    if c >= 40: return "рабочий"
    if c >= COH_PARALYSIS: return "шаткий"
    return "паралич"


def coh_bar(c: float, width: int = 10) -> str:
    filled = round(_clamp(c, 0, 100) / 100 * width)
    return "▰" * filled + "▱" * (width - filled)


def drift(value: float, target: float, step: float = COH_DRIFT_PER_H) -> float:
    if abs(target - value) <= step:
        return round(target, 2)
    return round(value + step * (1 if target > value else -1), 2)


# ── эффекты статей (сырые величины; умножаются на cohesion_mult) ──
COMMAND_BONUS = 0.12          # +к силе стороны в войне, если ≥2 члена блока на одной стороне
INTEL_COUNTER_MAX = 2         # +к контрразведке при полной сплочённости
MARKET_PER_MEMBER = 0.01
MARKET_CAP = 0.06
CUSTOMS_BONUS = 0.02
CUSTOMS_TRADE_K = 2.0         # множитель вклада торговли внутри союза в равновесие отношений
CURRENCY_SHIELD = 0.30        # доля смягчения санкционного удара
FUND_RATE = 0.02              # взнос от положительного авто-дохода
ULT_WEIGHT = 0.5              # доля силы членов военного блока в «силе» стороны ультиматума


def market_mult(other_members: int, mult: float) -> float:
    return round(1.0 + min(MARKET_CAP, MARKET_PER_MEMBER * other_members) * mult, 4)


def intel_bonus(mult: float) -> int:
    return int(math.ceil(INTEL_COUNTER_MAX * mult)) if mult > 0 else 0


# ── отношения: влияние блоков на равновесие ──
EQ_SAME_MIL = 18              # оба в одном военном блоке
EQ_SAME_ECO = 10              # оба в одном экономическом союзе
EQ_RIVAL_BLOCS = -12          # военные блоки в конфронтации (кто-то из них воюет/санкционирует другой)

# ── правила ──
VOTE_TTL = 12 * 3600
INVITE_TTL = 24 * 3600
RATIFY_S = 24 * 3600          # новичок получает коллективную оборону не сразу (анти-абьюз)
LEAVE_CD = 48 * 3600          # после выхода нельзя вступить в блок того же типа
SOLO_TTL = 48 * 3600          # блок из одной страны распускается, если никто не вступил
NAME_MAX = 32
TAG_MIN, TAG_MAX = 2, 5
GRANT_MIN = 1_000_000
BETRAYAL_REP = -35            # напал на члена своего же блока
LEAVE_REL_HIT = -8            # выход из блока — лёгкая обида остальных

# голосования: ключ → (подпись, иконка, кто инициирует)
VOTES: dict[str, dict] = {
    "invite":  {"label": "Пригласить страну", "icon": "invite", "who": "leader"},
    "apply":   {"label": "Заявка на вступление", "icon": "invite", "who": "outsider"},
    "expel":   {"label": "Исключить члена", "icon": "expel", "who": "leader"},
    "art_add": {"label": "Принять статью", "icon": "charter", "who": "leader"},
    "art_rem": {"label": "Отменить статью", "icon": "charter", "who": "leader"},
    "grant":   {"label": "Субсидия из фонда", "icon": "treasury", "who": "member"},
    "leader":  {"label": "Смена лидера", "icon": "leader", "who": "member"},
}


def vote_outcome(yes: int, no: int, electorate: int, final: bool) -> str | None:
    """→ 'passed' / 'failed' / None (ещё идёт). Простое большинство электората
    досрочно; на дедлайне — больше «за», чем «против», при явке ≥ половины."""
    electorate = max(1, electorate)
    if yes * 2 > electorate:
        return "passed"
    if no * 2 >= electorate:
        return "failed"
    if not final:
        return None
    turnout = yes + no
    return "passed" if (yes > no and turnout * 2 >= electorate) else "failed"


# цвета блоков на карте (яркие, различимые на тёмном фоне)
BLOC_COLORS = [
    (64, 156, 255), (232, 98, 92), (96, 204, 148), (240, 190, 70), (176, 120, 232),
    (60, 206, 214), (236, 132, 60), (226, 110, 186), (150, 200, 80), (130, 150, 255),
]


def bloc_color(idx: int) -> tuple[int, int, int]:
    return BLOC_COLORS[idx % len(BLOC_COLORS)]
