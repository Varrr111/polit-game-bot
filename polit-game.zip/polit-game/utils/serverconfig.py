"""
Резолвер динамических ID (роли/каналы) и игровых настроек.

Команда !setupserver создаёт роли/каналы и пишет их ID сюда (таблица
server_config). Весь код читает ID через rid(key, fallback): если в БД есть
свежее значение — берём его, иначе падаем на заглушку из config.py. Так бот
начинает работать с новой структурой сразу, без правки конфига и перезапуска.
"""

from .managers import ServerConfig

_sc = ServerConfig()


def rid(key: str, fallback=0) -> int:
    """ID роли/канала: из БД, иначе fallback (обычно константа config.py)."""
    v = _sc.get_int(key)
    if v:
        return v
    try:
        return int(fallback or 0)
    except (TypeError, ValueError):
        return 0


def sset(key: str, value):
    _sc.set(key, value)


def sget(key: str, fallback=None):
    v = _sc.get_raw(key)
    return v if v is not None else fallback


def all_config() -> dict[str, str]:
    return _sc.all()
