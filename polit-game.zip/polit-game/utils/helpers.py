"""
Вспомогательные функции, которые economy.py импортирует из utils.

Реализация поверх менеджеров (managers.py). Менеджеры лёгкие (без состояния,
кроме создания схемы), поэтому их можно инстанцировать по требованию.
"""

import re

import disnake
from disnake.ext import commands

from .managers import USER_MANAGERS, Settings
from .constants import LEVELS_CONFIG


# ── Форматирование ─────────────────────────────────────────────────────────
def int_format(n: int | float) -> str:
    """1234567 -> '1.234.567' (разделитель тысяч — точка)."""
    try:
        return f"{int(n):,}".replace(",", ".")
    except (TypeError, ValueError):
        return str(n)


_SUFFIXES = {
    "ккк": 1_000_000_000, "млрд": 1_000_000_000, "b": 1_000_000_000, "кккк": 1_000_000_000_000,
    "кк": 1_000_000, "млн": 1_000_000, "m": 1_000_000, "м": 1_000_000,
    "к": 1_000, "k": 1_000, "тыс": 1_000,
}


def string_to_number(s, all_amount: int | None = None) -> int:
    """
    Парсит пользовательский ввод суммы в int.

    Поддерживает:
      - уже число (int/float) -> int
      - 'все' / 'всё' / 'all' / 'max' -> all_amount (или 0)
      - суффиксы: к/k/тыс (1e3), кк/млн/m/м (1e6), ккк/млрд/b (1e9)
      - разделители-точки и пробелы ('1.000.000', '1 000 000')
      - проценты от all_amount: '50%'
    Возвращает 0, если распарсить не удалось (0 трактуется вызывающими как ошибка).
    """
    if isinstance(s, (int, float)):
        return int(s)
    if not isinstance(s, str):
        return 0

    text = s.strip().lower().replace(" ", "")
    if not text:
        return 0

    if text in ("все", "всё", "all", "max", "макс"):
        return int(all_amount or 0)

    # проценты от доступной суммы
    if text.endswith("%") and all_amount is not None:
        try:
            pct = float(text[:-1].replace(",", "."))
            return max(0, int(all_amount * pct / 100))
        except ValueError:
            return 0

    # суффиксы (проверяем от длинных к коротким)
    multiplier = 1
    for suf in sorted(_SUFFIXES, key=len, reverse=True):
        if text.endswith(suf):
            multiplier = _SUFFIXES[suf]
            text = text[: -len(suf)]
            break

    # в числовой части точки — разделители тысяч
    cleaned = text.replace(".", "").replace(",", "")
    if not re.fullmatch(r"-?\d+", cleaned):
        return 0
    try:
        return int(cleaned) * multiplier
    except ValueError:
        return 0


# ── Доступ к объектам ──────────────────────────────────────────────────────
def get_all_managers() -> list:
    """Список классов-менеджеров участников (Countries, PMCs, ...)."""
    return USER_MANAGERS


def get_object(name: str):
    """Ищет участника по имени во всех менеджерах. None если не найден."""
    if not name:
        return None
    for manager in USER_MANAGERS:
        obj = manager().get_object(name)
        if obj:
            return obj
    return None


def get_object_by_user(user_id: int):
    """Ищет участника по discord user id во всех менеджерах."""
    for manager in USER_MANAGERS:
        obj = manager().get_object_by_user(user_id)
        if obj:
            return obj
    return None


def update_money(name: str, delta: int):
    """Изменяет баланс участника на delta и возвращает обновлённый объект."""
    for manager in USER_MANAGERS:
        if manager().get_object(name):
            return manager().update_object(name, money=delta)
    return None


def calculate_income(obj, next_level: bool = False) -> dict[str, int]:
    """
    Доход участника по статам. Возвращает {'trade': income, 'tourism': ..., ...}
    только для статов, которые есть у объекта.

    next_level=True -> доход на СЛЕДУЮЩЕМ уровне (0, если уже максимум) —
    используется для превью улучшения в BalanceView.
    """
    result: dict[str, int] = {}
    for stat in ("trade", "tourism", "economy"):
        if not hasattr(obj, f"{stat}_lvl"):
            continue
        levels = LEVELS_CONFIG[stat][0]
        if not levels:
            result[stat] = 0
            continue
        current = getattr(obj, f"{stat}_lvl")
        idx = current + 1 if next_level else current
        if idx < 0 or idx >= len(levels):
            result[stat] = 0
        else:
            result[stat] = levels[idx][1]  # index 1 — доход уровня
    return result


# ── Поиск пользователя по аргументу команды ────────────────────────────────
async def find_user(ctx: commands.Context, user, isfetch: bool = False):
    """
    Резолвит аргумент команды в игровой объект:
      - disnake.Member / disnake.User -> по user.id
      - int (id) -> по id
      - строка -> точное или частичное совпадение имени участника
    Возвращает объект или None.
    """
    if isinstance(user, (disnake.Member, disnake.User)):
        return get_object_by_user(user.id)

    if isinstance(user, int):
        return get_object_by_user(user)

    if isinstance(user, str):
        text = user.strip()
        if text.isdigit():
            obj = get_object_by_user(int(text))
            if obj:
                return obj
        # точное совпадение имени
        obj = get_object(text)
        if obj:
            return obj
        # частичное (регистронезависимо)
        low = text.lower()
        for manager in USER_MANAGERS:
            for name in manager().get_object_names():
                if low in name.lower():
                    return manager().get_object(name)
    return None


# ── Проверка прав команды ──────────────────────────────────────────────────
# Права, доступные только админам/кураторам экономики.
ADMIN_PERMISSIONS = {"manage-money", "up"}


async def command_permissions_check(ctx: commands.Context, permission: str) -> bool:
    """
    Проверяет право автора на действие. Для админ-прав требует права
    администратора / id ADMINISTRATOR / роль MAIN_ECO_CURATOR. Иначе —
    отправляет сообщение об ошибке и возвращает False.
    """
    from config import ADMINISTRATOR, MAIN_ECO_CURATOR, ERROR_COLOR

    if permission in ADMIN_PERMISSIONS:
        is_admin = ctx.author.id == ADMINISTRATOR or ctx.author.guild_permissions.administrator
        is_curator = bool(MAIN_ECO_CURATOR) and ctx.guild.get_role(MAIN_ECO_CURATOR) in ctx.author.roles
        if not (is_admin or is_curator):
            await ctx.send(embed=disnake.Embed(
                description="У вас нет прав на эту команду.", color=ERROR_COLOR))
            return False
        return True

    # обычные права (напр. pay) — доступны всем зарегистрированным
    return True
