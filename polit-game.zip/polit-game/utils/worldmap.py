"""
Рендер политической карты мира (Nova Order).

Принцип: КАРТА = f(состояние). Модуль ничего не хранит и не «дорисовывает» —
он берёт словарь владения и каждый раз рисует картинку с нуля.

Геометрия (public domain, Natural Earth; см. scripts/fetch_map.py):
  * assets/map/world_admin1.geojson  — РЕГИОНЫ (области/штаты) всех стран (10m).
  * assets/map/world_admin0.geojson  — страны (для нац. границ, подписей, resolve).

Два уровня: регионы рисуются с тонкими внутренними границами, поверх — жирные
национальные границы. Страна «горит» одним цветом, но деление на регионы видно.

Владение:
  * Регион принадлежит своей стране по умолчанию (adm0_a3).
  * Оверрайд {adm1_code -> владелец_adm0_a3} (таблица map_territories) передаёт
    регион другой стране — Этап 2 (война). Регион перекрашивается в цвет
    захватчика без изменений кода рендера.

Сопоставление «русское имя страны -> adm0_a3» — автоматически по NAME_RU в
admin-0 (+2 алиаса), поэтому карта масштабируется при росте ростера.
"""

from __future__ import annotations

import io
import json
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

import config

# ── Пути к ресурсам ──────────────────────────────────────────────────────────
_MAP_DIR = Path(__file__).resolve().parent.parent / "assets" / "map"
_GEOJSON_A0 = _MAP_DIR / "world_admin0.geojson"
_GEOJSON_A1 = _MAP_DIR / "world_admin1.geojson"
_FONT_DIR = _MAP_DIR / "fonts"

# ── Канва и проекция (равнопромежуточная; Антарктида обрезана для кадра) ──────
WIDTH = 10240   # очень высокое разрешение + сглаживание 2× — чётко даже при сильном зуме
# (рендер ~6с, файл ~6 МБ, пик памяти ~2.4 ГБ; снизь, если хостингу не хватает RAM)
LAT_TOP = 83.5
LAT_BOT = -56.0
HEIGHT = int(WIDTH * (LAT_TOP - LAT_BOT) / 360.0)  # ≈ 854

# ── Палитра (фирменный сине-голубой градиент сервера) ────────────────────────
OCEAN_TOP = (9, 20, 36)
OCEAN_BOT = (4, 10, 20)
NEUTRAL_LAND = (46, 54, 68)       # свободные страны
NEUTRAL_REGION_EDGE = (60, 70, 86)  # тонкие границы регионов внутри серых стран
NATION_EDGE = (150, 178, 210)     # национальные границы (поверх) — ярче для чёткого деления
CAPTURE_EDGE = (255, 244, 190)    # окантовка захваченных/оккупированных областей
OCCUPIED_RED = (156, 42, 46)      # оккупированная на войне территория (красная заливка)
OCC_STRIPE = (230, 120, 120, 200)  # диагональные полоски поверх оккупации
LABEL_RGB = (226, 238, 250)
LABEL_SHADOW = (3, 8, 16)

# Рамп синего (тёмно-синий -> светло-голубой, включая бирюзово-синие):
# оттенок зарегистрированной страны выбирается по стабильному хэшу adm0_a3.
# 14 различимых тонов — чтобы territory разных владельцев не сливались.
# Разноцветная палитра — каждая страна своим цветом (чтобы различать на карте).
# Насыщенные, но гармоничные тона, читаемые на тёмном океане.
_BLUE_RAMP = [
    (214, 86, 92), (224, 124, 72), (226, 170, 74), (206, 200, 92),
    (150, 196, 92), (96, 196, 120), (86, 198, 170), (82, 184, 206),
    (86, 150, 220), (104, 120, 214), (150, 112, 206), (190, 108, 194),
    (214, 104, 158), (196, 132, 110), (160, 176, 120), (120, 160, 196),
    (230, 146, 120), (176, 146, 206), (120, 198, 196), (210, 180, 96),
    (140, 190, 150), (180, 120, 150), (120, 140, 210), (200, 160, 180),
]

# Имена ростера, которые не совпадают с NAME_RU в Admin-0 (или стран там нет —
# микрогосударства есть только в слое регионов Admin-1, рисуются через него).
_NAME_ALIASES = {
    "Китай": "CHN", "Южная Корея": "KOR",
    "Туркменистан": "TKM", "Кыргызстан": "KGZ", "Южно-Африканская Республика": "ZAF",
    "Гаити": "HTI", "Багамы": "BHS", "Косово": "KOS",
    "Мальта": "MLT", "Монако": "MCO", "Лихтенштейн": "LIE", "Андорра": "AND",
    "Сан-Марино": "SMR", "Ватикан": "VAT", "Сингапур": "SGP", "Бахрейн": "BHR",
    "Мальдивы": "MDV", "Маврикий": "MUS", "Кабо-Верде": "CPV", "Сейшелы": "SYC",
    "Коморы": "COM", "Сан-Томе и Принсипи": "STP", "Антигуа и Барбуда": "ATG",
    "Барбадос": "BRB", "Сент-Люсия": "LCA", "Гренада": "GRD", "Доминика": "DMA",
    "Сент-Китс и Невис": "KNA", "Сент-Винсент и Гренадины": "VCT", "Самоа": "WSM",
    "Тонга": "TON", "Тувалу": "TUV", "Кирибати": "KIR", "Науру": "NRU",
    "Федеративные Штаты Микронезии": "FSM", "Маршалловы Острова": "MHL", "Палау": "PLW",
}


# ── Структуры геометрии ──────────────────────────────────────────────────────
class _Region:
    __slots__ = ("region_id", "a0", "name_ru", "rings", "area")

    def __init__(self, region_id, a0, name_ru, rings, area):
        self.region_id = region_id
        self.a0 = a0
        self.name_ru = name_ru
        self.rings = rings
        self.area = area


class _Country:
    __slots__ = ("a3", "name_ru", "rings", "area", "centroid", "continent")

    def __init__(self, a3, name_ru, rings, area, centroid, continent):
        self.a3 = a3
        self.name_ru = name_ru
        self.rings = rings
        self.area = area
        self.centroid = centroid
        self.continent = continent


_REGIONS: list[_Region] | None = None
_COUNTRIES: list[_Country] | None = None
_RU_TO_A3: dict[str, str] | None = None
# кэш спроецированных в пиксели колец (для фикс. WIDTH/HEIGHT)
_REGIONS_PX: list[tuple[_Region, list]] | None = None
_COUNTRIES_PX: list[tuple[_Country, list]] | None = None


# ── Геометрические утилиты ───────────────────────────────────────────────────
def _ring_area(ring) -> float:
    s = 0.0
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def _ring_centroid(ring) -> tuple[float, float]:
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    return (sum(xs) / len(xs), sum(ys) / len(ys))


def _iter_outer_rings(geom):
    t = geom.get("type")
    if t == "Polygon":
        if geom["coordinates"]:
            yield geom["coordinates"][0]
    elif t == "MultiPolygon":
        for poly in geom["coordinates"]:
            if poly:
                yield poly[0]


def _rings_of(feature) -> list:
    rings = [r for r in _iter_outer_rings(feature["geometry"]) if len(r) >= 3]
    rings.sort(key=_ring_area, reverse=True)
    return rings


# ── Загрузка данных ──────────────────────────────────────────────────────────
def _load():
    global _REGIONS, _COUNTRIES, _RU_TO_A3
    if _REGIONS is not None:
        return
    if not _GEOJSON_A1.exists():
        raise FileNotFoundError(
            f"Нет данных регионов: {_GEOJSON_A1}. Запусти: ./.venv/bin/python scripts/fetch_map.py"
        )
    if not _GEOJSON_A0.exists():
        raise FileNotFoundError(
            f"Нет данных стран: {_GEOJSON_A0}. Запусти: ./.venv/bin/python scripts/fetch_map.py"
        )

    # Регионы (admin-1)
    gj = json.loads(_GEOJSON_A1.read_text(encoding="utf-8"))
    regions: list[_Region] = []
    for f in gj["features"]:
        p = f["properties"]
        a0 = p.get("adm0_a3") or p.get("ADM0_A3")
        rid = p.get("adm1_code") or p.get("iso_3166_2") or f"{a0}-{p.get('name')}"
        rings = _rings_of(f)
        if not rings or not a0:
            continue
        area = sum(_ring_area(r) for r in rings)
        regions.append(_Region(rid, a0, p.get("name_ru") or p.get("name"), rings, area))
    regions.sort(key=lambda r: r.area, reverse=True)  # мелкие рисуем поверх

    # Страны (admin-0) — нац. границы, подписи, resolve
    gj0 = json.loads(_GEOJSON_A0.read_text(encoding="utf-8"))
    countries: list[_Country] = []
    ru_to_a3: dict[str, str] = {}
    for f in gj0["features"]:
        p = f["properties"]
        a3 = p.get("ADM0_A3") or p.get("ISO_A3") or p.get("NAME")
        name_ru = p.get("NAME_RU") or p.get("NAME")
        rings = _rings_of(f)
        if not rings:
            continue
        area = sum(_ring_area(r) for r in rings)
        countries.append(_Country(a3, name_ru, rings, area, _ring_centroid(rings[0]),
                                  p.get("CONTINENT") or ""))
        if name_ru:
            ru_to_a3[name_ru] = a3
    countries.sort(key=lambda c: c.area, reverse=True)

    _REGIONS, _COUNTRIES, _RU_TO_A3 = regions, countries, ru_to_a3


def _project(ring, w, h):
    span = LAT_TOP - LAT_BOT
    out = []
    for lon, lat in ring:
        out.append(((lon + 180.0) / 360.0 * w, (LAT_TOP - lat) / span * h))
    return out


def _ensure_projected():
    global _REGIONS_PX, _COUNTRIES_PX
    if _REGIONS_PX is not None:
        return
    _load()
    _REGIONS_PX = [(r, [_project(rg, WIDTH, HEIGHT) for rg in r.rings]) for r in _REGIONS]
    _COUNTRIES_PX = [(c, [_project(rg, WIDTH, HEIGHT) for rg in c.rings]) for c in _COUNTRIES]


def resolve_a3(country_name: str) -> str | None:
    """Русское имя страны (из ростера/БД) -> adm0_a3."""
    _load()
    if country_name in _NAME_ALIASES:
        return _NAME_ALIASES[country_name]
    return _RU_TO_A3.get(country_name)  # type: ignore[union-attr]


def regions_of(a3: str) -> list[str]:
    """Список adm1_code регионов страны (для логики войны Этапа 2)."""
    _load()
    return [r.region_id for r in _REGIONS if r.a0 == a3]  # type: ignore[union-attr]


# ── Соседство областей (настоящие общие границы) ────────────────────────────
_ADJ: dict[str, set] | None = None
_ADJ_GRID = 0.02   # ° — точки границ привязываются к сетке ~2 км; общая точка = общая граница


def region_neighbors() -> dict[str, set]:
    """{adm1_code: {соседние adm1_code}} — по общим точкам границ (строится один раз, ~1.5 с)."""
    global _ADJ
    if _ADJ is not None:
        return _ADJ
    _load()
    cell: dict[tuple, set] = {}
    for r in _REGIONS:  # type: ignore[union-attr]
        for ring in r.rings:
            for lon, lat in ring:
                cell.setdefault((round(lon / _ADJ_GRID), round(lat / _ADJ_GRID)), set()).add(r.region_id)
    adj: dict[str, set] = {}
    for ids in cell.values():
        if len(ids) > 1:
            for a in ids:
                adj.setdefault(a, set()).update(ids - {a})
    _ADJ = adj
    return adj


def _owners(overrides: dict | None) -> dict[str, str]:
    _load()
    ov = overrides or {}
    return {r.region_id: ov.get(r.region_id, r.a0) for r in _REGIONS}  # type: ignore[union-attr]


def neighbor_countries(a3: str, overrides: dict | None = None) -> set:
    """Страны (a3), с которыми у a3 есть общая сухопутная граница — с учётом захватов."""
    adj, owner = region_neighbors(), _owners(overrides)
    out = set()
    for rid, o in owner.items():
        if o == a3:
            out |= {owner[n] for n in adj.get(rid, ()) if owner.get(n) and owner[n] != a3}
    return out


def owned_regions(a3: str, overrides: dict | None = None) -> list[str]:
    """Области, которыми a3 владеет СЕЙЧАС (свои незахваченные + захваченные чужие)."""
    return [rid for rid, o in _owners(overrides).items() if o == a3]


# ── Справочники для панели куратора ──────────────────────────────────────────
CONTINENT_RU = {
    "Europe": "Европа", "Asia": "Азия", "Africa": "Африка",
    "North America": "Северная Америка", "South America": "Южная Америка",
    "Oceania": "Австралия и Океания",
}
# Порядок континентов в меню (служебные океаны/Антарктида исключены).
CONTINENTS_ORDER = ["Europe", "Asia", "Africa", "North America", "South America", "Oceania"]


def country_name(a3: str) -> str:
    _load()
    for c in _COUNTRIES:  # type: ignore[union-attr]
        if c.a3 == a3:
            return c.name_ru or a3
    return a3


def region_name(code: str) -> str:
    _load()
    for r in _REGIONS:  # type: ignore[union-attr]
        if r.region_id == code:
            return r.name_ru or code
    return code


def region_centroid(code: str):
    """(cx, cy) центроид региона по его коду, или None."""
    _load()
    for r in _REGIONS:  # type: ignore[union-attr]
        if r.region_id == code and r.rings:
            return _ring_centroid(r.rings[0])
    return None


def all_regions() -> list[tuple[str, str, str, tuple[float, float], float]]:
    """[(region_id, adm0_a3, name_ru, (cx,cy), area)] — для военной логики (фронт)."""
    _load()
    out = []
    for r in _REGIONS:  # type: ignore[union-attr]
        if r.rings:
            out.append((r.region_id, r.a0, r.name_ru or r.region_id,
                        _ring_centroid(r.rings[0]), r.area))
    return out


def countries_by_continent(continent_en: str) -> list[tuple[str, str]]:
    """[(adm0_a3, name_ru)] стран континента, по алфавиту. Только у кого есть регионы."""
    _load()
    have_regions = {r.a0 for r in _REGIONS}  # type: ignore[union-attr]
    out = [(c.a3, c.name_ru or c.a3) for c in _COUNTRIES  # type: ignore[union-attr]
           if c.continent == continent_en and c.a3 in have_regions]
    out.sort(key=lambda t: t[1])
    return out


def region_list(a3: str) -> list[tuple[str, str]]:
    """[(adm1_code, name_ru)] регионов страны, по алфавиту."""
    _load()
    out = [(r.region_id, r.name_ru or r.region_id) for r in _REGIONS if r.a0 == a3]  # type: ignore[union-attr]
    out.sort(key=lambda t: t[1])
    return out


# ── Цвета ────────────────────────────────────────────────────────────────────
def _hash_idx(s: str, n: int) -> int:
    h = 2166136261
    for ch in s:
        h = (h ^ ord(ch)) * 16777619 & 0xFFFFFFFF
    return h % n


def color_for(a3: str) -> tuple[int, int, int]:
    return _BLUE_RAMP[_hash_idx(a3, len(_BLUE_RAMP))]


_color_for = color_for
OUTSIDE_BLOC = (58, 74, 96)   # зарегистрирована, но вне блоков (режим карты блоков)
LEGEND_GOLD = (214, 168, 64)  # «Наследие»: легендарная держава горит золотом


def _lighten(rgb, f):
    return tuple(min(255, int(c + (255 - c) * f)) for c in rgb)


# ── Шрифты ───────────────────────────────────────────────────────────────────
def _font(size: int, bold: bool = False):
    for c in (_FONT_DIR / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"),
              Path("/System/Library/Fonts/Supplemental/Arial.ttf")):
        try:
            if c.exists():
                return ImageFont.truetype(str(c), size)
        except Exception:
            continue
    return ImageFont.load_default()


# ── Фон/виньетка ─────────────────────────────────────────────────────────────
def _ocean_background(w, h) -> Image.Image:
    col = Image.new("RGB", (1, h))
    px = col.load()
    for y in range(h):
        t = y / max(1, h - 1)
        px[0, y] = tuple(int(OCEAN_TOP[i] + (OCEAN_BOT[i] - OCEAN_TOP[i]) * t) for i in range(3))
    return col.resize((w, h)).convert("RGBA")


def _vignette(w, h) -> Image.Image:
    v = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(v)
    m = int(min(w, h) * 0.16)
    d.rectangle([m, m, w - m, h - m], fill=255)
    v = v.filter(ImageFilter.GaussianBlur(m * 0.8))
    overlay = Image.new("RGBA", (w, h), (0, 0, 0, 120))
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(overlay, (0, 0), Image.eval(v, lambda a: 255 - a))
    return out


# ── Основной рендер ──────────────────────────────────────────────────────────
SS = 2  # суперсэмплинг: землю рисуем в SS× и ужимаем → гладкие края, тонкие границы

def render_map(
    active: dict[str, str],
    overrides: dict[str, str] | None = None,
    title: str = "NOVA ORDER",
    subtitle: str = "КАРТА МИРА",
    occupied: dict[str, str] | None = None,
    palette: dict[str, tuple[int, int, int]] | None = None,
    legend: list[tuple[str, tuple[int, int, int]]] | None = None,
    legendary: set | None = None,
    pmc_bases: dict[str, list[str]] | None = None,
) -> bytes:
    """
    active    — {adm0_a3: русское_имя} зарегистрированных стран.
    overrides — {adm1_code: владелец_adm0_a3} передачи регионов (аннексии); None — нет.
    occupied  — {adm1_code: оккупант_a3} временно оккупированные на войне (красный + полоски).
    palette   — {adm0_a3: rgb} режим «карта блоков»: страны блоков своим цветом,
                прочие зарегистрированные — приглушённые.
    """
    _ensure_projected()
    overrides = overrides or {}
    occupied = occupied or {}
    w, h = WIDTH, HEIGHT
    k = WIDTH / 2200.0
    img = _ocean_background(w, h)

    legendary = legendary or set()

    def color_for(a3):   # в режиме блоков цвет = цвет блока; легендарные державы — золото
        if palette is None:
            return LEGEND_GOLD if a3 in legendary else _color_for(a3)
        return palette.get(a3, OUTSIDE_BLOC)

    # Свечение активных стран (на финальном размере — оно мягкое, сглаживать не нужно).
    def _glow(radius, bright, alpha):
        layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        gd = ImageDraw.Draw(layer)
        for region, rings_px in _REGIONS_PX:
            if region.region_id in occupied:
                continue
            owner = overrides.get(region.region_id, region.a0)
            if owner not in active:
                continue
            gcol = _lighten(color_for(owner), bright)
            for rp in rings_px:
                if len(rp) >= 3:
                    gd.polygon(rp, fill=gcol + (alpha,))
        return layer.filter(ImageFilter.GaussianBlur(radius))

    img.alpha_composite(_glow(int(34 * k), 0.25, 140))
    img.alpha_composite(_glow(int(9 * k), 0.55, 210))

    # ── СУША в 2× (сглаживание): заливка регионов + тонкие границы провинций ──
    W2, H2 = w * SS, h * SS
    land = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
    ld = ImageDraw.Draw(land)

    def S(rp):
        return [(x * SS, y * SS) for x, y in rp]

    occ_mask = Image.new("L", (W2, H2), 0)
    om = ImageDraw.Draw(occ_mask)
    captured = []
    for region, rings_px in _REGIONS_PX:
        rid = region.region_id
        is_occ = rid in occupied
        owner = overrides.get(rid, region.a0)
        if is_occ:
            fill, edge = OCCUPIED_RED, CAPTURE_EDGE
        elif owner in active:
            fill = color_for(owner)
            edge = _lighten(fill, 0.30)
        else:
            fill, edge = NEUTRAL_LAND, NEUTRAL_REGION_EDGE
        for rp in rings_px:
            if len(rp) >= 3:
                sp = S(rp)
                ld.polygon(sp, fill=fill, outline=edge)   # контур 1px в 2× = тонкая граница провинции
                if is_occ:
                    om.polygon(sp, fill=255)
        if (is_occ or rid in overrides) and (is_occ or owner in active):
            captured.append((rings_px, is_occ))

    # Полоски на оккупированных областях (диагональная штриховка, обрезанная по маске).
    if occupied:
        stripes = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
        sd = ImageDraw.Draw(stripes)
        step = max(10, int(16 * k * SS))
        sw = max(2, int(2 * k * SS))
        for off in range(-H2, W2, step):
            sd.line([(off, 0), (off + H2, H2)], fill=OCC_STRIPE, width=sw)
        stripes.putalpha(ImageChops.multiply(stripes.getchannel("A"), occ_mask))  # обрезка по оккупации
        land.alpha_composite(stripes)

    # Национальные границы — ТОНКИЕ и ярче (в 2×, потом ужмётся → чёткая тонкая линия).
    nw = max(SS, int(0.8 * k * SS))
    for country, rings_px in _COUNTRIES_PX:
        for rp in rings_px:
            if len(rp) >= 3:
                ld.line(S(rp) + [S(rp)[0]], fill=NATION_EDGE, width=nw, joint="curve")

    # Захваченные/оккупированные — яркая окантовка (золото — аннексия, красный — оккупация).
    cw = max(SS, int(2 * k * SS))
    for rings_px, is_occ in captured:
        col = CAPTURE_EDGE
        for rp in rings_px:
            if len(rp) >= 3:
                ld.line(S(rp) + [S(rp)[0]], fill=col, width=cw, joint="curve")

    # Ужимаем сушу с LANCZOS → сглаженные края и тонкие аккуратные границы.
    img.alpha_composite(land.resize((w, h), Image.LANCZOS))
    draw = ImageDraw.Draw(img)

    # Подписи зарегистрированных стран.
    _draw_labels(img, active)
    if pmc_bases:
        _draw_pmc_bases(img, pmc_bases, active)

    img.alpha_composite(_vignette(w, h))
    _draw_header(img, title, subtitle, len(active))
    if legend:
        _draw_legend(img, legend)

    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="PNG", optimize=True)
    return buf.getvalue()


def _draw_labels(img, active):
    draw = ImageDraw.Draw(img)
    for country, _ in _COUNTRIES_PX:
        if country.a3 not in active:
            continue
        name = active[country.a3]
        cx, cy = _project([country.centroid], img.width, img.height)[0]
        k = img.width / 2200.0
        size = int((20 if country.area > 300 else 15) * k)
        font = _font(size, bold=True)
        tb = draw.textbbox((0, 0), name, font=font)
        x, y = cx - (tb[2] - tb[0]) / 2, cy - (tb[3] - tb[1]) / 2
        off = max(1, int(1.5 * k))
        draw.text((x + off, y + off), name, font=font, fill=LABEL_SHADOW)
        draw.text((x, y), name, font=font, fill=LABEL_RGB)


PMC_MARK = (120, 196, 255)


def _draw_pmc_bases(img, bases: dict, active: dict):
    """Базы ЧВК: голубой ромб + теги компаний под подписью страны базирования."""
    draw = ImageDraw.Draw(img)
    k = img.width / 2200.0
    for country, _ in _COUNTRIES_PX:
        tags = bases.get(country.a3)
        if not tags:
            continue
        cx, cy = _project([country.centroid], img.width, img.height)[0]
        cy += int((28 if country.a3 in active else 0) * k)       # под названием страны
        text = " ".join(tags[:3]) + (f" +{len(tags) - 3}" if len(tags) > 3 else "")
        font = _font(max(10, int(13 * k)), bold=True)
        tb = draw.textbbox((0, 0), text, font=font)
        tw, th = tb[2] - tb[0], tb[3] - tb[1]
        r = max(4, int(6 * k))
        pad = max(3, int(4 * k))
        w = r * 2 + pad + tw + pad * 2
        x0, y0 = cx - w / 2, cy - th / 2 - pad
        draw.rounded_rectangle([x0, y0, x0 + w, y0 + th + pad * 2], radius=pad + 2, fill=(8, 20, 38, 210),
                               outline=PMC_MARK, width=max(1, int(1.5 * k)))
        mx, my = x0 + pad + r, y0 + (th + pad * 2) / 2
        draw.polygon([(mx, my - r), (mx + r, my), (mx, my + r), (mx - r, my)], fill=PMC_MARK)
        draw.text((mx + r + pad, y0 + pad - tb[1]), text, font=font, fill=(225, 240, 255))


def _draw_header(img, title, subtitle, active_count):
    w = img.width
    strip_h = 92
    strip = Image.new("RGBA", (w, strip_h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(strip)
    for y in range(strip_h):
        sd.line([(0, y), (w, y)], fill=(4, 10, 20, int(150 * (1 - y / strip_h))))
    img.alpha_composite(strip, (0, 0))

    draw = ImageDraw.Draw(img)
    c = config.LIGHT_BLUE
    brand = _lighten(((c >> 16) & 255, (c >> 8) & 255, c & 255), 0.15)
    draw.text((34, 18), title, font=_font(40, bold=True), fill=brand)
    sfont = _font(20, bold=False)
    draw.text((36, 60), subtitle, font=sfont, fill=(150, 175, 200))
    cnt = f"Активных держав: {active_count}"
    cb = draw.textbbox((0, 0), cnt, font=sfont)
    draw.text((w - (cb[2] - cb[0]) - 34, 60), cnt, font=sfont, fill=(150, 175, 200))


def _draw_legend(img, legend):
    """Легенда карты блоков: плашка в левом нижнем углу (цветной маркер + подпись)."""
    k = img.width / 2200.0
    font = _font(int(20 * k) or 12, bold=True)
    draw = ImageDraw.Draw(img)
    pad, sw, gap = int(18 * k), int(22 * k), int(12 * k)
    lh = int(34 * k)
    rows = legend[:12]
    tw = max(draw.textbbox((0, 0), t, font=font)[2] for t, _ in rows)
    bw, bh = pad * 2 + sw + gap + tw, pad * 2 + lh * len(rows)
    x0, y0 = int(30 * k), img.height - bh - int(30 * k)
    box = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    ImageDraw.Draw(box).rounded_rectangle([0, 0, bw - 1, bh - 1], radius=int(14 * k),
                                          fill=(6, 14, 28, 200), outline=(70, 110, 150, 220), width=max(1, int(2 * k)))
    img.alpha_composite(box, (x0, y0))
    for i, (text, col) in enumerate(rows):
        y = y0 + pad + i * lh
        draw.rounded_rectangle([x0 + pad, y + (lh - sw) // 2 - int(3 * k), x0 + pad + sw, y + (lh + sw) // 2 - int(3 * k)],
                               radius=int(5 * k), fill=col, outline=_lighten(col, 0.4))
        draw.text((x0 + pad + sw + gap, y), text, font=font, fill=LABEL_RGB)


# ── Отладка из консоли ───────────────────────────────────────────────────────
if __name__ == "__main__":
    demo = {"RUS": "Россия", "USA": "США", "CHN": "Китай",
            "FRA": "Франция", "UKR": "Украина", "BRA": "Бразилия"}
    out = _MAP_DIR / "_preview_map.png"
    out.write_bytes(render_map(demo))
    print("Превью:", out)
