"""
UI-фреймворк для disnake Components V2.

disnake (в отличие от discord.py) не имеет LayoutView: контейнер нельзя положить
в View, а отправляется он через `components=[Container(...)]`. Интерактив (кнопки,
селекты) внутри контейнера не получает колбэков напрямую — клики ловятся
по `custom_id` центральным слушателем.

Этот модуль даёт:
  • Panel  — лёгкую базу-держатель компонентов (замена LayoutView): наследник
             в __init__ собирает контейнер через self.add_item(...), а отправка
             идёт как `components=panel.components`.
  • cid()/parse_cid() — кодек custom_id вида "ns:action:arg1:arg2".
"""

import disnake

CID_SEP = ":"


def cid(namespace: str, action: str, *args: str) -> str:
    """Строит custom_id: 'ns:action:arg1:arg2' (обрезан до 100 символов)."""
    parts = [namespace, action, *(str(a) for a in args)]
    return CID_SEP.join(parts)[:100]


def parse_cid(custom_id: str) -> tuple[str, str, list[str]]:
    """Разбирает custom_id → (namespace, action, [args])."""
    bits = custom_id.split(CID_SEP)
    ns = bits[0] if bits else ""
    action = bits[1] if len(bits) > 1 else ""
    return ns, action, bits[2:]


class Panel:
    """
    База для V2-панели disnake (замена discord.ui.LayoutView).

    Наследник в __init__ наполняет панель через self.add_item(Container(...)).
    Отправка:
        await dest.send(components=panel.components)
        await inter.response.edit_message(components=panel.components)
    """

    __discord_ui_view__ = False  # это не View

    def __init__(self, *, timeout: float | None = 300):
        self.timeout = timeout
        self._components: list = []

    def add_item(self, component):
        self._components.append(component)
        return self

    def clear_items(self):
        self._components = []
        return self

    @property
    def components(self) -> list:
        return self._components

    @property
    def children(self) -> list:
        # совместимость со старыми тестами (children[0] == контейнер)
        return self._components
