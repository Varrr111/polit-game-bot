"""
ООН на ИИ — ядро логики. Без БД и disnake: типы резолюций, подсчёт голосов,
потолки эффектов и запросы к gpt-4o-mini (секретариат, наблюдатель, судья испытаний).

КАК УСТРОЕНО:
  • ГЕНАССАМБЛЕЯ — все зарегистрированные страны + «мировое сообщество» (незанятые
    страны, за них голосует ИИ одним блоком). Решает необязательные резолюции:
    осуждение, инспекция МАГАТЭ, гуманитарная помощь.
  • СОВБЕЗ — 5 постоянных членов (США, Россия, Китай, Великобритания, Франция) с
    ВЕТО + до 10 избранных стран-игроков по силе. Решает обязательные: санкции ООН,
    оружейное эмбарго, прекращение огня. Незанятый постоянный член — голос за него
    даёт ИИ (по реальной внешней политике страны).
  • ИИ-СЕКРЕТАРИАТ проверяет допустимость проекта, пишет официальный текст, выбирает
    тяжесть (1–3) и позицию мирового сообщества. Бот КЛАМПИТ всё на своей стороне.
  • ИИ-НАБЛЮДАТЕЛЬ читает мировой журнал и сам выносит вопросы на повестку.
  • ИИ-СУДЬЯ ядерных испытаний (у штаба — час на вето).
Без ключа OPENAI_API_KEY: проекты допускаются как есть, мировое сообщество
воздерживается, наблюдатель работает по правилам, испытания решает штаб.

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from __future__ import annotations

import json
import logging

import config
from .aitext import clean, NO_EMOJI_RULE   # общая чистка текста ИИ (без эмодзи)

log = logging.getLogger("un")

H = 3600


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


# ── органы ──
P5 = ["США", "Россия", "Китай", "Великобритания", "Франция"]
SC_ELECTED = 10            # избранных мест в Совбезе
SC_PASS_SHARE = 0.6        # доля «за» от проголосовавших членов СБ
NPC_BLOCK_MIN = 5          # минимальный вес «мирового сообщества» в ГА (в голосах)

# ── резолюции ──
# body: ga | sc. needs: target | war. severity → эффект (числа по тяжести 1..3)
TYPES: dict[str, dict] = {
    "condemn": {"label": "Осуждение", "icon": "un_condemn", "body": "ga", "needs": "target",
                "desc": "Мир официально осуждает действия страны: репутация и отношения падают."},
    "inspect": {"label": "Инспекция МАГАТЭ", "icon": "inspect", "body": "ga", "needs": "target",
                "desc": "Инспекторы на ядерных объектах: тайная программа почти наверняка будет вскрыта."},
    "aid":     {"label": "Гуманитарная помощь", "icon": "un_aid", "body": "ga", "needs": "target",
                "desc": "Помощь стране в беде: счастье, стабильность и доход растут."},
    "sanctions": {"label": "Санкции ООН", "icon": "sanctions", "body": "sc", "needs": "target",
                  "desc": "Обязательные санкции всего мира: доход страны падает на срок."},
    "embargo": {"label": "Оружейное эмбарго", "icon": "un_embargo", "body": "sc", "needs": "target",
                "desc": "Запрет производить технику, покупать лицензии и боеголовки на срок."},
    "ceasefire": {"label": "Прекращение огня", "icon": "peace", "body": "sc", "needs": "war",
                  "desc": "Война ставится на паузу: раунды и удары запрещены на срок."},
    "pmc_sanctions": {"label": "Санкции против ЧВК", "icon": "pmc", "body": "sc", "needs": "pmc",
                      "desc": "Глобальные санкции против ЧВК: никаких покупок техники, доход ×0.5 на срок."},
}
TYPE_KEYS = list(TYPES.keys())

EFFECTS = {
    "condemn":   {"rep": (-6, -10, -15), "rel": (-4, -6, -8)},
    "inspect":   {"expose": (0.6, 0.8, 0.95), "clean_rep": 5},
    "aid":       {"happy": (4, 6, 8), "stab": (3, 5, 7), "income": (1.04, 1.07, 1.10), "hours": 48},
    "sanctions": {"income": (0.9, 0.82, 0.72), "hours": (72, 120, 168)},
    "embargo":   {"hours": (48, 96, 168)},
    "ceasefire": {"hours": (24, 48, 72)},
    "pmc_sanctions": {"hours": (72, 120, 168)},
}

PROPOSE_COST_INF = 20      # дипкапитал на внесение проекта
PROPOSE_CD = 12 * H        # не чаще на страну
VOTE_TTL = 24 * H
MIN_JUSTIFY = 40           # символов обоснования
REJECT_REFUND = 0.5
SG = "Генсек ООН"          # инициатор резолюций наблюдателя
WATCH_EVERY_H = 6
TEST_VETO_S = 3600         # окно вето штаба на решение по испытанию


def type_label(key: str) -> str:
    return TYPES[key]["label"] if key in TYPES else key


def sev_pick(key: str, field: str, severity: int):
    v = EFFECTS[key][field]
    return v[_clamp(int(severity or 2), 1, 3) - 1] if isinstance(v, tuple) else v


def ga_outcome(yes: int, no: int, npc_support: float, players: int) -> tuple[bool, float, float]:
    """Генассамблея: голоса игроков + блок «мирового сообщества».
    → (принято, итог «за», итог «против»). npc_support 0..100, 50 — нейтрально (поровну)."""
    block = max(NPC_BLOCK_MIN, players)
    s = _clamp(npc_support, 0, 100) / 100.0
    y, n = yes + block * s, no + block * (1 - s)
    return y > n, round(y, 1), round(n, 1)


def sc_outcome(votes: dict[str, str], members: list[str]) -> tuple[bool, str]:
    """Совбез: votes {страна: yes|no|abstain}. → (принято, пояснение)."""
    vetoes = [c for c in members if c in P5 and votes.get(c) == "no"]
    if vetoes:
        return False, "вето: " + ", ".join(vetoes)
    yes = sum(1 for c in members if votes.get(c) == "yes")
    no = sum(1 for c in members if votes.get(c) == "no")
    if yes + no == 0:
        return False, "никто не проголосовал «за»"
    ok = yes / (yes + no) >= SC_PASS_SHARE
    return ok, f"«за» {yes}, «против» {no}"


# ═══════════════ ИИ ═══════════════
def available() -> bool:
    return bool(getattr(config, "OPENAI_API_KEY", ""))



_STYLE = NO_EMOJI_RULE + " Кратко: ответ — компактный JSON."

# Экономия: gpt-4o-mini, короткие промпты, жёсткий лимит токенов ответа на каждую роль.
MAX_TOKENS = {"secretariat": 420, "watcher": 220, "judge": 200}


async def _chat(system: str, user: str, max_tokens: int = 300, timeout: float = 30.0) -> dict | None:
    if not available():
        return None
    import aiohttp
    payload = {
        "model": getattr(config, "OPENAI_MODEL", "gpt-4o-mini"),
        "temperature": 0.3,
        "max_tokens": max_tokens,
        "response_format": {"type": "json_object"},
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
    }
    headers = {"Authorization": f"Bearer {config.OPENAI_API_KEY}", "Content-Type": "application/json"}
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.post("https://api.openai.com/v1/chat/completions", json=payload, headers=headers,
                                 timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                if r.status != 200:
                    log.warning("OpenAI %s: %s", r.status, (await r.text())[:200])
                    return None
                data = await r.json()
        return json.loads(data["choices"][0]["message"]["content"])
    except Exception:
        log.exception("un ai error")
        return None


_SECRETARIAT = (
    "Ты — Секретариат ООН в военно-политической игре по реальному миру. Тебе дают ПРОЕКТ резолюции "
    "от страны-игрока, факты из мирового журнала и состояние сторон. Верни СТРОГО JSON.\n"
    "Задачи:\n"
    "1) admissible — допустим ли проект: есть ли реальные основания в ФАКТАХ (не в словах автора). "
    "Голословные обвинения, троллинг, резолюции против жертвы агрессии, помощь агрессору — недопустимы.\n"
    "2) title — официальное название (до 90 символов), text — официальный текст резолюции "
    "(2-4 предложения, стиль ООН, на русском).\n"
    "3) severity 1..3 — тяжесть по масштабу фактов (1 — мелко, 3 — ядерный удар, массовая агрессия).\n"
    "4) npc_support 0..100 — как проголосует мировое сообщество (незанятые страны), реалистично.\n"
    "5) p5 — позиции НЕЗАНЯТЫХ постоянных членов СБ из списка: {страна: yes|no|abstain} по их реальной "
    "внешней политике и отношениям со сторонами. Вето (no) — только когда реальная держава так бы и "
    "поступила (защищает союзника/себя).\n"
    "6) reason — 1 предложение: почему допустим или нет.\n"
    'Формат: {"admissible": true, "reason": "", "title": "", "text": "", "severity": 2, '
    '"npc_support": 60, "p5": {"Китай": "abstain"}}'
)

_WATCHER = (
    "Ты — Генеральный секретарь ООН, наблюдатель игрового мира. Тебе дают свежие записи мирового "
    "журнала (войны, ядерные удары, испытания, нарушения ДНЯО, санкции, ультиматумы, аннексии). "
    "Реши, выносить ли вопросы на повестку. Выноси ТОЛЬКО по-настоящему серьёзное: ядерное "
    "применение, нарушение ДНЯО, нападение несоразмерно сильного на слабого, гуманитарная катастрофа. "
    "Не чаще 2 вопросов. Типы: condemn, inspect, aid, sanctions, embargo, ceasefire. Для ceasefire "
    "укажи war_id из журнала. Верни СТРОГО JSON: "
    '{"items": [{"type": "sanctions", "target": "Страна", "war_id": 0, "justification": "1-2 предложения"}]} '
    'или {"items": []}.'
)

_JUDGE = (
    "Ты — Совет МАГАТЭ/ООН, который решает судьбу заявки на ЯДЕРНОЕ ИСПЫТАНИЕ в игре. Дано досье "
    "страны: стабильность, репутация, войны, статус по ДНЯО, недавние события. Реши approve true/false. "
    "Одобряй, когда страна стабильна, не ведёт агрессивных войн, имеет вменяемую репутацию или является "
    "исторической ядерной державой. Отклоняй нестабильные режимы, агрессоров, вероломные страны, "
    "нарушителей посреди скандала. Верни СТРОГО JSON: "
    '{"approve": true, "statement": "официальное заявление 2-3 предложения на русском"}'
)


async def secretariat(kind: str, proposer: str, target: str, justification: str,
                      facts: str, context: str, npc_p5: list[str]) -> dict:
    """→ {admissible, reason, title, text, severity, npc_support, p5, ai}."""
    base = {"admissible": True, "reason": "", "severity": 2, "npc_support": 50.0, "p5": {}, "ai": False,
            "title": f"{type_label(kind)}: {target}", "text": justification.strip()[:600]}
    user = (f"ТИП: {kind} ({type_label(kind)}) — {TYPES[kind]['desc']}\n"
            f"АВТОР: {proposer}\nЦЕЛЬ: {target}\nОБОСНОВАНИЕ АВТОРА: {justification[:800]}\n\n"
            f"ФАКТЫ ЖУРНАЛА:\n{facts or '(записей нет)'}\n\nСОСТОЯНИЕ СТОРОН:\n{context}\n\n"
            f"НЕЗАНЯТЫЕ ПОСТОЯННЫЕ ЧЛЕНЫ СБ: {', '.join(npc_p5) or 'нет'}")
    r = await _chat(_SECRETARIAT + _STYLE, user[:3500], MAX_TOKENS["secretariat"])
    if not r:
        return base
    p5 = {}
    for c, v in (r.get("p5") or {}).items():
        if c in npc_p5 and str(v) in ("yes", "no", "abstain"):
            p5[c] = str(v)
    try:
        sev = int(r.get("severity", 2))
    except (TypeError, ValueError):
        sev = 2
    try:
        sup = float(r.get("npc_support", 50))
    except (TypeError, ValueError):
        sup = 50.0
    return {
        "admissible": bool(r.get("admissible", True)),
        "reason": clean(r.get("reason"))[:300],
        "title": clean(r.get("title") or base["title"])[:90],
        "text": clean(r.get("text") or base["text"])[:900],
        "severity": int(_clamp(sev, 1, 3)),
        "npc_support": _clamp(sup, 0, 100),
        "p5": p5, "ai": True,
    }


async def watcher(journal_text: str, countries: list[str]) -> list[dict]:
    """→ [{type, target, war_id, justification}] — вопросы на повестку (≤2)."""
    r = await _chat(_WATCHER + _STYLE, f"СТРАНЫ ИГРЫ: {', '.join(countries)}\n\nЖУРНАЛ:\n{journal_text[:2500]}",
                    MAX_TOKENS["watcher"])
    if not r:
        return []
    out = []
    for it in (r.get("items") or [])[:2]:
        t = str(it.get("type") or "")
        tgt = str(it.get("target") or "")
        if t in TYPES and tgt in countries:
            try:
                wid = int(it.get("war_id") or 0)
            except (TypeError, ValueError):
                wid = 0
            out.append({"type": t, "target": tgt, "war_id": wid,
                        "justification": clean(it.get("justification"))[:500]})
    return out


async def judge_test(dossier: str) -> dict | None:
    """→ {approve, statement} или None (ИИ недоступен — решает штаб)."""
    r = await _chat(_JUDGE + _STYLE, dossier[:2000], MAX_TOKENS["judge"])
    if not r:
        return None
    return {"approve": bool(r.get("approve", False)), "statement": clean(r.get("statement"))[:600]}


# Наблюдатель зовёт ИИ только если в журнале есть СЕРЬЁЗНОЕ (иначе вызова нет вообще).
SERIOUS = {"nuke_strike", "nuke_expose", "nuke_test", "war_declared", "annex"}
