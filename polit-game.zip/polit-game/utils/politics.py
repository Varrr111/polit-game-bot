"""
Политика государства: идеология, религия, счастье и стабильность.

Счастье и стабильность — ЖИВЫЕ (не лежат мёртвым грузом):
  • у каждого строя/религии своя «точка равновесия» счастья и стабильности —
    показатели дрейфуют к ней каждый час;
  • счастье поддерживает стабильность (голодный, злой народ → бунты);
  • стабильность и строй множат авто-доход (порядок = экономика работает);
  • на краях шкал срабатывают СОБЫТИЯ (беспорядки, протесты, переворот, расцвет).

Все числа — ЗАГЛУШКИ под тюнинг клиента.
"""

# ── Идеологии: hap/stab — сдвиг точки равновесия (±), income — множитель дохода ──
IDEOLOGIES: dict[str, dict] = {
    "none":          {"label": "Без идеологии", "icon": "⚪", "hap": 0,   "stab": 0,  "income": 1.00,
                      "desc": "Нейтральный курс без выраженного строя."},
    "democracy":     {"label": "Демократия",    "icon": "🗳️", "hap": 15,  "stab": -5, "income": 1.10,
                      "desc": "Свободы радуют народ, но согласие даётся тяжело."},
    "liberalism":    {"label": "Либерализм",    "icon": "🕊️", "hap": 12,  "stab": -8, "income": 1.15,
                      "desc": "Рынок и свободы разгоняют экономику ценой порядка."},
    "socialism":     {"label": "Социализм",     "icon": "🚩", "hap": 10,  "stab": 4,  "income": 0.95,
                      "desc": "Соцгарантии держат народ довольным, рост умереннее."},
    "communism":     {"label": "Коммунизм",     "icon": "☭",  "hap": 5,   "stab": 12, "income": 0.90,
                      "desc": "Жёсткий контроль и равенство: стабильно, но бедно."},
    "monarchy":      {"label": "Монархия",      "icon": "👑", "hap": 8,   "stab": 12, "income": 1.00,
                      "desc": "Традиция и преемственность — опора стабильности."},
    "technocracy":   {"label": "Технократия",   "icon": "🔬", "hap": 5,   "stab": 6,  "income": 1.12,
                      "desc": "Управление специалистов: эффективно и предсказуемо."},
    "theocracy":     {"label": "Теократия",     "icon": "⛪", "hap": 8,   "stab": 10, "income": 0.95,
                      "desc": "Власть веры. Сильна в связке с госрелигией."},
    "authoritarian": {"label": "Авторитаризм",  "icon": "👁️", "hap": -10, "stab": 20, "income": 1.00,
                      "desc": "Железный порядок давит недовольство силой."},
    "fascism":       {"label": "Фашизм",        "icon": "⚔️", "hap": -15, "stab": 15, "income": 1.05,
                      "desc": "Милитаризм и мобилизация против счастья народа."},
}

# ── Религии: мягкие модификаторы; дают синергию с теократией ──
RELIGIONS: dict[str, dict] = {
    "secular":      {"label": "Светское",     "icon": "⚪", "hap": 0, "stab": 0, "desc": "Отделение веры от государства."},
    "christianity": {"label": "Христианство", "icon": "✝️", "hap": 5, "stab": 3, "desc": "Традиционные ценности и общины."},
    "islam":        {"label": "Ислам",        "icon": "☪️", "hap": 4, "stab": 5, "desc": "Крепкая община и порядок."},
    "buddhism":     {"label": "Буддизм",      "icon": "☸️", "hap": 8, "stab": 2, "desc": "Умиротворение выше богатства."},
    "judaism":      {"label": "Иудаизм",      "icon": "✡️", "hap": 4, "stab": 4, "desc": "Сплочённость и учёность."},
    "atheism":      {"label": "Атеизм",       "icon": "🚫", "hap": 2, "stab": -1, "desc": "Рационализм без догм."},
}

# Параметры динамики (в час)
HAP_STEP = 4.0          # шаг дрейфа счастья к равновесию
STAB_STEP = 3.0         # шаг дрейфа стабильности
HAP_BASE = 55.0         # базовая точка равновесия счастья
STAB_BASE = 50.0        # базовая точка равновесия стабильности
THEO_SYNERGY = 8.0      # бонус теократии при негосветской религии

# Стоимости смены/вложений (заглушки)
IDEOLOGY_CHANGE_COST = 50_000_000
RELIGION_CHANGE_COST = 20_000_000
IDEOLOGY_CHANGE_STAB_HIT = 15.0     # смена строя бьёт по стабильности
RELIGION_CHANGE_HAP_HIT = 8.0       # смена религии бьёт по счастью
CHANGE_COOLDOWN = 24 * 3600         # сутки между сменами
INVEST_COST_PER_STAB = 3_000_000    # $ за +1 стабильности
INVEST_COST_PER_HAP = 2_000_000     # $ за +1 счастья


# ══════════════════════════════════════════════════════════════════════════
#  ПОЛИТИЧЕСКИЕ ПЕРЕХОДЫ (реформа / революция) — глубокая механика
#  Все числа — ЗАГЛУШКИ под тюнинг.
# ══════════════════════════════════════════════════════════════════════════

# Карта «соседей»: реформой можно перейти ТОЛЬКО к соседнему строю. Дальние —
# через революцию. Граф симметричный (связь в обе стороны).
IDEOLOGY_ADJACENCY: dict[str, list[str]] = {
    "none":          ["democracy", "monarchy", "socialism", "technocracy"],
    "democracy":     ["none", "liberalism", "socialism", "technocracy"],
    "liberalism":    ["democracy", "technocracy"],
    "socialism":     ["none", "democracy", "communism"],
    "communism":     ["socialism", "authoritarian"],
    "monarchy":      ["none", "authoritarian", "theocracy"],
    "technocracy":   ["none", "democracy", "liberalism", "authoritarian"],
    "theocracy":     ["monarchy", "authoritarian"],
    "authoritarian": ["monarchy", "communism", "technocracy", "theocracy", "fascism"],
    "fascism":       ["authoritarian"],
}


def reform_targets(ideology: str) -> list[str]:
    return IDEOLOGY_ADJACENCY.get(ideology or "none", [])


def can_reform(frm: str, to: str) -> bool:
    return to in reform_targets(frm)


# Условия принятия строя (реформой ИЛИ революцией). ctx: {happiness, stability,
# dev (сумма уровней развития), army (кол-во соединений), religion}.
def check_requirements(ideology: str, ctx: dict) -> tuple[bool, str]:
    hap = ctx.get("happiness", 0); stab = ctx.get("stability", 0)
    dev = ctx.get("dev", 0); army = ctx.get("army", 0); religion = ctx.get("religion", "secular")
    if ideology == "technocracy" and dev < TECHNOCRACY_DEV_MIN:
        return False, f"нужен уровень развития ≥ {TECHNOCRACY_DEV_MIN} (сейчас {dev})"
    if ideology == "theocracy" and religion == "secular":
        return False, "нужна государственная религия (не светское)"
    if ideology == "fascism" and army < FASCISM_ARMY_MIN and stab > 35:
        return False, f"нужна армия ≥ {FASCISM_ARMY_MIN} соединений или кризис"
    if ideology == "democracy" and (hap < DEMOCRACY_HAP_MIN or stab < DEMOCRACY_STAB_MIN):
        return False, f"нужны счастье ≥ {DEMOCRACY_HAP_MIN} и стабильность ≥ {DEMOCRACY_STAB_MIN}"
    if ideology == "liberalism" and stab < LIBERALISM_STAB_MIN:
        return False, f"нужна стабильность ≥ {LIBERALISM_STAB_MIN}"
    return True, ""


TECHNOCRACY_DEV_MIN = 6
FASCISM_ARMY_MIN    = 2
DEMOCRACY_HAP_MIN   = 45
DEMOCRACY_STAB_MIN  = 45
LIBERALISM_STAB_MIN = 40

# ── Легитимность (прочность власти) ──
LEGIT_BASE = 45.0
LEGIT_STEP = 3.0            # дрейф легитимности в час
LEGIT_TRANSITION_DRAG = 2.0  # доп. снижение в час во время перехода


def target_legitimacy(happiness: float, stability: float) -> float:
    return clamp(LEGIT_BASE + (happiness - 50.0) * 0.30 + (stability - 50.0) * 0.50)


def legit_word(legit: float) -> str:
    if legit >= 80: return "незыблемая власть"
    if legit >= 60: return "прочная власть"
    if legit >= 40: return "шаткая власть"
    if legit >= 20: return "кризис легитимности"
    return "власть на грани"


# ── Реформа (постепенный переход к соседнему строю) ──
REFORM_STAB_MIN     = 55.0
REFORM_LEGIT_MIN    = 50.0
REFORM_COST         = 60_000_000
REFORM_DURATION_H   = 24               # длительность переходного периода (часы)
REFORM_INCOME_MULT  = 0.85             # множитель дохода на время перехода (через Effects)
REFORM_SETTLE_STAB  = -8.0             # разовый осадок по завершении
REFORM_SETTLE_HAP   = -4.0
REFORM_LEGIT_AFTER  = 58.0             # свежий мандат после реформы


def reform_ready(stability: float, legitimacy: float) -> tuple[bool, str]:
    if stability < REFORM_STAB_MIN:
        return False, f"нужна стабильность ≥ {int(REFORM_STAB_MIN)} (реформу проводит крепкое государство)"
    if legitimacy < REFORM_LEGIT_MIN:
        return False, f"нужна легитимность ≥ {int(REFORM_LEGIT_MIN)}"
    return True, ""


# ── Революция (к любому строю, только в кризис) ──
REVOLUTION_STAB_MAX   = 35.0           # революция возможна при кризисе (ИЛИ низкая легитимность)
REVOLUTION_LEGIT_MAX  = 35.0
REVOLUTION_COST       = 120_000_000
REVOLUTION_BASE       = 45.0           # база шанса успеха
REVOLUTION_MIN        = 15.0
REVOLUTION_MAX        = 90.0
REVOLUTION_CIVILWAR   = 35.0           # шанс гражданской войны при успехе (%)
# исходы:
REVOLUTION_WIN_STAB   = 22.0           # стабильность после удачной революции (крах)
REVOLUTION_WIN_HAP    = -18.0
REVOLUTION_WIN_LEGIT  = 32.0
REVOLUTION_FAIL_STAB  = -15.0
REVOLUTION_FAIL_LEGIT = -15.0


def revolution_allowed(stability: float, legitimacy: float) -> bool:
    return stability <= REVOLUTION_STAB_MAX or legitimacy <= REVOLUTION_LEGIT_MAX


def revolution_success_chance(army: int, funds_ratio: float, stability: float) -> float:
    """army — соединения; funds_ratio — казна/стоимость (ограничим); чем ниже
    стабильность старого режима — тем легче революция."""
    chance = (REVOLUTION_BASE
              + min(army, 6) * 4.0
              + clamp(funds_ratio, 0, 3) * 6.0
              - (stability - 20.0) * 0.6)
    return round(clamp(chance, REVOLUTION_MIN, REVOLUTION_MAX), 1)


# ── Религиозность и смена религии ──
def religiosity(ideology: str, religion: str) -> float:
    base = 0.0 if (religion or "secular") == "secular" else 40.0
    if ideology == "theocracy":
        base += 50.0
    return clamp(base, 0, 100)


RELIGION_BASE_HAP_HIT  = 6.0
RELIGION_BASE_STAB_HIT = 4.0


def religion_change_hits(ideology: str, religion: str) -> tuple[float, float]:
    """(−счастье, −стабильность) при смене религии — масштаб от религиозности."""
    r = religiosity(ideology, religion) / 100.0
    hap = RELIGION_BASE_HAP_HIT + 18.0 * r
    stab = RELIGION_BASE_STAB_HIT + 12.0 * r
    return round(hap, 1), round(stab, 1)


# ── Оппозиция (угроза свержения при долгой низкой легитимности) ──
OPPOSITION_LEGIT_LOW  = 30.0           # ниже — оппозиция крепнет
OPPOSITION_GROW       = 8.0            # прирост в час при низкой легитимности
OPPOSITION_DECAY      = 10.0           # спад в час при нормальной легитимности
OPPOSITION_WARN       = 45.0           # порог «оппозиция крепнет»
OPPOSITION_DANGER     = 70.0           # порог «режим на грани»
OPPOSITION_OVERTHROW  = 100.0          # достигнута — свержение


def opposition_word(opp: float) -> str:
    if opp >= OPPOSITION_DANGER: return "режим на грани свержения"
    if opp >= OPPOSITION_WARN: return "оппозиция крепнет"
    if opp > 10: return "есть недовольные"
    return "оппозиция подавлена"


# Кастомные иконки (application-эмодзи) — заполняются на старте через
# apply_custom_emojis(); до этого отдаём юникод-фолбэк из ['icon'].
POL_SLUG: dict[str, str] = {k: f"pol_{k}" for k in IDEOLOGIES}
REL_SLUG: dict[str, str] = {k: f"rel_{k}" for k in RELIGIONS}
POL_ICONS_CUSTOM: dict[str, str] = {}
REL_ICONS_CUSTOM: dict[str, str] = {}


def clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def ideo(key: str) -> dict:
    return IDEOLOGIES.get(key or "none", IDEOLOGIES["none"])


def rel(key: str) -> dict:
    return RELIGIONS.get(key or "secular", RELIGIONS["secular"])


def ideo_icon(key: str) -> str:
    key = key or "none"
    return POL_ICONS_CUSTOM.get(key) or ideo(key)["icon"]


def rel_icon(key: str) -> str:
    key = key or "secular"
    return REL_ICONS_CUSTOM.get(key) or rel(key)["icon"]


def ideo_label(key: str) -> str:
    return f"{ideo_icon(key)} {ideo(key)['label']}"


def rel_label(key: str) -> str:
    return f"{rel_icon(key)} {rel(key)['label']}"


def _theo_bonus(ideology: str, religion: str) -> float:
    return THEO_SYNERGY if (ideology == "theocracy" and religion != "secular") else 0.0


def target_happiness(ideology: str, religion: str) -> float:
    return clamp(HAP_BASE + ideo(ideology)["hap"] + rel(religion)["hap"] + _theo_bonus(ideology, religion))


def target_stability(ideology: str, religion: str, happiness: float) -> float:
    # счастье народа поддерживает (или подрывает) стабильность
    support = (happiness - 50.0) * 0.25
    return clamp(STAB_BASE + ideo(ideology)["stab"] + rel(religion)["stab"]
                 + _theo_bonus(ideology, religion) + support)


def drift(value: float, target: float, step: float) -> float:
    """Сдвигает value к target не больше чем на step."""
    diff = target - value
    if abs(diff) <= step:
        return round(target, 2)
    return round(value + (step if diff > 0 else -step), 2)


def stability_factor(stability: float) -> float:
    """Множитель авто-дохода от стабильности: 0.70 при 0 → 1.20 при 100."""
    return round(0.70 + (stability / 100.0) * 0.50, 3)


def income_multiplier(ideology: str, stability: float) -> float:
    """Итоговый множитель дохода: строй × стабильность."""
    return round(ideo(ideology)["income"] * stability_factor(stability), 3)


def bar(value: float, n: int = 10) -> str:
    filled = int(round(clamp(value) / 100 * n))
    return "▰" * filled + "▱" * (n - filled)


def mood_word(happiness: float) -> str:
    if happiness >= 80: return "ликование"
    if happiness >= 60: return "довольство"
    if happiness >= 40: return "спокойствие"
    if happiness >= 20: return "недовольство"
    return "гнев"


def order_word(stability: float) -> str:
    if stability >= 80: return "незыблемый порядок"
    if stability >= 60: return "порядок"
    if stability >= 40: return "напряжение"
    if stability >= 20: return "волнения"
    return "хаос"
