"""
Военный движок (Этап 2). Война между странами идёт по областям карты:
наступление от границы вглубь, область за областью, вплоть до столицы.

ПРИНЦИП (экономия токенов): всю МАТЕМАТИКУ считает код по реальным боевым
статам соединений (utils.army.formation_combat), а ИИ лишь читает планы обеих
сторон и выдаёт короткий тактический «перевес» (edge ∈ [-1..1]) + нарратив.
Влияние ИИ зажато в ±15% — слабая сторона не может «выговорить» победу.

Здесь только чистые функции и вызов ИИ; состояние войны хранит менеджер War,
применяет всё ког cogs/war.py (потери, карта, экономика, политика).
"""

import json
import logging
import math

import config

log = logging.getLogger("war")

# ── тюнинг (все числа — заглушки под баланс) ──
MOD_SWING = 0.15          # максимум влияния тактики ИИ на долю (±15%)
SIEGE_STEP = 55.0         # базовый шаг осадного прогресса за раунд
SIEGE_NEEDED = 100.0      # прогресс для захвата обычной области
ADVANCE_PIVOT = 0.47      # <0.5: у атакующего инициатива (даже паритет медленно двигает фронт)
OVEREXT_K = 0.5           # максимум штрафа за переразвёртывание (вглубь врага)
BASE_LOSS = 0.12          # базовая доля потерь за раунд при равном бое
MAX_LOSS = 0.40           # потолок потерь одной стороны за раунд
CAPITAL_FORT = 2.2        # множитель укрепления столицы (крупнейшая область)
BORDER_FORT = 0.9         # обычная область (открытый фронт — чуть в пользу инициативы атакующего)
FORT_PER_DEV = 0.03       # +укрепление за уровень развития обороняющегося
AIR_BONUS = 0.08          # прибавка к доле атакующего при господстве в воздухе
NAVAL_BONUS = 0.05        # прибавка при морском превосходстве (блокада/десант)
MISSILE_SIEGE = 0.10      # ракеты частично гасят укрепление (ускоряют осаду)
WEARINESS_BASE = 0.6      # падение стабильности за раунд у обеих сторон
WEARINESS_LOSER = 1.2     # доп. падение у проигравшего раунд


def combat_power(atk: float, arm: float, hp: float) -> float:
    """Единая боевая мощь: атака доминирует, броня/живучесть дают устойчивость."""
    return atk * 1.0 + arm * 0.6 + hp * 0.4


def fortification(is_capital: bool, dev: int = 0, stability: float = 50.0) -> float:
    """Укрепление области: столица крепче, развитие и стабильность добавляют."""
    base = CAPITAL_FORT if is_capital else BORDER_FORT
    return round(base * (1 + dev * FORT_PER_DEV) * (0.92 + (stability or 0) / 100 * 0.14), 3)


def overextension(captured: int, total: int) -> float:
    """Штраф наступающему за глубину прорыва (чем дальше от границы, тем тяжелее снабжать)."""
    if total <= 0:
        return 0.0
    return round(min(OVEREXT_K, (captured / total) * OVEREXT_K * 1.5), 3)


def domain_edge(att_dom: dict, def_dom: dict) -> float:
    """Доменные бонусы к доле атакующего: авиация и флот.
    att_dom/def_dom: {'land':power,'air':power,'naval':power,'missile':power}."""
    bonus = 0.0
    if att_dom.get("air", 0) > def_dom.get("air", 0) * 1.1 + 1:
        bonus += AIR_BONUS
    if att_dom.get("naval", 0) > def_dom.get("naval", 0) * 1.1 + 1:
        bonus += NAVAL_BONUS
    return bonus


def effective_fort(fort: float, att_missile_power: float, def_power: float) -> float:
    """Ракеты атакующего частично гасят укрепление обороны."""
    if att_missile_power > 0 and def_power > 0:
        relief = min(MISSILE_SIEGE, MISSILE_SIEGE * att_missile_power / (def_power + 1))
        return max(1.0, fort * (1 - relief))
    return fort


def resolve_round(att: tuple, deff: tuple, *, fort: float, overext: float,
                  edge: float, domain_bonus: float, siege_progress: float,
                  siege_needed: float = SIEGE_NEEDED) -> dict:
    """Один раунд боя за текущую область. Возвращает исход + доли потерь.

    att/deff = (атака, броня, живучесть) суммарно по введённым в бой соединениям.
    edge ∈ [-1..1] — тактический перевес от ИИ (>0 — у атакующего).
    """
    edge = max(-1.0, min(1.0, edge))
    pa_raw = combat_power(*att)
    pd_raw = combat_power(*deff)
    mA = 1 + edge * MOD_SWING
    mD = 1 - edge * MOD_SWING
    pa = max(0.0, pa_raw * mA * (1 - overext))
    pd = max(0.0, pd_raw * mD * fort)
    denom = pa + pd + 1e-9
    share = pa / denom + domain_bonus
    share = max(0.05, min(0.95, share))

    advance = (share - ADVANCE_PIVOT) * 2 * SIEGE_STEP   # прогресс осады (инициатива у атакующего)
    new_progress = siege_progress + advance
    captured = new_progress >= siege_needed
    repelled = new_progress <= -SIEGE_STEP              # атакующего отбросили

    intensity = 2 * min(pa, pd) / denom                # 0..1, выше при равной силе
    att_loss = min(MAX_LOSS, BASE_LOSS * intensity * (1 - share) * 2)
    def_loss = min(MAX_LOSS, BASE_LOSS * intensity * share * 2)

    return {
        "share": round(share, 3),
        "power_att": round(pa), "power_def": round(pd),
        "advance": round(advance, 1),
        "siege_progress": round(max(0.0, new_progress), 1),
        "captured": captured, "repelled": repelled,
        "att_loss_frac": round(att_loss, 3),
        "def_loss_frac": round(def_loss, 3),
        "attacker_won_round": share > 0.5,
    }


def clash(att: tuple, deff: tuple, att_dom: dict, def_dom: dict, edge: float) -> tuple:
    """Кто взял верх в раунде (без учёта укрепления) → (победил_атакующий?, score_att, score_def).
    Домены (авиация/флот) и тактический edge ИИ усиливают соответствующую сторону."""
    edge = max(-1.0, min(1.0, edge))
    a = combat_power(*att) * (1 + edge * MOD_SWING + domain_edge(att_dom, def_dom))
    d = combat_power(*deff) * (1 - edge * MOD_SWING + domain_edge(def_dom, att_dom))
    return (a >= d, max(1.0, a), max(1.0, d))


def push(winner_score: float, loser_score: float, *, fort: float, overext: float,
         siege_progress: float, siege_needed: float = SIEGE_NEEDED) -> dict:
    """Наступление победителя раунда на укреплённую область проигравшего.
    Возвращает прогресс осады, захват и доли потерь (победитель теряет меньше)."""
    wp = max(1.0, winner_score * (1 - overext))
    lp = max(1.0, loser_score * fort)
    share = wp / (wp + lp)
    advance = (share - ADVANCE_PIVOT) * 2 * SIEGE_STEP
    new = siege_progress + advance
    intensity = 2 * min(wp, lp) / (wp + lp)
    w_loss = min(MAX_LOSS, BASE_LOSS * intensity * (1 - share))
    l_loss = min(MAX_LOSS, BASE_LOSS * intensity * share * 1.4)
    return {
        "share": round(share, 3), "advance": round(advance, 1),
        "siege_progress": round(max(0.0, new), 1),
        "captured": new >= siege_needed, "stalled": advance <= 0,
        "winner_loss": round(w_loss, 3), "loser_loss": round(l_loss, 3),
        "wp": round(wp), "lp": round(lp),
    }


def weariness(attacker_won: bool) -> tuple[float, float]:
    """(падение стабильности атакующего, падение у обороняющегося) за раунд."""
    if attacker_won:
        return WEARINESS_BASE, WEARINESS_BASE + WEARINESS_LOSER
    return WEARINESS_BASE + WEARINESS_LOSER, WEARINESS_BASE


# ══════════════ ЛИНИЯ ФРОНТА (по карте) ══════════════
def _dist(a: tuple, b: tuple) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def land_adjacent(attacker_a3: str, defender_a3: str, overrides: dict, thresh: float = 6.0) -> bool:
    """Есть ли общая сухопутная граница — по НАСТОЯЩЕМУ соседству областей (общие участки границ),
    с учётом захваченных областей. (Раньше — по близости центроидов: Армения «граничила» с Ираком.)"""
    from .worldmap import neighbor_countries
    return defender_a3 in neighbor_countries(attacker_a3, overrides)


def build_front(attacker_a3: str, defender_a3: str, overrides: dict) -> list[dict]:
    """Области обороняющегося, упорядоченные от границы атакующего вглубь.

    overrides: {region_id: owner_a3} из MapState (кто чем реально владеет).
    Возвращает [{region, name, fort_capital(bool)}] — порядок = ось наступления.
    Укрепление считается отдельно (нужны dev/stability страны) в коге.
    """
    from .worldmap import all_regions
    regions = all_regions()

    def owner(rid: str, a0: str) -> str:
        return overrides.get(rid, a0)

    att_centroids = [c for (rid, a0, _n, c, _ar) in regions if owner(rid, a0) == attacker_a3]
    deff = [(rid, name, c, area) for (rid, a0, name, c, area) in regions
            if owner(rid, a0) == defender_a3]
    if not deff:
        return []
    # столица/крупнейшая область — самое укреплённое, идёт в конце оси
    capital_rid = max(deff, key=lambda x: x[3])[0]

    def border_dist(c):
        if not att_centroids:
            return 0.0
        return min(_dist(c, ac) for ac in att_centroids)

    # прочие области — от границы вглубь; СТОЛИЦА всегда финальная цель (в конце оси)
    others = [x for x in deff if x[0] != capital_rid]
    others.sort(key=lambda x: border_dist(x[2]))
    capital = [x for x in deff if x[0] == capital_rid]
    ordered = others + capital
    return [{"region": rid, "name": name, "is_capital": (rid == capital_rid)}
            for (rid, name, c, area) in ordered]


# ══════════════ ИИ-АРБИТР (короткий запрос) ══════════════
def available() -> bool:
    return bool(getattr(config, "OPENAI_API_KEY", ""))


_SYSTEM = (
    "Ты — военный арбитр стратегической игры. Тебе дают сводку сил двух стран "
    "(атакующий и обороняющийся) и их ПЛАНЫ действий на один раунд. Силы НЕ "
    "пересчитывай — оцени ТОЛЬКО качество тактики и верни тактический перевес.\n"
    "Что награждать: концентрацию сил на узком участке, разведку перед ударом, "
    "подавление ПВО перед работой авиации, завоевание господства в воздухе, "
    "удары по снабжению/резервам, окружение, грамотную оборону в глубину, "
    "контратаки во фланг, использование флота для десанта/блокады. "
    "Что штрафовать: распыление сил, пассивность, танки без прикрытия и разведки, "
    "выключенное ПВО, отсутствие резервов, бессмысленные или нереалистичные приказы.\n"
    "ДИПЛОМАТИЯ — ЖЁСТКОЕ ПРАВИЛО: сверяйся с блоком «ДИПЛОМАТИЯ» в сводке. Манёвр, удар или "
    "переброска через территорию ТРЕТЬЕЙ страны допустимы, ТОЛЬКО если у стороны есть право "
    "прохода через неё. Если права нет — приказ невыполним: войска упираются в чужую границу, "
    "это грубая ошибка, перевес уходит другой стороне. Не придумывай союзников, которых нет "
    "в сводке; помощь реальных союзников в бою учитывай как разумную.\n"
    "Любая сторона может получить перевес — и атакующий, и обороняющийся. "
    "Верни СТРОГО JSON: "
    '{"edge": число от -1 до 1 (ПОЛОЖИТЕЛЬНОЕ = тактический перевес у АТАКУЮЩЕГО, '
    'ОТРИЦАТЕЛЬНОЕ = у обороняющегося, 0 = поровну), '
    '"narrative": "2-3 предложения живого описания боя по-русски, по сути планов", '
    '"special": "короткое яркое спецсобытие или пустая строка"}. '
    "Если один план явно умнее другого — не стесняйся давать edge по модулю 0.6–0.9; "
    "при равных по качеству планах держи около 0."
)


async def adjudicate(att_plan: str, def_plan: str, snapshot: str, timeout: float = 25.0) -> dict:
    """Короткий запрос к gpt-4o-mini → {edge, narrative, special}.
    При отсутствии ключа/ошибке возвращает нейтральный edge=0 (бой решает код)."""
    if not available():
        return {"edge": 0.0, "narrative": "", "special": "", "ai": False, "err": "нет ключа OPENAI_API_KEY"}
    import aiohttp
    payload = {
        "model": getattr(config, "OPENAI_MODEL", "gpt-4o-mini"),
        "temperature": 0.5,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": (f"ОБЛАСТЬ И СИЛЫ:\n{snapshot}\n\n"
                                         f"ПЛАН АТАКУЮЩЕГО:\n{att_plan or '(нет плана)'}\n\n"
                                         f"ПЛАН ОБОРОНЯЮЩЕГОСЯ:\n{def_plan or '(нет плана)'}")},
        ],
    }
    headers = {"Authorization": f"Bearer {config.OPENAI_API_KEY}", "Content-Type": "application/json"}
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.post("https://api.openai.com/v1/chat/completions",
                                 json=payload, headers=headers,
                                 timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                if r.status != 200:
                    body = (await r.text())[:200]
                    log.warning("OpenAI %s: %s", r.status, body)
                    return {"edge": 0.0, "narrative": "", "special": "", "ai": False,
                            "err": f"HTTP {r.status}: {body}"}
                data = await r.json()
        parsed = json.loads(data["choices"][0]["message"]["content"])
    except Exception as ex:
        log.exception("war adjudicate error")
        return {"edge": 0.0, "narrative": "", "special": "", "ai": False, "err": repr(ex)[:200]}
    try:
        edge = float(parsed.get("edge", 0))
    except (TypeError, ValueError):
        edge = 0.0
    return {
        "edge": max(-1.0, min(1.0, edge)),
        "narrative": str(parsed.get("narrative") or "").strip()[:600],
        "special": str(parsed.get("special") or "").strip()[:200],
        "ai": True, "err": "",
    }
