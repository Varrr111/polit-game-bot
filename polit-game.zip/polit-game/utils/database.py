"""
Базовый слой доступа к данным (SQLite).

ГДЕ ЛЕЖИТ БАЗА (приоритет):
  1. переменная окружения GAME_DB_PATH (или DB_PATH) — абсолютный путь к файлу.
  2. контейнерный хостинг (есть /home/container, напр. Pterodactyl/bot-hosting.net)
     → /home/container/gamedata/game.db — ПОСТОЯННАЯ папка ВНЕ кода бота. При
     перезаливке/удалении папки с кодом эта база не трогается: ничего не сбросится.
     ⚠️ Единственное правило: не удаляй саму папку /home/container/gamedata.
  3. локально/dev → data/game.db рядом с проектом.

АВТО-ПЕРЕНОС: если целевая база пустая (ещё нет стран), а рядом с кодом есть
старая data/game.db с данными — она копируется в новое место автоматически,
чтобы при переезде ничего не сбросилось и без ручных шагов.

Соединение открывается на каждую операцию (просто и потокобезопасно для бота).
"""

import logging
import os
import shutil
import sqlite3
from dataclasses import fields, MISSING
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# ГДЕ БАЗА (просто и предсказуемо, без копирований):
#   1. контейнерный хостинг (есть /home/container) → /home/container/gamedata/game.db
#      — ПОСТОЯННАЯ папка ВНЕ кода бота. Заливка ZIP кода её НЕ трогает.
#   2. явная переменная GAME_DB_PATH — если задана, берётся она (override).
#   3. локально/dev → data/game.db рядом с проектом.
_env_db = os.getenv("GAME_DB_PATH") or os.getenv("DB_PATH")
if Path("/home/container").is_dir():
    DB_PATH = Path(_env_db).expanduser() if _env_db else Path("/home/container/gamedata/game.db")
elif _env_db:
    DB_PATH = Path(_env_db).expanduser()
else:
    DB_PATH = Path(__file__).resolve().parent.parent / "data" / "game.db"
DB_PATH = DB_PATH.resolve()
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
logging.getLogger("database").info("База данных: %s", DB_PATH)


def get_connection() -> sqlite3.Connection:
    # Каталог data/ может отсутствовать на свежем деплое (в git он пуст) —
    # гарантируем его наличие на каждом подключении (дёшево, идемпотентно).
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        # WAL ускоряет конкурентный доступ, НО на части хостингов (сетевые/
        # контейнерные ФС без shared-memory) PRAGMA падает. Раньше это роняло
        # get_connection и УТЕКАЛО соединение (дескриптор не закрывался) →
        # через ~1024 операций «unable to open database file». Теперь ловим
        # и остаёмся на журнале по умолчанию — без утечки и падений.
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.OperationalError:
        pass
    return conn


# Имя python-типа поля -> тип колонки SQLite.
# field.type в Python 3.14 (PEP 649) может приходить строкой ('int'/'bool'/...),
# поэтому нормализуем к имени типа.
_SQL_TYPES = {"int": "INTEGER", "float": "REAL", "bool": "INTEGER", "str": "TEXT"}


def _type_name(py_type) -> str:
    return py_type if isinstance(py_type, str) else getattr(py_type, "__name__", "str")


def _column_type(py_type) -> str:
    return _SQL_TYPES.get(_type_name(py_type), "TEXT")


def _is_bool(py_type) -> bool:
    return _type_name(py_type) == "bool"


class BaseDB:
    """Общий предок менеджеров: подключение + создание таблицы.

    ВАЖНО: соединение открывается на операцию и ЗАКРЫВАЕТСЯ (иначе утечка
    файловых дескрипторов → 'unable to open database file'). Схема создаётся
    один раз на класс (а не на каждый экземпляр).
    """

    table: str = ""
    _schema_ready: set = set()  # имена классов, у которых схема уже создана

    def __init__(self):
        cls = type(self).__name__
        if cls not in BaseDB._schema_ready:
            self._ensure_schema()
            BaseDB._schema_ready.add(cls)

    def _ensure_schema(self):
        """Переопределяется в наследниках, которым нужны свои таблицы."""
        pass

    def _execute(self, sql: str, params: tuple = ()):
        conn = get_connection()
        try:
            conn.execute(sql, params)
            conn.commit()
        finally:
            conn.close()

    def _query_one(self, sql: str, params: tuple = ()):
        conn = get_connection()
        try:
            return conn.execute(sql, params).fetchone()
        finally:
            conn.close()

    def _query_all(self, sql: str, params: tuple = ()):
        conn = get_connection()
        try:
            return conn.execute(sql, params).fetchall()
        finally:
            conn.close()


class UserDB(BaseDB):
    """
    Менеджер «участников» (страна/ЧВК/регион/террорист/повстанец).

    Схема таблицы автогенерируется из полей соответствующего датакласса
    (object_class). Первичный ключ — name.

    Контракт (используется cogs/economy.py):
      get_object(name)                -> объект | None
      update_object(name, **kwargs)   -> обновлённый объект (money=±delta!)
      get_object_names()              -> list[str]
      get_stat_lvls(name)             -> {'trade': lvl, ...} (только имеющиеся)
      get_object_by_user(user_id)     -> объект | None
      create_object(**kwargs)         -> созданный объект
    """

    object_class = None

    def _fieldnames(self) -> list[str]:
        return [f.name for f in fields(self.object_class)]

    def _ensure_schema(self):
        cols = []
        for f in fields(self.object_class):
            col_type = _column_type(f.type)
            pk = " PRIMARY KEY" if f.name == "name" else ""
            cols.append(f'"{f.name}" {col_type}{pk}')
        self._execute(f'CREATE TABLE IF NOT EXISTS {self.table} ({", ".join(cols)})')

    def _row_to_obj(self, row):
        if row is None:
            return None
        data = {k: row[k] for k in row.keys()}
        # bool-поля в БД хранятся как int — вернём обратно к bool
        for f in fields(self.object_class):
            if _is_bool(f.type) and data.get(f.name) is not None:
                data[f.name] = bool(data[f.name])
        return self.object_class(**data)

    def get_object(self, name: str):
        row = self._query_one(f"SELECT * FROM {self.table} WHERE name = ?", (name,))
        return self._row_to_obj(row)

    def get_object_by_user(self, user_id: int):
        row = self._query_one(f"SELECT * FROM {self.table} WHERE user = ?", (user_id,))
        return self._row_to_obj(row)

    def get_object_names(self) -> list[str]:
        rows = self._query_all(f"SELECT name FROM {self.table}")
        return [r["name"] for r in rows]

    def all_objects(self) -> list:
        rows = self._query_all(f"SELECT * FROM {self.table}")
        return [self._row_to_obj(r) for r in rows]

    def create_object(self, **kwargs):
        # заполняем недостающие поля значениями по умолчанию из датакласса
        values = {}
        for f in fields(self.object_class):
            if f.name in kwargs:
                values[f.name] = kwargs[f.name]
            elif f.default is not MISSING:
                values[f.name] = f.default
            elif f.default_factory is not MISSING:  # type: ignore[misc]
                values[f.name] = f.default_factory()  # type: ignore[misc]
        cols = ", ".join(f'"{k}"' for k in values)
        placeholders = ", ".join("?" for _ in values)
        self._execute(
            f"INSERT OR REPLACE INTO {self.table} ({cols}) VALUES ({placeholders})",
            tuple(values.values()),
        )
        return self.get_object(values["name"])

    def update_object(self, name: str, **kwargs):
        """
        money=<delta>  -> прибавляется к текущему балансу (может быть отрицательным).
        Остальные поля -> присваиваются как есть.
        Возвращает обновлённый объект (с учётом возможного переименования).
        """
        valid = set(self._fieldnames())
        sets, params = [], []
        for key, value in kwargs.items():
            if key not in valid:
                continue
            if key == "money":
                sets.append('"money" = "money" + ?')
            else:
                sets.append(f'"{key}" = ?')
            params.append(value)
        if sets:
            params.append(name)
            self._execute(f"UPDATE {self.table} SET {', '.join(sets)} WHERE name = ?", tuple(params))
        new_name = kwargs.get("name", name)
        return self.get_object(new_name)

    def get_stat_lvls(self, name: str) -> dict[str, int]:
        obj = self.get_object(name)
        if not obj:
            return {}
        return {
            stat: getattr(obj, f"{stat}_lvl")
            for stat in ("trade", "tourism", "economy")
            if hasattr(obj, f"{stat}_lvl")
        }
