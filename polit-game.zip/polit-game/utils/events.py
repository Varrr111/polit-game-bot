"""
Система событий: раз в 6 часов каждой стране выпадает событие, зависящее от её
СОСТОЯНИЯ (счастье, стабильность, казна, развитие, армия, население). События
дают бафы/дебафы — мгновенные (деньги/счастье/стабильность/население/ресурсы)
и временные (множитель дохода на часы).

Событие = dict:
  id, title, icon, tone (good|bad|neutral), cat, desc, cond(state)->bool, weight,
  effects: список операций:
     ("money_pct", f)   ±доля казны
     ("money", n)       ±фикс $
     ("happy", d)       ±счастье
     ("stab", d)        ±стабильность
     ("pop_pct", f)     ±доля населения
     ("res", name, n)   ±ресурс
     ("income_mult", m, hours)  временный множитель дохода

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from dataclasses import dataclass


@dataclass
class State:
    happiness: float = 50.0
    stability: float = 50.0
    money: int = 0
    population: int = 0
    territory: int = 0
    dev_income: int = 0        # доход развития (прокачка)
    army_power: int = 0        # суммарная боевая мощь
    formations: int = 0        # число соединений
    grain: int = 0             # запас зерна
    ideology: str = "none"


TONE = {"good": ("Удача", 0x2E9BD6), "bad": ("Беда", 0xE05260), "neutral": ("Событие", 0xE0A54D)}
CATS = {"economy": "Экономика", "social": "Общество", "politics": "Политика",
        "military": "Военное", "nature": "Природа", "science": "Наука", "diplomacy": "Дипломатия"}

# Категория → ключ кастом-иконки (экономика/политика/военное переиспользуют существующие)
CAT_UI = {"economy": "coins", "social": "ev_social", "politics": "gov", "military": "attack",
          "nature": "ev_nature", "science": "ev_science", "diplomacy": "ev_diplomacy"}


def cat_icon(category: str) -> str:
    from .resources import ui_icon
    return ui_icon(CAT_UI.get(category, "flat"))


def _e(id, title, icon, tone, cat, desc, effects, cond=None, weight=10):
    return {"id": id, "title": title, "icon": icon, "tone": tone, "cat": cat, "desc": desc,
            "effects": effects, "cond": cond or (lambda s: True), "weight": weight}


T = lambda s: True  # универсальное условие

EVENTS: list[dict] = [
    # ───────────── ЭКОНОМИКА (хорошее) ─────────────
    _e("invest_boom", "Инвестиционный бум", "📈", "good", "economy",
       "Иностранный капитал хлынул в экономику {name}. Биржи ликуют, заводы расширяются.",
       [("money_pct", 0.06), ("income_mult", 1.12, 12)], lambda s: s.dev_income > 0, 12),
    _e("export_record", "Экспортный рекорд", "🚢", "good", "economy",
       "{name} поставила на мировой рынок рекордный объём товаров.",
       [("money_pct", 0.05)], T, 11),
    _e("oil_strike", "Нефтяное месторождение", "🛢️", "good", "economy",
       "Геологи {name} открыли богатое месторождение. Приток средств обеспечен.",
       [("money", 40_000_000), ("res", "нефть", 400), ("income_mult", 1.08, 24)], T, 8),
    _e("tourism_wave", "Туристический наплыв", "🏖️", "good", "economy",
       "Мир открыл для себя {name}. Туристы везут валюту.",
       [("money_pct", 0.04), ("happy", 3)], lambda s: s.happiness > 50, 10),
    _e("trade_deal", "Торговое соглашение", "🤝", "good", "economy",
       "{name} заключила выгодный торговый пакт. Пошлины падают, прибыль растёт.",
       [("income_mult", 1.15, 18)], T, 9),
    _e("currency_up", "Укрепление валюты", "💹", "good", "economy",
       "Валюта {name} уверенно растёт на фоне доверия инвесторов.",
       [("money_pct", 0.03), ("stab", 2)], lambda s: s.stability > 55, 9),
    _e("eco_miracle", "Экономическое чудо", "✨", "good", "economy",
       "Экономика {name} демонстрирует невероятный рост — о нём пишут все газеты.",
       [("money_pct", 0.10), ("happy", 6), ("income_mult", 1.2, 12)],
       lambda s: s.dev_income > 0 and s.happiness > 60, 4),
    _e("tech_export", "Экспорт технологий", "💽", "good", "economy",
       "Высокотехнологичная продукция {name} нарасхват за рубежом.",
       [("money_pct", 0.05), ("res", "электроника", 150)], lambda s: s.dev_income > 0, 8),
    # ───────────── ЭКОНОМИКА (плохое) ─────────────
    _e("market_crash", "Биржевой обвал", "📉", "bad", "economy",
       "Паника на биржах {name}. Капитализация компаний рухнула за часы.",
       [("money_pct", -0.07), ("income_mult", 0.9, 12)], lambda s: s.money > 50_000_000, 11),
    _e("inflation", "Всплеск инфляции", "🔥", "bad", "economy",
       "Цены в {name} взлетели, сбережения граждан тают.",
       [("money_pct", -0.04), ("happy", -5)], T, 11),
    _e("capital_flight", "Бегство капитала", "🏃", "bad", "economy",
       "Инвесторы массово выводят деньги из {name}.",
       [("money_pct", -0.06), ("income_mult", 0.88, 18)], lambda s: s.stability < 55, 10),
    _e("corruption", "Коррупционный скандал", "💸", "bad", "economy",
       "Вскрылось крупное хищение из казны {name}. Доверие подорвано.",
       [("money_pct", -0.05), ("stab", -6), ("happy", -4)], T, 10),
    _e("res_price_drop", "Обвал цен на сырьё", "⬇️", "bad", "economy",
       "Мировые цены на ресурсы упали — экспорт {name} приносит гроши.",
       [("income_mult", 0.85, 24)], T, 9),
    _e("bank_crisis", "Банковский кризис", "🏦", "bad", "economy",
       "Несколько банков {name} на грани краха. Вкладчики в панике.",
       [("money_pct", -0.08), ("stab", -5)], lambda s: s.money > 100_000_000, 7),
    _e("bad_harvest", "Неурожай", "🌾", "bad", "economy",
       "Поля {name} дали скудный урожай. Запасы зерна тают.",
       [("res", "зерно", -200), ("happy", -4)], T, 9),
    _e("strike_eco", "Всеобщая забастовка", "✊", "bad", "economy",
       "Рабочие {name} остановили заводы, требуя повышения зарплат.",
       [("income_mult", 0.8, 10), ("happy", -3)], lambda s: s.happiness < 50, 9),

    # ───────────── ОБЩЕСТВО (хорошее) ─────────────
    _e("festival", "Народный фестиваль", "🎉", "good", "social",
       "По всей {name} гремят праздники. Народ счастлив и сплочён.",
       [("happy", 8), ("stab", 2)], lambda s: s.happiness > 45, 12),
    _e("sport_win", "Спортивная победа", "🏆", "good", "social",
       "Сборная {name} взяла золото на международном турнире — ликование по всей стране!",
       [("happy", 7)], T, 11),
    _e("baby_boom", "Демографический подъём", "👶", "good", "social",
       "В {name} резко выросла рождаемость — нация молодеет.",
       [("pop_pct", 0.015), ("happy", 3)], lambda s: s.happiness > 55, 9),
    _e("culture_renaissance", "Культурный ренессанс", "🎭", "good", "social",
       "{name} переживает расцвет искусства и науки.",
       [("happy", 6), ("stab", 3)], T, 8),
    _e("crime_down", "Снижение преступности", "🛡️", "good", "social",
       "Реформа полиции {name} дала плоды — улицы стали безопаснее.",
       [("stab", 6), ("happy", 3)], lambda s: s.stability > 40, 9),
    _e("patriotism", "Патриотический подъём", "🎌", "good", "social",
       "Волна национальной гордости захлестнула {name}.",
       [("happy", 5), ("stab", 5)], T, 9),
    # ───────────── ОБЩЕСТВО (плохое) ─────────────
    _e("protests", "Массовые протесты", "📢", "bad", "social",
       "Площади {name} заполнены недовольными. Правительство нервничает.",
       [("happy", -6), ("stab", -8)], lambda s: s.happiness < 45, 12),
    _e("riots", "Городские беспорядки", "🔥", "bad", "social",
       "В городах {name} вспыхнули погромы и поджоги.",
       [("stab", -10), ("money_pct", -0.03)], lambda s: s.stability < 45, 11),
    _e("epidemic", "Эпидемия", "🦠", "bad", "social",
       "По {name} распространяется болезнь. Больницы переполнены.",
       [("pop_pct", -0.012), ("happy", -6), ("income_mult", 0.9, 12)], T, 9),
    _e("crime_up", "Рост преступности", "🔪", "bad", "social",
       "Криминал {name} поднимает голову — граждане боятся выходить из дома.",
       [("stab", -6), ("happy", -4)], lambda s: s.stability < 55, 10),
    _e("famine", "Голод", "🍽️", "bad", "social",
       "Нехватка продовольствия в {name} обернулась голодом в регионах.",
       [("pop_pct", -0.015), ("happy", -10), ("stab", -5)],
       lambda s: s.grain < 50 or s.happiness < 30, 7),
    _e("migration_crisis", "Миграционный кризис", "🧳", "bad", "social",
       "Потоки беженцев хлынули в {name}, создавая напряжение.",
       [("happy", -4), ("stab", -4)], T, 8),

    # ───────────── ПОЛИТИКА (хорошее) ─────────────
    _e("elections_ok", "Успешные выборы", "🗳️", "good", "politics",
       "Выборы в {name} прошли честно и спокойно — власть легитимна как никогда.",
       [("stab", 7), ("happy", 3)], lambda s: s.ideology in ("democracy", "liberalism", "none"), 9),
    _e("great_leader", "Харизматичный лидер", "⭐", "good", "politics",
       "Новый лидер {name} вдохновляет нацию и укрепляет единство.",
       [("stab", 8), ("happy", 5)], T, 7),
    _e("reform_ok", "Удачная реформа", "📜", "good", "politics",
       "Правительство {name} провело реформу, которую приняли на ура.",
       [("stab", 5), ("income_mult", 1.08, 12)], lambda s: s.stability > 45, 9),
    _e("anticorruption", "Антикоррупционная кампания", "⚖️", "good", "politics",
       "{name} очищает власть от казнокрадов — народ аплодирует.",
       [("stab", 6), ("happy", 4), ("money_pct", 0.02)], T, 8),
    # ───────────── ПОЛИТИКА (плохое) ─────────────
    _e("political_crisis", "Политический кризис", "🏛️", "bad", "politics",
       "Правительство {name} парализовано внутренней борьбой.",
       [("stab", -8), ("income_mult", 0.9, 12)], T, 11),
    _e("coup_attempt", "Попытка переворота", "🎖️", "bad", "politics",
       "Военные {name} попытались захватить власть. Хаос в столице.",
       [("stab", -14), ("money_pct", -0.05), ("happy", -5)], lambda s: s.stability < 40, 8),
    _e("gov_resign", "Отставка правительства", "🚪", "bad", "politics",
       "Кабинет министров {name} ушёл в отставку на фоне скандалов.",
       [("stab", -7)], lambda s: s.stability < 55, 10),
    _e("separatism", "Сепаратизм", "🗺️", "bad", "politics",
       "Один из регионов {name} заговорил о независимости.",
       [("stab", -9), ("territory_note", 0)], lambda s: s.stability < 45 and s.territory > 500_000, 7),
    _e("no_confidence", "Вотум недоверия", "🙅", "bad", "politics",
       "Парламент {name} выразил недоверие власти.",
       [("stab", -6), ("happy", -3)], T, 9),

    # ───────────── ВОЕННОЕ ─────────────
    _e("parade", "Военный парад", "🎇", "good", "military",
       "По столице {name} прошла мощь армии — народ преисполнен гордости.",
       [("happy", 6), ("stab", 3)], lambda s: s.formations > 0, 10),
    _e("drills_ok", "Успешные учения", "🎯", "good", "military",
       "Армия {name} блестяще отработала манёвры. Боеготовность на высоте.",
       [("stab", 4)], lambda s: s.formations > 0, 9),
    _e("defense_contract", "Оборонный контракт", "🛩️", "good", "military",
       "{name} продала партию техники союзникам — казна пополнилась.",
       [("money_pct", 0.04)], lambda s: s.army_power > 0, 8),
    _e("border_incident", "Пограничный инцидент", "💥", "bad", "military",
       "На границе {name} произошла стычка. Напряжение растёт.",
       [("stab", -5), ("happy", -3)], lambda s: s.army_power > 0, 9),
    _e("desertion", "Дезертирство", "🏳️", "bad", "military",
       "В армии {name} участились случаи дезертирства.",
       [("stab", -4)], lambda s: s.formations > 0 and s.happiness < 50, 8),
    _e("arms_leak", "Утечка оружия", "🔫", "bad", "military",
       "Со складов {name} пропала партия вооружения — скандал.",
       [("stab", -5), ("money_pct", -0.02)], lambda s: s.army_power > 0, 7),

    # ───────────── ПРИРОДА ─────────────
    _e("good_harvest", "Богатый урожай", "🌻", "good", "nature",
       "Поля {name} дали небывалый урожай — амбары полны.",
       [("res", "зерно", 300), ("happy", 4)], T, 11),
    _e("mild_winter", "Мягкая зима", "❄️", "good", "nature",
       "Тёплая зима сберегла {name} топливо и нервы.",
       [("res", "топливо", 150), ("happy", 2)], T, 9),
    _e("earthquake", "Землетрясение", "🌋", "bad", "nature",
       "Мощные толчки разрушили инфраструктуру {name}.",
       [("money_pct", -0.05), ("pop_pct", -0.008), ("happy", -5)], T, 8),
    _e("flood", "Наводнение", "🌊", "bad", "nature",
       "Разлив рек затопил регионы {name}.",
       [("money_pct", -0.04), ("res", "зерно", -150), ("happy", -4)], T, 8),
    _e("drought", "Засуха", "☀️", "bad", "nature",
       "Длительная засуха иссушила поля {name}.",
       [("res", "зерно", -200), ("happy", -4)], T, 8),
    _e("hurricane", "Ураган", "🌀", "bad", "nature",
       "Разрушительный ураган прошёлся по побережью {name}.",
       [("money_pct", -0.05), ("happy", -4)], lambda s: s.territory > 200_000, 7),
    _e("wildfire", "Лесные пожары", "🔥", "bad", "nature",
       "Пожары охватили леса {name}, дым застилает города.",
       [("happy", -4), ("res", "зерно", -80)], T, 8),

    # ───────────── НАУКА ─────────────
    _e("breakthrough", "Научный прорыв", "🔬", "good", "science",
       "Учёные {name} совершили открытие мирового значения.",
       [("income_mult", 1.12, 24), ("happy", 4)], lambda s: s.dev_income > 0, 9),
    _e("infra_project", "Инфраструктурный рывок", "🛣️", "good", "science",
       "{name} запустила крупный проект — новые дороги, мосты и электростанции.",
       [("happy", 4), ("stab", 3), ("income_mult", 1.06, 18)], lambda s: s.dev_income > 0, 7),
    _e("vaccine", "Новая вакцина", "💉", "good", "science",
       "Медики {name} создали прорывную вакцину.",
       [("happy", 5), ("pop_pct", 0.006)], T, 7),
    _e("brain_drain", "Утечка мозгов", "🧠", "bad", "science",
       "Лучшие умы {name} уезжают за границу в поисках лучшей жизни.",
       [("income_mult", 0.92, 18), ("happy", -3)], lambda s: s.happiness < 45, 8),
    _e("program_fail", "Провал госпрограммы", "📉", "bad", "science",
       "Дорогая научная программа {name} провалилась, деньги потрачены зря.",
       [("money_pct", -0.04)], lambda s: s.money > 30_000_000, 7),

    # ───────────── ДИПЛОМАТИЯ ─────────────
    _e("alliance", "Союзный договор", "🕊️", "good", "diplomacy",
       "{name} заключила крепкий союз — безопасность и торговля укрепились.",
       [("stab", 5), ("income_mult", 1.08, 18)], T, 8),
    _e("humanitarian", "Гуманитарная помощь", "🎗️", "good", "diplomacy",
       "Миру помогла {name} — международное уважение растёт.",
       [("happy", 3), ("money", -5_000_000), ("stab", 3)], lambda s: s.money > 20_000_000, 7),
    _e("recognition", "Международное признание", "🌍", "good", "diplomacy",
       "Авторитет {name} на мировой арене заметно вырос.",
       [("stab", 4), ("happy", 3)], T, 8),
    _e("diplo_scandal", "Дипломатический скандал", "📰", "bad", "diplomacy",
       "Утечка переписки опозорила {name} на весь мир.",
       [("stab", -4), ("happy", -3)], T, 9),
    _e("sanctions_hit", "Новые санкции", "🚫", "bad", "diplomacy",
       "Против {name} ввели международные санкции — экономика под давлением.",
       [("income_mult", 0.85, 24), ("money_pct", -0.03)], T, 9),
    _e("envoys_expelled", "Высылка послов", "✉️", "bad", "diplomacy",
       "Дипломатов {name} выслали из нескольких стран.",
       [("stab", -3)], T, 8),

    # ───────────── ✦ ЛЕГЕНДАРНЫЕ (редкие, на экстремумах состояния) ✦ ─────────────
    _e("golden_age", "Золотой век", "👑", "good", "politics",
       "История запомнит эту эпоху: {name} на вершине — процветание, порядок и слава.",
       [("money_pct", 0.08), ("happy", 8), ("stab", 5), ("income_mult", 1.25, 24)],
       lambda s: s.happiness > 75 and s.stability > 75 and s.dev_income > 0, 3),
    _e("state_collapse", "Коллапс государства", "💀", "bad", "politics",
       "{name} трещит по швам: пустая казна, гнев улиц, паралич власти. Катастрофа.",
       [("money_pct", -0.12), ("happy", -8), ("stab", -8), ("pop_pct", -0.01), ("income_mult", 0.72, 24)],
       lambda s: s.happiness < 22 and s.stability < 22, 4),
    _e("global_crisis", "Мировой экономический кризис", "🌍", "bad", "economy",
       "Мировая рецессия ударила по {name}: падает экспорт, рушатся доходы.",
       [("money_pct", -0.09), ("stab", -4), ("income_mult", 0.85, 18)], T, 4),

    # ───────────── ✦ ПОД ИДЕОЛОГИЮ (связь с политикой) ✦ ─────────────
    _e("five_year_plan", "Пятилетка перевыполнена", "🚩", "good", "economy",
       "Планы {name} выполнены досрочно! Герои труда на обложках газет.",
       [("income_mult", 1.1, 12), ("happy", 4), ("stab", 3)],
       lambda s: s.ideology in ("communism", "socialism"), 9),
    _e("shortage", "Товарный дефицит", "🫙", "bad", "social",
       "Полки магазинов {name} опустели. Очереди растут, а с ними и недовольство.",
       [("happy", -6), ("money_pct", -0.02)], lambda s: s.ideology == "communism", 9),
    _e("show_trials", "Показательные процессы", "⚖️", "neutral", "politics",
       "Власть {name} жёстко расправилась с несогласными: страх навёл порядок.",
       [("stab", 7), ("happy", -5)], lambda s: s.ideology in ("authoritarian", "fascism"), 9),
    _e("royal_wedding", "Королевская свадьба", "💍", "good", "social",
       "Вся {name} празднует брак монаршей особы — улицы в цветах и флагах.",
       [("happy", 7), ("stab", 3)], lambda s: s.ideology == "monarchy", 9),
    _e("holy_festival", "Великий религиозный праздник", "🕊️", "good", "social",
       "Духовный подъём охватил {name} — вера сплачивает народ как никогда.",
       [("happy", 8), ("stab", 4)], lambda s: s.ideology == "theocracy", 9),
    _e("mass_mobilization", "Всеобщая мобилизация", "📣", "neutral", "military",
       "{name} поставлена под ружьё. Дисциплина железная, но народ устал.",
       [("stab", 6), ("happy", -6)], lambda s: s.ideology == "fascism", 8),

    # ───────────── ✦ ПРОЧЕЕ (реальные) ✦ ─────────────
    _e("national_hero", "Герой нации", "🦸", "good", "social",
       "В {name} появился человек, которым гордится вся страна.",
       [("happy", 6), ("stab", 5)], T, 6),
    _e("cyber_attack", "Кибератака", "💻", "bad", "science",
       "Хакеры взломали системы {name} и вывели крупные суммы со счетов.",
       [("money_pct", -0.05), ("stab", -3)], lambda s: s.dev_income > 0, 7),

    # ───────────── ✦ ДОПОЛНИТЕЛЬНЫЕ ПОЛИТ/ЭКОНОМ СОБЫТИЯ ✦ ─────────────
    _e("tax_reform", "Налоговая реформа", "🧾", "neutral", "economy",
       "{name} перекроила налоги: казна рада, бизнес ворчит.",
       [("income_mult", 1.07, 18), ("happy", -2)], T, 9),
    _e("energy_crisis", "Энергетический кризис", "⚡", "bad", "economy",
       "Нехватка энергии ударила по заводам и домам {name}.",
       [("money_pct", -0.03), ("happy", -4), ("income_mult", 0.92, 12)], T, 9),
    _e("pension_crisis", "Пенсионный кризис", "👴", "bad", "social",
       "Пенсионная система {name} даёт сбой — пожилые выходят на улицы.",
       [("happy", -5), ("stab", -3), ("money_pct", -0.02)], T, 8),
    _e("housing_boom", "Строительный бум", "🏗️", "good", "economy",
       "Города {name} растут на глазах — стройки кипят, рабочих мест всё больше.",
       [("money_pct", 0.03), ("happy", 3), ("income_mult", 1.07, 12)], T, 9),
    _e("coalition", "Правящая коалиция", "🤝", "good", "politics",
       "Партии {name} договорились — власть стала устойчивой.",
       [("stab", 6)], lambda s: 35 < s.stability < 75, 8),
    _e("assassination", "Покушение на лидера", "🩸", "bad", "politics",
       "Совершено покушение на главу {name}. Страна в шоке и тревоге.",
       [("stab", -9), ("happy", -4)], T, 5),
    _e("trade_war", "Торговая война", "⚔️", "bad", "economy",
       "{name} втянута в торговую войну — пошлины бьют по экономике.",
       [("income_mult", 0.88, 18), ("money_pct", -0.02)], T, 8),
    _e("debt_relief", "Списание долга", "📑", "good", "economy",
       "Кредиторы простили {name} часть долгов — бюджету стало легче.",
       [("money_pct", 0.04)], lambda s: s.money < 30_000_000, 7),
    _e("referendum", "Референдум", "🗳️", "neutral", "politics",
       "{name} вынесла важный вопрос на всенародное голосование.",
       [("stab", 2)], lambda s: s.ideology in ("democracy", "liberalism"), 7),

    # ───────────── НЕЙТРАЛЬНЫЕ / ФИЛЛЕРЫ ─────────────
    _e("quiet_week", "Спокойные дни", "🌤️", "neutral", "social",
       "В {name} выдалась тихая неделя без потрясений — народ отдыхает.",
       [("happy", 2)], T, 6),
    _e("census", "Перепись населения", "📋", "neutral", "social",
       "{name} провела перепись — данные уточнены, бюрократия торжествует.",
       [("stab", 1)], T, 5),
    _e("market_steady", "Стабильный рынок", "📊", "neutral", "economy",
       "Рынки {name} без резких движений — инвесторы спокойны.",
       [("money_pct", 0.01)], T, 6),
    _e("minor_reform", "Мелкая реформа", "🧾", "neutral", "politics",
       "Правительство {name} подкрутило пару законов. Жизнь продолжается.",
       [("stab", 2)], T, 6),
]


def eligible(state: State) -> list[dict]:
    out = []
    for ev in EVENTS:
        try:
            if ev["cond"](state):
                out.append(ev)
        except Exception:
            continue
    return out or [EVENTS[-1]]
