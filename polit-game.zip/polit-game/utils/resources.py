"""
Система ресурсов — ядро (данные + баланс).

Философия: «золотая середина» сложности.
  • 10 видов СЫРЬЯ (raw) — добывается (ветки добычи + !mine).
  • 5 МАТЕРИАЛОВ (material) — производится из сырья по рецептам (переработка).
  • Материалы и сырьё тратятся на: улучшение веток развития, магазин/крафт,
    счастье, позже армию/войны. Обмен между игроками — рынок.

Иконки — абстракция: значение это строка, вставляемая в текст Discord.
Сейчас юникод-эмодзи; когда загрузим кастомные эмодзи бота — впишем
"<:name:id>" в RESOURCE_ICONS_CUSTOM, КОД НЕ МЕНЯЕТСЯ (res_icon берёт оттуда).
"""

from enum import Enum


class ResTier(str, Enum):
    RAW = "raw"            # сырьё
    MATERIAL = "material"  # материал (из сырья)


# ─────────────────────────────────────────────────────────────────────────
#  Определения ресурсов: name -> (label, tier, базовая_ценность_за_единицу_$)
#  base_value — ориентир для рынка/магазина.
# ─────────────────────────────────────────────────────────────────────────
RESOURCES: dict[str, tuple[str, ResTier, int]] = {
    # ── Руды (сырьё) — набор под ТЗ ──
    "железо":    ("Железо",    ResTier.RAW,    800),
    "уголь":     ("Уголь",     ResTier.RAW,    600),
    "хром":      ("Хром",      ResTier.RAW,  3_000),
    "никель":    ("Никель",    ResTier.RAW,  2_500),
    "марганец":  ("Марганец",  ResTier.RAW,  1_200),
    "медь":      ("Медь",      ResTier.RAW,  1_500),
    "нефть":     ("Нефть",     ResTier.RAW,  1_200),
    "бокситы":   ("Бокситы",   ResTier.RAW,  1_000),
    "молибден":  ("Молибден",  ResTier.RAW,  6_000),
    "вольфрам":  ("Вольфрам",  ResTier.RAW, 12_000),
    "уран":      ("Уран",      ResTier.RAW, 20_000),   # стратегическое сырьё (атомная программа)
    # ── Материалы ──
    "сталь":       ("Сталь",       ResTier.MATERIAL,  3_500),
    "топливо":     ("Топливо",     ResTier.MATERIAL,  4_000),
    "электроника": ("Электроника", ResTier.MATERIAL, 12_000),
    "ядерное топливо": ("Ядерное топливо", ResTier.MATERIAL, 60_000),   # ТВЭЛы для АЭС
}

# ─────────────────────────────────────────────────────────────────────────
#  Иконки (строки для вставки в текст). Поменять = поменять строку.
# ─────────────────────────────────────────────────────────────────────────
RESOURCE_ICONS: dict[str, str] = {
    "железо": "⛓️", "уголь": "🪨", "хром": "🪨", "никель": "🪙", "марганец": "⚫",
    "медь": "🔩", "нефть": "🛢️", "бокситы": "🟫", "молибден": "🔩", "вольфрам": "⬛", "уран": "☢️",
    "сталь": "⚙️", "топливо": "⛽", "электроника": "💻", "ядерное топливо": "🔋",
}
# Переопределение кастомными эмодзи бота. Пример: {"железо": "<:iron:123456789>"}
RESOURCE_ICONS_CUSTOM: dict[str, str] = {}


# Латинские слаги: имя эмодзи в Discord обязано быть [a-z0-9_] (без кириллицы).
# Используются как имя application-emoji и имя PNG-файла иконки.
RESOURCE_SLUG: dict[str, str] = {
    "железо": "iron", "уголь": "coal", "хром": "chromium", "никель": "nickel",
    "марганец": "manganese", "медь": "copper", "нефть": "oil", "бокситы": "bauxite",
    "молибден": "molybdenum", "вольфрам": "tungsten", "уран": "uranium",
    "сталь": "steel", "топливо": "fuel", "электроника": "electronics", "ядерное топливо": "nuclear_fuel",
}
SLUG_TO_RES = {v: k for k, v in RESOURCE_SLUG.items()}


def apply_custom_emojis(by_slug: dict[str, str]) -> int:
    """Раскладывает {slug: '<:name:id>'} по иконкам ресурсов/зданий/действий
    (вызывается на старте после fetch_application_emojis)."""
    from .upgrades import CATEGORY_SLUG, CATEGORY_ICONS_CUSTOM
    from .equipment import EQUIP_SLUG, EQUIP_ICONS_CUSTOM
    from .politics import POL_SLUG, REL_SLUG, POL_ICONS_CUSTOM, REL_ICONS_CUSTOM
    n = 0
    bld_rev = {v: k for k, v in BUILDING_SLUG.items()}
    act_rev = {v: k for k, v in ACTION_SLUG.items()}
    ui_rev = {v: k for k, v in UI_SLUG.items()}
    cat_rev = {v: k for k, v in CATEGORY_SLUG.items()}
    eq_rev = {v: k for k, v in EQUIP_SLUG.items()}
    pol_rev = {v: k for k, v in POL_SLUG.items()}
    rel_rev = {v: k for k, v in REL_SLUG.items()}
    for slug, mention in by_slug.items():
        if slug in SLUG_TO_RES:
            RESOURCE_ICONS_CUSTOM[SLUG_TO_RES[slug]] = mention
        elif slug in bld_rev:
            BUILDING_ICONS_CUSTOM[bld_rev[slug]] = mention
        elif slug in act_rev:
            ACTION_ICONS_CUSTOM[act_rev[slug]] = mention
        elif slug in ui_rev:
            UI_ICONS_CUSTOM[ui_rev[slug]] = mention
        elif slug in cat_rev:
            CATEGORY_ICONS_CUSTOM[cat_rev[slug]] = mention
        elif slug in eq_rev:
            EQUIP_ICONS_CUSTOM[eq_rev[slug]] = mention
        elif slug in pol_rev:
            POL_ICONS_CUSTOM[pol_rev[slug]] = mention
        elif slug in rel_rev:
            REL_ICONS_CUSTOM[rel_rev[slug]] = mention
        else:
            continue
        n += 1
    return n


def icon_manifest() -> list[tuple[str, "object"]]:
    """Единый список всех кастом-иконок (slug, путь_к_png) — один источник правды
    для заливки (scripts/upload_emojis.py) и догрузки через !reloadicons."""
    from pathlib import Path
    from .upgrades import CATEGORY_SLUG
    from .equipment import EQUIP_SLUG
    from .politics import POL_SLUG, REL_SLUG
    A = Path(__file__).resolve().parent.parent / "assets"
    groups = [
        ("resources", RESOURCE_SLUG), ("buildings", BUILDING_SLUG), ("actions", ACTION_SLUG),
        ("ui", UI_SLUG), ("dev", CATEGORY_SLUG), ("equipment", EQUIP_SLUG),
        ("politics", POL_SLUG), ("politics", REL_SLUG),
    ]
    items: list[tuple[str, object]] = []
    for folder, slugs in groups:
        for slug in slugs.values():
            items.append((slug, A / folder / f"{slug}.png"))
    return items


def res_icon(name: str) -> str:
    return RESOURCE_ICONS_CUSTOM.get(name) or RESOURCE_ICONS.get(name, "📦")


def res_label(name: str) -> str:
    return RESOURCES[name][0] if name in RESOURCES else name.capitalize()


def res_tier(name: str) -> ResTier | None:
    return RESOURCES[name][1] if name in RESOURCES else None


def res_value(name: str) -> int:
    return RESOURCES[name][2] if name in RESOURCES else 0


RAW_RESOURCES = [n for n, d in RESOURCES.items() if d[1] is ResTier.RAW]
MATERIAL_RESOURCES = [n for n, d in RESOURCES.items() if d[1] is ResTier.MATERIAL]


# ─────────────────────────────────────────────────────────────────────────
#  Рецепты переработки: материал -> {сырьё/материал: кол-во}.
#  Немного глубины (2–3 входа), но без переусложнения.
# ─────────────────────────────────────────────────────────────────────────
RECIPES: dict[str, dict[str, int]] = {
    "сталь":       {"железо": 2, "уголь": 1},
    "топливо":     {"нефть": 2},
    "электроника": {"медь": 2, "никель": 1},
    "ядерное топливо": {"уран": 4, "электроника": 1},
}

# ─────────────────────────────────────────────────────────────────────────
#  Добыча !mine: сырьё -> (мин, макс) за добычу. Кулдаун общий, на тип.
#  Пассивная добыча (ветки) будет давать больше — !mine это «ручная подработка».
# ─────────────────────────────────────────────────────────────────────────
MINE_COOLDOWN = 3 * 3600  # 3 часа на тип
MINE_YIELD: dict[str, tuple[int, int]] = {
    "железо": (70, 140), "уголь": (80, 160), "хром": (20, 50), "никель": (25, 55),
    "марганец": (40, 90), "медь": (50, 110), "нефть": (40, 90), "бокситы": (45, 100),
    "молибден": (5, 15), "вольфрам": (2, 8), "уран": (1, 4),
}


# ─────────────────────────────────────────────────────────────────────────
#  МЕСТОРОЖДЕНИЯ: страна -> {сырьё: богатство 1..3}. Что есть в земле.
#  1 — бедное (×0.6), 2 — среднее (×1.0), 3 — богатое (×1.5).
# ─────────────────────────────────────────────────────────────────────────
RICHNESS_MULT = {1: 0.6, 2: 1.0, 3: 1.5}

_DEP = {
    "Россия": "нефть3 уголь3 железо2 медь2 никель3 хром2 вольфрам2 марганец1 молибден1 уран2",
    "Германия": "уголь2 железо1",
    "Франция": "железо1 бокситы1 уголь1",
    "Великобритания": "нефть2 уголь1 вольфрам1",
    "Италия": "марганец1 медь1",
    "Испания": "медь1 вольфрам1 железо1",
    "Польша": "уголь3 медь2",
    "Украина": "железо3 уголь2 марганец2 уран1",
    "Швеция": "железо3 медь2 вольфрам1",
    "Норвегия": "нефть3 молибден1 медь1",
    "Китай": "уголь3 железо2 медь2 вольфрам3 молибден3 марганец2 бокситы2 никель1 уран1",
    "Индия": "уголь3 железо3 хром2 марганец2 бокситы2 уран1",
    "Япония": "медь1",
    "Южная Корея": "вольфрам1",
    "КНДР": "уголь2 железо2 медь1 вольфрам1 молибден1 уран1",
    "Иран": "нефть3 медь2 хром1 железо1 уран1",
    "Ирак": "нефть3",
    "Саудовская Аравия": "нефть3",
    "Турция": "хром3 медь1 уголь1 марганец1",
    "Израиль": "медь1",
    "Вьетнам": "уголь2 вольфрам2 бокситы2 марганец1",
    "Казахстан": "нефть3 уголь3 железо2 медь2 хром3 марганец2 никель1 молибден1 уран3",
    "Пакистан": "уголь1 хром1 медь1 уран1",
    "Египет": "нефть2 марганец1 железо1",
    "Южно-Африканская Республика": "хром3 марганец3 железо2 уголь3 никель2 вольфрам1 уран1",
    "Нигерия": "нефть3",
    "Эфиопия": "медь1 марганец1",
    "Алжир": "нефть3 железо1",
    "Марокко": "медь1 марганец1 железо1",
    "Кения": "медь1",
    "США": "нефть3 уголь3 железо2 медь2 молибден3 бокситы1 никель1 вольфрам1 уран1",
    "Канада": "нефть3 никель3 железо2 медь2 уголь2 молибден2 вольфрам1 уран3",
    "Мексика": "нефть2 медь3 молибден2 железо1 марганец1",
    "Куба": "никель2 медь1",
    "Бразилия": "железо3 бокситы3 марганец2 никель2 нефть2 медь2 уран1",
    "Аргентина": "нефть2 медь2 вольфрам1",
    "Чили": "медь3 молибден3 железо1",
    "Колумбия": "нефть2 уголь2 никель1",
    "Венесуэла": "нефть3 железо2 бокситы1",
    "Австралия": "уголь3 железо3 бокситы3 никель3 марганец2 медь2 вольфрам1 уран3",
    "Новая Зеландия": "железо1 уголь1",
    "Индонезия": "нефть2 уголь3 никель3 бокситы2 медь2",
    # ── Остальной ростер: у каждой страны минимум одна залежь, иначе заводы
    # стоят без дела. У микрогосударств это условность (бедная, ×0.6);
    # у тихоокеанских — железомарганцевые конкреции морского дна.
    # Европа
    "Нидерланды": "нефть1 уголь1",
    "Швейцария": "железо1",
    "Бельгия": "уголь1",
    "Австрия": "железо2 вольфрам2 марганец1",
    "Ирландия": "медь1 уголь1",
    "Дания": "нефть2",
    "Финляндия": "никель2 хром2 медь1 железо1",
    "Чехия": "уголь2 железо1 уран1",
    "Румыния": "нефть2 уголь2 бокситы1 железо1",
    "Мальта": "нефть1",
    "Португалия": "вольфрам3 медь2 железо1",
    "Греция": "бокситы3 никель2 хром1 уголь1",
    "Косово": "уголь2 никель1 хром1",
    "Венгрия": "бокситы2 уголь1 марганец1",
    "Монако": "железо1",
    "Лихтенштейн": "железо1",
    "Словакия": "железо2 медь1 марганец1 уголь1",
    "Андорра": "железо1",
    "Сан-Марино": "железо1",
    "Люксембург": "железо2",
    "Болгария": "медь2 уголь2 марганец1 железо1",
    "Белоруссия": "нефть1 железо1",
    "Хорватия": "нефть1 бокситы1",
    "Литва": "нефть1",
    "Словения": "уголь1 бокситы1",
    "Сербия": "медь3 уголь2 молибден1",
    "Ватикан": "медь1",
    "Латвия": "уголь1",
    "Эстония": "нефть2",
    "Исландия": "железо1",
    "Босния и Герцеговина": "уголь2 бокситы2 железо2",
    "Албания": "хром3 медь1 нефть1 никель1",
    "Северная Македония": "медь1 хром1 никель1 уголь1",
    "Молдавия": "железо1",
    "Черногория": "бокситы2 уголь1",
    # Азия
    "Сингапур": "нефть1",
    "Тайвань": "уголь1 медь1",
    "Туркменистан": "нефть3",
    "Таиланд": "вольфрам2 уголь1 нефть1",
    "Объединённые Арабские Эмираты": "нефть3",
    "Филиппины": "никель3 медь2 хром2 железо1",
    "Малайзия": "нефть2 бокситы2 железо1 вольфрам1",
    "Бахрейн": "нефть2",
    "Бангладеш": "уголь1 нефть1",
    "Кыргызстан": "уголь2 вольфрам1 молибден1 медь1",
    "Катар": "нефть3",
    "Мальдивы": "нефть1",
    "Кувейт": "нефть3",
    "Сирия": "нефть2 железо1",
    "Шри-Ланка": "железо1",
    "Оман": "нефть3 хром2 медь1",
    "Мьянма": "вольфрам2 нефть1 медь1 никель1",
    "Узбекистан": "медь3 молибден2 нефть1 вольфрам1 уголь1 уран2",
    "Ливан": "железо1",
    "Азербайджан": "нефть3 железо1 медь1 молибден1",
    "Иордания": "медь1 нефть1",
    "Непал": "железо1 медь1",
    "Камбоджа": "бокситы1 железо1 нефть1",
    "Кипр": "медь2 хром1",
    "Йемен": "нефть2",
    "Афганистан": "медь3 железо3 хром2 вольфрам1 уголь1",
    "Лаос": "медь2 бокситы2",
    "Грузия": "марганец3 медь2 уголь1",
    "Палестина": "нефть1",
    "Монголия": "медь3 уголь3 молибден2 железо2 вольфрам1 уран1",
    "Армения": "медь3 молибден3 железо1",
    "Бруней": "нефть3",
    "Таджикистан": "бокситы1 молибден1 вольфрам1 уголь1",
    "Бутан": "уголь1 железо1",
    "Восточный Тимор": "нефть2",
    # Африка
    "Маврикий": "железо1",
    "Кабо-Верде": "железо1",
    "Сейшелы": "нефть1",
    "Ангола": "нефть3 железо1 медь1 марганец1",
    "Гана": "марганец3 бокситы2 нефть2",
    "Танзания": "никель2 уголь1 железо1 медь1 уран1",
    "Кот-д’Ивуар": "нефть1 марганец1 никель1",
    "Ливия": "нефть3 железо1",
    "Демократическая Республика Конго": "медь3 вольфрам2 марганец1 уголь1",
    "Коморы": "железо1",
    "Сан-Томе и Принсипи": "нефть1",
    "Камерун": "бокситы2 нефть2 железо1",
    "Тунис": "нефть1 железо1",
    "Уганда": "медь1 вольфрам1 железо1",
    "Судан": "нефть2 хром2 железо1",
    "Сенегал": "железо1 нефть1",
    "Замбия": "медь3 марганец1 никель1 уголь1",
    "Зимбабве": "хром3 никель2 уголь2 медь1 железо1",
    "Ботсвана": "медь2 никель2 уголь2",
    "Мали": "бокситы1 железо1 марганец1",
    "Габон": "марганец3 нефть2 железо2",
    "Буркина-Фасо": "марганец2 медь1",
    "Мозамбик": "уголь3 бокситы1 нефть1",
    "Бенин": "нефть1 железо1",
    "Мадагаскар": "никель2 хром2 железо1",
    "Нигер": "уголь1 нефть1 уран2",
    "Намибия": "медь2 вольфрам1 нефть1 уран3",
    "Гвинея": "бокситы3 железо3",
    "Республика Конго": "нефть3 железо1",
    "Южный Судан": "нефть3",
    "Чад": "нефть2",
    "Экваториальная Гвинея": "нефть3",
    "Руанда": "вольфрам2",
    "Малави": "уголь1 бокситы1 уран1",
    "Мавритания": "железо3 медь1",
    "Того": "железо1",
    "Сомали": "нефть1 железо1",
    "Эсватини": "уголь2 железо1",
    "Сьерра-Леоне": "железо2 бокситы2",
    "Джибути": "железо1",
    "Либерия": "железо3",
    "Бурунди": "никель2 вольфрам1",
    "Лесото": "железо1",
    "Центральноафриканская Республика": "железо1 медь1",
    "Эритрея": "медь2",
    "Гамбия": "железо1",
    "Гвинея-Бисау": "бокситы1 нефть1",
    # Северная Америка
    "Гаити": "медь1 бокситы1",
    "Багамы": "нефть1",
    "Антигуа и Барбуда": "железо1",
    "Барбадос": "нефть1",
    "Сент-Люсия": "железо1",
    "Доминиканская Республика": "никель2 медь1 бокситы1",
    "Гватемала": "никель2 нефть1",
    "Панама": "медь3",
    "Коста-Рика": "бокситы1",
    "Гренада": "железо1",
    "Доминика": "железо1",
    "Сент-Китс и Невис": "железо1",
    "Сент-Винсент и Гренадины": "железо1",
    "Сальвадор": "железо1",
    "Гондурас": "железо1 медь1",
    "Тринидад и Тобаго": "нефть3",
    "Ямайка": "бокситы3",
    "Никарагуа": "медь1 железо1",
    "Белиз": "нефть1",
    # Южная Америка
    "Перу": "медь3 молибден2 железо2 вольфрам1 нефть1",
    "Эквадор": "нефть3 медь1",
    "Уругвай": "железо1",
    "Боливия": "вольфрам2 нефть2 железо2",
    "Парагвай": "железо1 марганец1",
    "Гайана": "бокситы3 нефть3 марганец1",
    "Суринам": "бокситы3 нефть2",
    # Австралия и Океания
    "Самоа": "марганец1",
    "Тонга": "марганец1 никель1",
    "Тувалу": "марганец1",
    "Кирибати": "марганец1 никель1",
    "Науру": "марганец1 никель1",
    "Федеративные Штаты Микронезии": "марганец1",
    "Маршалловы Острова": "марганец1 никель1",
    "Палау": "марганец1",
    "Папуа — Новая Гвинея": "медь3 нефть2 никель2",
    "Фиджи": "медь1 бокситы1",
    "Соломоновы Острова": "никель2 бокситы1",
    "Вануату": "марганец1",
}
DEPOSITS: dict[str, dict[str, int]] = {
    country: {p.rstrip("123"): int(p[-1]) for p in spec.split()}
    for country, spec in _DEP.items()
}


def country_deposits(country: str) -> dict[str, int]:
    return DEPOSITS.get(country, {})


def has_deposit(country: str, resource: str) -> bool:
    return resource in DEPOSITS.get(country, {})


# ─────────────────────────────────────────────────────────────────────────
#  ЗДАНИЯ: ключ -> (label, kind, out, cost_$)
#    kind = "extract" (добывает сырьё out) | "factory" (позволяет крафт out)
#    extract-здание можно строить только при наличии залежи out.
# ─────────────────────────────────────────────────────────────────────────
BUILDINGS: dict[str, tuple[str, str, str, int]] = {
    # добыча (по одному на сырьё)
    # универсальные заводы (дают общий пул добычи, распределяемый по рудам)
    "factory_small":  ("Малый завод",   "production", "",   300_000_000),
    "factory_medium": ("Средний завод", "production", "",   800_000_000),
    "factory_large":  ("Крупный завод", "production", "", 2_000_000_000),
    # переработка (по одному на материал)
    "steel_mill":    ("Сталелитейный завод", "factory", "сталь",       60_000_000),
    "refinery":      ("НПЗ",                 "factory", "топливо",     70_000_000),
    "electro_fab":   ("Электронный завод",   "factory", "электроника", 90_000_000),
    "fuel_fab":      ("Завод ТВЭЛ",          "factory", "ядерное топливо", 900_000_000),
    # хранилище (расширяет склад)
    "warehouse":     ("Склад",               "storage", "",            25_000_000),
}

# Мощность (пул добычи ресурсов/ч) по типу универсального завода.
FACTORY_POWER = {"factory_small": 125_000, "factory_medium": 137_500, "factory_large": 150_000}

# Уровни зданий (прокачка): множитель выхода. Макс. уровень 3.
MAX_BUILDING_LEVEL = 3
LEVEL_MULT = {1: 1.0, 2: 1.6, 3: 2.4}


def upgrade_cost(key: str, current_level: int) -> int:
    """Стоимость улучшения здания с текущего уровня на следующий."""
    base = BUILDINGS[key][3]
    return int(base * current_level * 1.5)


# Редкость руды: доля пула заводов, которая реально превращается в руду.
# Уран добывается в десятки раз медленнее — атомная программа не «бесплатная».
ORE_SCALE: dict[str, float] = {"уран": 0.03}


def ore_scale(resource: str) -> float:
    return ORE_SCALE.get(resource, 1.0)


# Пассивная добыча в час (на 1 здание) — середина диапазона !mine.
PASSIVE_YIELD = {r: (lo + hi) // 2 for r, (lo, hi) in MINE_YIELD.items()}

# Склад: базовая вместимость на ресурс + прибавка за каждый «Склад».
STORAGE_BASE = 500_000
STORAGE_PER_WAREHOUSE = 500_000
EXTRACT_BUILDINGS = {k: v for k, v in BUILDINGS.items() if v[1] == "extract"}
FACTORY_BUILDINGS = {k: v for k, v in BUILDINGS.items() if v[1] == "factory"}
PRODUCTION_BUILDINGS = {k: v for k, v in BUILDINGS.items() if v[1] == "production"}
# сырьё -> ключ добывающего здания; материал -> ключ завода (без склада)
OUT_TO_BUILDING = {v[2]: k for k, v in BUILDINGS.items() if v[2]}


def building_label(key: str) -> str:
    return BUILDINGS[key][0] if key in BUILDINGS else key


def find_building(query: str) -> str | None:
    """Резолвит ввод пользователя в ключ здания (по названию, частично)."""
    if not query:
        return None
    q = query.strip().lower()
    if q in BUILDINGS:
        return q
    for key, (label, *_rest) in BUILDINGS.items():
        if q in label.lower():
            return key
    return None


# ── Иконки зданий (slug = ключ здания; имена валидны для эмодзи) ──
BUILDING_SLUG: dict[str, str] = {k: k for k in BUILDINGS}
BUILDING_ICONS: dict[str, str] = {
    "factory_small": "🏭", "factory_medium": "🏭", "factory_large": "🏭",
    "steel_mill": "⚙️", "refinery": "🛢️", "electro_fab": "💻", "fuel_fab": "☢️", "warehouse": "📦",
}
BUILDING_ICONS_CUSTOM: dict[str, str] = {}


def bld_icon(key: str) -> str:
    return BUILDING_ICONS_CUSTOM.get(key) or BUILDING_ICONS.get(key, "🏭")


# ── Иконки действий хаба (сине-голубые, тема снежинки) ──
ACTION_SLUG: dict[str, str] = {
    "mine": "act_mine", "build": "act_build", "craft": "act_craft",
    "exchange": "act_exchange", "deposits": "act_deposits",
}
ACTION_ICONS: dict[str, str] = {
    "mine": "⛏️", "build": "🏗️", "craft": "🏭", "exchange": "💱", "deposits": "🗺️",
}
ACTION_ICONS_CUSTOM: dict[str, str] = {}


def action_icon(name: str) -> str:
    return ACTION_ICONS_CUSTOM.get(name) or ACTION_ICONS.get(name, "▫️")


# ── UI-иконки (статусы/тренды/деньги), тоже кастомные ──
UI_SLUG: dict[str, str] = {
    "check": "ui_check", "lock": "ui_lock", "upgrade": "ui_upgrade",
    "up": "ui_up", "down": "ui_down", "flat": "ui_flat",
    "coins": "ui_coins", "storage": "ui_storage",
    "prev": "ui_prev", "next": "ui_next", "globe": "ui_globe", "money": "ui_money",
    "land": "ui_land", "air": "ui_air", "naval": "ui_naval", "missile": "ui_missile",
    "plant": "ui_plant", "register": "ui_register", "license": "ui_license",
    "gov": "ui_gov", "stability": "ui_stability", "happy": "ui_happy",
    "barracks": "ui_barracks", "academy": "ui_academy", "command": "ui_command",
    "recruit": "ui_recruit", "form": "ui_form", "disband": "ui_disband",
    "soldier": "ui_soldier", "attack": "ui_attack", "armor": "ui_armor", "hp": "ui_hp",
    "ev_social": "ui_ev_social", "ev_nature": "ui_ev_nature",
    "ev_science": "ui_ev_science", "ev_diplomacy": "ui_ev_diplomacy",
    # шпионаж (Этап 1)
    "spy": "ui_spy", "recon": "ui_recon", "counterintel": "ui_counterintel",
    "agent": "ui_agent", "sweep": "ui_sweep", "destab": "ui_destab",
    "eco_sab": "ui_eco_sab", "sabotage": "ui_sabotage", "theft": "ui_theft",
    "heat": "ui_heat", "exposed": "ui_exposed",
    # права / !perm
    "perm": "ui_perm", "perm_grant": "ui_perm_grant", "perm_revoke": "ui_perm_revoke",
    "perm_all": "ui_perm_all", "perm_clear": "ui_perm_clear",
    # админ-инструменты
    "reload": "ui_reload", "dbreset": "ui_dbreset", "tools": "ui_tools",
    # ультиматумы
    "ultimatum": "ui_ultimatum", "accept": "ui_accept", "reject": "ui_reject",
    "counter": "ui_counter", "blockade": "ui_blockade",
    # гайд / новости
    "guide": "ui_guide", "news": "ui_news",
    # политика: переходы строя
    "legitimacy": "ui_legitimacy", "reform": "ui_reform",
    "revolution": "ui_revolution", "opposition": "ui_opposition",
    # регистрация
    "atomic": "ui_atomic", "population": "ui_population",
    # санкции
    "sanctions": "ui_sanctions", "embargo": "ui_embargo", "financial": "ui_financial",
    "techban": "ui_techban", "resilience": "ui_resilience",
    # защита сервера
    "guard": "ui_guard", "antispam": "ui_antispam", "antinuke": "ui_antinuke",
    "antiwebhook": "ui_antiwebhook", "antiban": "ui_antiban", "antibot": "ui_antibot",
    "antirole": "ui_antirole", "raidmode": "ui_raidmode", "raider": "ui_raider",
    "restore": "ui_restore",
    # война (Этап 2)
    "war": "ui_war", "war_declare": "ui_war_declare", "front": "ui_front",
    "offensive": "ui_offensive", "defense_op": "ui_defense_op", "siege": "ui_siege",
    "victory": "ui_victory", "defeat": "ui_defeat", "peace": "ui_peace",
    "losses": "ui_losses", "supply": "ui_supply", "warplan": "ui_warplan",
    "exhaustion": "ui_exhaustion",
    # соединения армии
    "fm_motor_rifle": "ui_fm_motor_rifle", "fm_tank_div": "ui_fm_tank_div",
    "fm_arty_regt": "ui_fm_arty_regt", "fm_aa_div": "ui_fm_aa_div",
    "fm_recon_bn": "ui_fm_recon_bn", "fm_air_wing": "ui_fm_air_wing",
    "fm_bomber_wing": "ui_fm_bomber_wing", "fm_heli_regt": "ui_fm_heli_regt",
    "fm_uav_sqn": "ui_fm_uav_sqn", "fm_flotilla": "ui_fm_flotilla",
    "fm_carrier_group": "ui_fm_carrier_group", "fm_sub_fleet": "ui_fm_sub_fleet",
    "fm_missile_bde": "ui_fm_missile_bde",
    # торговля
    "trade": "ui_trade", "market": "ui_market", "buy": "ui_buy",
    "sell": "ui_sell", "deal": "ui_deal", "cancel_x": "ui_cancel_x",
    # дипломатия
    "diplo": "ui_diplo", "relations": "ui_relations", "rel_up": "ui_rel_up",
    "rel_down": "ui_rel_down", "influence": "ui_influence", "treaty": "ui_treaty",
    "nonaggression": "ui_nonaggression", "trade_pact": "ui_trade_pact",
    "alliance": "ui_alliance", "transit": "ui_transit", "embassy": "ui_embassy",
    "reputation": "ui_reputation", "incident": "ui_incident", "deescalate": "ui_deescalate",
    "escalate": "ui_escalate", "betrayal": "ui_betrayal", "call_arms": "ui_call_arms",
    "envelope": "ui_envelope",    # альянсы
    "bloc_mil": "ui_bloc_mil",
    "bloc_eco": "ui_bloc_eco",
    "charter": "ui_charter",
    "cohesion": "ui_cohesion",
    "vote": "ui_vote",
    "treasury": "ui_treasury",
    "leader": "ui_leader",
    "invite": "ui_invite",
    "expel": "ui_expel",
    "leave_bloc": "ui_leave_bloc",
    "split": "ui_split",
    "ratify": "ui_ratify",
    "joint_command": "ui_joint_command",
    "intel_share": "ui_intel_share",
    "customs": "ui_customs",
    "currency_union": "ui_currency_union",
    # атомная программа
    "nuclear": "ui_nuclear",
    "physics": "ui_physics",
    "centrifuge": "ui_centrifuge",
    "enrich": "ui_enrich",
    "heu": "ui_heu",
    "warhead": "ui_warhead",
    "nuke_test": "ui_nuke_test",
    "npt": "ui_npt",
    "violator": "ui_violator",
    "fallout": "ui_fallout",
    "launch": "ui_launch",
    "intercept": "ui_intercept",
    "accident": "ui_accident",
    "umbrella": "ui_umbrella",
    "deterrence": "ui_deterrence",
    "nuke_club": "ui_nuke_club",
    "inspect": "ui_inspect",
    "nuke_sab": "ui_nuke_sab",
    "research": "ui_research",    # ООН
    "un": "ui_un",
    "un_condemn": "ui_un_condemn",
    "un_aid": "ui_un_aid",
    "un_embargo": "ui_un_embargo",
    "un_sc": "ui_un_sc",
    "veto": "ui_veto",
    "resolution": "ui_resolution",
    "un_news": "ui_un_news",
    "ga": "ui_ga",
    "abstain": "ui_abstain",
    "secgen": "ui_secgen",
    # ИИ-государства
    "ai_state": "ui_ai_state",
    # Наследие
    "legacy": "ui_legacy", "legacy_crown": "ui_legacy_crown", "legacy_decline": "ui_legacy_decline",
    # Модерация
    "mod": "ui_mod",
    "mod_warn": "ui_mod_warn",
    "mod_timeout": "ui_mod_timeout",
    "mod_ban": "ui_mod_ban",
    "mod_unban": "ui_mod_unban",
    "purge": "ui_purge",
    # ЧВК
    "pmc": "ui_pmc",
    "contract": "ui_contract",
    "riot": "ui_riot",
    "pmc_target": "ui_pmc_target",
    "pmc_hire": "ui_pmc_hire",
    "pmc_base": "ui_pmc_base",
    "black_market": "ui_black_market",
    "pmc_rating": "ui_pmc_rating",
}
UI_ICONS: dict[str, str] = {
    "check": "✅", "lock": "🔒", "upgrade": "⬆️", "up": "📈", "down": "📉",
    "flat": "➖", "coins": "💰", "storage": "📦",
    "prev": "◀️", "next": "▶️", "globe": "🌍", "money": "🪙",
    "land": "🪖", "air": "✈️", "naval": "⚓", "missile": "🚀", "plant": "🏭",
    "register": "➕", "license": "📜",
    "gov": "🏛️", "stability": "🛡️", "happy": "😊",
    "barracks": "🏕️", "academy": "🎖️", "command": "🗼",
    "recruit": "🫡", "form": "🎖️", "disband": "🏳️",
    "soldier": "👥", "attack": "⚔️", "armor": "🛡️", "hp": "❤️",
    "ev_social": "👥", "ev_nature": "🌿", "ev_science": "🔬", "ev_diplomacy": "🤝",
    # шпионаж (Этап 1) — юникод-фолбэки до заливки кастом-эмодзи
    "spy": "🕵️", "recon": "🔭", "counterintel": "🛡️", "agent": "🎭", "sweep": "🧹",
    "destab": "✊", "eco_sab": "🏦", "sabotage": "🔧", "theft": "💰",
    "heat": "🔥", "exposed": "🚨",
    # права / !perm — юникод-фолбэки
    "perm": "🔑", "perm_grant": "🔓", "perm_revoke": "🔒", "perm_all": "🌟", "perm_clear": "🧹",
    # админ-инструменты
    "reload": "🔄", "dbreset": "🗑️", "tools": "🛠️",
    # ультиматумы
    "ultimatum": "⏳", "accept": "🤝", "reject": "✖️", "counter": "⚖️", "blockade": "🧱",
    # гайд / новости
    "guide": "📖", "news": "📰",
    # политика: переходы строя
    "legitimacy": "👑", "reform": "📜", "revolution": "🔥", "opposition": "✊",
    # регистрация
    "atomic": "☢️", "population": "👨‍👩‍👧",
    # санкции
    "sanctions": "🔨", "embargo": "📦", "financial": "🧊", "techban": "🖥️", "resilience": "🏰",
    # защита сервера
    "guard": "🛡️", "antispam": "📣", "antinuke": "💥", "antiwebhook": "🔗",
    "antiban": "🔨", "antibot": "🤖", "antirole": "🎭", "raidmode": "🚨",
    "raider": "🏴‍☠️", "restore": "💾",
    # война (Этап 2)
    "war": "⚔️", "war_declare": "📣", "front": "🪖", "offensive": "🗡️",
    "defense_op": "🛡️", "siege": "🏰", "victory": "🏆", "defeat": "💀",
    "peace": "🕊️", "losses": "☠️", "supply": "📦", "warplan": "🗺️", "exhaustion": "😮‍💨",
    # соединения армии — юникод-фолбэки (до заливки кастома)
    "fm_motor_rifle": "🪖", "fm_tank_div": "🛡️", "fm_arty_regt": "💥", "fm_aa_div": "🎯",
    "fm_recon_bn": "🔎", "fm_air_wing": "✈️", "fm_bomber_wing": "🛩️", "fm_heli_regt": "🚁",
    "fm_uav_sqn": "🛸", "fm_flotilla": "🚢", "fm_carrier_group": "⚓", "fm_sub_fleet": "🌊",
    "fm_missile_bde": "🚀",
    # торговля
    "trade": "🔁", "market": "🏪", "buy": "🛒", "sell": "🏷️", "deal": "🤝", "cancel_x": "✖️",
    # дипломатия
    "diplo": "🤝", "relations": "💞", "rel_up": "👍", "rel_down": "👎", "influence": "🪙",
    "treaty": "📜", "nonaggression": "🕊️", "trade_pact": "💱", "alliance": "🛡️",
    "transit": "🚪", "embassy": "🏳️", "reputation": "🎖️", "incident": "⚠️",
    "deescalate": "🧘", "escalate": "🔥", "betrayal": "🗡️", "call_arms": "⚔️", "envelope": "✉️",    # альянсы
    "bloc_mil": "🛡️",
    "bloc_eco": "🏦",
    "charter": "📜",
    "cohesion": "🔗",
    "vote": "🗳️",
    "treasury": "💰",
    "leader": "👑",
    "invite": "🚪",
    "expel": "🥾",
    "leave_bloc": "🚶",
    "split": "💔",
    "ratify": "⏳",
    "joint_command": "🎖️",
    "intel_share": "👁️",
    "customs": "🚧",
    "currency_union": "🪙",
    # атомная программа
    "nuclear": "☢️",
    "physics": "🧪",
    "centrifuge": "🌀",
    "enrich": "⚗️",
    "heu": "🛢️",
    "warhead": "💣",
    "nuke_test": "💥",
    "npt": "🛡️",
    "violator": "☣️",
    "fallout": "😷",
    "launch": "🚀",
    "intercept": "📡",
    "accident": "⚠️",
    "umbrella": "☂️",
    "deterrence": "⚛️",
    "nuke_club": "🏛️",
    "inspect": "🔍",
    "nuke_sab": "🕵️",
    "research": "⏱️",    # ООН
    "un": "🇺🇳",
    "un_condemn": "⚖️",
    "un_aid": "🩹",
    "un_embargo": "🔒",
    "un_sc": "🏛️",
    "veto": "✋",
    "resolution": "📜",
    "un_news": "📰",
    "ga": "🌍",
    "abstain": "⚖️",
    "secgen": "📣",
    "ai_state": "🤖",
    "legacy": "⚜️", "legacy_crown": "👑", "legacy_decline": "🥀",
    # Модерация
    "mod": "🛡️",
    "mod_warn": "⚠️",
    "mod_timeout": "⏳",
    "mod_ban": "🔨",
    "mod_unban": "🔓",
    "purge": "🧹",
    # ЧВК
    "pmc": "🪖",
    "contract": "📄",
    "riot": "🛡️",
    "pmc_target": "🎯",
    "pmc_hire": "⛺",
    "pmc_base": "🏰",
    "black_market": "🕶️",
    "pmc_rating": "🏆",
}
UI_ICONS_CUSTOM: dict[str, str] = {}


def ui_icon(name: str) -> str:
    return UI_ICONS_CUSTOM.get(name) or UI_ICONS.get(name, "")


def _validate():
    """Самопроверка целостности справочника (вызывается при импорте)."""
    for c, deps in DEPOSITS.items():
        for res in deps:
            assert res in RAW_RESOURCES, f"залежь {c}: {res} не сырьё"
    for key, (label, kind, out, cost) in BUILDINGS.items():
        assert kind in ("extract", "factory", "storage", "production"), f"{key}: тип {kind}"
        if kind not in ("storage", "production"):
            assert out in RESOURCES, f"{key}: out {out} неизвестен"
        if kind == "factory":
            assert out in RECIPES, f"{key}: завод для {out} без рецепта"
    for name in RESOURCE_ICONS:
        assert name in RESOURCES, f"иконка для неизвестного ресурса: {name}"
    for mat, inputs in RECIPES.items():
        assert res_tier(mat) is ResTier.MATERIAL, f"рецепт не для материала: {mat}"
        for ing in inputs:
            assert ing in RESOURCES, f"рецепт {mat}: неизвестный ингредиент {ing}"
    for raw in MINE_YIELD:
        assert res_tier(raw) is ResTier.RAW, f"!mine только для сырья: {raw}"
    assert set(RESOURCE_SLUG) == set(RESOURCES), "слаги должны покрывать все ресурсы"
    assert len(set(RESOURCE_SLUG.values())) == len(RESOURCE_SLUG), "слаги должны быть уникальны"


_validate()
