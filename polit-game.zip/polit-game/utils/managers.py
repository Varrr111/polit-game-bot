"""
Менеджеры данных — весь публичный API, который использует cogs/economy.py.

Сигнатуры извлечены из economy.py. Хранилище — SQLite (см. database.py).
"""

import time

import disnake

from .database import UserDB, BaseDB, get_connection
from .objects import (
    CountryObject, PMCObject, RegionObject, TerroristObject, RebelObject,
    CompanyObject, InfrastructureObject, InventoryObject,
)
from .enums import InfrastructureType
from .runtime import get_bot


def _now() -> int:
    return int(time.time())


def _infra_value(infra_type) -> str:
    """Принимает enum InfrastructureType или строку, возвращает строку-колонку."""
    return infra_type.value if isinstance(infra_type, InfrastructureType) else str(infra_type)


# ── Участники экономики ─────────────────────────────────────────────────────
class Countries(UserDB):
    object_class = CountryObject
    table = "countries"


class PMCs(UserDB):
    object_class = PMCObject
    table = "pmcs"


class Regions(UserDB):
    object_class = RegionObject
    table = "regions"


class Terrorists(UserDB):
    object_class = TerroristObject
    table = "terrorists"


class Rebels(UserDB):
    object_class = RebelObject
    table = "rebels"


# ── Инвентарь / лицензии ────────────────────────────────────────────────────
class Items(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS inventory ("
            "owner TEXT, item_name TEXT, amount INTEGER DEFAULT 1, data TEXT DEFAULT '', "
            "PRIMARY KEY (owner, item_name))"
        )
        self._execute(
            "CREATE TABLE IF NOT EXISTS licenses (owner TEXT, license TEXT, "
            "PRIMARY KEY (owner, license))"
        )

    def get_licenses(self, name: str) -> list[str]:
        rows = self._query_all("SELECT license FROM licenses WHERE owner = ?", (name,))
        return [r["license"] for r in rows]

    def add_license(self, name: str, license_: str):
        self._execute("INSERT OR IGNORE INTO licenses (owner, license) VALUES (?, ?)", (name, license_))

    def get_inventory(self, name: str) -> list[InventoryObject]:
        rows = self._query_all("SELECT * FROM inventory WHERE owner = ?", (name,))
        return [InventoryObject(name=r["item_name"], owner=r["owner"], amount=r["amount"]) for r in rows]

    def add_item(self, name: str, item_name: str, amount: int = 1):
        self._execute(
            "INSERT INTO inventory (owner, item_name, amount) VALUES (?, ?, ?) "
            "ON CONFLICT(owner, item_name) DO UPDATE SET amount = amount + ?",
            (name, item_name, amount, amount),
        )


# ── Банк / настройки / ресурсы / кулдауны ──────────────────────────────────
class Settings(BaseDB):
    def _ensure_schema(self):
        self._execute("CREATE TABLE IF NOT EXISTS bank (name TEXT PRIMARY KEY, amount INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS resources (name TEXT, resource TEXT, amount INTEGER DEFAULT 0, "
            "PRIMARY KEY (name, resource))"
        )
        self._execute(
            "CREATE TABLE IF NOT EXISTS collect_cooldown (name TEXT, level_type TEXT, until INTEGER, "
            "PRIMARY KEY (name, level_type))"
        )
        self._execute("CREATE TABLE IF NOT EXISTS work_cooldown (name TEXT PRIMARY KEY, until INTEGER)")

    # банк
    def get_bank(self, name: str) -> int:
        row = self._query_one("SELECT amount FROM bank WHERE name = ?", (name,))
        return row["amount"] if row else 0

    def dep_bank(self, name: str, amount: int):
        self._execute(
            "INSERT INTO bank (name, amount) VALUES (?, ?) "
            "ON CONFLICT(name) DO UPDATE SET amount = amount + ?",
            (name, amount, amount),
        )

    def with_bank(self, name: str, amount: int):
        self._execute("UPDATE bank SET amount = amount - ? WHERE name = ?", (amount, name))

    # ресурсы
    def get_resources(self, name: str) -> dict[str, int]:
        rows = self._query_all("SELECT resource, amount FROM resources WHERE name = ?", (name,))
        return {r["resource"]: r["amount"] for r in rows}

    def add_resource(self, name: str, resource: str, amount: int):
        self._execute(
            "INSERT INTO resources (name, resource, amount) VALUES (?, ?, ?) "
            "ON CONFLICT(name, resource) DO UPDATE SET amount = amount + ?",
            (name, resource, amount, amount),
        )

    # кулдаун коллекта
    def get_collect_cooldown(self, name: str, level_type: str) -> int | None:
        row = self._query_one(
            "SELECT until FROM collect_cooldown WHERE name = ? AND level_type = ?", (name, level_type)
        )
        return row["until"] if row else None

    def update_collect_cooldown(self, name: str, level_type: str, ts: int):
        self._execute(
            "INSERT INTO collect_cooldown (name, level_type, until) VALUES (?, ?, ?) "
            "ON CONFLICT(name, level_type) DO UPDATE SET until = ?",
            (name, level_type, ts, ts),
        )

    # кулдаун работы
    def get_work_cooldown(self, name: str) -> int | None:
        row = self._query_one("SELECT until FROM work_cooldown WHERE name = ?", (name,))
        return row["until"] if row else None

    def update_work_cooldown(self, name: str, ts: int):
        self._execute(
            "INSERT INTO work_cooldown (name, until) VALUES (?, ?) "
            "ON CONFLICT(name) DO UPDATE SET until = ?",
            (name, ts, ts),
        )


# ── Развитие страны (уровни веток, без ролей) ──────────────────────────────
class CountryUpgrades(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS country_upgrades (name TEXT, branch TEXT, "
            "level INTEGER DEFAULT 0, PRIMARY KEY (name, branch))"
        )

    def get_levels(self, name: str) -> dict[str, int]:
        rows = self._query_all("SELECT branch, level FROM country_upgrades WHERE name = ?", (name,))
        return {r["branch"]: r["level"] for r in rows if r["level"] > 0}

    def get_level(self, name: str, branch: str) -> int:
        row = self._query_one("SELECT level FROM country_upgrades WHERE name = ? AND branch = ?", (name, branch))
        return row["level"] if row else 0

    def set_level(self, name: str, branch: str, level: int):
        self._execute(
            "INSERT INTO country_upgrades (name, branch, level) VALUES (?, ?, ?) "
            "ON CONFLICT(name, branch) DO UPDATE SET level = ?",
            (name, branch, level, level),
        )


# ── Мировая биржа ресурсов (динамические цены) ─────────────────────────────
class Market(BaseDB):
    def _ensure_schema(self):
        self._execute("CREATE TABLE IF NOT EXISTS market (resource TEXT PRIMARY KEY, factor REAL DEFAULT 1.0)")

    def get_factor(self, resource: str) -> float:
        row = self._query_one("SELECT factor FROM market WHERE resource = ?", (resource,))
        return row["factor"] if row else 1.0

    def set_factor(self, resource: str, factor: float):
        factor = max(0.3, min(3.0, factor))
        self._execute(
            "INSERT INTO market (resource, factor) VALUES (?, ?) "
            "ON CONFLICT(resource) DO UPDATE SET factor = ?",
            (resource, factor, factor),
        )

    def all_factors(self) -> dict[str, float]:
        rows = self._query_all("SELECT resource, factor FROM market")
        return {r["resource"]: r["factor"] for r in rows}


# ── Войны ───────────────────────────────────────────────────────────────────
class Wars(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS wars ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, attacker TEXT, defender TEXT, "
            "started_at INTEGER, status TEXT DEFAULT 'active')"
        )

    def get_wars_by_country(self, name: str):
        """Возвращает первую активную войну страны или None."""
        return self._query_one(
            "SELECT * FROM wars WHERE status = 'active' AND (attacker = ? OR defender = ?)",
            (name, name),
        )


# ── Компании ────────────────────────────────────────────────────────────────
class Companies(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS companies ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, country TEXT, "
            "specialization TEXT, level INTEGER DEFAULT 1)"
        )

    def get_companies(self, country: str) -> list[CompanyObject]:
        rows = self._query_all("SELECT * FROM companies WHERE country = ?", (country,))
        return [CompanyObject(name=r["name"], country=r["country"],
                              specialization=r["specialization"], level=r["level"]) for r in rows]

    def get_company(self, country: str, name: str) -> CompanyObject | None:
        row = self._query_one("SELECT * FROM companies WHERE country = ? AND name = ?", (country, name))
        if not row:
            return None
        return CompanyObject(name=row["name"], country=row["country"],
                             specialization=row["specialization"], level=row["level"])

    def create_company(self, name: str, country: str, specialization: str) -> CompanyObject:
        self._execute(
            "INSERT INTO companies (name, country, specialization, level) VALUES (?, ?, ?, 1)",
            (name, country, specialization),
        )
        return CompanyObject(name=name, country=country, specialization=specialization, level=1)

    def get_company_count_by_specialization(self, country: str, specialization: str) -> int:
        row = self._query_one(
            "SELECT COUNT(*) AS c FROM companies WHERE country = ? AND specialization = ?",
            (country, specialization),
        )
        return row["c"] if row else 0

    def delete_company(self, country: str, name: str):
        self._execute("DELETE FROM companies WHERE country = ? AND name = ?", (country, name))

    def update_company(self, country: str, old_name: str, new_name: str, level: int):
        self._execute(
            "UPDATE companies SET name = ?, level = ? WHERE country = ? AND name = ?",
            (new_name, level, country, old_name),
        )
        return self.get_company(country, new_name)


# ── Инфраструктура ──────────────────────────────────────────────────────────
class Infrastructure(BaseDB):
    _COLS = ("chp", "atomic", "hps1", "hps2", "hps3", "hps4")

    def _ensure_schema(self):
        cols = ", ".join(f"{c} INTEGER DEFAULT 0" for c in self._COLS)
        self._execute(f"CREATE TABLE IF NOT EXISTS infrastructure (name TEXT PRIMARY KEY, {cols})")

    def get_infrastructure(self, name: str) -> InfrastructureObject | None:
        row = self._query_one("SELECT * FROM infrastructure WHERE name = ?", (name,))
        if not row:
            return None
        return InfrastructureObject(name=name, **{c: row[c] for c in self._COLS})

    def create_infrastructure(self, name: str, infra_type):
        col = _infra_value(infra_type)
        if col not in self._COLS:
            return
        self._execute(
            f"INSERT INTO infrastructure (name, {col}) VALUES (?, 1) "
            f"ON CONFLICT(name) DO UPDATE SET {col} = {col} + 1",
            (name,),
        )


# ── Здания (добыча/переработка ресурсов) ────────────────────────────────────
class Buildings(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS buildings (name TEXT, building TEXT, "
            "count INTEGER DEFAULT 0, PRIMARY KEY (name, building))"
        )
        self._execute(
            "CREATE TABLE IF NOT EXISTS building_levels (name TEXT, building TEXT, "
            "level INTEGER DEFAULT 1, PRIMARY KEY (name, building))"
        )

    def get_buildings(self, name: str) -> dict[str, int]:
        rows = self._query_all("SELECT building, count FROM buildings WHERE name = ?", (name,))
        return {r["building"]: r["count"] for r in rows if r["count"] > 0}

    def get_count(self, name: str, building: str) -> int:
        row = self._query_one("SELECT count FROM buildings WHERE name = ? AND building = ?", (name, building))
        return row["count"] if row else 0

    def add_building(self, name: str, building: str, n: int = 1):
        self._execute(
            "INSERT INTO buildings (name, building, count) VALUES (?, ?, ?) "
            "ON CONFLICT(name, building) DO UPDATE SET count = count + ?",
            (name, building, n, n),
        )

    def get_level(self, name: str, building: str) -> int:
        row = self._query_one("SELECT level FROM building_levels WHERE name = ? AND building = ?", (name, building))
        return row["level"] if row else 1

    def set_level(self, name: str, building: str, level: int):
        self._execute(
            "INSERT INTO building_levels (name, building, level) VALUES (?, ?, ?) "
            "ON CONFLICT(name, building) DO UPDATE SET level = ?",
            (name, building, level, level),
        )

    def get_all_levels(self, name: str) -> dict[str, int]:
        rows = self._query_all("SELECT building, level FROM building_levels WHERE name = ?", (name,))
        return {r["building"]: r["level"] for r in rows}

    def cleanup_orphans(self, valid_keys: list[str]):
        """Удаляет постройки, которых больше нет в справочнике (после рефакторов)."""
        if not valid_keys:
            return
        ph = ",".join("?" * len(valid_keys))
        self._execute(f"DELETE FROM buildings WHERE building NOT IN ({ph})", tuple(valid_keys))
        self._execute(f"DELETE FROM building_levels WHERE building NOT IN ({ph})", tuple(valid_keys))


# ── Распределение мощности заводов по рудам (веса) ──────────────────────────
class Allocation(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS allocation (name TEXT, resource TEXT, "
            "weight INTEGER DEFAULT 0, PRIMARY KEY (name, resource))"
        )

    def get_weights(self, name: str) -> dict[str, int]:
        rows = self._query_all("SELECT resource, weight FROM allocation WHERE name = ?", (name,))
        return {r["resource"]: r["weight"] for r in rows if r["weight"] > 0}

    def add_weight(self, name: str, resource: str, delta: int):
        self._execute(
            "INSERT INTO allocation (name, resource, weight) VALUES (?, ?, ?) "
            "ON CONFLICT(name, resource) DO UPDATE SET weight = MAX(0, weight + ?)",
            (name, resource, max(0, delta), delta),
        )

    def reset(self, name: str):
        self._execute("DELETE FROM allocation WHERE name = ?", (name,))


# ── Новости (прогресс строек/фестивалей) ───────────────────────────────────
class BuildNews(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS build_news ("
            "name TEXT, build_type TEXT, count INTEGER DEFAULT 0, last_ts INTEGER DEFAULT 0, "
            "PRIMARY KEY (name, build_type))"
        )

    def get_build(self, name: str, build_type: str) -> tuple[int, int]:
        build_type = _infra_value(build_type)
        row = self._query_one(
            "SELECT count, last_ts FROM build_news WHERE name = ? AND build_type = ?",
            (name, build_type),
        )
        return (row["count"], row["last_ts"]) if row else (0, 0)

    def update_news(self, name: str, build_type: str, inc: int):
        build_type = _infra_value(build_type)
        now = _now()
        self._execute(
            "INSERT INTO build_news (name, build_type, count, last_ts) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(name, build_type) DO UPDATE SET count = count + ?, last_ts = ?",
            (name, build_type, inc, now, inc, now),
        )

    def reset_news(self, name: str, build_type: str):
        build_type = _infra_value(build_type)
        self._execute("DELETE FROM build_news WHERE name = ? AND build_type = ?", (name, build_type))


# ── Произвольные кулдауны ───────────────────────────────────────────────────
class Cooldown(BaseDB):
    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS cooldowns (key TEXT, name TEXT, until REAL, "
            "PRIMARY KEY (key, name))"
        )

    def get_cooldown(self, key, name: str) -> float:
        key = _infra_value(key)
        row = self._query_one("SELECT until FROM cooldowns WHERE key = ? AND name = ?", (key, name))
        return row["until"] if row else 0.0

    def set_cooldown(self, key, until_ts: float, name: str):
        key = _infra_value(key)
        self._execute(
            "INSERT INTO cooldowns (key, name, until) VALUES (?, ?, ?) "
            "ON CONFLICT(key, name) DO UPDATE SET until = ?",
            (key, name, until_ts, until_ts),
        )


# ── Логирование в канал ─────────────────────────────────────────────────────
class Logging:
    """Отправка служебных логов в LOG_CHANNEL. Безопасна офлайн (no-op)."""

    async def _send(self, title: str, description: str, color: int):
        bot = get_bot()
        from config import LOG_CHANNEL
        if not bot or not LOG_CHANNEL:
            return
        channel = bot.get_channel(LOG_CHANNEL)
        if channel is None:
            return
        try:
            await channel.send(embed=disnake.Embed(title=title, description=description, color=color))
        except Exception:
            pass

    async def message(self, title: str, description: str):
        from config import COMMAND_COLOR
        await self._send(title, description, COMMAND_COLOR)

    async def success(self, title: str, description: str):
        from config import SUCCESS_COLOR
        await self._send(title, description, SUCCESS_COLOR)


class Equipment(BaseDB):
    """Именная техника стран: реестр образцов, лицензии и арсенал (склад)."""

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS equipment ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, category TEXT, "
            "cls TEXT, owner TEXT, created_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS equipment_licenses ("
            "equipment_id INTEGER, country TEXT, PRIMARY KEY (equipment_id, country))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS equipment_stock ("
            "country TEXT, equipment_id INTEGER, count INTEGER DEFAULT 0, "
            "PRIMARY KEY (country, equipment_id))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS license_offers ("
            "equipment_id INTEGER, buyer TEXT, price INTEGER, created_at INTEGER, "
            "PRIMARY KEY (equipment_id, buyer))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS equipment_plants ("
            "country TEXT, domain TEXT, count INTEGER DEFAULT 0, "
            "PRIMARY KEY (country, domain))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS production_queue ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, equipment_id INTEGER, "
            "count INTEGER, started_at INTEGER, ready_at INTEGER)")

    # ── реестр образцов ──
    def name_taken(self, name: str) -> bool:
        return self._query_one("SELECT 1 FROM equipment WHERE name = ? COLLATE NOCASE", (name,)) is not None

    def register(self, name: str, category: str, cls: str, owner: str, created_at: int) -> int | None:
        if self.name_taken(name):
            return None
        self._execute(
            "INSERT INTO equipment (name, category, cls, owner, created_at) VALUES (?, ?, ?, ?, ?)",
            (name, category, cls, owner, created_at))
        row = self._query_one("SELECT id FROM equipment WHERE name = ?", (name,))
        eid = row["id"] if row else None
        if eid:
            self.grant_license(eid, owner)  # владелец всегда лицензирован
        return eid

    def get(self, equipment_id: int):
        return self._query_one("SELECT * FROM equipment WHERE id = ?", (equipment_id,))

    def get_by_name(self, name: str):
        return self._query_one("SELECT * FROM equipment WHERE name = ? COLLATE NOCASE", (name,))

    def by_owner(self, owner: str):
        return self._query_all("SELECT * FROM equipment WHERE owner = ? ORDER BY name", (owner,))

    def count_owned(self, owner: str) -> int:
        r = self._query_one("SELECT COUNT(*) AS c FROM equipment WHERE owner = ?", (owner,))
        return r["c"] if r else 0

    def remove(self, equipment_id: int):
        self._execute("DELETE FROM equipment WHERE id = ?", (equipment_id,))
        for t in ("equipment_licenses", "equipment_stock", "license_offers", "production_queue"):
            self._execute(f"DELETE FROM {t} WHERE equipment_id = ?", (equipment_id,))

    # ── лицензии ──
    def grant_license(self, equipment_id: int, country: str):
        self._execute("INSERT OR IGNORE INTO equipment_licenses (equipment_id, country) VALUES (?, ?)",
                      (equipment_id, country))

    def has_license(self, equipment_id: int, country: str) -> bool:
        return self._query_one(
            "SELECT 1 FROM equipment_licenses WHERE equipment_id = ? AND country = ?",
            (equipment_id, country)) is not None

    def licensees(self, equipment_id: int) -> list[str]:
        return [r["country"] for r in self._query_all(
            "SELECT country FROM equipment_licenses WHERE equipment_id = ?", (equipment_id,))]

    def producible(self, country: str):
        """Образцы, которые страна может производить (владеет или есть лицензия)."""
        return self._query_all(
            "SELECT e.* FROM equipment e JOIN equipment_licenses l ON l.equipment_id = e.id "
            "WHERE l.country = ? ORDER BY e.name", (country,))

    # ── офферы лицензий ──
    def add_offer(self, equipment_id: int, buyer: str, price: int, created_at: int):
        self._execute(
            "INSERT INTO license_offers (equipment_id, buyer, price, created_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(equipment_id, buyer) DO UPDATE SET price = ?, created_at = ?",
            (equipment_id, buyer, price, created_at, price, created_at))

    def offers_for(self, buyer: str):
        return self._query_all(
            "SELECT o.equipment_id, o.price, e.name, e.owner, e.category, e.cls "
            "FROM license_offers o JOIN equipment e ON e.id = o.equipment_id WHERE o.buyer = ?", (buyer,))

    def get_offer(self, equipment_id: int, buyer: str):
        return self._query_one(
            "SELECT * FROM license_offers WHERE equipment_id = ? AND buyer = ?", (equipment_id, buyer))

    def delete_offer(self, equipment_id: int, buyer: str):
        self._execute("DELETE FROM license_offers WHERE equipment_id = ? AND buyer = ?", (equipment_id, buyer))

    # ── арсенал (склад техники) ──
    def add_stock(self, country: str, equipment_id: int, count: int):
        self._execute(
            "INSERT INTO equipment_stock (country, equipment_id, count) VALUES (?, ?, ?) "
            "ON CONFLICT(country, equipment_id) DO UPDATE SET count = count + ?",
            (country, equipment_id, count, count))

    def arsenal(self, country: str):
        return self._query_all(
            "SELECT s.count, e.* FROM equipment_stock s JOIN equipment e ON e.id = s.equipment_id "
            "WHERE s.country = ? AND s.count > 0 ORDER BY e.name", (country,))

    # ── заводы (по родам войск) ──
    def get_plants(self, country: str) -> dict[str, int]:
        rows = self._query_all("SELECT domain, count FROM equipment_plants WHERE country = ?", (country,))
        return {r["domain"]: r["count"] for r in rows}

    def plant_count(self, country: str, domain: str) -> int:
        r = self._query_one("SELECT count FROM equipment_plants WHERE country = ? AND domain = ?", (country, domain))
        return r["count"] if r else 0

    def add_plant(self, country: str, domain: str, n: int = 1):
        self._execute(
            "INSERT INTO equipment_plants (country, domain, count) VALUES (?, ?, ?) "
            "ON CONFLICT(country, domain) DO UPDATE SET count = count + ?",
            (country, domain, n, n))

    # ── очередь производства ──
    def queue_add(self, country: str, equipment_id: int, count: int, started_at: int, ready_at: int):
        self._execute(
            "INSERT INTO production_queue (country, equipment_id, count, started_at, ready_at) "
            "VALUES (?, ?, ?, ?, ?)", (country, equipment_id, count, started_at, ready_at))

    def queue_for(self, country: str):
        return self._query_all(
            "SELECT q.id, q.count, q.ready_at, e.* FROM production_queue q "
            "JOIN equipment e ON e.id = q.equipment_id WHERE q.country = ? ORDER BY q.ready_at", (country,))

    def queue_ready(self, now_ts: int):
        return self._query_all("SELECT * FROM production_queue WHERE ready_at <= ?", (now_ts,))

    def queue_remove(self, queue_id: int):
        self._execute("DELETE FROM production_queue WHERE id = ?", (queue_id,))

    # ── для ЧВК: рынок моделей стран ──
    def market_rows(self, categories: list[str]):
        """Модели на складах стран (свободный резерв), доступные к продаже ЧВК."""
        q = ",".join("?" for _ in categories) or "''"
        return self._query_all(
            f"SELECT s.country, s.count, e.* FROM equipment_stock s JOIN equipment e ON e.id = s.equipment_id "
            f"WHERE s.count > 0 AND e.category IN ({q}) ORDER BY e.name", tuple(categories))

    def stock_of(self, country: str, equipment_id: int) -> int:
        r = self._query_one("SELECT count FROM equipment_stock WHERE country = ? AND equipment_id = ?",
                            (country, equipment_id))
        return int(r["count"]) if r else 0

    def all_models(self, categories: list[str]):
        q = ",".join("?" for _ in categories) or "''"
        return self._query_all(f"SELECT * FROM equipment WHERE category IN ({q})", tuple(categories))

    # ── арсенал по категориям (для армии) ──
    def category_counts(self, country: str) -> dict[str, int]:
        rows = self._query_all(
            "SELECT e.category AS cat, SUM(s.count) AS c FROM equipment_stock s "
            "JOIN equipment e ON e.id = s.equipment_id WHERE s.country = ? AND s.count > 0 "
            "GROUP BY e.category", (country,))
        return {r["cat"]: r["c"] for r in rows}

    def take_category(self, country: str, category: str, count: int):
        """Снимает count единиц категории из арсенала (по моделям). → [(equipment_id, n)] или None."""
        rows = self._query_all(
            "SELECT s.equipment_id AS eid, s.count AS c FROM equipment_stock s "
            "JOIN equipment e ON e.id = s.equipment_id "
            "WHERE s.country = ? AND e.category = ? AND s.count > 0 ORDER BY s.count DESC",
            (country, category))
        if sum(r["c"] for r in rows) < count:
            return None
        taken, need = [], count
        for r in rows:
            if need <= 0:
                break
            t = min(need, r["c"])
            self.add_stock(country, r["eid"], -t)
            taken.append((r["eid"], t))
            need -= t
        return taken


class Army(BaseDB):
    """Армия: военные здания, личный состав и соединения (со слаживанием)."""

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS army_buildings ("
            "country TEXT, kind TEXT, count INTEGER DEFAULT 0, PRIMARY KEY (country, kind))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS manpower (country TEXT PRIMARY KEY, pool INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS formations ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, template TEXT, "
            "personnel INTEGER, ready_at INTEGER, created_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS formation_equipment ("
            "formation_id INTEGER, equipment_id INTEGER, count INTEGER)")

    # ── здания ──
    def get_buildings(self, country: str) -> dict[str, int]:
        rows = self._query_all("SELECT kind, count FROM army_buildings WHERE country = ?", (country,))
        return {r["kind"]: r["count"] for r in rows}

    def building_count(self, country: str, kind: str) -> int:
        r = self._query_one("SELECT count FROM army_buildings WHERE country = ? AND kind = ?", (country, kind))
        return r["count"] if r else 0

    def add_building(self, country: str, kind: str, n: int = 1):
        self._execute(
            "INSERT INTO army_buildings (country, kind, count) VALUES (?, ?, ?) "
            "ON CONFLICT(country, kind) DO UPDATE SET count = count + ?", (country, kind, n, n))

    # ── личный состав ──
    def get_pool(self, country: str) -> int:
        r = self._query_one("SELECT pool FROM manpower WHERE country = ?", (country,))
        return r["pool"] if r else 0

    def add_pool(self, country: str, delta: int):
        self._execute(
            "INSERT INTO manpower (country, pool) VALUES (?, ?) "
            "ON CONFLICT(country) DO UPDATE SET pool = pool + ?", (country, delta, delta))

    # ── соединения ──
    def add_formation(self, country: str, template: str, personnel: int, ready_at: int, created_at: int) -> int:
        self._execute(
            "INSERT INTO formations (country, template, personnel, ready_at, created_at) VALUES (?, ?, ?, ?, ?)",
            (country, template, personnel, ready_at, created_at))
        r = self._query_one("SELECT MAX(id) AS id FROM formations WHERE country = ?", (country,))
        return r["id"] if r else 0

    def formations_for(self, country: str):
        return self._query_all("SELECT * FROM formations WHERE country = ? ORDER BY ready_at", (country,))

    def get_formation(self, fid: int):
        return self._query_one("SELECT * FROM formations WHERE id = ?", (fid,))

    def count_formations(self, country: str) -> int:
        r = self._query_one("SELECT COUNT(*) AS c FROM formations WHERE country = ?", (country,))
        return r["c"] if r else 0

    def add_formation_equipment(self, fid: int, equipment_id: int, count: int):
        self._execute("INSERT INTO formation_equipment (formation_id, equipment_id, count) VALUES (?, ?, ?)",
                      (fid, equipment_id, count))

    def formation_equipment(self, fid: int):
        return self._query_all("SELECT equipment_id, count FROM formation_equipment WHERE formation_id = ?", (fid,))

    def remove_formation(self, fid: int):
        self._execute("DELETE FROM formations WHERE id = ?", (fid,))
        self._execute("DELETE FROM formation_equipment WHERE formation_id = ?", (fid,))

    def damage_formation(self, fid: int, frac: float, lost: dict | None = None) -> bool:
        """Наносит соединению потери (доля frac л/с и техники). Возвращает True,
        если соединение разбито (личный состав упал почти до нуля — удаляется).
        lost — если передан, сюда копится потерянная техника {equipment_id: шт} (трофеи)."""
        frac = max(0.0, min(1.0, frac))
        row = self.get_formation(fid)
        if not row:
            return False
        for e in self.formation_equipment(fid):
            left = max(0, int(e["count"] * (1 - frac)))
            if lost is not None and (e["count"] or 0) > left:
                lost[e["equipment_id"]] = lost.get(e["equipment_id"], 0) + (e["count"] - left)
            self._execute(
                "UPDATE formation_equipment SET count = ? WHERE formation_id = ? AND equipment_id = ?",
                (left, fid, e["equipment_id"]))
        new_p = int((row["personnel"] or 0) * (1 - frac))
        if new_p < max(1, int((row["personnel"] or 0) * 0.10)):   # разбито (<10% л/с)
            self.remove_formation(fid)
            return True
        self._execute("UPDATE formations SET personnel = ? WHERE id = ?", (new_p, fid))
        return False


class Politics(BaseDB):
    """Строй и религия страны (счастье/стабильность — в countries). Плюс
    легитимность, оппозиция и состояние политического перехода (реформа/революция)."""

    # новые колонки (миграция старой 3-колоночной таблицы): имя -> определение
    _EXTRA_COLS = {
        "legitimacy": "REAL DEFAULT 50",
        "opposition": "REAL DEFAULT 0",
        "transition_to": "TEXT DEFAULT ''",
        "transition_until": "INTEGER DEFAULT 0",
        "transition_type": "TEXT DEFAULT ''",
    }

    def _ensure_schema(self):
        cols = ", ".join(f"{c} {d}" for c, d in self._EXTRA_COLS.items())
        self._execute(
            "CREATE TABLE IF NOT EXISTS politics ("
            "name TEXT PRIMARY KEY, ideology TEXT DEFAULT 'none', "
            f"religion TEXT DEFAULT 'secular', {cols})")
        # миграция существующих БД: добавить недостающие колонки
        for c, d in self._EXTRA_COLS.items():
            try:
                self._execute(f"ALTER TABLE politics ADD COLUMN {c} {d}")
            except Exception:
                pass  # колонка уже есть

    def _ensure_row(self, name: str):
        self._execute("INSERT OR IGNORE INTO politics (name, ideology, religion) VALUES (?, 'none', 'secular')", (name,))

    def get(self, name: str) -> tuple[str, str]:
        row = self._query_one("SELECT ideology, religion FROM politics WHERE name = ?", (name,))
        if not row:
            return "none", "secular"
        return row["ideology"] or "none", row["religion"] or "secular"

    def get_state(self, name: str) -> dict:
        row = self._query_one("SELECT * FROM politics WHERE name = ?", (name,))
        if not row:
            return {"ideology": "none", "religion": "secular", "legitimacy": 50.0,
                    "opposition": 0.0, "transition_to": "", "transition_until": 0,
                    "transition_type": ""}
        return {
            "ideology": row["ideology"] or "none",
            "religion": row["religion"] or "secular",
            "legitimacy": row["legitimacy"] if row["legitimacy"] is not None else 50.0,
            "opposition": row["opposition"] if row["opposition"] is not None else 0.0,
            "transition_to": row["transition_to"] or "",
            "transition_until": row["transition_until"] or 0,
            "transition_type": row["transition_type"] or "",
        }

    def set_ideology(self, name: str, ideology: str):
        self._ensure_row(name)
        self._execute("UPDATE politics SET ideology = ? WHERE name = ?", (ideology, name))

    def set_religion(self, name: str, religion: str):
        self._ensure_row(name)
        self._execute("UPDATE politics SET religion = ? WHERE name = ?", (religion, name))

    def set_legitimacy(self, name: str, value: float):
        self._ensure_row(name)
        self._execute("UPDATE politics SET legitimacy = ? WHERE name = ?", (max(0.0, min(100.0, value)), name))

    def set_opposition(self, name: str, value: float):
        self._ensure_row(name)
        self._execute("UPDATE politics SET opposition = ? WHERE name = ?", (max(0.0, min(100.0, value)), name))

    def start_transition(self, name: str, to: str, until: int, ttype: str):
        self._ensure_row(name)
        self._execute("UPDATE politics SET transition_to = ?, transition_until = ?, transition_type = ? WHERE name = ?",
                      (to, until, ttype, name))

    def clear_transition(self, name: str):
        self._execute("UPDATE politics SET transition_to = '', transition_until = 0, transition_type = '' WHERE name = ?",
                      (name,))


class Effects(BaseDB):
    """Временные эффекты событий (баффы/дебафы с истечением), напр. множитель дохода."""

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS country_effects ("
            "country TEXT, kind TEXT, value REAL, expires_at INTEGER)")

    def add(self, country: str, kind: str, value: float, expires_at: int):
        self._execute("INSERT INTO country_effects (country, kind, value, expires_at) VALUES (?, ?, ?, ?)",
                      (country, kind, value, expires_at))

    def active(self, country: str, now: int):
        return self._query_all(
            "SELECT kind, value, expires_at FROM country_effects WHERE country = ? AND expires_at > ?",
            (country, now))

    def income_mult(self, country: str, now: int) -> float:
        rows = self._query_all(
            "SELECT value FROM country_effects WHERE country = ? AND kind = 'income_mult' AND expires_at > ?",
            (country, now))
        m = 1.0
        for r in rows:
            m *= r["value"]
        return round(m, 4)

    def cleanup(self, now: int):
        self._execute("DELETE FROM country_effects WHERE expires_at <= ?", (now,))


class MapState(BaseDB):
    """Состояние карты мира: канал/сообщение для авто-обновления + оверрайды
    владения территориями (Этап 2 — война). На Этапе 1 оверрайдов нет."""

    def _ensure_schema(self):
        self._execute("CREATE TABLE IF NOT EXISTS map_config (key TEXT PRIMARY KEY, value TEXT)")
        self._execute("CREATE TABLE IF NOT EXISTS map_territories ("
                      "region TEXT PRIMARY KEY, owner TEXT)")
        # ОККУПАЦИЯ (временно, во время войны): регион -> кто оккупировал (красный+полоски)
        self._execute("CREATE TABLE IF NOT EXISTS map_occupation ("
                      "region TEXT PRIMARY KEY, occupier TEXT)")

    # — конфиг (канал/сообщение) —
    def _get(self, key: str) -> str | None:
        row = self._query_one("SELECT value FROM map_config WHERE key = ?", (key,))
        return row["value"] if row else None

    def _set(self, key: str, value: str | None):
        if value is None:
            self._execute("DELETE FROM map_config WHERE key = ?", (key,))
        else:
            self._execute("INSERT OR REPLACE INTO map_config (key, value) VALUES (?, ?)", (key, value))

    def get_channel_id(self) -> int | None:
        v = self._get("channel_id")
        return int(v) if v else None

    def get_message_id(self) -> int | None:
        v = self._get("message_id")
        return int(v) if v else None

    def set_location(self, channel_id: int | None, message_id: int | None):
        self._set("channel_id", str(channel_id) if channel_id else None)
        self._set("message_id", str(message_id) if message_id else None)

    # — оверрайды владения (регион_A3 -> владелец_A3), Этап 2 —
    def overrides(self) -> dict[str, str]:
        return {r["region"]: r["owner"] for r in self._query_all("SELECT region, owner FROM map_territories")}

    def set_owner(self, region: str, owner: str):
        self._execute("INSERT OR REPLACE INTO map_territories (region, owner) VALUES (?, ?)", (region, owner))

    def reset_region(self, region: str):
        self._execute("DELETE FROM map_territories WHERE region = ?", (region,))

    # — оккупация (временный военный контроль: красный + полоски на карте) —
    def occupations(self) -> dict[str, str]:
        return {r["region"]: r["occupier"]
                for r in self._query_all("SELECT region, occupier FROM map_occupation")}

    def set_occupied(self, region: str, occupier: str):
        self._execute("INSERT OR REPLACE INTO map_occupation (region, occupier) VALUES (?, ?)",
                      (region, occupier))

    def clear_occupied(self, region: str):
        self._execute("DELETE FROM map_occupation WHERE region = ?", (region,))

    def occupied_by(self, occupier: str) -> list[str]:
        return [r["region"] for r in self._query_all(
            "SELECT region FROM map_occupation WHERE occupier = ?", (occupier,))]


class News(BaseDB):
    """Учёт мировых новостей: активность страны (для авто-снятия по простою)
    и журнал публикаций (для лимита N в сутки)."""

    def _ensure_schema(self):
        self._execute("CREATE TABLE IF NOT EXISTS news_activity (country TEXT PRIMARY KEY, last_ts INTEGER)")
        self._execute("CREATE TABLE IF NOT EXISTS news_log (country TEXT, ts INTEGER, message_id INTEGER)")

    def touch(self, country: str, ts: int, message_id: int | None = None, log: bool = True):
        self._execute("INSERT OR REPLACE INTO news_activity (country, last_ts) VALUES (?, ?)", (country, ts))
        if log:
            self._execute("INSERT INTO news_log (country, ts, message_id) VALUES (?, ?, ?)",
                          (country, ts, message_id))

    def count_since(self, country: str, since_ts: int) -> int:
        row = self._query_one("SELECT COUNT(*) AS c FROM news_log WHERE country = ? AND ts >= ?",
                              (country, since_ts))
        return row["c"] if row else 0

    def last_ts(self, country: str) -> int | None:
        row = self._query_one("SELECT last_ts FROM news_activity WHERE country = ?", (country,))
        return row["last_ts"] if row else None

    def all_activity(self) -> list[tuple[str, int]]:
        return [(r["country"], r["last_ts"]) for r in
                self._query_all("SELECT country, last_ts FROM news_activity")]

    def clear_country(self, country: str):
        self._execute("DELETE FROM news_activity WHERE country = ?", (country,))
        self._execute("DELETE FROM news_log WHERE country = ?", (country,))


class ServerConfig(BaseDB):
    """Хранилище ID ролей/каналов и игровых настроек, созданных !setupserver.
    Позволяет боту подставлять свежие ID без правки config.py (см. serverconfig.rid)."""

    def _ensure_schema(self):
        self._execute("CREATE TABLE IF NOT EXISTS server_config (key TEXT PRIMARY KEY, value TEXT)")

    def get_raw(self, key: str) -> str | None:
        row = self._query_one("SELECT value FROM server_config WHERE key = ?", (key,))
        return row["value"] if row else None

    def get_int(self, key: str) -> int | None:
        v = self.get_raw(key)
        try:
            return int(v) if v is not None else None
        except (TypeError, ValueError):
            return None

    def set(self, key: str, value):
        self._execute("INSERT OR REPLACE INTO server_config (key, value) VALUES (?, ?)", (key, str(value)))

    def all(self) -> dict[str, str]:
        return {r["key"]: r["value"] for r in self._query_all("SELECT key, value FROM server_config")}


class Spy(BaseDB):
    """Шпионаж (Этап 1): разведслужба страны, агенты, накал и журнал инцидентов.

    Таблицы:
      • spy_agency    — уровни recon/counter на страну
      • spy_agents    — агенты (ранг + специализация)
      • spy_heat      — накал атакующего (значение + момент пересчёта, остывает)
      • spy_incidents — журнал всех операций (для зачистки, casus belli, ленты
                        разоблачений). revealed=1 → раскрыт публично.
    Все числа/клампы считаются в utils.spy; здесь только хранилище.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS spy_agency ("
            "country TEXT PRIMARY KEY, recon INTEGER DEFAULT 0, counter INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS spy_agents ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, spec TEXT, "
            "rank INTEGER DEFAULT 1, created_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS spy_heat ("
            "country TEXT PRIMARY KEY, heat REAL DEFAULT 0, updated_at INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS spy_incidents ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, target TEXT, op TEXT, "
            "ts INTEGER, success INTEGER DEFAULT 0, revealed INTEGER DEFAULT 0)")

    # ── разведслужба (уровни) ──
    def get_agency(self, country: str) -> tuple[int, int]:
        row = self._query_one("SELECT recon, counter FROM spy_agency WHERE country = ?", (country,))
        return (row["recon"], row["counter"]) if row else (0, 0)

    def _ensure_agency(self, country: str):
        self._execute("INSERT OR IGNORE INTO spy_agency (country, recon, counter) VALUES (?, 0, 0)",
                      (country,))

    def set_recon(self, country: str, level: int):
        self._ensure_agency(country)
        self._execute("UPDATE spy_agency SET recon = ? WHERE country = ?", (max(0, level), country))

    def set_counter(self, country: str, level: int):
        self._ensure_agency(country)
        self._execute("UPDATE spy_agency SET counter = ? WHERE country = ?", (max(0, level), country))

    # ── агенты ──
    def add_agent(self, country: str, spec: str, rank: int, now: int) -> int:
        self._execute(
            "INSERT INTO spy_agents (country, spec, rank, created_at) VALUES (?, ?, ?, ?)",
            (country, spec, max(1, rank), now))
        r = self._query_one("SELECT MAX(id) AS id FROM spy_agents WHERE country = ?", (country,))
        return r["id"] if r else 0

    def agents(self, country: str) -> list:
        return self._query_all("SELECT * FROM spy_agents WHERE country = ? ORDER BY rank DESC, id", (country,))

    def agents_by_spec(self, country: str, spec: str) -> list:
        return self._query_all(
            "SELECT * FROM spy_agents WHERE country = ? AND spec = ? ORDER BY rank DESC, id",
            (country, spec))

    def get_agent(self, agent_id: int):
        return self._query_one("SELECT * FROM spy_agents WHERE id = ?", (agent_id,))

    def count_agents(self, country: str) -> int:
        r = self._query_one("SELECT COUNT(*) AS c FROM spy_agents WHERE country = ?", (country,))
        return r["c"] if r else 0

    def remove_agent(self, agent_id: int):
        self._execute("DELETE FROM spy_agents WHERE id = ?", (agent_id,))

    # ── накал (heat) ──
    def get_heat_raw(self, country: str) -> tuple[float, int]:
        row = self._query_one("SELECT heat, updated_at FROM spy_heat WHERE country = ?", (country,))
        return (row["heat"], row["updated_at"]) if row else (0.0, 0)

    def set_heat(self, country: str, heat: float, now: int):
        self._execute(
            "INSERT INTO spy_heat (country, heat, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(country) DO UPDATE SET heat = ?, updated_at = ?",
            (country, max(0.0, heat), now, max(0.0, heat), now))

    # ── инциденты (журнал операций) ──
    def log_incident(self, actor: str, target: str, op: str, ts: int,
                     success: bool, revealed: bool = False) -> int:
        self._execute(
            "INSERT INTO spy_incidents (actor, target, op, ts, success, revealed) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (actor, target, op, ts, 1 if success else 0, 1 if revealed else 0))
        r = self._query_one("SELECT MAX(id) AS id FROM spy_incidents WHERE actor = ?", (actor,))
        return r["id"] if r else 0

    def get_incident(self, incident_id: int):
        return self._query_one("SELECT * FROM spy_incidents WHERE id = ?", (incident_id,))

    def ops_today(self, actor: str, since_ts: int) -> int:
        r = self._query_one(
            "SELECT COUNT(*) AS c FROM spy_incidents WHERE actor = ? AND ts >= ?", (actor, since_ts))
        return r["c"] if r else 0

    def incidents_against(self, target: str, since_ts: int, unrevealed_only: bool = True) -> list:
        sql = "SELECT * FROM spy_incidents WHERE target = ? AND ts >= ?"
        if unrevealed_only:
            sql += " AND revealed = 0"
        return self._query_all(sql + " ORDER BY ts DESC", (target, since_ts))

    def reveal_incident(self, incident_id: int):
        self._execute("UPDATE spy_incidents SET revealed = 1 WHERE id = ?", (incident_id,))

    def revealed_incidents(self, since_ts: int) -> list:
        return self._query_all(
            "SELECT * FROM spy_incidents WHERE revealed = 1 AND ts >= ? ORDER BY ts DESC", (since_ts,))

    def clear_country(self, country: str):
        """Полная очистка шпионских данных страны (при авто-снятии/разрегистрации)."""
        for sql in (
            "DELETE FROM spy_agency WHERE country = ?",
            "DELETE FROM spy_agents WHERE country = ?",
            "DELETE FROM spy_heat WHERE country = ?",
            "DELETE FROM spy_incidents WHERE actor = ? OR target = ?",
        ):
            self._execute(sql, (country, country) if "OR" in sql else (country,))


class CommandPerms(BaseDB):
    """Права доступа к командам (система !perm). Строка = один grant:
    scope ('*' = все команды, иначе имя команды) для holder (роль/юзер)."""

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS command_perms ("
            "scope TEXT, holder_kind TEXT, holder_id INTEGER, "
            "PRIMARY KEY (scope, holder_kind, holder_id))")

    def grant(self, scope: str, kind: str, holder_id: int):
        self._execute(
            "INSERT OR IGNORE INTO command_perms (scope, holder_kind, holder_id) VALUES (?, ?, ?)",
            (scope, kind, holder_id))

    def revoke(self, scope: str, kind: str, holder_id: int):
        self._execute(
            "DELETE FROM command_perms WHERE scope = ? AND holder_kind = ? AND holder_id = ?",
            (scope, kind, holder_id))

    def has(self, scope: str, user_id: int, role_ids: list[int]) -> bool:
        if user_id and self._query_one(
                "SELECT 1 FROM command_perms WHERE scope = ? AND holder_kind = 'user' AND holder_id = ?",
                (scope, user_id)):
            return True
        if role_ids:
            ph = ",".join("?" * len(role_ids))
            if self._query_one(
                    f"SELECT 1 FROM command_perms WHERE scope = ? AND holder_kind = 'role' "
                    f"AND holder_id IN ({ph})", (scope, *role_ids)):
                return True
        return False

    def list_all(self) -> list:
        return self._query_all("SELECT * FROM command_perms ORDER BY scope, holder_kind")

    def list_scope(self, scope: str) -> list:
        return self._query_all("SELECT * FROM command_perms WHERE scope = ?", (scope,))


class Ultimatums(BaseDB):
    """Ультиматумы: требования одной страны к другой с дедлайном и исходом.
    demands — JSON-строка списка требований; status: pending/accepted/rejected/
    expired/withdrawn. Числа/формулы — в utils.ultimatum."""

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS ultimatums ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, issuer TEXT, target TEXT, "
            "demands TEXT, consequence TEXT, deadline INTEGER, status TEXT DEFAULT 'pending', "
            "leverage REAL DEFAULT 0, message_id INTEGER DEFAULT 0, created_at INTEGER)")

    def create(self, issuer: str, target: str, demands: str, consequence: str,
               deadline: int, leverage: float, created_at: int) -> int:
        self._execute(
            "INSERT INTO ultimatums (issuer, target, demands, consequence, deadline, "
            "leverage, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (issuer, target, demands, consequence, deadline, leverage, created_at))
        r = self._query_one("SELECT MAX(id) AS id FROM ultimatums WHERE issuer = ?", (issuer,))
        return r["id"] if r else 0

    def get(self, uid: int):
        return self._query_one("SELECT * FROM ultimatums WHERE id = ?", (uid,))

    def set_status(self, uid: int, status: str):
        self._execute("UPDATE ultimatums SET status = ? WHERE id = ?", (status, uid))

    def set_message(self, uid: int, message_id: int):
        self._execute("UPDATE ultimatums SET message_id = ? WHERE id = ?", (message_id, uid))

    def set_demands(self, uid: int, demands: str):
        self._execute("UPDATE ultimatums SET demands = ? WHERE id = ?", (demands, uid))

    def active_between(self, issuer: str, target: str):
        """Активный (pending) ультиматум от issuer к target, если есть."""
        return self._query_one(
            "SELECT * FROM ultimatums WHERE issuer = ? AND target = ? AND status = 'pending'",
            (issuer, target))

    def pending_for_target(self, target: str):
        return self._query_all(
            "SELECT * FROM ultimatums WHERE target = ? AND status = 'pending' ORDER BY deadline",
            (target,))

    def pending_by_issuer(self, issuer: str):
        return self._query_all(
            "SELECT * FROM ultimatums WHERE issuer = ? AND status = 'pending' ORDER BY deadline",
            (issuer,))

    def pending_expired(self, now: int):
        return self._query_all(
            "SELECT * FROM ultimatums WHERE status = 'pending' AND deadline <= ?", (now,))

    def casus_since(self, since_ts: int):
        """Отклонённые/просроченные ультиматумы (активные casus belli) за окно."""
        return self._query_all(
            "SELECT * FROM ultimatums WHERE status IN ('rejected', 'expired') AND created_at >= ? "
            "ORDER BY created_at DESC", (since_ts,))

    def clear_country(self, country: str):
        self._execute("DELETE FROM ultimatums WHERE issuer = ? OR target = ?", (country, country))


class Sanctions(BaseDB):
    """Санкции: кто против кого + пакеты. Плюс предрасчитанный per-country эффект
    (множители дохода цели и санкционера), обновляемый почасовым циклом, и
    устойчивость. Экономика читает effect_of() дёшево. Числа — в utils.sanctions."""

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS sanctions ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, sanctioner TEXT, target TEXT, "
            "packages TEXT, created_at INTEGER, status TEXT DEFAULT 'active')")
        self._execute(
            "CREATE TABLE IF NOT EXISTS sanction_effect ("
            "country TEXT PRIMARY KEY, target_mult REAL DEFAULT 1, cost_mult REAL DEFAULT 1, "
            "resilience REAL DEFAULT 0, updated INTEGER DEFAULT 0)")

    # ── санкции ──
    def impose(self, sanctioner: str, target: str, packages: str, now: int) -> int:
        self._execute(
            "INSERT INTO sanctions (sanctioner, target, packages, created_at) VALUES (?, ?, ?, ?)",
            (sanctioner, target, packages, now))
        r = self._query_one("SELECT MAX(id) AS id FROM sanctions WHERE sanctioner = ?", (sanctioner,))
        return r["id"] if r else 0

    def active_between(self, sanctioner: str, target: str):
        return self._query_one(
            "SELECT * FROM sanctions WHERE sanctioner = ? AND target = ? AND status = 'active'",
            (sanctioner, target))

    def active_against(self, target: str):
        return self._query_all(
            "SELECT * FROM sanctions WHERE target = ? AND status = 'active'", (target,))

    def active_by(self, sanctioner: str):
        return self._query_all(
            "SELECT * FROM sanctions WHERE sanctioner = ? AND status = 'active'", (sanctioner,))

    def all_active(self):
        return self._query_all("SELECT * FROM sanctions WHERE status = 'active'")

    def get(self, sid: int):
        return self._query_one("SELECT * FROM sanctions WHERE id = ?", (sid,))

    def lift(self, sid: int):
        self._execute("UPDATE sanctions SET status = 'lifted' WHERE id = ?", (sid,))

    def lift_between(self, sanctioner: str, target: str):
        self._execute(
            "UPDATE sanctions SET status = 'lifted' WHERE sanctioner = ? AND target = ? AND status = 'active'",
            (sanctioner, target))

    def is_embargoed(self, a: str, b: str) -> bool:
        """Есть ли активное эмбарго между a и b (в любую сторону) — для биржи/лицензий."""
        rows = self._query_all(
            "SELECT packages FROM sanctions WHERE status = 'active' AND "
            "((sanctioner = ? AND target = ?) OR (sanctioner = ? AND target = ?))",
            (a, b, b, a))
        return any("embargo" in (r["packages"] or "") for r in rows)

    # ── предрасчитанный эффект (для экономики) ──
    def effect_of(self, country: str) -> tuple[float, float]:
        r = self._query_one("SELECT target_mult, cost_mult FROM sanction_effect WHERE country = ?", (country,))
        if not r:
            return 1.0, 1.0
        return (r["target_mult"] if r["target_mult"] is not None else 1.0,
                r["cost_mult"] if r["cost_mult"] is not None else 1.0)

    def set_effect(self, country: str, target_mult: float, cost_mult: float, now: int):
        self._execute(
            "INSERT INTO sanction_effect (country, target_mult, cost_mult, updated) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(country) DO UPDATE SET target_mult = ?, cost_mult = ?, updated = ?",
            (country, target_mult, cost_mult, now, target_mult, cost_mult, now))

    def income_mult(self, country: str) -> float:
        """Итоговый санкционный множитель дохода (цель × стоимость санкционера)."""
        t, c = self.effect_of(country)
        return round(t * c, 3)

    # ── устойчивость ──
    def get_resilience(self, country: str) -> float:
        r = self._query_one("SELECT resilience FROM sanction_effect WHERE country = ?", (country,))
        return (r["resilience"] if r and r["resilience"] is not None else 0.0)

    def set_resilience(self, country: str, value: float):
        value = max(0.0, min(100.0, value))
        self._execute(
            "INSERT INTO sanction_effect (country, resilience) VALUES (?, ?) "
            "ON CONFLICT(country) DO UPDATE SET resilience = ?", (country, value, value))

    def clear_country(self, country: str):
        self._execute("DELETE FROM sanctions WHERE sanctioner = ? OR target = ?", (country, country))
        self._execute("DELETE FROM sanction_effect WHERE country = ?", (country,))


class Guard(BaseDB):
    """Защита сервера (Sentinel): настройки модулей, вайтлист (иммунитет),
    глобальный список рейдеров (автобан), статистика. Один сервер (GUILD_ID),
    поэтому настройки глобальны (ключ-значение)."""

    def _ensure_schema(self):
        self._execute("CREATE TABLE IF NOT EXISTS guard_settings (key TEXT PRIMARY KEY, value TEXT)")
        self._execute("CREATE TABLE IF NOT EXISTS guard_wl ("
                      "user_id INTEGER, module TEXT, PRIMARY KEY (user_id, module))")
        self._execute("CREATE TABLE IF NOT EXISTS guard_raiders (user_id INTEGER PRIMARY KEY, reason TEXT)")
        self._execute("CREATE TABLE IF NOT EXISTS guard_stats (key TEXT PRIMARY KEY, value INTEGER DEFAULT 0)")

    # ── настройки (key-value) ──
    def _get(self, key: str):
        row = self._query_one("SELECT value FROM guard_settings WHERE key = ?", (key,))
        return row["value"] if row else None

    def _set(self, key: str, value):
        self._execute("INSERT OR REPLACE INTO guard_settings (key, value) VALUES (?, ?)", (key, str(value)))

    def module_on(self, module: str, default: bool = True) -> bool:
        v = self._get(f"mod_{module}")
        return (v == "1") if v is not None else default

    def set_module(self, module: str, on: bool):
        self._set(f"mod_{module}", "1" if on else "0")

    def raid_mode(self) -> bool:
        return self._get("raid_mode") == "1"

    def set_raid_mode(self, on: bool):
        self._set("raid_mode", "1" if on else "0")

    def log_channel(self) -> int:
        try:
            return int(self._get("log_channel") or 0)
        except (TypeError, ValueError):
            return 0

    def set_log_channel(self, channel_id: int):
        self._set("log_channel", channel_id)

    def all_settings(self) -> dict:
        return {r["key"]: r["value"] for r in self._query_all("SELECT key, value FROM guard_settings")}

    # ── вайтлист (иммунитет ПО МОДУЛЯМ; модуль 'all' = полный иммунитет) ──
    def wl_add(self, user_id: int, module: str):
        self._execute("INSERT OR IGNORE INTO guard_wl (user_id, module) VALUES (?, ?)", (user_id, module))

    def wl_remove(self, user_id: int, module: str):
        self._execute("DELETE FROM guard_wl WHERE user_id = ? AND module = ?", (user_id, module))

    def wl_remove_all(self, user_id: int):
        self._execute("DELETE FROM guard_wl WHERE user_id = ?", (user_id,))

    def wl_has(self, user_id: int, module: str) -> bool:
        return self._query_one(
            "SELECT 1 FROM guard_wl WHERE user_id = ? AND module IN (?, 'all')",
            (user_id, module)) is not None

    def wl_modules(self, user_id: int) -> list[str]:
        return [r["module"] for r in self._query_all(
            "SELECT module FROM guard_wl WHERE user_id = ?", (user_id,))]

    def wl_all(self) -> dict:
        out: dict[int, list[str]] = {}
        for r in self._query_all("SELECT user_id, module FROM guard_wl ORDER BY user_id"):
            out.setdefault(r["user_id"], []).append(r["module"])
        return out

    # ── список рейдеров (глобальный автобан) ──
    def raider_add(self, user_id: int, reason: str = ""):
        self._execute("INSERT OR REPLACE INTO guard_raiders (user_id, reason) VALUES (?, ?)", (user_id, reason))

    def raider_remove(self, user_id: int):
        self._execute("DELETE FROM guard_raiders WHERE user_id = ?", (user_id,))

    def raider_is(self, user_id: int) -> bool:
        return self._query_one("SELECT 1 FROM guard_raiders WHERE user_id = ?", (user_id,)) is not None

    def raider_get(self, user_id: int):
        return self._query_one("SELECT * FROM guard_raiders WHERE user_id = ?", (user_id,))

    def raider_list(self):
        return self._query_all("SELECT * FROM guard_raiders ORDER BY user_id")

    # ── статистика ──
    def stat_inc(self, key: str, n: int = 1):
        self._execute(
            "INSERT INTO guard_stats (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = value + ?", (key, n, n))

    def stats_all(self) -> dict:
        return {r["key"]: r["value"] for r in self._query_all("SELECT key, value FROM guard_stats")}


class War(BaseDB):
    """Войны (Этап 2): объявление, линия фронта по областям, планы по раундам, журнал.

    Таблицы:
      • wars        — война (атакующий/обороняющийся, статус, номер раунда, повод, победитель)
      • war_fronts  — области обороняющегося по оси наступления (порядок, осадный
                      прогресс, захвачена ли, столица ли)
      • war_plans   — план стороны на раунд (текст + введённые соединения json)
      • war_log     — журнал боёв (для отчётов и истории)
    Всю математику считает utils.war, применяет cogs/war.py.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS war_conflicts ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, attacker TEXT, defender TEXT, "
            "status TEXT DEFAULT 'active', round_no INTEGER DEFAULT 0, casus TEXT, "
            "winner TEXT, started_at INTEGER, ended_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS war_fronts ("
            "war_id INTEGER, region TEXT, name TEXT, ord INTEGER, is_capital INTEGER DEFAULT 0, "
            "siege REAL DEFAULT 0, captured INTEGER DEFAULT 0, PRIMARY KEY (war_id, region))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS war_plans ("
            "war_id INTEGER, round_no INTEGER, side TEXT, country TEXT, plan TEXT, "
            "committed TEXT, submitted_at INTEGER, PRIMARY KEY (war_id, round_no, side))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS war_log ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, war_id INTEGER, round_no INTEGER, "
            "text TEXT, ts INTEGER)")
        # миграция: кто предложил мир (ожидает согласия второй стороны)
        try:
            self._execute("ALTER TABLE war_conflicts ADD COLUMN peace_by TEXT")
        except Exception:
            pass  # колонка уже есть
        # миграция: сторона фронта — 'D' области обороняющегося (цель атакующего),
        # 'A' области атакующего (цель контрнаступления обороняющегося)
        try:
            self._execute("ALTER TABLE war_fronts ADD COLUMN side TEXT DEFAULT 'D'")
        except Exception:
            pass
        # миграция: сумма репараций в текущем предложении мира (условие доминатора)
        try:
            self._execute("ALTER TABLE war_conflicts ADD COLUMN peace_rep INTEGER DEFAULT 0")
        except Exception:
            pass
        # миграция: через чьи земли идёт наступление (право прохода/союз), NULL — напрямую
        try:
            self._execute("ALTER TABLE war_conflicts ADD COLUMN via TEXT")
        except Exception:
            pass
        # союзники, вступившие в войну на чьей-то стороне ('att' | 'def') — воюют в общем бою
        self._execute(
            "CREATE TABLE IF NOT EXISTS war_allies ("
            "war_id INTEGER, country TEXT, side TEXT, joined_at INTEGER, PRIMARY KEY (war_id, country))")

    # ── войны ──
    def create_war(self, attacker: str, defender: str, casus: str, started_at: int) -> int:
        self._execute(
            "INSERT INTO war_conflicts (attacker, defender, casus, started_at, status, round_no) "
            "VALUES (?, ?, ?, ?, 'active', 0)", (attacker, defender, casus, started_at))
        r = self._query_one(
            "SELECT id FROM war_conflicts WHERE attacker = ? AND defender = ? ORDER BY id DESC LIMIT 1",
            (attacker, defender))
        return r["id"] if r else 0

    def get_war(self, war_id: int):
        return self._query_one("SELECT * FROM war_conflicts WHERE id = ?", (war_id,))

    def active_between(self, a: str, b: str):
        return self._query_one(
            "SELECT * FROM war_conflicts WHERE status = 'active' AND "
            "((attacker = ? AND defender = ?) OR (attacker = ? AND defender = ?))", (a, b, b, a))

    def active_for(self, country: str):
        return self._query_all(
            "SELECT * FROM war_conflicts WHERE status = 'active' AND (attacker = ? OR defender = ?)",
            (country, country))

    def all_active(self):
        return self._query_all("SELECT * FROM war_conflicts WHERE status = 'active' ORDER BY id")

    def set_via(self, war_id: int, via: str | None):
        self._execute("UPDATE war_conflicts SET via = ? WHERE id = ?", (via, war_id))

    def get_via(self, war_id: int) -> str | None:
        r = self.get_war(war_id)
        try:
            return r["via"] if r else None
        except (KeyError, IndexError):
            return None

    # ── союзники в войне ──
    def add_ally(self, war_id: int, country: str, side: str, ts: int):
        self._execute("INSERT OR IGNORE INTO war_allies (war_id, country, side, joined_at) VALUES (?, ?, ?, ?)",
                      (war_id, country, side, ts))

    def remove_ally(self, war_id: int, country: str):
        """Союзник/ЧВК покидает войну (контракт ЧВК закончился или сорван)."""
        self._execute("DELETE FROM war_allies WHERE war_id = ? AND country = ?", (war_id, country))

    def allies_of(self, war_id: int, side: str) -> list[str]:
        return [r["country"] for r in self._query_all(
            "SELECT country FROM war_allies WHERE war_id = ? AND side = ? ORDER BY joined_at", (war_id, side))]

    def ally_wars(self) -> list:
        """Союзники во всех активных войнах: (war_id, country, side, attacker, defender)."""
        return self._query_all(
            "SELECT a.war_id, a.country, a.side, w.attacker, w.defender FROM war_allies a "
            "JOIN war_conflicts w ON w.id = a.war_id WHERE w.status = 'active'")

    def is_participant(self, war_id: int, country: str) -> bool:
        w = self.get_war(war_id)
        if w and country in (w["attacker"], w["defender"]):
            return True
        return bool(self._query_one(
            "SELECT 1 FROM war_allies WHERE war_id = ? AND country = ?", (war_id, country)))

    def set_round(self, war_id: int, round_no: int):
        self._execute("UPDATE war_conflicts SET round_no = ? WHERE id = ?", (round_no, war_id))

    def end_war(self, war_id: int, winner: str | None, ended_at: int, status: str = "ended"):
        self._execute("UPDATE war_conflicts SET status = ?, winner = ?, ended_at = ? WHERE id = ?",
                      (status, winner, ended_at, war_id))

    # ── предложение мира (нужно согласие второй стороны) ──
    def set_peace_offer(self, war_id: int, country: str, reparations: int = 0):
        rep = int(reparations)
        rep = -1 if rep == -1 else max(0, rep)   # −1 — «уступка занятого» (капитуляция ИИ-государства)
        self._execute("UPDATE war_conflicts SET peace_by = ?, peace_rep = ? WHERE id = ?",
                      (country, rep, war_id))

    def get_peace_offer(self, war_id: int):
        """→ (кто_предложил | None, сумма_репараций)."""
        r = self.get_war(war_id)
        if not r:
            return None, 0
        try:
            return r["peace_by"], (r["peace_rep"] or 0)
        except (KeyError, IndexError):
            return None, 0

    def clear_peace_offer(self, war_id: int):
        self._execute("UPDATE war_conflicts SET peace_by = NULL, peace_rep = 0 WHERE id = ?", (war_id,))

    # ── фронты (двусторонние: side 'D' — цели атакующего, 'A' — цели обороны) ──
    def add_front(self, war_id: int, region: str, name: str, ord_: int, is_capital: bool,
                  side: str = "D"):
        self._execute(
            "INSERT OR IGNORE INTO war_fronts (war_id, region, name, ord, is_capital, side) "
            "VALUES (?, ?, ?, ?, ?, ?)", (war_id, region, name, ord_, 1 if is_capital else 0, side))

    def fronts_for(self, war_id: int, side: str | None = None):
        if side:
            return self._query_all(
                "SELECT * FROM war_fronts WHERE war_id = ? AND side = ? ORDER BY ord", (war_id, side))
        return self._query_all("SELECT * FROM war_fronts WHERE war_id = ? ORDER BY side, ord", (war_id,))

    def current_front(self, war_id: int, side: str = "D"):
        return self._query_one(
            "SELECT * FROM war_fronts WHERE war_id = ? AND side = ? AND captured = 0 ORDER BY ord LIMIT 1",
            (war_id, side))

    def set_siege(self, war_id: int, region: str, siege: float):
        self._execute("UPDATE war_fronts SET siege = ? WHERE war_id = ? AND region = ?",
                      (siege, war_id, region))

    def capture_front(self, war_id: int, region: str):
        self._execute("UPDATE war_fronts SET captured = 1 WHERE war_id = ? AND region = ?",
                      (war_id, region))

    def captured_count(self, war_id: int, side: str | None = None) -> int:
        if side:
            r = self._query_one(
                "SELECT COUNT(*) AS c FROM war_fronts WHERE war_id = ? AND captured = 1 AND side = ?",
                (war_id, side))
        else:
            r = self._query_one(
                "SELECT COUNT(*) AS c FROM war_fronts WHERE war_id = ? AND captured = 1", (war_id,))
        return r["c"] if r else 0

    def fronts_total(self, war_id: int, side: str | None = None) -> int:
        if side:
            r = self._query_one(
                "SELECT COUNT(*) AS c FROM war_fronts WHERE war_id = ? AND side = ?", (war_id, side))
        else:
            r = self._query_one("SELECT COUNT(*) AS c FROM war_fronts WHERE war_id = ?", (war_id,))
        return r["c"] if r else 0

    # ── планы ──
    def submit_plan(self, war_id: int, round_no: int, side: str, country: str,
                    plan: str, committed: str, ts: int):
        self._execute(
            "INSERT OR REPLACE INTO war_plans (war_id, round_no, side, country, plan, committed, submitted_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)", (war_id, round_no, side, country, plan, committed, ts))

    def plan_for(self, war_id: int, round_no: int, side: str):
        return self._query_one(
            "SELECT * FROM war_plans WHERE war_id = ? AND round_no = ? AND side = ?",
            (war_id, round_no, side))

    def both_plans_in(self, war_id: int, round_no: int) -> bool:
        r = self._query_one(
            "SELECT COUNT(*) AS c FROM war_plans WHERE war_id = ? AND round_no = ?",
            (war_id, round_no))
        return (r["c"] if r else 0) >= 2

    # ── журнал ──
    def log(self, war_id: int, round_no: int, text: str, ts: int):
        self._execute("INSERT INTO war_log (war_id, round_no, text, ts) VALUES (?, ?, ?, ?)",
                      (war_id, round_no, text, ts))

    def log_for(self, war_id: int, limit: int = 20):
        return self._query_all(
            "SELECT * FROM war_log WHERE war_id = ? ORDER BY id DESC LIMIT ?", (war_id, limit))


class Trade(BaseDB):
    """Общий рынок: книга заявок на покупку/продажу ресурсов между странами.

    trade_offers: id, side ('sell'|'buy'), country, resource, amount (остаток),
    price (цена за единицу), created_at. Любая страна может создать заявку, любая —
    исполнить (частично или полностью). Переводы денег/ресурсов делает ког.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS trade_offers ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, side TEXT, country TEXT, resource TEXT, "
            "amount INTEGER, price INTEGER, created_at INTEGER)")

    def create_offer(self, side: str, country: str, resource: str, amount: int,
                     price: int, created_at: int) -> int:
        self._execute(
            "INSERT INTO trade_offers (side, country, resource, amount, price, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)", (side, country, resource, max(0, amount), max(0, price), created_at))
        r = self._query_one("SELECT MAX(id) AS id FROM trade_offers WHERE country = ?", (country,))
        return r["id"] if r else 0

    def get_offer(self, offer_id: int):
        return self._query_one("SELECT * FROM trade_offers WHERE id = ?", (offer_id,))

    def offers_by_resource(self, resource: str, side: str):
        # для продажи сортируем по цене возр. (дешевле — выгоднее купить),
        # для покупки — по цене убыв. (дороже — выгоднее продать)
        order = "ASC" if side == "sell" else "DESC"
        return self._query_all(
            f"SELECT * FROM trade_offers WHERE resource = ? AND side = ? AND amount > 0 "
            f"ORDER BY price {order}, id ASC", (resource, side))

    def resources_on_market(self):
        return [r["resource"] for r in self._query_all(
            "SELECT DISTINCT resource FROM trade_offers WHERE amount > 0 ORDER BY resource")]

    def my_offers(self, country: str):
        return self._query_all(
            "SELECT * FROM trade_offers WHERE country = ? AND amount > 0 ORDER BY id DESC", (country,))

    def reduce_offer(self, offer_id: int, qty: int):
        self._execute("UPDATE trade_offers SET amount = amount - ? WHERE id = ?", (max(0, qty), offer_id))
        self._execute("DELETE FROM trade_offers WHERE id = ? AND amount <= 0", (offer_id,))

    def remove_offer(self, offer_id: int):
        self._execute("DELETE FROM trade_offers WHERE id = ?", (offer_id,))

    def all_offers(self):
        return self._query_all("SELECT * FROM trade_offers WHERE amount > 0 ORDER BY resource, side")


class Diplomacy(BaseDB):
    """Дипломатия: отношения пар, дипкапитал/репутация, договоры, посольства,
    журнал торговли между странами, фоновые инциденты, зов союзника.

    Таблицы:
      • diplo_relations — отношения неупорядоченной пары (a < b), −100..+100
      • diplo_state     — дипкапитал и репутация страны
      • diplo_treaties  — договоры (pending → active → ended | rejected | expired)
      • diplo_embassies — посольство owner в стране host
      • diplo_trade_log — оборот сделок рынка между странами (для равновесия)
      • diplo_incidents — кризис пары: выборы сторон, статус, casus belli
      • diplo_calls     — зов союзника в войну (ожидает ответа)
    Формулы — в utils.diplomacy, применяет cogs/diplomacy.py.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS diplo_relations ("
            "a TEXT, b TEXT, value REAL DEFAULT 0, PRIMARY KEY (a, b))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS diplo_state ("
            "country TEXT PRIMARY KEY, influence REAL DEFAULT 30, reputation REAL DEFAULT 60)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS diplo_treaties ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, a TEXT, b TEXT, proposer TEXT, "
            "status TEXT DEFAULT 'pending', cost REAL DEFAULT 0, created_at INTEGER, "
            "signed_at INTEGER, ended_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS diplo_embassies ("
            "owner TEXT, host TEXT, created_at INTEGER, PRIMARY KEY (owner, host))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS diplo_trade_log ("
            "a TEXT, b TEXT, value INTEGER, ts INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS diplo_incidents ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, a TEXT, b TEXT, "
            "a_choice TEXT, b_choice TEXT, status TEXT DEFAULT 'open', casus INTEGER DEFAULT 0, "
            "created_at INTEGER, deadline INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS diplo_calls ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, war_id INTEGER, ally TEXT, aggressor TEXT, "
            "defender TEXT, status TEXT DEFAULT 'pending', created_at INTEGER, deadline INTEGER)")

    @staticmethod
    def _pair(a: str, b: str) -> tuple[str, str]:
        return (a, b) if a < b else (b, a)

    # ── отношения ──
    def get_relation(self, a: str, b: str) -> float:
        x, y = self._pair(a, b)
        r = self._query_one("SELECT value FROM diplo_relations WHERE a = ? AND b = ?", (x, y))
        return float(r["value"]) if r and r["value"] is not None else 0.0

    def set_relation(self, a: str, b: str, value: float):
        x, y = self._pair(a, b)
        value = max(-100.0, min(100.0, round(value, 2)))
        self._execute(
            "INSERT INTO diplo_relations (a, b, value) VALUES (?, ?, ?) "
            "ON CONFLICT(a, b) DO UPDATE SET value = ?", (x, y, value, value))

    def add_relation(self, a: str, b: str, delta: float) -> float:
        v = max(-100.0, min(100.0, self.get_relation(a, b) + delta))
        self.set_relation(a, b, v)
        return v

    def relations_of(self, country: str) -> dict[str, float]:
        rows = self._query_all(
            "SELECT a, b, value FROM diplo_relations WHERE a = ? OR b = ?", (country, country))
        return {(r["b"] if r["a"] == country else r["a"]): float(r["value"] or 0) for r in rows}

    # ── дипкапитал / репутация ──
    def _ensure_state(self, country: str):
        self._execute("INSERT OR IGNORE INTO diplo_state (country) VALUES (?)", (country,))

    def get_state(self, country: str) -> tuple[float, float]:
        """→ (дипкапитал, репутация)."""
        self._ensure_state(country)
        r = self._query_one("SELECT influence, reputation FROM diplo_state WHERE country = ?", (country,))
        return float(r["influence"] or 0), float(r["reputation"] if r["reputation"] is not None else 60)

    def set_influence(self, country: str, value: float):
        self._ensure_state(country)
        self._execute("UPDATE diplo_state SET influence = ? WHERE country = ?",
                      (max(0.0, min(100.0, round(value, 2))), country))

    def add_influence(self, country: str, delta: float):
        self.set_influence(country, self.get_state(country)[0] + delta)

    def set_reputation(self, country: str, value: float):
        self._ensure_state(country)
        self._execute("UPDATE diplo_state SET reputation = ? WHERE country = ?",
                      (max(0.0, min(100.0, round(value, 2))), country))

    def add_reputation(self, country: str, delta: float):
        self.set_reputation(country, self.get_state(country)[1] + delta)

    # ── договоры ──
    def propose(self, kind: str, proposer: str, target: str, cost: float, now: int) -> int:
        x, y = self._pair(proposer, target)
        self._execute(
            "INSERT INTO diplo_treaties (kind, a, b, proposer, status, cost, created_at) "
            "VALUES (?, ?, ?, ?, 'pending', ?, ?)", (kind, x, y, proposer, cost, now))
        r = self._query_one("SELECT MAX(id) AS id FROM diplo_treaties WHERE proposer = ?", (proposer,))
        return r["id"] if r else 0

    def get_treaty(self, tid: int):
        return self._query_one("SELECT * FROM diplo_treaties WHERE id = ?", (tid,))

    def set_treaty_status(self, tid: int, status: str, now: int):
        col = "signed_at" if status == "active" else "ended_at"
        self._execute(f"UPDATE diplo_treaties SET status = ?, {col} = ? WHERE id = ?", (status, now, tid))

    def treaty_between(self, a: str, b: str, kind: str, statuses=("active",)):
        x, y = self._pair(a, b)
        marks = ",".join("?" for _ in statuses)
        return self._query_one(
            f"SELECT * FROM diplo_treaties WHERE a = ? AND b = ? AND kind = ? AND status IN ({marks})",
            (x, y, kind, *statuses))

    def treaties_between(self, a: str, b: str, status: str = "active"):
        x, y = self._pair(a, b)
        return self._query_all(
            "SELECT * FROM diplo_treaties WHERE a = ? AND b = ? AND status = ?", (x, y, status))

    def treaties_of(self, country: str, status: str = "active"):
        return self._query_all(
            "SELECT * FROM diplo_treaties WHERE (a = ? OR b = ?) AND status = ? ORDER BY id",
            (country, country, status))

    def incoming_proposals(self, country: str):
        return self._query_all(
            "SELECT * FROM diplo_treaties WHERE (a = ? OR b = ?) AND proposer != ? AND status = 'pending' "
            "ORDER BY id", (country, country, country))

    def pending_expired(self, before_ts: int):
        return self._query_all(
            "SELECT * FROM diplo_treaties WHERE status = 'pending' AND created_at <= ?", (before_ts,))

    def partners(self, country: str, kind: str) -> list[str]:
        return [(t["b"] if t["a"] == country else t["a"]) for t in self.treaties_of(country)
                if t["kind"] == kind]

    # ── посольства ──
    def has_embassy(self, owner: str, host: str) -> bool:
        return bool(self._query_one(
            "SELECT 1 FROM diplo_embassies WHERE owner = ? AND host = ?", (owner, host)))

    def open_embassy(self, owner: str, host: str, now: int):
        self._execute("INSERT OR IGNORE INTO diplo_embassies (owner, host, created_at) VALUES (?, ?, ?)",
                      (owner, host, now))

    def close_embassy(self, owner: str, host: str):
        self._execute("DELETE FROM diplo_embassies WHERE owner = ? AND host = ?", (owner, host))

    def embassies_of(self, owner: str) -> list[str]:
        return [r["host"] for r in self._query_all(
            "SELECT host FROM diplo_embassies WHERE owner = ? ORDER BY created_at", (owner,))]

    # ── торговля между странами ──
    def log_trade(self, a: str, b: str, value: int, ts: int):
        if a == b or value <= 0:
            return
        x, y = self._pair(a, b)
        self._execute("INSERT INTO diplo_trade_log (a, b, value, ts) VALUES (?, ?, ?, ?)",
                      (x, y, int(value), ts))

    def trade_volume(self, a: str, b: str, since_ts: int) -> int:
        x, y = self._pair(a, b)
        r = self._query_one(
            "SELECT COALESCE(SUM(value), 0) AS v FROM diplo_trade_log WHERE a = ? AND b = ? AND ts >= ?",
            (x, y, since_ts))
        return int(r["v"]) if r else 0

    def trade_volumes(self, since_ts: int) -> dict[tuple[str, str], int]:
        """Оборот всех пар за окно одним запросом (для часового пересчёта)."""
        rows = self._query_all(
            "SELECT a, b, SUM(value) AS v FROM diplo_trade_log WHERE ts >= ? GROUP BY a, b", (since_ts,))
        return {(r["a"], r["b"]): int(r["v"] or 0) for r in rows}

    def ultimatums_since(self, since_ts: int) -> list:
        """Ультиматумы за окно (таблица модуля ультиматумов; пусто, если её ещё нет)."""
        try:
            return self._query_all(
                "SELECT issuer, target FROM ultimatums WHERE created_at >= ?", (since_ts,))
        except Exception:
            return []

    def prune_trade(self, before_ts: int):
        self._execute("DELETE FROM diplo_trade_log WHERE ts < ?", (before_ts,))

    # ── инциденты ──
    def create_incident(self, kind: str, a: str, b: str, now: int, deadline: int) -> int:
        self._execute(
            "INSERT INTO diplo_incidents (kind, a, b, status, created_at, deadline) "
            "VALUES (?, ?, ?, 'open', ?, ?)", (kind, a, b, now, deadline))
        r = self._query_one("SELECT MAX(id) AS id FROM diplo_incidents WHERE a = ? AND b = ?", (a, b))
        return r["id"] if r else 0

    def get_incident(self, iid: int):
        return self._query_one("SELECT * FROM diplo_incidents WHERE id = ?", (iid,))

    def set_choice(self, iid: int, side: str, choice: str):
        col = "a_choice" if side == "a" else "b_choice"
        self._execute(f"UPDATE diplo_incidents SET {col} = ? WHERE id = ?", (choice, iid))

    def close_incident(self, iid: int, casus: bool):
        self._execute("UPDATE diplo_incidents SET status = 'closed', casus = ? WHERE id = ?",
                      (1 if casus else 0, iid))

    def open_incident_between(self, a: str, b: str):
        return self._query_one(
            "SELECT * FROM diplo_incidents WHERE status = 'open' AND "
            "((a = ? AND b = ?) OR (a = ? AND b = ?))", (a, b, b, a))

    def open_incidents_due(self, now: int):
        return self._query_all(
            "SELECT * FROM diplo_incidents WHERE status = 'open' AND deadline <= ?", (now,))

    def last_incident_ts(self, country: str) -> int:
        r = self._query_one(
            "SELECT MAX(created_at) AS t FROM diplo_incidents WHERE a = ? OR b = ?", (country, country))
        return int(r["t"] or 0) if r else 0

    def casus_incidents(self, since_ts: int):
        return self._query_all(
            "SELECT * FROM diplo_incidents WHERE casus = 1 AND created_at >= ? ORDER BY created_at DESC",
            (since_ts,))

    # ── зов союзника ──
    def create_call(self, war_id: int, ally: str, aggressor: str, defender: str,
                    now: int, deadline: int) -> int:
        self._execute(
            "INSERT INTO diplo_calls (war_id, ally, aggressor, defender, status, created_at, deadline) "
            "VALUES (?, ?, ?, ?, 'pending', ?, ?)", (war_id, ally, aggressor, defender, now, deadline))
        r = self._query_one("SELECT MAX(id) AS id FROM diplo_calls WHERE ally = ?", (ally,))
        return r["id"] if r else 0

    def get_call(self, call_id: int):
        return self._query_one("SELECT * FROM diplo_calls WHERE id = ?", (call_id,))

    def set_call_status(self, call_id: int, status: str):
        self._execute("UPDATE diplo_calls SET status = ? WHERE id = ?", (status, call_id))

    def calls_due(self, now: int):
        return self._query_all(
            "SELECT * FROM diplo_calls WHERE status = 'pending' AND deadline <= ?", (now,))

    def clear_country(self, country: str):
        for sql in (
            "DELETE FROM diplo_relations WHERE a = ? OR b = ?",
            "DELETE FROM diplo_treaties WHERE a = ? OR b = ?",
            "DELETE FROM diplo_embassies WHERE owner = ? OR host = ?",
            "DELETE FROM diplo_trade_log WHERE a = ? OR b = ?",
            "DELETE FROM diplo_incidents WHERE a = ? OR b = ?",
            "DELETE FROM diplo_calls WHERE ally = ? OR defender = ?",
        ):
            self._execute(sql, (country, country))
        self._execute("DELETE FROM diplo_state WHERE country = ?", (country,))



class Alliances(BaseDB):
    """Альянсы (блоки): военные и экономические.

    Таблицы:
      • blocs         — блок: тип, имя, тег, лидер, сплочённость, казна, статьи устава
      • bloc_members  — членство (joined_at — для ратификации обороны)
      • bloc_votes    — голосования (open → passed | failed)
      • bloc_ballots  — голоса членов
      • bloc_invites  — приглашения после одобренного голосования (pending → accepted | declined | expired)
    Формулы — в utils.alliance, применяет cogs/alliance.py.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS blocs ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, name TEXT, tag TEXT, leader TEXT, "
            "cohesion REAL DEFAULT 55, treasury INTEGER DEFAULT 0, articles TEXT DEFAULT '', "
            "color_idx INTEGER DEFAULT 0, status TEXT DEFAULT 'active', created_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS bloc_members ("
            "bloc_id INTEGER, country TEXT, joined_at INTEGER, PRIMARY KEY (bloc_id, country))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS bloc_votes ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, bloc_id INTEGER, kind TEXT, subject TEXT, "
            "amount INTEGER DEFAULT 0, initiator TEXT, status TEXT DEFAULT 'open', "
            "created_at INTEGER, deadline INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS bloc_ballots ("
            "vote_id INTEGER, country TEXT, yes INTEGER, PRIMARY KEY (vote_id, country))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS bloc_invites ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, bloc_id INTEGER, country TEXT, "
            "status TEXT DEFAULT 'pending', created_at INTEGER, deadline INTEGER)")

    # ── блоки ──
    def create(self, kind: str, name: str, tag: str, leader: str, cohesion: float, now: int) -> int:
        r = self._query_one("SELECT COUNT(*) AS n FROM blocs")
        color_idx = int(r["n"]) if r else 0
        self._execute(
            "INSERT INTO blocs (kind, name, tag, leader, cohesion, articles, color_idx, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, '', ?, 'active', ?)", (kind, name, tag, leader, cohesion, color_idx, now))
        r = self._query_one("SELECT MAX(id) AS id FROM blocs WHERE leader = ?", (leader,))
        bid = r["id"] if r else 0
        self.add_member(bid, leader, now)
        return bid

    def get(self, bid: int):
        return self._query_one("SELECT * FROM blocs WHERE id = ?", (bid,))

    def active(self, kind: str | None = None):
        if kind:
            return self._query_all("SELECT * FROM blocs WHERE status = 'active' AND kind = ? ORDER BY id", (kind,))
        return self._query_all("SELECT * FROM blocs WHERE status = 'active' ORDER BY id")

    def name_taken(self, name: str, tag: str) -> bool:
        return bool(self._query_one(
            "SELECT 1 FROM blocs WHERE status = 'active' AND (LOWER(name) = LOWER(?) OR UPPER(tag) = UPPER(?))",
            (name, tag)))

    def dissolve(self, bid: int):
        self._execute("UPDATE blocs SET status = 'dissolved' WHERE id = ?", (bid,))
        self._execute("DELETE FROM bloc_members WHERE bloc_id = ?", (bid,))
        self._execute("UPDATE bloc_votes SET status = 'failed' WHERE bloc_id = ? AND status = 'open'", (bid,))
        self._execute("UPDATE bloc_invites SET status = 'expired' WHERE bloc_id = ? AND status = 'pending'", (bid,))

    def set_leader(self, bid: int, leader: str):
        self._execute("UPDATE blocs SET leader = ? WHERE id = ?", (leader, bid))

    def set_cohesion(self, bid: int, value: float):
        self._execute("UPDATE blocs SET cohesion = ? WHERE id = ?",
                      (max(0.0, min(100.0, round(value, 2))), bid))

    def add_cohesion(self, bid: int, delta: float):
        b = self.get(bid)
        if b:
            self.set_cohesion(bid, (b["cohesion"] or 0) + delta)

    def add_treasury(self, bid: int, delta: int) -> int:
        self._execute("UPDATE blocs SET treasury = MAX(0, treasury + ?) WHERE id = ?", (int(delta), bid))
        b = self.get(bid)
        return int(b["treasury"] or 0) if b else 0

    def set_articles(self, bid: int, raw: str):
        self._execute("UPDATE blocs SET articles = ? WHERE id = ?", (raw, bid))

    # ── члены ──
    def add_member(self, bid: int, country: str, now: int):
        self._execute("INSERT OR IGNORE INTO bloc_members (bloc_id, country, joined_at) VALUES (?, ?, ?)",
                      (bid, country, now))

    def remove_member(self, bid: int, country: str):
        self._execute("DELETE FROM bloc_members WHERE bloc_id = ? AND country = ?", (bid, country))

    def members(self, bid: int) -> list[str]:
        return [r["country"] for r in self._query_all(
            "SELECT country FROM bloc_members WHERE bloc_id = ? ORDER BY joined_at", (bid,))]

    def member_rows(self, bid: int):
        return self._query_all("SELECT * FROM bloc_members WHERE bloc_id = ? ORDER BY joined_at", (bid,))

    def joined_at(self, bid: int, country: str) -> int:
        r = self._query_one("SELECT joined_at FROM bloc_members WHERE bloc_id = ? AND country = ?", (bid, country))
        return int(r["joined_at"] or 0) if r else 0

    def bloc_of(self, country: str, kind: str):
        return self._query_one(
            "SELECT b.* FROM blocs b JOIN bloc_members m ON m.bloc_id = b.id "
            "WHERE m.country = ? AND b.kind = ? AND b.status = 'active'", (country, kind))

    def blocs_of(self, country: str):
        return self._query_all(
            "SELECT b.* FROM blocs b JOIN bloc_members m ON m.bloc_id = b.id "
            "WHERE m.country = ? AND b.status = 'active' ORDER BY b.kind DESC", (country,))

    # ── голосования ──
    def create_vote(self, bid: int, kind: str, subject: str, amount: int, initiator: str,
                    now: int, deadline: int) -> int:
        self._execute(
            "INSERT INTO bloc_votes (bloc_id, kind, subject, amount, initiator, status, created_at, deadline) "
            "VALUES (?, ?, ?, ?, ?, 'open', ?, ?)", (bid, kind, subject, int(amount), initiator, now, deadline))
        r = self._query_one("SELECT MAX(id) AS id FROM bloc_votes WHERE bloc_id = ?", (bid,))
        return r["id"] if r else 0

    def get_vote(self, vid: int):
        return self._query_one("SELECT * FROM bloc_votes WHERE id = ?", (vid,))

    def open_votes(self, bid: int):
        return self._query_all("SELECT * FROM bloc_votes WHERE bloc_id = ? AND status = 'open' ORDER BY id", (bid,))

    def open_vote_like(self, bid: int, kind: str, subject: str):
        return self._query_one(
            "SELECT * FROM bloc_votes WHERE bloc_id = ? AND kind = ? AND subject = ? AND status = 'open'",
            (bid, kind, subject))

    def votes_due(self, now: int):
        return self._query_all("SELECT * FROM bloc_votes WHERE status = 'open' AND deadline <= ?", (now,))

    def cast(self, vid: int, country: str, yes: bool):
        self._execute("INSERT OR REPLACE INTO bloc_ballots (vote_id, country, yes) VALUES (?, ?, ?)",
                      (vid, country, 1 if yes else 0))

    def ballots(self, vid: int) -> dict[str, bool]:
        return {r["country"]: bool(r["yes"]) for r in self._query_all(
            "SELECT country, yes FROM bloc_ballots WHERE vote_id = ?", (vid,))}

    def close_vote(self, vid: int, status: str):
        self._execute("UPDATE bloc_votes SET status = ? WHERE id = ?", (status, vid))

    # ── приглашения ──
    def create_invite(self, bid: int, country: str, now: int, deadline: int) -> int:
        self._execute("INSERT INTO bloc_invites (bloc_id, country, status, created_at, deadline) "
                      "VALUES (?, ?, 'pending', ?, ?)", (bid, country, now, deadline))
        r = self._query_one("SELECT MAX(id) AS id FROM bloc_invites WHERE country = ?", (country,))
        return r["id"] if r else 0

    def get_invite(self, iid: int):
        return self._query_one("SELECT * FROM bloc_invites WHERE id = ?", (iid,))

    def set_invite_status(self, iid: int, status: str):
        self._execute("UPDATE bloc_invites SET status = ? WHERE id = ?", (status, iid))

    def invites_for(self, country: str):
        return self._query_all(
            "SELECT * FROM bloc_invites WHERE country = ? AND status = 'pending' ORDER BY id", (country,))

    def invites_due(self, now: int):
        return self._query_all("SELECT * FROM bloc_invites WHERE status = 'pending' AND deadline <= ?", (now,))

    def clear_country(self, country: str):
        """Снятие страны: выход из всех блоков (лидерство/роспуск решает ког на тике)."""
        self._execute("DELETE FROM bloc_members WHERE country = ?", (country,))
        self._execute("DELETE FROM bloc_ballots WHERE country = ?", (country,))
        self._execute("UPDATE bloc_invites SET status = 'expired' WHERE country = ? AND status = 'pending'",
                      (country,))
        self._execute("UPDATE bloc_votes SET status = 'failed' WHERE subject = ? AND status = 'open'", (country,))



class Nuclear(BaseDB):
    """Атомная программа.

    Таблицы:
      • nuke_state   — страна: пройдено ступеней, текущее исследование, статус ДНЯО,
                       оружейный уран (кг), каскады, АЭС (+стройка), работающие АЭС
      • nuke_designs — зарегистрированные боеголовки (своё название, тип, мощность)
      • nuke_stock   — арсенал боеголовок по моделям
      • nuke_queue   — производство боеголовок
      • nuke_tests   — заявки на испытание (арбитр: штаб, позже ИИ-ООН)
      • nuke_strikes — журнал ударов (для ответного удара и истории)
    Формулы — в utils.nuclear, применяет cogs/nuclear.py.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS nuke_state ("
            "country TEXT PRIMARY KEY, stage INTEGER DEFAULT 0, research TEXT DEFAULT '', "
            "research_until INTEGER DEFAULT 0, status TEXT DEFAULT 'member', heu REAL DEFAULT 0, "
            "cascades INTEGER DEFAULT 0, plants INTEGER DEFAULT 0, plant_until INTEGER DEFAULT 0, "
            "fueled INTEGER DEFAULT 0, historic INTEGER DEFAULT 0, status_at INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS nuke_designs ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, name TEXT, kind TEXT, "
            "yield_kt INTEGER, tested INTEGER DEFAULT 0, created_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS nuke_stock (design_id INTEGER PRIMARY KEY, count INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS nuke_queue ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, design_id INTEGER, count INTEGER, ready_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS nuke_tests ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, design_id INTEGER, status TEXT DEFAULT 'pending', "
            "created_at INTEGER, decided_by TEXT DEFAULT '', note TEXT DEFAULT '')")
        self._execute(
            "CREATE TABLE IF NOT EXISTS nuke_strikes ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, attacker TEXT, target TEXT, war_id INTEGER, design TEXT, "
            "yield_kt INTEGER, carrier TEXT, mode TEXT, intercepted INTEGER, ts INTEGER)")

    # ── состояние ──
    def ensure(self, country: str, historic: bool = False):
        if self._query_one("SELECT 1 FROM nuke_state WHERE country = ?", (country,)):
            return
        if historic:
            self._execute("INSERT INTO nuke_state (country, stage, status, historic) VALUES (?, 2, 'historic', 1)",
                          (country,))
        else:
            self._execute("INSERT INTO nuke_state (country) VALUES (?)", (country,))

    def get(self, country: str):
        return self._query_one("SELECT * FROM nuke_state WHERE country = ?", (country,))

    def all(self):
        return self._query_all("SELECT * FROM nuke_state")

    def update(self, country: str, **kw):
        if not kw:
            return
        cols = ", ".join(f"{k} = ?" for k in kw)
        self._execute(f"UPDATE nuke_state SET {cols} WHERE country = ?", (*kw.values(), country))

    def add_heu(self, country: str, kg: float):
        self._execute("UPDATE nuke_state SET heu = MAX(0, heu + ?) WHERE country = ?", (kg, country))

    # ── боеголовки ──
    def add_design(self, country: str, name: str, kind: str, yield_kt: int, now: int) -> int:
        self._execute("INSERT INTO nuke_designs (country, name, kind, yield_kt, created_at) VALUES (?, ?, ?, ?, ?)",
                      (country, name, kind, yield_kt, now))
        r = self._query_one("SELECT MAX(id) AS id FROM nuke_designs WHERE country = ?", (country,))
        return r["id"] if r else 0

    def design(self, did: int):
        return self._query_one("SELECT * FROM nuke_designs WHERE id = ?", (did,))

    def designs(self, country: str):
        return self._query_all("SELECT * FROM nuke_designs WHERE country = ? ORDER BY id", (country,))

    def design_name_taken(self, name: str) -> bool:
        return bool(self._query_one("SELECT 1 FROM nuke_designs WHERE LOWER(name) = LOWER(?)", (name,)))

    def set_tested(self, did: int):
        self._execute("UPDATE nuke_designs SET tested = 1 WHERE id = ?", (did,))

    def stock(self, did: int) -> int:
        r = self._query_one("SELECT count FROM nuke_stock WHERE design_id = ?", (did,))
        return int(r["count"] or 0) if r else 0

    def add_stock(self, did: int, n: int):
        self._execute("INSERT INTO nuke_stock (design_id, count) VALUES (?, MAX(0, ?)) "
                      "ON CONFLICT(design_id) DO UPDATE SET count = MAX(0, count + ?)", (did, n, n))

    def warheads(self, country: str) -> int:
        r = self._query_one(
            "SELECT COALESCE(SUM(s.count), 0) AS n FROM nuke_stock s JOIN nuke_designs d ON d.id = s.design_id "
            "WHERE d.country = ?", (country,))
        return int(r["n"] or 0) if r else 0

    def queue(self, country: str):
        return self._query_all("SELECT * FROM nuke_queue WHERE country = ? ORDER BY ready_at", (country,))

    def enqueue(self, country: str, did: int, count: int, ready_at: int):
        self._execute("INSERT INTO nuke_queue (country, design_id, count, ready_at) VALUES (?, ?, ?, ?)",
                      (country, did, count, ready_at))

    def queue_due(self, now: int):
        return self._query_all("SELECT * FROM nuke_queue WHERE ready_at <= ?", (now,))

    def queue_done(self, qid: int):
        self._execute("DELETE FROM nuke_queue WHERE id = ?", (qid,))

    # ── испытания ──
    def create_test(self, country: str, did: int, now: int) -> int:
        self._execute("INSERT INTO nuke_tests (country, design_id, status, created_at) VALUES (?, ?, 'pending', ?)",
                      (country, did, now))
        r = self._query_one("SELECT MAX(id) AS id FROM nuke_tests WHERE country = ?", (country,))
        return r["id"] if r else 0

    def test(self, tid: int):
        return self._query_one("SELECT * FROM nuke_tests WHERE id = ?", (tid,))

    def pending_test(self, country: str):
        return self._query_one("SELECT * FROM nuke_tests WHERE country = ? AND status = 'pending'", (country,))

    def decide_test(self, tid: int, status: str, by: str, note: str = ""):
        self._execute("UPDATE nuke_tests SET status = ?, decided_by = ?, note = ? WHERE id = ?",
                      (status, by, note, tid))

    # ── удары ──
    def log_strike(self, attacker: str, target: str, war_id: int, design: str, yield_kt: int,
                   carrier: str, mode: str, intercepted: bool, ts: int) -> int:
        self._execute(
            "INSERT INTO nuke_strikes (attacker, target, war_id, design, yield_kt, carrier, mode, intercepted, ts) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (attacker, target, war_id, design, yield_kt, carrier, mode, 1 if intercepted else 0, ts))
        r = self._query_one("SELECT MAX(id) AS id FROM nuke_strikes WHERE attacker = ?", (attacker,))
        return r["id"] if r else 0

    def strike(self, sid: int):
        return self._query_one("SELECT * FROM nuke_strikes WHERE id = ?", (sid,))

    def strikes_since(self, since_ts: int):
        return self._query_all("SELECT * FROM nuke_strikes WHERE ts >= ? ORDER BY ts DESC", (since_ts,))

    def clear_country(self, country: str):
        for did in [r["id"] for r in self.designs(country)]:
            self._execute("DELETE FROM nuke_stock WHERE design_id = ?", (did,))
        for sql in ("DELETE FROM nuke_designs WHERE country = ?", "DELETE FROM nuke_queue WHERE country = ?",
                    "DELETE FROM nuke_state WHERE country = ?",
                    "UPDATE nuke_tests SET status = 'void' WHERE country = ? AND status = 'pending'"):
            self._execute(sql, (country,))



class Un(BaseDB):
    """ООН: мировой журнал, резолюции, голоса, решения ИИ по ядерным испытаниям.

    Таблицы:
      • un_journal — крупные события мира (для ИИ-наблюдателя и фактов секретариата)
      • un_res     — резолюции (voting → adopted | rejected | inadmissible)
      • un_votes   — голоса стран (yes | no | abstain)
      • un_tests   — вердикт ИИ по испытанию, ждущий окна вето штаба
    Формулы и ИИ — в utils.un, применяет cogs/un.py.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS un_journal ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, actor TEXT, target TEXT, war_id INTEGER DEFAULT 0, "
            "text TEXT, ts INTEGER, seen INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS un_res ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, proposer TEXT, target TEXT, war_id INTEGER DEFAULT 0, "
            "title TEXT, text TEXT, severity INTEGER DEFAULT 2, npc_support REAL DEFAULT 50, p5 TEXT DEFAULT '{}', "
            "body TEXT, status TEXT DEFAULT 'voting', reason TEXT DEFAULT '', created_at INTEGER, deadline INTEGER, "
            "channel_id INTEGER DEFAULT 0, msg_id INTEGER DEFAULT 0, sc TEXT DEFAULT '[]')")
        self._execute(
            "CREATE TABLE IF NOT EXISTS un_votes (res_id INTEGER, country TEXT, vote TEXT, PRIMARY KEY (res_id, country))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS un_tests ("
            "test_id INTEGER PRIMARY KEY, approve INTEGER, statement TEXT, apply_at INTEGER, "
            "status TEXT DEFAULT 'pending')")

    # ── журнал ──
    def log(self, kind: str, actor: str, target: str, text: str, ts: int, war_id: int = 0):
        self._execute("INSERT INTO un_journal (kind, actor, target, war_id, text, ts) VALUES (?, ?, ?, ?, ?, ?)",
                      (kind, actor or "", target or "", int(war_id or 0), text[:300], ts))

    def unseen(self):
        return self._query_all("SELECT * FROM un_journal WHERE seen = 0 ORDER BY ts")

    def mark_seen(self, upto_id: int):
        self._execute("UPDATE un_journal SET seen = 1 WHERE id <= ?", (upto_id,))

    def facts_about(self, country: str, since_ts: int, limit: int = 12):
        return self._query_all(
            "SELECT * FROM un_journal WHERE (actor = ? OR target = ?) AND ts >= ? ORDER BY ts DESC LIMIT ?",
            (country, country, since_ts, limit))

    def prune(self, before_ts: int):
        self._execute("DELETE FROM un_journal WHERE ts < ?", (before_ts,))

    # ── резолюции ──
    def create(self, **kw) -> int:
        cols = ", ".join(kw)
        self._execute(f"INSERT INTO un_res ({cols}) VALUES ({', '.join('?' for _ in kw)})", tuple(kw.values()))
        r = self._query_one("SELECT MAX(id) AS id FROM un_res")
        return r["id"] if r else 0

    def get(self, rid_: int):
        return self._query_one("SELECT * FROM un_res WHERE id = ?", (rid_,))

    def update(self, rid_: int, **kw):
        cols = ", ".join(f"{k} = ?" for k in kw)
        self._execute(f"UPDATE un_res SET {cols} WHERE id = ?", (*kw.values(), rid_))

    def voting(self):
        return self._query_all("SELECT * FROM un_res WHERE status = 'voting' ORDER BY id")

    def recent(self, limit: int = 8):
        return self._query_all("SELECT * FROM un_res WHERE status != 'voting' ORDER BY id DESC LIMIT ?", (limit,))

    def open_like(self, kind: str, target: str):
        return self._query_one("SELECT * FROM un_res WHERE status = 'voting' AND kind = ? AND target = ?",
                               (kind, target))

    def cast(self, rid_: int, country: str, vote: str):
        self._execute("INSERT OR REPLACE INTO un_votes (res_id, country, vote) VALUES (?, ?, ?)", (rid_, country, vote))

    def votes(self, rid_: int) -> dict[str, str]:
        return {r["country"]: r["vote"] for r in self._query_all(
            "SELECT country, vote FROM un_votes WHERE res_id = ?", (rid_,))}

    # ── испытания ──
    def set_test(self, test_id: int, approve: bool, statement: str, apply_at: int):
        self._execute("INSERT OR REPLACE INTO un_tests (test_id, approve, statement, apply_at, status) "
                      "VALUES (?, ?, ?, ?, 'pending')", (test_id, 1 if approve else 0, statement, apply_at))

    def test(self, test_id: int):
        return self._query_one("SELECT * FROM un_tests WHERE test_id = ?", (test_id,))

    def tests_due(self, now: int):
        return self._query_all("SELECT * FROM un_tests WHERE status = 'pending' AND apply_at <= ?", (now,))

    def set_test_status(self, test_id: int, status: str):
        self._execute("UPDATE un_tests SET status = ? WHERE test_id = ?", (status, test_id))

    def clear_country(self, country: str):
        self._execute("DELETE FROM un_votes WHERE country = ?", (country,))
        self._execute("UPDATE un_res SET status = 'rejected', reason = 'страна вышла из игры' "
                      "WHERE status = 'voting' AND (target = ? OR proposer = ?)", (country, country))



class Npc(BaseDB):
    """ИИ-страны (незанятые государства, воюющие сами).

    Таблицы:
      • npc_state — сила армии (доля от базы 0..1), мораль, «исчезла» (полностью аннексирована)
      • npc_meta  — когда страна-игрок зарегистрирована (защита новичков от нападений ИИ)
      • npc_aggr  — войны, начатые ИИ (кулдауны агрессии)
    Армии и формулы — в utils.npc, война — в cogs/war.py, агрессия — в cogs/npc.py.
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS npc_state ("
            "country TEXT PRIMARY KEY, strength REAL DEFAULT 1.0, morale REAL DEFAULT 70, "
            "dissolved INTEGER DEFAULT 0, updated_at INTEGER DEFAULT 0)")
        self._execute("CREATE TABLE IF NOT EXISTS npc_meta (name TEXT PRIMARY KEY, registered_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS npc_aggr ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, npc TEXT, target TEXT, war_id INTEGER, ts INTEGER)")

    def state(self, country: str):
        r = self._query_one("SELECT * FROM npc_state WHERE country = ?", (country,))
        if r:
            return r
        self._execute("INSERT OR IGNORE INTO npc_state (country, updated_at) VALUES (?, 0)", (country,))
        return self._query_one("SELECT * FROM npc_state WHERE country = ?", (country,))

    def set(self, country: str, **kw):
        self.state(country)
        cols = ", ".join(f"{k} = ?" for k in kw)
        self._execute(f"UPDATE npc_state SET {cols} WHERE country = ?", (*kw.values(), country))

    def all(self):
        return self._query_all("SELECT * FROM npc_state")

    def is_dissolved(self, country: str) -> bool:
        r = self._query_one("SELECT dissolved FROM npc_state WHERE country = ?", (country,))
        return bool(r and r["dissolved"])

    # ── защита новичков ──
    def touch_registered(self, name: str, ts: int, force: bool = False):
        if force:
            self._execute("INSERT OR REPLACE INTO npc_meta (name, registered_at) VALUES (?, ?)", (name, ts))
        else:
            self._execute("INSERT OR IGNORE INTO npc_meta (name, registered_at) VALUES (?, ?)", (name, ts))

    def registered_at(self, name: str) -> int:
        r = self._query_one("SELECT registered_at FROM npc_meta WHERE name = ?", (name,))
        return int(r["registered_at"]) if r else 0

    # ── агрессия ИИ ──
    def log_aggr(self, npc: str, target: str, war_id: int, ts: int):
        self._execute("INSERT INTO npc_aggr (npc, target, war_id, ts) VALUES (?, ?, ?, ?)", (npc, target, war_id, ts))

    def last_aggr(self, target: str | None = None) -> int:
        if target:
            r = self._query_one("SELECT MAX(ts) AS t FROM npc_aggr WHERE target = ?", (target,))
        else:
            r = self._query_one("SELECT MAX(ts) AS t FROM npc_aggr")
        return int(r["t"] or 0) if r else 0

    def aggr_war_ids(self) -> list[int]:
        return [r["war_id"] for r in self._query_all("SELECT war_id FROM npc_aggr")]

    def clear_country(self, country: str):
        self._execute("DELETE FROM npc_meta WHERE name = ?", (country,))



class Legacy(BaseDB):
    """«Наследие»: провозглашённые исторические державы (одна на страну, каждая — один раз за игру).

    Таблица legacy: country, key (держава из utils.legacy.FORMABLES), title, formed_at, declined (упадок).
    """

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS legacy ("
            "country TEXT PRIMARY KEY, key TEXT UNIQUE, title TEXT, formed_at INTEGER, declined INTEGER DEFAULT 0)")

    def of(self, country: str):
        return self._query_one("SELECT * FROM legacy WHERE country = ?", (country,))

    def by_key(self, key: str):
        return self._query_one("SELECT * FROM legacy WHERE key = ?", (key,))

    def all(self):
        return self._query_all("SELECT * FROM legacy ORDER BY formed_at")

    def form(self, country: str, key: str, title: str, ts: int):
        self._execute("INSERT INTO legacy (country, key, title, formed_at, declined) VALUES (?, ?, ?, ?, 0)",
                      (country, key, title, ts))

    def set_declined(self, country: str, declined: bool):
        self._execute("UPDATE legacy SET declined = ? WHERE country = ?", (1 if declined else 0, country))

    def clear_country(self, country: str):
        """Страна снята — держава снова свободна для основания."""
        self._execute("DELETE FROM legacy WHERE country = ?", (country,))



class Pmc(BaseDB):
    """ЧВК — отдельные игроки (свои таблицы: механики государств их не видят).

    Таблицы:
      • pmc            — компания: название, тег, владелец, база, казна, бойцы, репутация
      • pmc_stock      — техника ЧВК: ИМЕННЫЕ модели стран (снимок модели + состояние new/worn)
      • pmc_contracts  — контракты (open → active → done | cancelled | failed | expired)
      • pmc_deals      — сделки со странами: sell (страна предлагает) / ask (ЧВК просит)
      • pmc_black      — лоты чёрного рынка (контрабанда и трофеи)
      • pmc_rel        — отношения ЧВК со странами (−100..100)
      • pmc_sanctions  — санкции стран / ООН и высылки (лишение лицензии)
      • pmc_tax        — налог страны базирования с контрактов (%)
    Формулы — в utils.pmc, логика — в cogs/pmc.py.
    """

    _EXTRA_COLS = {"last_move": "INTEGER DEFAULT 0", "done_count": "INTEGER DEFAULT 0"}

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS pmc ("
            "name TEXT PRIMARY KEY, tag TEXT, user INTEGER UNIQUE, base TEXT, money INTEGER DEFAULT 0, "
            "personnel INTEGER DEFAULT 0, reputation REAL DEFAULT 50, created_at INTEGER)")
        have = {r["name"] for r in self._query_all("PRAGMA table_info(pmc)")}
        for c, d in self._EXTRA_COLS.items():
            if c not in have:
                self._execute(f"ALTER TABLE pmc ADD COLUMN {c} {d}")
        self._execute(
            "CREATE TABLE IF NOT EXISTS pmc_stock (name TEXT, model TEXT, category TEXT, cls TEXT, origin TEXT, "
            "grade TEXT, count INTEGER DEFAULT 0, PRIMARY KEY (name, model, grade))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS pmc_contracts ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, client TEXT, kind TEXT, price INTEGER, war_id INTEGER DEFAULT 0, "
            "target TEXT DEFAULT '', pmc TEXT DEFAULT '', status TEXT DEFAULT 'open', created_at INTEGER, "
            "deadline INTEGER, ends_at INTEGER DEFAULT 0, channel_id INTEGER DEFAULT 0, msg_id INTEGER DEFAULT 0)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS pmc_deals ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, direction TEXT, country TEXT, pmc TEXT, equipment_id INTEGER, "
            "model TEXT, category TEXT, cls TEXT, count INTEGER, price INTEGER, status TEXT DEFAULT 'open', "
            "created_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS pmc_black ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, model TEXT, category TEXT, cls TEXT, origin TEXT, "
            "count INTEGER, price INTEGER, source TEXT, created_at INTEGER, expires_at INTEGER)")
        self._execute(
            "CREATE TABLE IF NOT EXISTS pmc_rel (pmc TEXT, country TEXT, value REAL DEFAULT 0, "
            "PRIMARY KEY (pmc, country))")
        self._execute(
            "CREATE TABLE IF NOT EXISTS pmc_sanctions (pmc TEXT, by TEXT, kind TEXT, until INTEGER DEFAULT 0, "
            "PRIMARY KEY (pmc, by, kind))")
        self._execute("CREATE TABLE IF NOT EXISTS pmc_tax (country TEXT PRIMARY KEY, rate INTEGER DEFAULT 0)")
        self._execute("CREATE TABLE IF NOT EXISTS pmc_meta (key TEXT PRIMARY KEY, value TEXT)")

    # ── служебное ──
    def meta(self, key: str) -> str | None:
        r = self._query_one("SELECT value FROM pmc_meta WHERE key = ?", (key,))
        return r["value"] if r else None

    def set_meta(self, key: str, value: str):
        self._execute("INSERT INTO pmc_meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = ?",
                      (key, value, value))

    def legacy_equipment_rows(self) -> int:
        """Старая абстрактная техника (до именных моделей) — для разовой миграции."""
        if not self._query_one("SELECT 1 FROM sqlite_master WHERE type='table' AND name='pmc_equipment'"):
            return 0
        r = self._query_one("SELECT COUNT(*) AS n FROM pmc_equipment")
        return int(r["n"]) if r else 0

    def drop_legacy_equipment(self):
        self._execute("DROP TABLE IF EXISTS pmc_equipment")

    # ── компании ──
    def create(self, name: str, tag: str, user: int, base: str, money: int, personnel: int, rep: float, now: int):
        self._execute("INSERT INTO pmc (name, tag, user, base, money, personnel, reputation, created_at) "
                      "VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (name, tag, user, base, money, personnel, rep, now))

    def get(self, name: str):
        return self._query_one("SELECT * FROM pmc WHERE name = ?", (name,))

    def find(self, text: str):
        """По названию или тегу (без учёта регистра)."""
        t = (text or "").strip().strip("[]")
        return self._query_one("SELECT * FROM pmc WHERE LOWER(name) = LOWER(?) OR UPPER(tag) = UPPER(?)", (t, t))

    def by_user(self, user: int):
        return self._query_one("SELECT * FROM pmc WHERE user = ?", (user,))

    def all(self):
        return self._query_all("SELECT * FROM pmc ORDER BY reputation DESC")

    def based_in(self, country: str):
        return self._query_all("SELECT * FROM pmc WHERE base = ? ORDER BY name", (country,))

    def name_taken(self, name: str, tag: str) -> bool:
        return bool(self._query_one("SELECT 1 FROM pmc WHERE LOWER(name) = LOWER(?) OR UPPER(tag) = UPPER(?)",
                                    (name, tag)))

    def add_money(self, name: str, delta: int):
        self._execute("UPDATE pmc SET money = MAX(0, money + ?) WHERE name = ?", (int(delta), name))

    def set(self, name: str, **kw):
        cols = ", ".join(f"{k} = ?" for k in kw)
        self._execute(f"UPDATE pmc SET {cols} WHERE name = ?", (*kw.values(), name))

    def add_rep(self, name: str, delta: float):
        self._execute("UPDATE pmc SET reputation = MAX(0, MIN(100, reputation + ?)) WHERE name = ?", (delta, name))

    def delete(self, name: str):
        for sql in ("DELETE FROM pmc WHERE name = ?", "DELETE FROM pmc_stock WHERE name = ?",
                    "DELETE FROM pmc_rel WHERE pmc = ?", "DELETE FROM pmc_sanctions WHERE pmc = ?"):
            self._execute(sql, (name,))
        self._execute("UPDATE pmc_deals SET status = 'cancelled' WHERE pmc = ? AND status = 'open'", (name,))

    # ── техника (именные модели) ──
    def stock(self, name: str):
        return self._query_all("SELECT * FROM pmc_stock WHERE name = ? AND count > 0 ORDER BY category, model",
                               (name,))

    def stock_total(self, name: str) -> int:
        r = self._query_one("SELECT COALESCE(SUM(count), 0) AS n FROM pmc_stock WHERE name = ?", (name,))
        return int(r["n"]) if r else 0

    def add_stock(self, name: str, model: str, category: str, cls: str, origin: str, grade: str, n: int):
        self._execute(
            "INSERT INTO pmc_stock (name, model, category, cls, origin, grade, count) VALUES (?, ?, ?, ?, ?, ?, MAX(0, ?)) "
            "ON CONFLICT(name, model, grade) DO UPDATE SET count = MAX(0, count + ?)",
            (name, model, category, cls, origin, grade, n, n))
        self._execute("DELETE FROM pmc_stock WHERE name = ? AND count <= 0", (name,))

    # ── контракты ──
    def create_contract(self, client: str, kind: str, price: int, war_id: int, target: str, now: int,
                        deadline: int) -> int:
        self._execute("INSERT INTO pmc_contracts (client, kind, price, war_id, target, status, created_at, deadline) "
                      "VALUES (?, ?, ?, ?, ?, 'open', ?, ?)", (client, kind, price, war_id, target, now, deadline))
        r = self._query_one("SELECT MAX(id) AS id FROM pmc_contracts WHERE client = ?", (client,))
        return r["id"] if r else 0

    def contract(self, cid_: int):
        return self._query_one("SELECT * FROM pmc_contracts WHERE id = ?", (cid_,))

    def update_contract(self, cid_: int, **kw):
        cols = ", ".join(f"{k} = ?" for k in kw)
        self._execute(f"UPDATE pmc_contracts SET {cols} WHERE id = ?", (*kw.values(), cid_))

    def claim_contract(self, cid_: int, pmc: str) -> bool:
        """Атомарно забирает ОТКРЫТЫЙ заказ (защита от двойного клика/двух ЧВК сразу)."""
        conn = get_connection()
        try:
            cur = conn.execute("UPDATE pmc_contracts SET status = 'active', pmc = ? WHERE id = ? AND status = 'open'",
                               (pmc, cid_))
            conn.commit()
            return cur.rowcount == 1
        finally:
            conn.close()

    def contracts(self, status: str):
        return self._query_all("SELECT * FROM pmc_contracts WHERE status = ? ORDER BY id DESC", (status,))

    def contracts_of_client(self, client: str):
        return self._query_all("SELECT * FROM pmc_contracts WHERE client = ? AND status IN ('open', 'active') "
                               "ORDER BY id DESC", (client,))

    def contracts_of_pmc(self, name: str):
        return self._query_all("SELECT * FROM pmc_contracts WHERE pmc = ? AND status = 'active' ORDER BY id DESC",
                               (name,))

    def secret_ops(self, name: str, since: int):
        """Спецоперации ЧВК (успешные и тайные) — для компромата."""
        return self._query_all("SELECT * FROM pmc_contracts WHERE pmc = ? AND kind = 'special' AND status = 'done' "
                               "AND created_at >= ?", (name, since))

    def clear_client(self, client: str):
        """Страна снята: открытые заказы закрываются (деньги уже стёрты вместе со страной)."""
        self._execute("UPDATE pmc_contracts SET status = 'cancelled' WHERE client = ? AND status IN ('open', 'active')",
                      (client,))

    def clear_country(self, country: str):
        """Страна снята с игры: заказы, сделки, отношения, санкции, высылки и налог — прочь."""
        self.clear_client(country)
        self._execute("UPDATE pmc_deals SET status = 'cancelled' WHERE country = ? AND status = 'open'", (country,))
        self._execute("DELETE FROM pmc_rel WHERE country = ?", (country,))
        self._execute("DELETE FROM pmc_sanctions WHERE by = ?", (country,))
        self._execute("DELETE FROM pmc_tax WHERE country = ?", (country,))

    # ── сделки со странами ──
    def create_deal(self, direction: str, country: str, pmc: str, eq, count: int, price: int, now: int) -> int:
        self._execute(
            "INSERT INTO pmc_deals (direction, country, pmc, equipment_id, model, category, cls, count, price, "
            "status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)",
            (direction, country, pmc, eq["id"], eq["name"], eq["category"], eq["cls"], count, price, now))
        r = self._query_one("SELECT MAX(id) AS id FROM pmc_deals")
        return r["id"] if r else 0

    def deal(self, did: int):
        return self._query_one("SELECT * FROM pmc_deals WHERE id = ?", (did,))

    def close_deal(self, did: int, status: str) -> bool:
        """Атомарно закрывает ОТКРЫТУЮ сделку. False — уже закрыта (двойной клик)."""
        conn = get_connection()
        try:
            cur = conn.execute("UPDATE pmc_deals SET status = ? WHERE id = ? AND status = 'open'", (status, did))
            conn.commit()
            return cur.rowcount == 1
        finally:
            conn.close()

    def deals_open(self, pmc: str | None = None, country: str | None = None):
        sql, args = "SELECT * FROM pmc_deals WHERE status = 'open'", []
        if pmc:
            sql += " AND pmc = ?"; args.append(pmc)
        if country:
            sql += " AND country = ?"; args.append(country)
        return self._query_all(sql + " ORDER BY id DESC", tuple(args))

    # ── чёрный рынок ──
    def add_lot(self, model: str, category: str, cls: str, origin: str, count: int, price: int, source: str,
                now: int, expires: int):
        self._execute("INSERT INTO pmc_black (model, category, cls, origin, count, price, source, created_at, "
                      "expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                      (model, category, cls, origin, count, price, source, now, expires))

    def lots(self, now: int):
        return self._query_all("SELECT * FROM pmc_black WHERE count > 0 AND expires_at > ? ORDER BY id DESC", (now,))

    def lot(self, lid: int):
        return self._query_one("SELECT * FROM pmc_black WHERE id = ?", (lid,))

    def take_lot(self, lid: int, n: int, now: int) -> bool:
        """Атомарно снимает n единиц с живого лота. False — не хватило / лот ушёл."""
        conn = get_connection()
        try:
            cur = conn.execute("UPDATE pmc_black SET count = count - ? WHERE id = ? AND count >= ? AND expires_at > ?",
                               (n, lid, n, now))
            conn.commit()
            return cur.rowcount == 1
        finally:
            conn.close()

    def prune_lots(self, now: int, keep: int):
        self._execute("DELETE FROM pmc_black WHERE count <= 0 OR expires_at <= ?", (now,))
        self._execute("DELETE FROM pmc_black WHERE id NOT IN (SELECT id FROM pmc_black ORDER BY id DESC LIMIT ?)",
                      (keep,))

    # ── отношения ──
    def rel(self, pmc: str, country: str) -> float:
        r = self._query_one("SELECT value FROM pmc_rel WHERE pmc = ? AND country = ?", (pmc, country))
        return float(r["value"]) if r else 0.0

    def add_rel(self, pmc: str, country: str, delta: float) -> float:
        v = max(-100.0, min(100.0, self.rel(pmc, country) + delta))
        self._execute("INSERT INTO pmc_rel (pmc, country, value) VALUES (?, ?, ?) "
                      "ON CONFLICT(pmc, country) DO UPDATE SET value = ?", (pmc, country, v, v))
        return v

    def rels(self, pmc: str):
        return self._query_all("SELECT country, value FROM pmc_rel WHERE pmc = ? AND value != 0 "
                               "ORDER BY ABS(value) DESC", (pmc,))

    # ── санкции и высылки ──
    def sanction(self, pmc: str, by: str, kind: str, until: int = 0):
        self._execute("INSERT INTO pmc_sanctions (pmc, by, kind, until) VALUES (?, ?, ?, ?) "
                      "ON CONFLICT(pmc, by, kind) DO UPDATE SET until = ?", (pmc, by, kind, until, until))

    def unsanction(self, pmc: str, by: str, kind: str):
        self._execute("DELETE FROM pmc_sanctions WHERE pmc = ? AND by = ? AND kind = ?", (pmc, by, kind))

    def has_sanction(self, pmc: str, by: str, kind: str, now: int) -> bool:
        return self._query_one("SELECT 1 FROM pmc_sanctions WHERE pmc = ? AND by = ? AND kind = ? "
                               "AND (until = 0 OR until > ?)", (pmc, by, kind, now)) is not None

    def sanctions_of(self, pmc: str, now: int):
        return self._query_all("SELECT * FROM pmc_sanctions WHERE pmc = ? AND (until = 0 OR until > ?)", (pmc, now))

    def sanctioned_by(self, country: str, kind: str = "sanction"):
        return [r["pmc"] for r in self._query_all("SELECT pmc FROM pmc_sanctions WHERE by = ? AND kind = ?",
                                                   (country, kind))]

    def un_until(self, pmc: str) -> int:
        r = self._query_one("SELECT until FROM pmc_sanctions WHERE pmc = ? AND by = 'ООН' AND kind = 'un'", (pmc,))
        return int(r["until"]) if r else 0

    def prune_sanctions(self, now: int):
        self._execute("DELETE FROM pmc_sanctions WHERE until != 0 AND until <= ?", (now,))

    # ── налог страны базирования ──
    def tax(self, country: str) -> int:
        r = self._query_one("SELECT rate FROM pmc_tax WHERE country = ?", (country,))
        return int(r["rate"]) if r else 0

    def set_tax(self, country: str, rate: int):
        self._execute("INSERT INTO pmc_tax (country, rate) VALUES (?, ?) ON CONFLICT(country) DO UPDATE SET rate = ?",
                      (country, rate, rate))


class ModWarns(BaseDB):
    """Предупреждения модерации (варны): кто, кому, за что, когда."""

    def _ensure_schema(self):
        self._execute(
            "CREATE TABLE IF NOT EXISTS mod_warns ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, user INTEGER, moderator INTEGER, reason TEXT, ts INTEGER)")

    def add(self, user: int, moderator: int, reason: str, ts: int) -> int:
        self._execute("INSERT INTO mod_warns (user, moderator, reason, ts) VALUES (?, ?, ?, ?)",
                      (user, moderator, reason[:300], ts))
        return self.count(user)

    def of(self, user: int):
        return self._query_all("SELECT * FROM mod_warns WHERE user = ? ORDER BY ts DESC", (user,))

    def count(self, user: int) -> int:
        r = self._query_one("SELECT COUNT(*) AS n FROM mod_warns WHERE user = ?", (user,))
        return int(r["n"]) if r else 0

    def clear(self, user: int) -> int:
        n = self.count(user)
        self._execute("DELETE FROM mod_warns WHERE user = ?", (user,))
        return n


# Список классов-менеджеров «участников» — используется get_all_managers().
USER_MANAGERS = [Countries, PMCs, Regions, Terrorists, Rebels]

__all_managers_extra__ = [Market, Buildings]  # для импорта из utils
