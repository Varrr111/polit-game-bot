"""
Глобальная ссылка на экземпляр бота.

Нужна компонентам, которым требуется доступ к боту без прямой передачи
(например, Logging для отправки в LOG_CHANNEL). Устанавливается в main.py
при старте через set_bot(bot).
"""

_bot = None


def set_bot(bot):
    global _bot
    _bot = bot


def get_bot():
    return _bot
