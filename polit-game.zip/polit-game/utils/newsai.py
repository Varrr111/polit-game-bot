"""
ИИ-анализ мировых новостей (gpt-4o-mini через aiohttp).

На вход — текст новости + состояние страны. На выход — СТРОГО JSON с умеренными,
реалистичными последствиями. Бот всё равно КЛАМПИТ значения на своей стороне
(analyze возвращает «сырой» разбор, clamp_effects приводит к безопасным рамкам),
поэтому «-100 счастья» невозможно даже при сбое модели.

Без OPENAI_API_KEY модуль молча не работает (available() == False) — система
новостей при этом функционирует, просто без ИИ-последствий.
"""

from __future__ import annotations

import json
import logging

import aiohttp

import config
from .resources import RESOURCE_SLUG
from .aitext import clean

log = logging.getLogger("newsai")

VALID_RESOURCES = list(RESOURCE_SLUG.keys())

# ── Жёсткие лимиты последствий (анти-хаос) ───────────────────────────────────
CAP_MONEY_PCT = 10.0      # ±% от баланса
CAP_HAPPINESS = 8         # ±пункты
CAP_STABILITY = 8         # ±пункты
CAP_POP_PCT = 2.0         # ±% населения
CAP_RES_ABS = 500         # ±ед. на ресурс
CAP_MULT_LO, CAP_MULT_HI = 0.85, 1.15   # множитель дохода
CAP_MULT_HOURS = 72       # макс. срок эффекта, ч

CATEGORIES = ["economy", "military", "diplomacy", "social", "nature", "science", "trade"]

CAP_RELATION = 6          # ±отношения с упомянутой страной
CAP_REPUTATION = 4        # ±репутация автора
LOW_CREDIBILITY = 40      # ниже — новость не подкреплена ресурсами: положительные эффекты обнуляются

_SYSTEM = (
    "Ты — аналитический движок мира военно-политической игры по реальному миру. Тебе дают НОВОСТЬ "
    "от страны-игрока и ПОЛНОЕ ДОСЬЕ из базы игры: казна и доход, ресурсы, заводы, развитие, армия и "
    "техника, строй, войны, санкции, дипломатия, альянсы, атом. Плюс краткие досье упомянутых стран. "
    "Оцени реалистичные последствия и верни СТРОГО JSON.\n\n"
    "Как думать:\n"
    "1) ПРОВЕРКА РЕАЛЬНОСТИ. Сверь заявления новости с досье. Нельзя запустить ракеты без ракет, провести "
    "парад без армии, построить АЭС без атомной программы, продать нефть без нефти, потратить больше казны. "
    "credibility 0..100: 90+ всё подкреплено досье; 40-70 преувеличено; ниже 40 — пустые заявления "
    "(тогда последствия нейтральные или отрицательные: мир не верит, доверие падает).\n"
    "2) СВЯЗЬ С МЕХАНИКАМИ. Опирайся на досье: сильная армия делает угрозы весомыми, санкции и война давят на "
    "экономику, членство в блоках и договоры усиливают поддержку союзников, противоречие договорам бьёт по "
    "стабильности, ресурсы определяют, что реально может страна. Не выдумывай того, чего нет в досье.\n"
    "3) МАСШТАБ. Мелкое событие — почти ноль. Крупное — заметно, но не катастрофично. Меняй только то, что "
    "логично следует из новости.\n"
    "4) ДРУГИЕ СТРАНЫ. relations — сдвиг отношений автора с УПОМЯНУТЫМИ странами из досье (только они), "
    "[-6..6]: угрозы и обвинения портят, помощь и сделки улучшают.\n\n"
    "Рамки: money_pct [-10..10], happiness [-8..8], stability [-8..8], population_pct [-2..2], каждый ресурс "
    "[-500..500], income_mult.value [0.85..1.15], hours [1..72], reputation [-4..4].\n"
    "Ресурсы — только из списка: " + ", ".join(VALID_RESOURCES) + ".\n"
    "category — одна из: " + ", ".join(CATEGORIES) + ".\n"
    "Пиши нейтрально, как мировая аналитика, на русском, без фантастики. Пиши строго БЕЗ эмодзи и "
    "пиктограмм.\n\n"
    "Формат ответа:\n"
    "{\n"
    '  "headline": "заголовок последствий до 80 символов",\n'
    '  "analysis": "2-4 предложения разбора со ссылкой на реальные возможности страны",\n'
    '  "credibility": 85,\n'
    '  "reality": "1 предложение: что подкреплено, а что нет",\n'
    '  "category": "одна из категорий",\n'
    '  "effects": {"money_pct": 0, "happiness": 0, "stability": 0, "population_pct": 0, '
    '"resources": {"нефть": 0}, "income_mult": {"value": 1.0, "hours": 0}, "reputation": 0},\n'
    '  "relations": {"Страна": 0}\n'
    "}\n"
    "Любое поле effects/relations можно опустить, если изменений нет."
)


def available() -> bool:
    return bool(config.OPENAI_API_KEY)


def _clampf(x, lo, hi, default=0.0):
    try:
        return max(lo, min(hi, float(x)))
    except (TypeError, ValueError):
        return default


def clamp_effects(effects: dict) -> dict:
    """Приводит эффекты модели к безопасным рамкам. Возвращает чистый словарь."""
    effects = effects or {}
    out: dict = {}
    mp = _clampf(effects.get("money_pct", 0), -CAP_MONEY_PCT, CAP_MONEY_PCT)
    if mp:
        out["money_pct"] = round(mp, 2)
    hp = _clampf(effects.get("happiness", 0), -CAP_HAPPINESS, CAP_HAPPINESS)
    if hp:
        out["happiness"] = int(round(hp))
    st = _clampf(effects.get("stability", 0), -CAP_STABILITY, CAP_STABILITY)
    if st:
        out["stability"] = int(round(st))
    pp = _clampf(effects.get("population_pct", 0), -CAP_POP_PCT, CAP_POP_PCT)
    if pp:
        out["population_pct"] = round(pp, 3)
    res = {}
    for name, amt in (effects.get("resources") or {}).items():
        if name in VALID_RESOURCES:
            a = int(_clampf(amt, -CAP_RES_ABS, CAP_RES_ABS))
            if a:
                res[name] = a
    if res:
        out["resources"] = res
    im = effects.get("income_mult") or {}
    val = _clampf(im.get("value", 1.0), CAP_MULT_LO, CAP_MULT_HI, 1.0)
    hours = int(_clampf(im.get("hours", 0), 0, CAP_MULT_HOURS))
    if hours > 0 and abs(val - 1.0) > 0.001:
        out["income_mult"] = {"value": round(val, 3), "hours": hours}
    rp = _clampf(effects.get("reputation", 0), -CAP_REPUTATION, CAP_REPUTATION)
    if rp:
        out["reputation"] = int(round(rp))
    return out


def clamp_relations(relations: dict, allowed: list[str]) -> dict[str, int]:
    """Сдвиги отношений только с реально упомянутыми странами, в рамках ±CAP_RELATION."""
    out = {}
    for name, d in (relations or {}).items():
        if name in allowed:
            v = int(round(_clampf(d, -CAP_RELATION, CAP_RELATION)))
            if v:
                out[name] = v
    return out


def strip_gains(eff: dict) -> dict:
    """Новость не подкреплена досье (низкая достоверность) — все ПОЛОЖИТЕЛЬНЫЕ эффекты снимаются."""
    out = {}
    for k, v in eff.items():
        if k == "resources":
            neg = {r: a for r, a in v.items() if a < 0}
            if neg:
                out[k] = neg
        elif k == "income_mult":
            if v["value"] < 1.0:
                out[k] = v
        elif isinstance(v, (int, float)) and v < 0:
            out[k] = v
    return out


async def analyze(news_text: str, dossier: str, others: str = "", timeout: float = 30.0) -> dict | None:
    """Запрос к gpt-4o-mini. → {headline, analysis, credibility, reality, category, effects(сырые),
    relations(сырые)} или None при ошибке/отсутствии ключа. Текст уже очищен от эмодзи."""
    if not available():
        return None
    user = (f"НОВОСТЬ:\n{news_text[:1800]}\n\nДОСЬЕ АВТОРА:\n{dossier[:2600]}"
            + (f"\n\nУПОМЯНУТЫЕ СТРАНЫ:\n{others[:1200]}" if others else ""))
    payload = {
        "model": config.OPENAI_MODEL,
        "temperature": 0.5,
        "max_tokens": 520,
        "response_format": {"type": "json_object"},
        "messages": [{"role": "system", "content": _SYSTEM}, {"role": "user", "content": user}],
    }
    headers = {"Authorization": f"Bearer {config.OPENAI_API_KEY}", "Content-Type": "application/json"}
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.post("https://api.openai.com/v1/chat/completions",
                                 json=payload, headers=headers,
                                 timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                if r.status != 200:
                    log.warning("OpenAI %s: %s", r.status, (await r.text())[:300])
                    return None
                data = await r.json()
        parsed = json.loads(data["choices"][0]["message"]["content"])
    except Exception:
        log.exception("Ошибка запроса/парсинга ИИ")
        return None
    if not isinstance(parsed, dict):
        return None
    cat = parsed.get("category")
    parsed["category"] = cat if cat in CATEGORIES else "social"
    parsed["headline"] = clean(parsed.get("headline") or "Последствия")[:120]
    parsed["analysis"] = clean(parsed.get("analysis"))[:900]
    parsed["reality"] = clean(parsed.get("reality"))[:300]
    parsed["credibility"] = int(_clampf(parsed.get("credibility", 70), 0, 100, 70))
    parsed["effects"] = parsed.get("effects") or {}
    parsed["relations"] = parsed.get("relations") or {}
    return parsed
