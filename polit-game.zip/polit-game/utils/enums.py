"""Перечисления игры."""

from enum import Enum


class InfrastructureType(Enum):
    """Типы энергетической инфраструктуры."""
    CHP = "chp"        # ТЭС/ТЭЦ
    ATOMIC = "atomic"  # АЭС
    HPS1 = "hps1"      # Микро ГЭС
    HPS2 = "hps2"      # Малая ГЭС
    HPS3 = "hps3"      # Средняя ГЭС
    HPS4 = "hps4"      # Большая ГЭС
