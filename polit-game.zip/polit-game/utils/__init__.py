"""
Пакет utils — единая точка входа для когов.

cogs/economy.py делает `from utils import *`, поэтому здесь реэкспортируется
весь публичный API: конфиг, цвета, константы, объекты, менеджеры, хелперы,
декораторы, enum. Это «фасад» всего фундамента.
"""

# config как модуль (economy.py обращается к config.COUNTIES_GDP)
import config

# Всё из конфига (цвета, ID, CURRENCY, TZ, параметры экономики)
from config import *

from .enums import InfrastructureType
from .objects import (
    BaseObject,
    CountryObject, PMCObject, RegionObject, TerroristObject, RebelObject,
    CompanyObject, InfrastructureObject, InventoryObject,
)
from .constants import (
    LEVELS_CONFIG,
    MINING_SPECIALIZATIONS, PRODUCTION_RATES, ALL_SPECIALIZATIONS,
    COMPANY_LIMITIONS, CREATION_COSTS,
    INFRASTRUCTURE_ELECTRICITY, REGISTRATION_CONFIG,
)
from .database import UserDB, BaseDB
from .managers import (
    Countries, PMCs, Regions, Terrorists, Rebels,
    Items, Settings, Wars, Companies,
    Infrastructure, BuildNews, Cooldown, Logging, Buildings, Market, CountryUpgrades, Allocation,
    Equipment, Politics, Army, Effects, MapState, News, ServerConfig, Spy, CommandPerms,
    Ultimatums, Sanctions, Guard, War, Trade, Diplomacy, Alliances, Nuclear, Un, Npc, Legacy, Pmc, ModWarns,
    USER_MANAGERS,
)
from .helpers import (
    int_format, string_to_number,
    get_all_managers, get_object, get_object_by_user,
    update_money, calculate_income, find_user, command_permissions_check,
)
from .decorators import interaction_error_handler
from .upgrades import country_income, country_mining_multiplier, country_gdp
from .perms import is_staff, has_command_access
