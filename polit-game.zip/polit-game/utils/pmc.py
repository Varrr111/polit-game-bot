"""
ЧВК — частные военные компании как отдельные игроки. Без БД и disnake.

ЧВК не государство: у неё нет территории, налогов и дипломатии. Деньги — из КОНТРАКТОВ с
государствами и небольших «частных заказов» (пассивный доход по уровню репутации).

ТЕХНИКА — только настоящие ИМЕННЫЕ модели стран (никаких абстрактных «ОБТ из магазина бота»):
  • сделки со странами — страна продаёт модели из своего арсенала (деньги получает страна),
    или ЧВК сама просит продать; техника новая (состояние 100%);
  • чёрный рынок — контрабанда (раз в сутки партии случайных моделей стран) и трофеи войн
    (часть техники, потерянной в боях); дешевле, но б/у — в бою слабее.
Флота, стратегической авиации и ракет ЧВК не держат.

ГОСУДАРСТВА ДЕРЖАТ ЧВК В РУКАХ:
  • лицензия — страна базирования (игрок) берёт налог 0–30% с контрактов и может выгнать ЧВК
    (без лицензии контракты брать нельзя, пока не переедет);
  • отношения ЧВК со странами (≤ HOSTILE — страна не нанимает и не продаёт);
  • санкции страны (её контракты и оружие закрыты) и санкции ООН (никаких покупок, доход ×0.5);
  • разведка против ЧВК — досье, диверсия на базе, переманивание бойцов, компромат.

Все числа — ЗАГЛУШКИ под тюнинг.
"""

from __future__ import annotations

from .equipment import EQUIP_CATEGORIES, class_mult

H = 3600
DAY = 24 * H

START_MONEY = 30_000_000
START_PERSONNEL = 300
NAME_MIN, NAME_MAX = 3, 24
TAG_MIN, TAG_MAX = 2, 5

HIRE_COST = 40_000              # $ за бойца
HIRE_MAX = 2_000                # за раз
PERSONNEL_UPKEEP_K = 250_000    # $/ч за 1000 бойцов
EQUIP_UPKEEP = 0.0015           # доля ориентировочной цены техники в час

READINESS = 1.0                 # ЧВК воюет всем, что есть
INF_K = 1.2                     # профессиональная пехота сильнее призывной

# категории техники, которые может иметь ЧВК (без флота, стратегической авиации и ракет)
ALLOWED: list[str] = ["mbt", "light_tank", "ifv", "apc", "mrap", "recon_veh", "eng_veh", "spg", "towed_arty",
                      "mlrs", "atgm", "aa_gun", "sam_short", "attack_heli", "transp_heli", "uav_recon",
                      "uav_combat", "strike"]

# состояние техники: ключ → (подпись, боевой множитель)
GRADES = {"new": ("новая", 1.0), "worn": ("б/у", 0.75)}


def grade_label(g: str) -> str:
    return GRADES.get(g, (g, 1.0))[0]


def grade_mult(g: str) -> float:
    return GRADES.get(g, (g, 1.0))[1]


def ref_price(cat: str, cls: str) -> int:
    """Ориентировочная цена единицы модели (категория × класс)."""
    if cat not in EQUIP_CATEGORIES:
        return 0
    return int(EQUIP_CATEGORIES[cat][4] * class_mult(cls))


def unit_upkeep(cat: str, cls: str) -> int:
    return int(ref_price(cat, cls) * EQUIP_UPKEEP)


# ── сделки со странами ──
DEAL_MIN_K = 0.25               # цена за единицу не ниже 25% ориентира (без «подарков» в обход)
DEAL_MAX_UNITS = 200            # за одну сделку
DEAL_TTL = 48 * H
DEALS_OPEN_MAX = 10             # открытых предложений на одну сторону

# ── чёрный рынок ──
CONTRABAND_EVERY = DAY
CONTRABAND_LOTS = (3, 5)
CONTRABAND_PRICE_K = 0.60
TROPHY_SHARE = 0.08             # доля потерянной в бою техники, уходящая на чёрный рынок
TROPHY_PRICE_K = 0.45
LOT_TTL = 72 * H
POOL_MAX = 30                   # лотов одновременно


def contraband_count(cat: str, cls: str, rnd) -> int:
    p = ref_price(cat, cls)
    if p >= 3_000_000:
        return rnd.randint(1, 3)
    if p >= 1_500_000:
        return rnd.randint(2, 6)
    return rnd.randint(3, 10)


# ── репутация ──
REP_START = 50.0
TIERS = [(70, "elite", "Элита", 1.3), (40, "pro", "Профессионалы", 1.15), (-1, "rookie", "Новички", 1.0)]
SECURITY = {"rookie": 1, "pro": 2, "elite": 3}      # «контрразведка» ЧВК против операций стран
PASSIVE = {"rookie": 40_000, "pro": 120_000, "elite": 300_000}   # частные заказы, $/ч


def tier(rep: float) -> tuple[str, str, float]:
    """→ (ключ, подпись, множитель качества)."""
    for lo, key, label, q in TIERS:
        if rep >= lo:
            return key, label, q
    return TIERS[-1][1:]


REP_DONE = 5          # выполненный контракт
REP_WAR_WIN = 10      # заказчик выиграл войну
REP_WITHDRAW = -20    # ушёл с войны / сорвал контракт
REP_EXPOSED = -15     # спецоперация раскрыта
REP_KOMPROMAT = -15   # компромат о тайных операциях

# ── отношения ЧВК ↔ страны (−100..100) ──
HOSTILE = -50         # ниже — страна не нанимает ЧВК и не продаёт ей оружие
REL_CLIENT_DONE = 6
REL_WAR_ENEMY = -10
REL_SPECIAL_EXPOSED = -25
REL_KOMPROMAT = -15
REL_SANCTION = -20
REL_SALE = 3
REL_SPY_EXPOSED = -15  # страна попалась на операции против ЧВК

# ── лицензия и база ──
TAX_STEPS = [0, 5, 10, 15, 20, 25, 30]
TAX_MAX = 30
RELOCATE_COST = 3_000_000
RELOCATE_CD = 48 * H

# ── санкции ──
UN_INCOME_MULT = 0.5

# ── контракты ──
# key → подпись, иконка, мин. бойцов, мин. репутация, нужна война/цель, длительность (ч), описание
CONTRACTS: dict[str, dict] = {
    "war": {"label": "Участие в войне", "icon": "war", "min_pers": 300, "min_rep": 0, "needs": "war",
            "hours": 7 * 24, "min_price": 20_000_000,
            "desc": "ЧВК вступает в войну на стороне заказчика: её силы и потери — настоящие."},
    "guard": {"label": "Охрана и контрразведка", "icon": "guard", "min_pers": 100, "min_rep": 0, "needs": None,
              "hours": 72, "min_price": 5_000_000,
              "desc": "+2 к контрразведке заказчика на 72ч (охрана объектов и ядерных площадок)."},
    "riot": {"label": "Подавление беспорядков", "icon": "riot", "min_pers": 200, "min_rep": 0, "needs": None,
             "hours": 0, "min_price": 8_000_000,
             "desc": "Сразу: +стабильность и −оппозиция (по числу бойцов), но −счастье."},
    "training": {"label": "Обучение армии", "icon": "academy", "min_pers": 300, "min_rep": 40, "needs": None,
                 "hours": 72, "min_price": 12_000_000,
                 "desc": "+10% к силе армии заказчика на 72ч (инструкторы ЧВК)."},
    "special": {"label": "Спецоперация", "icon": "pmc_target", "min_pers": 100, "min_rep": 40, "needs": "target",
                "hours": 0, "min_price": 12_000_000,
                "desc": "Дестабилизация и саботаж экономики цели. Провал — ЧВК раскрыта, заказчик может всплыть."},
}
CONTRACT_KEYS = list(CONTRACTS.keys())
CONTRACT_TTL = 48 * H           # сколько висит открытый заказ
GUARD_COUNTER = 2
TRAIN_MULT = 1.10
RIOT_STAB_PER_100 = 1.0         # стабильность за 100 бойцов
RIOT_STAB_MAX = 15
RIOT_HAPPY = -4
RIOT_OPPOSITION = -10
SPECIAL_BASE = 50               # % успеха
SPECIAL_PER_TIER = {"rookie": 0, "pro": 12, "elite": 25}
SPECIAL_CLIENT_TRACE = 0.35     # шанс, что при провале всплывёт заказчик
SPECIAL_STAB = (5, 12)
SPECIAL_ECO = (0.88, 48)        # множитель дохода цели и часы
WITHDRAW_REFUND = 0.5           # доля оплаты, возвращаемая заказчику при уходе ЧВК с войны


def contract_label(key: str) -> str:
    return CONTRACTS[key]["label"] if key in CONTRACTS else key


# ── разведка государств против ЧВК ──
SPY_OPS: dict[str, dict] = {
    "dossier": {"label": "Досье на ЧВК", "icon": "recon", "cost": 20_000_000,
                "desc": "Казна, бойцы, вся техника по моделям, контракты и связи компании."},
    "sabotage": {"label": "Диверсия на базе", "icon": "sabotage", "cost": 60_000_000,
                 "desc": "Уничтожает часть техники ЧВК на базе."},
    "poach": {"label": "Переманить бойцов", "icon": "pmc_hire", "cost": 50_000_000,
              "desc": "Часть бойцов ЧВК переходит в резерв вашей армии."},
    "kompromat": {"label": "Компромат", "icon": "exposed", "cost": 80_000_000,
                  "desc": "Вскрывает тайные спецоперации ЧВК за 14 дней: удар по репутации ЧВК и заказчиков."},
}
SPY_KEYS = list(SPY_OPS.keys())
SABOTAGE_FRAC = (0.15, 0.30)
POACH_FRAC = (0.10, 0.20)
KOMPROMAT_DAYS = 14
KOMPROMAT_CLIENT_REP = -5
PMC_SPY_CD = 6 * H              # пауза между операциями одной страны против ЧВК
